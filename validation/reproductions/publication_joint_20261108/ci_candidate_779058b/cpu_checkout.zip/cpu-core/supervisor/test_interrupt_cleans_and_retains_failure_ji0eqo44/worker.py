from pathlib import Path
import time
Path('ready').write_text('ready')
time.sleep(60)
