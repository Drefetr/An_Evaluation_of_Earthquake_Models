"""ctypes adapter to C++ dynamic-productivity likelihood and analytic gradient."""
from __future__ import annotations
import ctypes as ct
import hashlib
import json
from pathlib import Path
import numpy as np

MODELS={"E0":(0,4),"E0_fixed":(0,4),"E0_free":(0,4),
        "I0":(1,5),"I0_fixed":(1,5),"I0_free":(1,5)}
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def model_bounds(model,*,fixed_d=None,fixed_r=None,r_bounds=(0.,.95)):
    bounds=[(-12.,0.),(-2.,2.),(0.,.98)]+([(0.,3.)] if model.startswith("I0") else [])+[tuple(r_bounds)]
    if fixed_d is not None:bounds[1]=(float(fixed_d),float(fixed_d))
    if fixed_r is not None:bounds[-1]=(float(fixed_r),float(fixed_r))
    return bounds
def library(path=None):
    path=Path(path or Path(__file__).with_name("objective.dll")).resolve();lib=ct.CDLL(str(path));pd=ct.POINTER(ct.c_double)
    lib.ps_create.argtypes=[ct.c_int,ct.c_int,ct.c_int]+[pd]*10;lib.ps_create.restype=ct.c_void_p
    lib.ps_eval.argtypes=[ct.c_void_p,ct.c_int,pd,ct.c_int,pd,pd];lib.ps_eval.restype=ct.c_int
    lib.ps_destroy.argtypes=[ct.c_void_p];lib.ps_destroy.restype=None
    lib.ps_last_error.argtypes=[];lib.ps_last_error.restype=ct.c_char_p
    return lib,path
class Objective:
    def __init__(self,path,dll_path=None):
        self.path=Path(path).resolve();self.handle=None;self.lib,self.dll_path=library(dll_path)
        names=("event_x","event_g","event_excess","parent_excess","event_parent_kernel","parent_exposure","quad_x","quad_w","quad_g","parent_time","event_time","quad_time")
        with np.load(self.path,allow_pickle=False) as saved:
            self.metadata=json.loads(str(saved["metadata_json"].item()))
            self.arrays={}
            for name in names:
                value=saved[name]
                if value.dtype!=np.dtype("float64"):raise ValueError("geometry must use float64: "+name)
                self.arrays[name]=np.ascontiguousarray(value)
        self.ne=len(self.arrays["event_x"]);self.np=len(self.arrays["parent_excess"]);self.nq=len(self.arrays["quad_x"])
        for name,value in self.arrays.items():
            shape=(self.ne,self.np) if name=="event_parent_kernel" else (self.np,) if name.startswith("parent_") else (self.nq,) if name.startswith("quad_") else (self.ne,)
            if value.shape!=shape or not np.isfinite(value).all():raise ValueError("invalid geometry array "+name)
        if np.any(np.diff(self.arrays["parent_time"])<=0) or np.any(np.diff(self.arrays["event_time"])<=0):raise ValueError("nonchronological geometry")
        mask=self.arrays["parent_time"][None,:]>=self.arrays["event_time"][:,None]
        if np.any(self.arrays["event_parent_kernel"][mask]!=0):raise ValueError("nonzero future/self kernel")
        m=self.metadata
        if m["geometry_version"]!=1 or m["r_independent"] is not True or m["n_events"]!=self.ne or m["n_parents"]!=self.np:raise ValueError("geometry metadata differs from arrays")
        meta=np.array([m["start"],m["end"],m["T0"],m["beta"]],dtype=np.float64);pd=ct.POINTER(ct.c_double)
        ptr=lambda name:self.arrays[name].ctypes.data_as(pd)
        handle=self.lib.ps_create(self.ne,self.np,self.nq,*[ptr(n) for n in names[:9]],meta.ctypes.data_as(pd))
        if not handle:raise ValueError(self.last_error())
        self.handle=handle;self.identity={"feature_path":str(self.path),"feature_sha256":digest(self.path),"dll_path":str(self.dll_path),"dll_sha256":digest(self.dll_path),"metadata":m,"n_events":self.ne,"n_parents":self.np,"quadrature_nodes":self.nq}
    def last_error(self):
        value=self.lib.ps_last_error();return value.decode("utf-8",errors="replace") if value else "compiled objective failed"
    def evaluate(self,model,pars):
        if self.handle is None:raise RuntimeError("Objective closed")
        mid,dim=MODELS[model];pars=np.ascontiguousarray(pars,dtype=np.float64)
        if pars.shape!=(dim,) or not np.isfinite(pars).all():raise ValueError("wrong parameter vector")
        out=np.empty(6);grad=np.empty(dim);pd=ct.POINTER(ct.c_double)
        if self.lib.ps_eval(self.handle,mid,pars.ctypes.data_as(pd),dim,out.ctypes.data_as(pd),grad.ctypes.data_as(pd)):raise FloatingPointError(self.last_error())
        if not np.isfinite(out).all() or not np.isfinite(grad).all():raise FloatingPointError("nonfinite compiled result")
        return dict(joint_nll=float(out[0]),timing_logscore=float(out[1]),mark_logscore=float(out[2]),integrated_intensity=float(out[3]),rho_raw=float(out[4]),expected_branching_radius=float(out[5]),gradient=grad.copy())
    def parameter_bounds(self,model,**kwargs):return model_bounds(model,**kwargs)
    def close(self):
        if self.handle is not None:self.lib.ps_destroy(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
