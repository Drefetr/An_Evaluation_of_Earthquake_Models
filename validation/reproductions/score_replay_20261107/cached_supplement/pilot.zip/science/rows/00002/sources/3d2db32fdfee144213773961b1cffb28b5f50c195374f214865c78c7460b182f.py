"""Small Python interface to the compiled fixed-feature numerical objective.

Geometry, finite-mixture kernels and quadrature are exported by the preserved
PredictiveHistory adapter. Repeated objective/gradient evaluation stays in C++.
"""
from __future__ import annotations

import ctypes as ct
import hashlib
import json
import math
from pathlib import Path

import numpy as np


MODELS={"E0":(0,3),"I0":(1,4),"E1":(2,5),"E1_h0":(2,5)}
BOUNDS={"E0":[(-12.,0.),(-2.,2.),(0.,.98)],
        "I0":[(-12.,0.),(-2.,2.),(0.,.98),(0.,3.)],
        "E1":[(-12.,0.),(-2.,2.),(0.,.98),(-.95,.95),(-1.,1.)]}


def model_bounds(model,metadata,fixed_d=None):
    canonical="E1" if model=="E1_h0" else model
    bounds=list(BOUNDS[canonical])
    if canonical=="E1":
        p0=-math.expm1(-metadata["beta"]*metadata["excess_cut"])
        p1=math.exp(-metadata["beta"]*metadata["excess_cut"])
        bounds[3]=(-.95*min(p0/p1,p1/p0),.95)
    if model=="E1_h0":bounds[3]=(0.,0.)
    if fixed_d is not None:bounds[1]=(float(fixed_d),float(fixed_d))
    return bounds


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def library(path=None):
    path=Path(path or Path(__file__).with_name("objective.dll")).resolve()
    lib=ct.CDLL(str(path))
    pd=ct.POINTER(ct.c_double);pi=ct.POINTER(ct.c_int)
    lib.mh_create.argtypes=[ct.c_int,ct.c_int,pd,pd,pd,pd,pi,pd,pd,pd,pd,pd]
    lib.mh_create.restype=ct.c_void_p
    lib.mh_eval.argtypes=[ct.c_void_p,ct.c_int,pd,ct.c_int,pd,pd]
    lib.mh_eval.restype=ct.c_int
    lib.mh_destroy.argtypes=[ct.c_void_p];lib.mh_destroy.restype=None
    lib.mh_last_error.argtypes=[];lib.mh_last_error.restype=ct.c_char_p
    return lib,path


class Objective:
    def __init__(self,cache_path,dll_path=None):
        self.path=Path(cache_path).resolve();self.lib,self.dll_path=library(dll_path)
        self.handle=None
        with np.load(self.path,allow_pickle=False) as saved:
            self.metadata=json.loads(str(saved["metadata_json"].item()))
            self.arrays={name:np.ascontiguousarray(saved[name],dtype=np.float64)
                for name in ("event_x","event_g","event_H0","event_H1","event_excess",
                             "quad_x","quad_w","quad_g","K")}
            classes=np.asarray(saved["event_class"])
            if classes.dtype!=np.dtype("int32"):
                raise ValueError("event_class must be int32")
            self.classes=np.ascontiguousarray(classes,dtype=np.int32)
        self.ne=len(self.arrays["event_x"]);self.nq=len(self.arrays["quad_x"])
        for name,arr in self.arrays.items():
            expected=2 if name=="K" else self.nq if name.startswith("quad_") else self.ne
            if arr.ndim!=1 or len(arr)!=expected or not np.isfinite(arr).all():
                raise ValueError("Invalid cache array "+name)
        if self.classes.shape!=(self.ne,) or not np.isin(self.classes,[0,1]).all():
            raise ValueError("Invalid event classes")
        m=self.metadata
        meta=np.array([*self.arrays["K"],m["start"],m["end"],m["T0"],
                       m["beta"],m["productivity_ratio"],m["excess_cut"]],dtype=np.float64)
        pd=ct.POINTER(ct.c_double)
        def ptr(name):return self.arrays[name].ctypes.data_as(pd)
        handle=self.lib.mh_create(self.ne,self.nq,ptr("event_x"),ptr("event_g"),
            ptr("event_H0"),ptr("event_H1"),self.classes.ctypes.data_as(ct.POINTER(ct.c_int)),
            ptr("event_excess"),ptr("quad_x"),ptr("quad_w"),ptr("quad_g"),meta.ctypes.data_as(pd))
        if not handle:
            raise ValueError(self.last_error())
        self.handle=handle
        self.identity={"feature_path":str(self.path),"feature_sha256":digest(self.path),
                       "dll_path":str(self.dll_path),"dll_sha256":digest(self.dll_path),
                       "metadata":self.metadata,"n_events":self.ne,"quadrature_nodes":self.nq}

    def last_error(self):
        value=self.lib.mh_last_error()
        return value.decode("utf-8",errors="replace") if value else "compiled objective failed"

    def evaluate(self,model,pars):
        if self.handle is None:
            raise RuntimeError("Objective has been closed")
        mid,dimension=MODELS[model]
        pars=np.ascontiguousarray(pars,dtype=np.float64)
        if pars.shape!=(dimension,) or not np.isfinite(pars).all():
            raise ValueError("Wrong parameter vector for "+model)
        if model=="E1_h0" and pars[3]!=0:
            raise ValueError("E1_h0 scoring requires exactly h=0")
        output=np.empty(6,dtype=np.float64);gradient=np.empty(dimension,dtype=np.float64)
        pd=ct.POINTER(ct.c_double)
        status=self.lib.mh_eval(self.handle,mid,pars.ctypes.data_as(pd),dimension,
                                output.ctypes.data_as(pd),gradient.ctypes.data_as(pd))
        if status!=0:
            raise FloatingPointError(self.last_error())
        if not np.isfinite(output).all() or not np.isfinite(gradient).all():
            raise FloatingPointError("Nonfinite compiled result")
        return {"joint_nll":float(output[0]),"timing_logscore":float(output[1]),
                "mark_logscore":float(output[2]),"integrated_intensity":float(output[3]),
                "rho_raw":float(output[4]),"expected_branching_radius":float(output[5]),
                "gradient":gradient.copy()}

    def target(self,model):
        def objective(pars):
            result=self.evaluate(model,pars)
            return result["joint_nll"],result["gradient"]
        return objective

    def parameter_bounds(self,model,fixed_d=None):
        return model_bounds(model,self.metadata,fixed_d)

    def close(self):
        if self.handle is not None:
            self.lib.mh_destroy(self.handle);self.handle=None

    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
