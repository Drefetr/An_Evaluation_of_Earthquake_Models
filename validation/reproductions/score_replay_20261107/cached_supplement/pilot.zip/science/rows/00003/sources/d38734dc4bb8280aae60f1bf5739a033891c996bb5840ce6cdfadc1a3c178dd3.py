"""Cached proper continuous point likelihood; all density scores in km^-2."""
from pathlib import Path
import ctypes as ct,json,hashlib
import numpy as np
MODELS={"E_cont":(0,3),"E_lift":(0,3),"I_cont_zone":(1,4),"I_cont_globalG":(2,4)}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def model_bounds(model,*,fixed_d=None):
    b=[(-12.,0.),(-2.,2.),(0.,.98)]+([(0.,3.)] if model.startswith("I") else [])
    if fixed_d is not None:b[1]=(float(fixed_d),float(fixed_d))
    return b
def library(path=None):
    path=Path(path or Path(__file__).with_name("objective.dll")).resolve();lib=ct.CDLL(str(path));pd=ct.POINTER(ct.c_double)
    lib.cl_create.argtypes=[ct.c_int]*3+[pd]*15;lib.cl_create.restype=ct.c_void_p
    lib.cl_eval.argtypes=[ct.c_void_p,ct.c_int,pd,ct.c_int,pd,pd,pd];lib.cl_eval.restype=ct.c_int
    lib.cl_destroy.argtypes=[ct.c_void_p];lib.cl_destroy.restype=None;lib.cl_last_error.restype=ct.c_char_p
    return lib,path
class Objective:
    def __init__(self,path,dll_path=None):
        self.path=Path(path).resolve();self.handle=None;self.lib,self.dll_path=library(dll_path)
        with np.load(self.path,allow_pickle=False) as saved:
            self.metadata=json.loads(str(saved["metadata_json"].item()));self.arrays={}
            for name in saved.files:
                if name=="metadata_json":continue
                v=saved[name]
                if v.dtype!=np.dtype("float64") or not np.isfinite(v).all():raise ValueError("invalid cache "+name)
                self.arrays[name]=np.ascontiguousarray(v)
        a=self.arrays;m=self.metadata;self.ne=len(a["event_time"]);self.np=len(a["parent_time"]);self.nq=len(a["quad_time"]);stress=bool(m["stress_available"])
        shape={n:(self.ne,) for n in ["event_time","event_excess","event_cell","event_x","event_background_density","event_h_point","event_g_global"]};shape.update(event_xy=(self.ne,2),event_h_cell=(self.ne,9),event_g_zone=(self.ne,3));shape.update({n:(self.nq,) for n in ["quad_time","quad_x","quad_w"]});shape.update(quad_g_zone=(self.nq,3) if stress else (0,3),quad_g_global=(self.nq,) if stress else (0,),cell_pi=(9,),cell_areas=(9,),K_cell=(9,),rectangles=(9,4),cell_centers_xy=(9,2),parent_xy=(self.np,2),parent_cell_mass=(self.np,9))
        if m["geometry_version"]!=1 or m["n_events"]!=self.ne or m["n_parents"]!=self.np:raise ValueError("cache dimensions")
        for key,expected in shape.items():
            if a[key].shape!=expected:raise ValueError("cache shape "+key)
        if np.any(np.diff(a["parent_time"])<=0) or np.any(np.diff(a["event_time"])<=0):raise ValueError("raw time ordering")
        cell=a["event_cell"]
        if np.any(cell!=np.floor(cell)) or np.any(cell<0) or np.any(cell>=9):raise ValueError("event cell")
        cells=cell.astype(int)
        if np.max(np.abs(a["event_background_density"]-a["cell_pi"][cells]/a["cell_areas"][cells]),initial=0)>1e-18:raise ValueError("point background density binding")
        area=(a["rectangles"][:,1]-a["rectangles"][:,0])*(a["rectangles"][:,3]-a["rectangles"][:,2])
        if not np.array_equal(area,a["cell_areas"]) or np.max(np.abs(a["cell_pi"]-m["pi"]))>1e-14 or np.max(np.abs(a["parent_cell_mass"].sum(axis=1)-1),initial=0)>1e-12:raise ValueError("proper support mass")
        if np.max(np.abs(a["event_g_zone"].sum(axis=1)-a["event_g_global"]),initial=0)>1e-10:raise ValueError("raw global stress must sum disjoint3zones")
        if stress and np.max(np.abs(a["quad_g_zone"].sum(axis=1)-a["quad_g_global"]),initial=0)>1e-10:raise ValueError("global quadrature stress")
        meta=np.array([m["start"],m["end"],m["T0"],m["beta"],self.ne*np.log(m["beta"])-m["beta"]*a["event_excess"].sum()],dtype=np.float64);pd=ct.POINTER(ct.c_double)
        names=["event_x","event_background_density","event_h_point","event_h_cell","event_g_zone","event_g_global","event_cell","quad_x","quad_w","quad_g_zone","quad_g_global","cell_pi","cell_areas","K_cell"]
        self.handle=self.lib.cl_create(self.ne,self.nq,int(stress),*[a[n].ctypes.data_as(pd) for n in names],meta.ctypes.data_as(pd))
        if not self.handle:raise ValueError(self.last_error())
        self.identity=dict(feature_path=str(self.path),feature_sha256=digest(self.path),dll_path=str(self.dll_path),dll_sha256=digest(self.dll_path),metadata=m)
    def last_error(self):return self.lib.cl_last_error().decode(errors="replace")
    def evaluate(self,model,pars):
        if self.handle is None:raise RuntimeError("closed objective")
        mid,dim=MODELS[model];p=np.ascontiguousarray(pars,dtype=np.float64)
        if p.shape!=(dim,) or not np.isfinite(p).all():raise ValueError("parameter dimension")
        out=np.empty(28);grad=np.empty(dim);logs=np.empty((self.ne,4));pd=ct.POINTER(ct.c_double)
        if self.lib.cl_eval(self.handle,mid,p.ctypes.data_as(pd),dim,out.ctypes.data_as(pd),grad.ctypes.data_as(pd),logs.ctypes.data_as(pd)):raise FloatingPointError(self.last_error())
        cellC=out[10:19].copy();cellE=out[19:28].copy();zoneC=cellC.reshape(3,3).sum(axis=1)
        return dict(joint_nll=float(out[0]),joint_logscore=-float(out[0]),timing_logscore=float(out[1]),conditional_zone_logscore=float(out[2]),conditional_cell_logscore=float(out[3]),within_cell_density_logscore=float(out[4]),mark_logscore=float(out[5]),integrated_intensity=float(out[6]),event_log_point_intensity_sum=float(out[7]),event_log_ground_intensity_sum=float(out[8]),event_log_intensity_sum=float(out[7]),trigger_exposure=float(out[9]),cell_integrated_intensity=cellC,zone_integrated_intensity=zoneC,cell_point_event_log_intensity_sum=cellE,cell_point_logscore=cellE-cellC,event_log_point_intensity=logs[:,0].copy(),event_log_cell_intensity=logs[:,1].copy(),event_log_zone_intensity=logs[:,2].copy(),event_log_ground_intensity=logs[:,3].copy(),gradient=grad.copy())
    def close(self):
        if self.handle:self.lib.cl_destroy(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
