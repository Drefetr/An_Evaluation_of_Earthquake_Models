#!/bin/sh
set -eu
cd "$(dirname "$0")"
GXX=${GXX:-g++-11}
"$GXX" -O3 -std=c++17 -fPIC -shared -ffp-contract=off source/cached_stage2.cpp -o source/temporal_stage2.so
