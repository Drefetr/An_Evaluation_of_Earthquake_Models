"""Append-only recovery plumbing. No generation or alternate fitting algorithm."""
import argparse,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
HOME=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,d):Path(p).write_text(json.dumps(d,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def rebased(path,workspace):
 text=str(path).replace('\\','/');key='research_runs/'
 if key not in text:raise ValueError('Manifest input outside registered research_runs tree')
 candidate=(workspace/text[text.index(key):]).resolve()
 if not candidate.is_relative_to(workspace):raise ValueError('Input path escapes workspace')
 return candidate
def prepare(a):
 workspace=Path(a.workspace).resolve();prior=workspace/'research_runs/scientific_stage2_20261030T041738Z/M01';out=Path(a.output).resolve()
 if out.exists():raise FileExistsError('Prepare requires fresh output directory')
 manifest=read(prior/'S02_GENERATION_MANIFEST_RECOVERY_v1.json');rows=manifest['cases']
 if len(rows)!=300 or {(r['forest'],r['h']) for r in rows}!={(i,h) for i in range(100) for h in (0.,.5,.9)}:raise ValueError('Fixed300 roster changed')
 path_changes=[]
 for row in rows:
  if row['time_seed']!=2033000000+100*row['forest'] or row['mark_seed']!=row['time_seed']+10000000 or row['generation']['status']!='ok' or not row['coupled_skeleton_match']:raise ValueError('Frozen successful generation contract changed')
  target=rebased(row['path'],workspace)
  if sha(target)!=row['history_sha256']:raise ValueError('Committed history pin changed')
  path_changes.append(dict(id=row['id'],original_path=row['path'],resumed_path=str(target),sha256=row['history_sha256']));row['path']=str(target)
 admission=read(workspace/'research_runs/scientific_stage2_20261030T041738Z/Q01/Q02_S02_fullfit_execution_admission.json');pilotpins=admission['mandatory_additional_reuse_pins'];reuse=[]
 for old,expected in pilotpins.items():
  source=rebased(old,workspace)
  if sha(source)!=expected:raise ValueError('Accepted pilot pin changed')
  reuse.append((source,expected))
 out.mkdir(parents=True)
 for source,expected in reuse:
  target=out/'s02_fits'/source.name if source.parent.name=='s02_fits' else out/source.name;target.parent.mkdir(exist_ok=True);shutil.copyfile(source,target)
 shutil.copyfile(prior/'S02_STAGED_RECIPE.json',out/'S02_STAGED_RECIPE.json')
 manifest['resume_input_lineage']=dict(original_manifest=str(prior/'S02_GENERATION_MANIFEST_RECOVERY_v1.json'),sha256=sha(prior/'S02_GENERATION_MANIFEST_RECOVERY_v1.json'),path_rebase_only=True)
 write(out/'manifest.json',manifest);write(out/'path_lineage_private.json',path_changes)
 write(out/'prepare.json',dict(status='prepared_not_run',catalogues=300,reused_catalogues=2,reused_method_cases=4,remaining_catalogues=298,remaining_method_cases=596,no_seed_redraw=True,prior=str(prior),source_manifest_sha256=manifest['resume_input_lineage']['sha256'],copied_reuse=[dict(name=p.name,sha256=h) for p,h in reuse]))
def main():
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['prepare','fit','summary','paired']);p.add_argument('--workspace',required=True);p.add_argument('--output',required=True);p.add_argument('--library');p.add_argument('--workers',type=int,choices=range(1,7),default=6);a=p.parse_args()
 if a.stage=='prepare':prepare(a);return
 out=Path(a.output).resolve();receipt=read(out/'prepare.json')
 if receipt['status']!='prepared_not_run':raise ValueError('Missing preparation custody')
 # Environment propagates into spawned workers; original solver code is unchanged.
 env=dict(os.environ,M01_OUTPUT_ROOT=str(out),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
 if a.library:env['M01_TEMPORAL_LIBRARY']=str(Path(a.library).resolve())
 elif a.stage=='fit':raise ValueError('Fit requires explicit compiled --library')
 if a.stage=='paired':command=[sys.executable,'-B',str(HOME/'source/s02_paired_extra.py')]
 else:command=[sys.executable,'-B',str(HOME/'source/s02_explicit_manifest_v2.py'),a.stage,'--root',str(Path(a.workspace).resolve()),'--manifest',str(out/'manifest.json'),'--workers',str(a.workers)]
 raise SystemExit(subprocess.call(command,env=env))
if __name__=='__main__':main()
