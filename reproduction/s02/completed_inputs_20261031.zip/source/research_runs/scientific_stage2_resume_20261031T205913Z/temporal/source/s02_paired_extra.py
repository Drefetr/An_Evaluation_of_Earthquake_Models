"""Predeclared paired analysis helper, no simulation or fitting."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from pathlib import Path
import json,math
import numpy as np
HOME=Path(os.environ.get("M01_OUTPUT_ROOT",str(Path(__file__).resolve().parent.parent)))
def save(path,data):Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def main():
 rows=json.loads((HOME/'S02_PRIVATE_ANALYSIS_ROWS.json').read_text());lookup={(r['procedure'],r['h'],r['forest']):r for r in rows}
 def describe(values):
  valid=[x for x in values if x is not None];n=len(valid)
  return dict(planned_pairs=100,complete_pairs=n,mean=float(np.mean(valid)) if n else None,median=float(np.median(valid)) if n else None,mcse=float(np.std(valid,ddof=1)/math.sqrt(n)) if n>1 else None,scope='all100pairedforests' if n==100 else 'conditional_complete_pairs_missing_retained')
 cross=[];within=[]
 for h in (0.,.5,.9):
  glr=[];selection=[];k1=k2=u1=u2=0
  for i in range(100):
   a=lookup['M1',h,i];b=lookup['M2',h,i];both=a['resolved'] and b['resolved'];glr.append(b['glr']-a['glr'] if both else None);selection.append(int(b['selected'])-int(a['selected']) if both else None);k1+=a['selected'] is True;k2+=b['selected'] is True;u1+=not a['resolved'];u2+=not b['resolved']
  cross.append(dict(h=h,contrast='M2minusM1',glr=describe(glr),selection=describe(selection),all_planned_selection_difference_bounds=[(k2-k1-u1)/100,(k2+u2-k1)/100]))
 for proc in ('M1','M2'):
  for h in (.5,.9):
   d=[lookup[proc,h,i]['glr']-lookup[proc,0.,i]['glr'] if lookup[proc,h,i]['resolved'] and lookup[proc,0.,i]['resolved'] else None for i in range(100)];within.append(dict(procedure=proc,h_minus0=h,glr=describe(d)))
 result=dict(scope='paired forest contrasts; no new experiment and no independent h0 calibration',cross_procedure=cross,within_procedure=within,uncertainty_note='forest-unit sample MCSE; no new bootstrap or independent calibration; incompletepair means explicitly conditional')
 save(HOME/'S02_PAIRED_CONTRASTS.json',result);print(json.dumps(dict(cross_procedure_contrasts=len(cross),within_procedure_contrasts=len(within))))
if __name__=='__main__':main()
