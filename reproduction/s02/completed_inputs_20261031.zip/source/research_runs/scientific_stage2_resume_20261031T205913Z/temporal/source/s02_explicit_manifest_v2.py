"""Explicit-manifest fit/summary adapter; frozen fit function unchanged."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
from s02_campaign import HOME,save,wilson,fit,pool_run
from pathlib import Path
import argparse,json,math
import numpy as np

def summarize(manifest_path):
 manifest=json.loads(Path(manifest_path).read_text());rows=[];lookup={};table=[];paired=[]
 for case in manifest['cases']:
  file=HOME/'s02_fits'/(case['id']+'.json');result=json.loads(file.read_text()) if file.exists() else {}
  for proc in ('M1','M2'):
   m=next((x for x in result.get('methods',[]) if x['procedure']==proc),{})
   resolved=m.get('status')=='complete';glr=m.get('direct_contrast16',{}).get('statistic') if resolved else None;eta=m.get('alternative',{}).get('pars',[None]*4)[3] if resolved else None
   row=dict(forest=case['forest'],h=case['h'],procedure=proc,resolved=resolved,glr=glr,eta=eta,selected=bool(glr>.001 and eta>1e-6) if resolved else None);rows.append(row);lookup[proc,case['h'],case['forest']]=row
 for proc in ('M1','M2'):
  null=[lookup[proc,0.,i]['glr'] for i in range(100)];threshold=float(np.quantile(null,.95,method='higher')) if all(v is not None for v in null) else None
  for h in (0.,.5,.9):
   group=[lookup[proc,h,i] for i in range(100)];n=sum(x['resolved'] for x in group);k=sum(x['selected'] is True for x in group)
   table.append(dict(procedure=proc,h=h,planned=100,resolved=n,unknown=100-n,selected=k,selection_proportion=k/100 if n==100 else None,selection_bounds=[k/100,(k+100-n)/100],wilson95=wilson(k,n) if n else None,wilson_scope='all100' if n==100 else 'conditional_resolved_only',empirical_h0_95threshold=threshold,threshold_scope='same100_h0_descriptive_not_independent_calibration',above_empirical_threshold=sum(x['glr']>threshold for x in group if x['resolved']) if threshold is not None else None))
   differences=[lookup[proc,h,i]['glr']-lookup[proc,0.,i]['glr'] for i in range(100) if lookup[proc,h,i]['resolved'] and lookup[proc,0.,i]['resolved']]
   paired.append(dict(procedure=proc,h_minus0=h,planned_pairs=100,complete_pairs=len(differences),mean=float(np.mean(differences)) if differences else None,median=float(np.median(differences)) if differences else None,mcse=float(np.std(differences,ddof=1)/math.sqrt(len(differences))) if len(differences)>1 else None))
 save(HOME/'S02_PRIVATE_ANALYSIS_ROWS.json',rows)
 save(HOME/'S02_SUMMARY.json',dict(status='complete' if all(r['resolved'] for r in rows) else 'partial',planned_forests=100,planned_catalogues=300,planned_method_cases=600,completed_method_cases=sum(r['resolved'] for r in rows),table=table,paired_glr_differences=paired,interpretation='Productivity comparison at r0 generator with common candidate n=.5; M1 r=.7 replication arm strengthens starts and changes original supplied n≈.501775 to.5 in both arms. h0 thresholds descriptive empirical on same100, no independent calibration; exactML generator/finite195-mode candidate mismatch remains disclosed.'))
 print(json.dumps(dict(planned_method_cases=600,completed_method_cases=sum(r['resolved'] for r in rows))))

def main():
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['fit','summary']);p.add_argument('--root',required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--workers',type=int,default=6);p.add_argument('--limit',type=int);a=p.parse_args()
 manifest=json.loads(a.manifest.read_text());cases=manifest['cases'];expected={(i,h) for i in range(100) for h in (0.,.5,.9)}
 if manifest['planned']!=300 or len(cases)!=300 or {(r['forest'],r['h']) for r in cases}!=expected or len({r['id'] for r in cases})!=300:raise ValueError('complete fixed300case map required')
 for row in cases:
  if row['time_seed']!=2033000000+100*row['forest'] or row['mark_seed']!=row['time_seed']+10000000:raise ValueError('registeredseed changed')
 if a.stage=='summary':summarize(a.manifest)
 else:
  cases=cases[:a.limit] if a.limit else cases
  results=pool_run(fit,[(a.root,row) for row in cases],a.workers);save(HOME/('S02_FIT_PILOT_RESULT.json' if a.limit else 'S02_FIT_CAMPAIGN_RESULT.json'),dict(planned=len(cases),completed=len(results),cases=results,manifest_path=str(a.manifest)))
if __name__=='__main__':main()
