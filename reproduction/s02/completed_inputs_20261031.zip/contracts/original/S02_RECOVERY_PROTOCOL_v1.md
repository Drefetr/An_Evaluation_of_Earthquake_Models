# Same-seed generation timeout recovery

Original120-second generation job timed out; conductor verified parent/CLI descendants terminal. Frozen original manifest has211 completed successful histories with exact seed/config/history hashes, one unmanifested CSV orphan,88 unattempted cases. Original files and manifest remain unchanged. S02_RECOVERY_INSPECTION.json records exact private IDs, registered time/mark seeds, orphan bytes/hash and89-case continuation plan.

Before generating anything, verify frozen manifest hash, every committed CSV hash/config, registered seed rule and identical timed/ancestry skeleton within forest. Resume exactly88 unattempted cases and replay the one interrupted seed into NEW directory s02_histories_recovery_v1. Use identical pinned C++ executable, config, original time/mark seed; no new seed, no outcome-based replacement, no overwrite. Root explicitly authorized same-seed replay, subject to independent Q01 review.

Compare orphan bytes to new complete same-seed CSV. Byte identity certifies orphan was complete; if old bytes are a prefix, preserve partial original and use new complete replay with both hashes and partial-prefix classification. Nonprefix mismatch stays unknown pending review. Capture native completion flag/count and new output hash; verify coupling across original/recovered forest members. Any native failure remains a planned unknown; no automatic retry.

Write a NEW combined S02_GENERATION_MANIFEST_RECOVERY_v1.json (211 original rows plus89 fresh/replayed rows) and aggregate-only recovery receipt. Timeout600 seconds serial, one CLI child at a time, each CLI timeout30s. Whole-run timeout preserves new partial manifest; further continuation would require a separate append-only recovery epoch.

New fit driver accepts explicit combined manifest; old generation/fitting source and original manifest untouched. Fitting and summaries still use exact previously frozen candidate methods, common n=.5 and100 paired units/300 catalogues. Pilot outputs reused once. This is deterministic interrupted-execution recovery, not a new scientific design or seed redraw.
