# Additional paired contrast, before S02 outcomes

Conductor requested direct r-confound contrast in addition to existing within-procedure h-minus0 differences. Separate s02_paired_extra.py preserves existing generation/fitting/source pins. Compute GLR(M2)-GLR(M1) and selection(M2)-selection(M1) per same forest at each h, with complete-pair counts and all-planned selection difference bounds. Existing within-procedure h-minus0 GLR contrasts remain available.

Report mean, median and forest-unit sample MCSE. No extra bootstrap, catalogue, fit or threshold calibration. Missing pairs retained; means explicitly conditional if fewer than100 pairs resolve. This is deterministic arithmetic on already planned600 method cases.
