"""Independent post-terminal S02 custody/solver/scalar audit; no likelihood imports."""
import argparse,csv,hashlib,json,math,statistics
from pathlib import Path

TIERS=['LBFGSB40','LBFGSB200','Powell'];HS=(0.,.5,.9);PROCS=('M1','M2')
def read(p):
 def bad(value):raise ValueError('nonfinite JSON '+value)
 return json.loads(Path(p).read_text(encoding='utf-8-sig'),parse_constant=bad)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024**2),b''):h.update(block)
 return h.hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def need(ok,message):
 if not ok:raise ValueError(message)
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
def close(a,b,atol=1e-9):return finite(a) and finite(b) and abs(a-b)<=atol+1e-12*max(abs(a),abs(b))
def same(a,b):
 if isinstance(a,dict):return isinstance(b,dict) and set(a)==set(b) and all(same(v,b[k]) for k,v in a.items())
 if isinstance(a,list):return isinstance(b,list) and len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
 if isinstance(a,bool) or a is None or isinstance(a,str):return type(a)==type(b) and a==b
 return close(a,b)
def parameters(p,phase):
 need(len(p)==4 and all(finite(x) for x in p),'finite four-parameter state');need(-12<=p[0]<=0 and -2<=p[1]<=2 and p[2]==.5 and 0<=p[3]<=3,'fixed-n parameter bounds')
 if phase=='null':need(p[3]==0,'null eta floor')
def history(path):
 h=hashlib.sha256();count=0;fields=['time_hi','time_lo','event_gap','event_id','parent_id','generation']
 with Path(path).open(newline='') as f:
  rows=csv.DictReader(f);need(set(fields+['excess']).issubset(rows.fieldnames),'raw CSV fields')
  for row in rows:h.update(json.dumps([row[k] for k in fields],separators=(',',':')).encode());h.update(b'\n');count+=1
 return h.hexdigest(),count

def check_method(m,trace,base,trigger=None):
 name=m['procedure'];need(name in PROCS and m.get('candidate_ratio')==(.7 if name=='M1' else 0.),'procedure ratio')
 records=m.get('attempts',[]);need(trace==records,'JSONL attempt coverage/semantic identity')
 if m['status']!='complete':return dict(resolved=False,attempts=len(trace))
 need(m['cell']=='I11' and m['prescribed_null_starts']==8 and m['prescribed_alt_starts']==8,'I11 eight-start prescription')
 need(records and all(r['phase'] in ['null','alternative'] for r in records),'attempt phase roster')
 offsets=[(0,0),(.2,.1),(-.2,-.1),(.5,.5),(-.5,-.5),(1,1),(-1,-1),(0,0)];etas=[0,.02,.05,.1,.2,.5,1,2]
 for phase in ['null','alternative']:
  need({r['start_index'] for r in records if r['phase']==phase}==set(range(8)),'eight distinct start indices')
  for index in range(8):
   seq=[r for r in records if r['phase']==phase and r['start_index']==index]
   need(1<=len(seq)<=3 and [r['tier'] for r in seq]==TIERS[:len(seq)],'failure-only tier sequence')
   need(seq[-1]['success'] is True and not any(r['success'] for r in seq[:-1]),'successful start terminal tier')
   start=[min(0,max(-12,base[0]+offsets[index][0])),min(2,max(-2,base[1]+offsets[index][1])),.5,0] if phase=='null' else [*m['null']['pars'][:3],etas[index]]
   for r in seq:
    need(r['free']==([0,1] if phase=='null' else [0,1,3]),'frozen free coordinates');parameters(r['terminal_pars'],phase)
    need(all(close(x,y,1e-12) for x,y in zip(r['start'],start)) and len(r['start'])==4,'frozen initial start')
    need(finite(r['terminal_best_nll']) and finite(r['terminal_gradient_norm']),'finite retained terminal diagnostics')
 for phase in ['null','alternative']:
  parameters(m[phase]['pars'],phase);need(finite(m[phase]['nll']) and m[phase]['ratio']==m['candidate_ratio'],'selected state identity')
  if trigger is not None:need(m[phase]['trigger']==trigger,'frozen selected trigger metadata')
 need(m['alternative']['nll']<=m['null']['nll']+1e-9,'exact null candidate floor')
 if m['alternative']['origin']=='exact_null_floor':need(m['alternative']['pars']==m['null']['pars'] and m['alternative']['nll']==m['null']['nll'],'floor provenance')
 controls=m['controls'];need(len(controls)==2 and {x['phase'] for x in controls}=={'null','alternative'},'two selected-state quadrature controls')
 ctl={x['phase']:x for x in controls}
 for phase,x in ctl.items():
  need(x['passed'] is True and close(x['order16'],m[phase]['nll']) and close(x['absolute_difference'],abs(x['order32']-x['order16'])) and abs(x['order32']-x['order16'])<=1e-4,'selected16/32 quadrature gate')
 for order in [16,32]:
  c=m['direct_contrast'+str(order)];sub=2*(ctl['null']['order'+str(order)]-ctl['alternative']['order'+str(order)])
  need(close(c['nll_subtraction_control'],sub) and close(c['direct_minus_subtraction'],c['statistic']-sub) and abs(c['direct_minus_subtraction'])<=1e-4 and c['statistic']>=-1e-4,'direct GLR subtraction gate')
  need(close(c['statistic'],2*math.fsum(c[k] for k in ['event_difference','background_compensator_difference','trigger_compensator_difference'])),'direct GLR component sum')
 need(abs(m['direct_contrast16']['statistic']-m['direct_contrast32']['statistic'])<=1e-4,'direct GLR quadrature agreement')
 need(m['near_optimal_candidates'],'near-optimal candidate coverage')
 for r in m['near_optimal_candidates']:
  parameters(r['pars'],'alternative');need(r['nll']<=m['alternative']['nll']+4e-4,'near-optimal bound')
 return dict(resolved=True,attempts=len(records),failed_tiers=sum(not r['success'] for r in records),glr=m['direct_contrast16']['statistic'],eta=m['alternative']['pars'][3])

def wilson(k,n):
 if not n:return None
 z=1.959963984540054;q=z*z;den=2*(n+q);center=2*k+q;half=z*math.sqrt(q+4*k*(1-k/n));return [(center-half)/den,(center+half)/den]
def describe(v):
 x=[a for a in v if a is not None];n=len(x)
 return dict(planned_pairs=100,complete_pairs=n,mean=statistics.mean(x) if n else None,median=statistics.median(x) if n else None,mcse=statistics.stdev(x)/math.sqrt(n) if n>1 else None,scope='all100pairedforests' if n==100 else 'conditional_complete_pairs_missing_retained')
def aggregates(rows):
 lookup={(r['procedure'],r['h'],r['forest']):r for r in rows};need(len(rows)==600 and len(lookup)==600,'unique600 analysis roster');table=[];paired=[];cross=[];within=[]
 for proc in PROCS:
  null=[lookup[proc,0.,i]['glr'] for i in range(100)];threshold=sorted(null)[math.ceil(.95*(len(null)-1))] if all(x is not None for x in null) else None
  for h in HS:
   group=[lookup[proc,h,i] for i in range(100)];n=sum(x['resolved'] for x in group);k=sum(x['selected'] is True for x in group)
   table.append(dict(procedure=proc,h=h,planned=100,resolved=n,unknown=100-n,selected=k,selection_proportion=k/100 if n==100 else None,selection_bounds=[k/100,(k+100-n)/100],wilson95=wilson(k,n),wilson_scope='all100' if n==100 else 'conditional_resolved_only',empirical_h0_95threshold=threshold,threshold_scope='same100_h0_descriptive_not_independent_calibration',above_empirical_threshold=sum(x['glr']>threshold for x in group if x['resolved']) if threshold is not None else None))
   differences=[lookup[proc,h,i]['glr']-lookup[proc,0.,i]['glr'] for i in range(100) if lookup[proc,h,i]['resolved'] and lookup[proc,0.,i]['resolved']];d=describe(differences)
   paired.append(dict(procedure=proc,h_minus0=h,**{key:d[key] for key in ['planned_pairs','complete_pairs','mean','median','mcse']}))
   if h:within.append(dict(procedure=proc,h_minus0=h,glr=d))
 for h in HS:
  differences=[];selections=[];k1=k2=u1=u2=0
  for i in range(100):
   a=lookup['M1',h,i];b=lookup['M2',h,i];both=a['resolved'] and b['resolved'];differences.append(b['glr']-a['glr'] if both else None);selections.append(int(b['selected'])-int(a['selected']) if both else None);k1+=a['selected'] is True;k2+=b['selected'] is True;u1+=not a['resolved'];u2+=not b['resolved']
  cross.append(dict(h=h,contrast='M2minusM1',glr=describe(differences),selection=describe(selections),all_planned_selection_difference_bounds=[(k2-k1-u1)/100,(k2+u2-k1)/100]))
 return dict(table=table,paired_glr_differences=paired,cross_procedure=cross,within_procedure=within)

def main():
 p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--output',required=True);p.add_argument('--terminal-receipt');a=p.parse_args();run=Path(a.run).resolve();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False);report=dict(status='not_ready',passed=False,likelihood_evaluations=0)
 # Never interpret running checkpoint files as failures.
 marker=run/'S02_FIT_CAMPAIGN_RESULT.json'
 if not marker.exists():write(out/'report.json',report);raise SystemExit(2)
 try:
  if a.terminal_receipt:
   terminal=read(a.terminal_receipt);need(terminal.get('terminal') is True and terminal.get('status')=='succeeded','terminal execution receipt');report['terminal_receipt_sha256']=sha(a.terminal_receipt)
  campaign=read(marker);manifest=read(run/'manifest.json');cases=manifest['cases'];need(manifest['planned']==300 and len(cases)==300 and len({r['id'] for r in cases})==300 and {(r['forest'],r['h']) for r in cases}=={(i,h) for i in range(100) for h in HS},'fixed300 catalogue roster')
  lineage=manifest['resume_input_lineage'];authority=Path(lineage['original_manifest']);need(sha(authority)==lineage['sha256'] and lineage['path_rebase_only'] is True,'original manifest authority');original=read(authority);originals={r['id']:r for r in original['cases']};need(set(originals)=={r['id'] for r in cases},'original300 identity map')
  need(campaign['planned']==300 and campaign['completed']==300 and len(campaign['cases'])==300 and {r['id'] for r in campaign['cases']}=={r['id'] for r in cases},'terminal campaign coverage')
  need(sha(run/'S02_STAGED_RECIPE.json')==sha(authority.parent/'S02_STAGED_RECIPE.json'),'original recipe unchanged')
  fitted_law=read(run/'S02_STAGED_RECIPE.json')['law']['alternative_generating_fit'];base=fitted_law['pars'];pins={str(p):sha(p) for p in [marker,run/'manifest.json',run/'S02_STAGED_RECIPE.json',authority,authority.parent/'S02_STAGED_RECIPE.json']};rows=[];checks=[];skeletons={};total_attempts=0
  for case in cases:
   forest=case['forest'];h=case['h'];need(case['time_seed']==2033000000+100*forest and case['mark_seed']==case['time_seed']+10000000,'registered seed map')
   need(case['id']==('s%03d_h'%forest)+format(h,'.1f').replace('.','p'),'registered catalogue ID')
   need(all(case[k]==originals[case['id']][k] for k in ['forest','h','time_seed','mark_seed','history_sha256','generation','coupled_skeleton_match']),'original input record unchanged')
   gen=case['generation'];need(gen['status']=='ok' and gen['construction_complete'] is True and case['coupled_skeleton_match'] is True and case['returncode']==0 and gen['time_seed']==case['time_seed'] and gen['mark_seed']==case['mark_seed'],'generation custody')
   raw=Path(case['path']);need(sha(raw)==case['history_sha256'],'raw history SHA');identity,count=history(raw);need(count==gen['events'],'raw event count');need(forest not in skeletons or skeletons[forest]==identity,'coupled raw time/ancestry skeleton');skeletons[forest]=identity;pins[str(raw)]=case['history_sha256']
   file=run/'s02_fits'/(case['id']+'.json');saved=read(file);pins[str(file)]=sha(file);need((saved['id'],saved['forest'],saved['h'],saved['history_sha256'])==(case['id'],forest,h,case['history_sha256']),'fit/input identity');methods=saved['methods'];need(len(methods)==2 and {m['procedure'] for m in methods}==set(PROCS),'two unique procedures')
   need((saved['status']=='complete')==all(m['status']=='complete' for m in methods),'catalogue status consistency')
   for name in PROCS:
    m=next(m for m in methods if m['procedure']==name);path=run/'s02_fits'/(case['id']+'.'+name+'.attempts.jsonl');trace=[json.loads(x) for x in path.read_text().splitlines() if x.strip()] if path.exists() else []
    if path.exists():pins[str(path)]=sha(path)
    if m['status']=='complete':checked=check_method(m,trace,base,fitted_law['trigger'])
    else:checked=dict(resolved=False,attempts=len(trace),producer_status=m['status'])
    total_attempts+=checked['attempts'];resolved=checked['resolved'];glr=checked.get('glr');eta=checked.get('eta');rows.append(dict(forest=forest,h=h,procedure=name,resolved=resolved,glr=glr,eta=eta,selected=bool(glr>.001 and eta>1e-6) if resolved else None));checks.append(dict(case_id=case['id'],procedure=name,**checked))
  computed=aggregates(rows);summary=read(run/'S02_SUMMARY.json');analysis=read(run/'S02_PRIVATE_ANALYSIS_ROWS.json');extra=read(run/'S02_PAIRED_CONTRASTS.json')
  need(same(analysis,rows),'analysis row derivation');need(summary['planned_forests']==100 and summary['planned_catalogues']==300 and summary['planned_method_cases']==600 and summary['completed_method_cases']==sum(r['resolved'] for r in rows),'summary denominators');need(summary['status']==('complete' if all(r['resolved'] for r in rows) else 'partial'),'summary completion status')
  for key in ['table','paired_glr_differences']:need(same(summary[key],computed[key]),'independent summary '+key)
  for key in ['cross_procedure','within_procedure']:need(same(extra[key],computed[key]),'independent paired '+key)
  for name in ['S02_SUMMARY.json','S02_PRIVATE_ANALYSIS_ROWS.json','S02_PAIRED_CONTRASTS.json']:pins[str(run/name)]=sha(run/name)
  for path,h in pins.items():need(sha(path)==h,'audit input changed')
  complete=sum(r['resolved'] for r in rows);report.update(status='complete_saved_inspection' if complete==600 else 'terminal_with_unknown_methods',passed=complete==600,catalogues=300,planned_methods=600,complete_methods=complete,unknown_methods=600-complete,retained_attempts=total_attempts,methods=checks,independent_aggregates=computed,input_pins=pins,auditor_sha256=sha(__file__),scope='100percent custody/saved scalar audit; no independent likelihood replay or global-optimality claim',selected_winner_limit='Attempts save best visited points, not every solver r.x return. Exact selected-vs-all-start return minimum cannot be reconstructed from these fields alone.',sampled_raw_validation='separate predeclared raw oracle required for sampled numerical validation')
 except BaseException as exc:report.update(status='failed_saved_inspection',error_type=type(exc).__name__,error=str(exc));raise
 finally:write(out/'report.json',report)
 if not report['passed']:raise SystemExit(1)

if __name__=='__main__':main()
