import copy,unittest
import inspect_saved as A

def method():
 base=[-4.,.2,.5,0];null=dict(pars=base,nll=100.,ratio=.7,origin='LBFGSB40');alt=dict(pars=[-4.,.2,.5,.1],nll=99.,ratio=.7,origin='LBFGSB40');offsets=[(0,0),(.2,.1),(-.2,-.1),(.5,.5),(-.5,-.5),(1,1),(-1,-1),(0,0)];etas=[0,.02,.05,.1,.2,.5,1,2];records=[]
 for phase in ['null','alternative']:
  for i in range(8):
   start=[base[0]+offsets[i][0],base[1]+offsets[i][1],.5,0] if phase=='null' else [*base[:3],etas[i]]
   records.append(dict(phase=phase,start_index=i,tier='LBFGSB40',success=True,free=[0,1] if phase=='null' else [0,1,3],start=start,terminal_pars=base if phase=='null' else alt['pars'],terminal_best_nll=100 if phase=='null' else 99,terminal_gradient_norm=0.))
 controls=[dict(phase=p,order16=n,order32=n,absolute_difference=0,passed=True) for p,n in [('null',100.),('alternative',99.)]];contrast=dict(statistic=2.,event_difference=1.,background_compensator_difference=0.,trigger_compensator_difference=0.,nll_subtraction_control=2.,direct_minus_subtraction=0.)
 return dict(procedure='M1',candidate_ratio=.7,status='complete',cell='I11',prescribed_null_starts=8,prescribed_alt_starts=8,null=null,alternative=alt,attempts=records,controls=controls,direct_contrast16=contrast,direct_contrast32=contrast,near_optimal_candidates=[alt]),base

class SavedAuditTests(unittest.TestCase):
 def test_eight_starts_floor_and_quadrature(self):
  m,b=method();self.assertTrue(A.check_method(m,m['attempts'],b)['resolved'])
 def test_extra_tier_after_success_rejected(self):
  m,b=method();m['attempts'].insert(1,dict(m['attempts'][0],tier='LBFGSB200'))
  with self.assertRaises(ValueError):A.check_method(m,m['attempts'],b)
 def test_attempt_checkpoint_mismatch_rejected(self):
  m,b=method()
  with self.assertRaises(ValueError):A.check_method(m,[],b)
 def test_missing_start_and_false_control_rejected(self):
  m,b=method();m['attempts'].pop()
  with self.assertRaises(ValueError):A.check_method(m,m['attempts'],b)
  m,b=method();m['controls'][0]['passed']=False
  with self.assertRaises(ValueError):A.check_method(m,m['attempts'],b)
 def test_fixed_n_and_floor_not_relaxed(self):
  m,b=method();m['null']['pars'][2]=.49
  with self.assertRaises(ValueError):A.check_method(m,m['attempts'],b)
 def test_independent_aggregate_and_duplicate_detection(self):
  rows=[dict(forest=i,h=h,procedure=p,resolved=True,glr=i*.001+h,eta=.1,selected=i*.001+h>.001) for i in range(100) for h in A.HS for p in A.PROCS];result=A.aggregates(rows)
  self.assertEqual(len(result['table']),6);self.assertAlmostEqual(result['paired_glr_differences'][1]['mean'],.5);self.assertEqual(result['table'][0]['empirical_h0_95threshold'],.095);self.assertAlmostEqual(A.wilson(0,100)[0],0.)
  with self.assertRaises(ValueError):A.aggregates(rows[:-1]+[rows[0]])

if __name__=='__main__':unittest.main()
