"""Build-only compiler child recorder; run inside the reviewed outer supervisor."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
import psutil

HELPERS={
 'C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Tools/MSVC/14.42.34433/bin/Hostx64/x64/mspdbsrv.exe':'7e98569a6f6488d8027b55b426972bb9b827063211702336c8d274531e92ddd4',
 'C:/Program Files/Microsoft Visual Studio/2022/Community/VC/Tools/MSVC/14.42.34433/bin/Hostx64/x64/vctip.exe':'65c4b480f8c32d4029858f32e27a4a307478bcd3e64692316b465f552e7d3b40',
}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def same(pid,created):
 try:
  p=psutil.Process(pid)
  return p if p.create_time()==created and p.is_running() and p.status()!=psutil.STATUS_ZOMBIE else None
 except psutil.NoSuchProcess:return None
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--build-cmd',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);a=parser.parse_args()
 a.output.mkdir(parents=True,exist_ok=False);began=time.monotonic();known={};actions=[];error=None;child=None;code=None;survivors=[]
 helpers={str(Path(p).resolve()).casefold():digest for p,digest in HELPERS.items()}
 report=dict(passed=False,scope='Compiler process management only; no DLL loading or scientific execution',helper_allowlist=HELPERS,command=['cmd.exe','/d','/c',str(a.build_cmd.resolve())],grace_seconds=3,sampling_seconds=.02,tracked=[],cleanup_actions=[])
 def remember(p):
  try:
   created=p.create_time();key=(p.pid,created)
   if key not in known:known[key]=dict(pid=p.pid,create_time=created,exe=p.exe(),command_line=p.cmdline(),parent_pid=p.ppid())
  except psutil.NoSuchProcess:pass
 def discover():
  for p in psutil.Process(os.getpid()).children(recursive=True):remember(p)
 def living():return [(key,p) for key in known if (p:=same(*key)) is not None]
 try:
  for p,digest in HELPERS.items():
   if sha(p)!=digest:raise RuntimeError('Installed compiler helper identity changed: '+p)
  with (a.output/'compiler.stdout.log').open('w',encoding='utf-8') as out,(a.output/'compiler.stderr.log').open('w',encoding='utf-8') as err:
   child=subprocess.Popen(report['command'],stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
   remember(psutil.Process(child.pid))
   while child.poll() is None:discover();time.sleep(.02)
   code=child.wait();discover();report['compiler_exit_code']=code
   grace=time.monotonic()+3
   while living() and time.monotonic()<grace:discover();time.sleep(.02)
   pending=living();unknown=[]
   for key,p in pending:
    row=known[key];actual=str(Path(p.exe()).resolve());digest=sha(actual);row['executable_sha256']=digest
    if actual.casefold() not in helpers or digest!=helpers[actual.casefold()] or str(Path(row['exe']).resolve()).casefold()!=actual.casefold():unknown.append(row)
   report['lingering_after_grace']=[known[key] for key,_ in pending]
   if unknown:
    report['unexpected_lingering']=unknown
    raise RuntimeError('Unrecognized lingering owned process; defer failure cleanup to reviewed outer supervisor')
   for key,p in pending:
    exact=same(*key)
    if exact is None:continue
    actual=str(Path(exact.exe()).resolve())
    if actual.casefold() not in helpers or sha(actual)!=helpers[actual.casefold()]:raise RuntimeError('Helper identity changed before cleanup')
    exact.kill();actions.append(dict(pid=key[0],create_time=key[1],exe=actual,sha256=helpers[actual.casefold()],action='kill_exact_owned_allowlisted_compiler_helper_after_grace'))
   if pending:psutil.wait_procs([p for _,p in pending],timeout=3)
   survivors=[known[key] for key,_ in living()]
   report['passed']=code==0 and not survivors
 except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc))
 finally:
  report.update(error=error,tracked=list(known.values()),cleanup_actions=actions,survivors=survivors,elapsed_seconds=time.monotonic()-began,wrapper_sha256=sha(__file__))
  if error:report['passed']=False
  (a.output/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
  print(json.dumps(dict(passed=report['passed'],compiler_exit_code=code,tracked=len(known),cleaned_helpers=len(actions),error=error)),flush=True)
 return 0 if report['passed'] else 1
if __name__=='__main__':sys.exit(main())
