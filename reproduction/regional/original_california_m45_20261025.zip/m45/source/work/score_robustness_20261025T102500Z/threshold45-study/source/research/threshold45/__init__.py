"""Separately frozen M>=4.5 sensitivity; baseline authorities remain unchanged."""
