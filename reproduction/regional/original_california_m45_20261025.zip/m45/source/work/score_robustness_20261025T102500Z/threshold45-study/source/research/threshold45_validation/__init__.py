"""Independent M4.5 source binding and full saved-procedure validation.

No producer module or objective DLL is imported. Empirical execution belongs
to the root's exclusive numerical lease; detailed inputs remain local.
"""
