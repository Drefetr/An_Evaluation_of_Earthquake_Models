"""Separate all-component reconciliation, after independent output and termination.

Private block rows never reach stdout. Producer outputs are read only here,
after independent reconstruction; they are never inputs to the oracle.
"""
from __future__ import annotations
import copy
import math
from .common import (ARMS, COMPONENTS, CONTRASTS, DIAGNOSTICS, PLANNED, TARGETS,
                     TOL, AuditError, blank_rows, blocks, close, contrast_rows,
                     derived, digest, finite_number, need, pin_map, read_pinned,
                     write_new)

def keyed(rows, fields, expected, code):
    need(isinstance(rows,list), code)
    index = {}
    for row in rows:
        need(isinstance(row,dict),code); key=tuple(row[f] for f in fields)
        need(key not in index,code); index[key]=row
    need(set(index)==set(expected),code)
    return index

def identity(row):
    need(row['status']=='succeeded', 'INCOMPLETE_OUTPUT_ROW')
    need(type(row['target_count']) is int and row['target_count']>=0, 'TARGET_COUNT_TYPE')
    need(all(finite_number(row[k]) for k in COMPONENTS), 'NONFINITE_OUTPUT_COMPONENT')
    expected=derived({k:row[k] for k in COMPONENTS})
    return {k:close(row[k],expected[k],'OUTPUT_SCORE_IDENTITY') for k in ('timing_logscore','conditional_location_logscore','joint_logscore')}

def check_arm(row):
    errors=identity(row)
    need(all(finite_number(row[k]) for k in DIAGNOSTICS[:3]) and
         all(row[k]>=0 for k in ('integrated_intensity',*DIAGNOSTICS[:3])), 'EXPOSURE_SIGN_OR_FINITE')
    need(isinstance(row['cell_integrated_intensity'],list) and len(row['cell_integrated_intensity'])==9 and
         isinstance(row['zone_integrated_intensity'],list) and len(row['zone_integrated_intensity'])==3,
         'SPATIAL_DIAGNOSTIC_SHAPE')
    need(all(finite_number(v) and v>=0 for v in row['cell_integrated_intensity']+row['zone_integrated_intensity']), 'EXPOSURE_CELL_FINITE')
    errors['total_exposure']=close(row['integrated_intensity'],row['immigrant_exposure']+row['triggered_integrated_intensity'],'B_PLUS_NK_IDENTITY')
    errors['cell_exposure']=close(math.fsum(row['cell_integrated_intensity']),row['integrated_intensity'],'CELL_EXPOSURE_IDENTITY')
    zones=[math.fsum(row['cell_integrated_intensity'][3*z:3*z+3]) for z in range(3)]
    errors['zone_exposure']=close(row['zone_integrated_intensity'],zones,'ZONE_EXPOSURE_IDENTITY')
    if row['target_count']==0:
        need(all(row[k]==0 for k in COMPONENTS if k not in ('integrated_intensity','timing_logscore','joint_logscore')),
             'EMPTY_BLOCK_EVENT_TERMS')
        need(row.get('per_target_mean') is None, 'EMPTY_BLOCK_NULL_MEAN')
    for k in ('actual_procedure_id','selected_candidate_id','logical_arm_window_id'):
        need(row.get(k) is not None,'OUTPUT_LINEAGE_REQUIRED')
    return errors

def expected_keys():
    return {(r['fold_id'],r['arm_id'],r['block_id']) for r in blank_rows()}

def validate_output(obj, producer):
    # Only these supervisor-reviewed spelling aliases are admitted. Normalize a
    # private copy; conflicting dual spellings fail rather than silently choosing.
    obj=copy.deepcopy(obj)
    plan=obj.get('planned_denominators',{})
    for canonical,alias in (('arm_block_rows','arm_blocks'),('contrast_block_rows','contrast_blocks')):
        if alias in plan:
            if canonical in plan:need(plan[canonical]==plan[alias],'CONFLICTING_DENOMINATOR_ALIAS')
            plan[canonical]=plan[alias]
    for row in obj.get('contrast_blocks',[]):
        if 'exposure_contribution' in row:
            if 'exposure_contrast' in row:
                need(row['exposure_contribution']==row['exposure_contrast'],'CONFLICTING_EXPOSURE_ALIAS')
            row['exposure_contrast']=row['exposure_contribution']
    need(obj.get('schema')=='score_robustness_blocks_v1' and obj.get('producer')==producer,'BLOCK_OUTPUT_SCHEMA')
    mandatory=('arm_block_rows','contrast_block_rows','arm_component_slots','contrast_component_slots')
    for key,value in PLANNED.items():
        if key in mandatory or key in obj['planned_denominators']:
            need(obj['planned_denominators'].get(key)==value,'PLANNED_DENOMINATOR_MISMATCH')
    arms=keyed(obj['arm_blocks'],('fold_id','arm_id','block_id'),expected_keys(),'COMPLETE_60_ARM_ROWS')
    expected_cases={(f,a) for f in range(3) for a in ARMS}
    cases=keyed(obj['case_statuses'],('fold_id','arm_id'),expected_cases,'COMPLETE_12_CASE_STATUSES')
    need(all(c['status']=='succeeded' for c in cases.values()),'INCOMPLETE_CASE_STATUSES')
    maxima={}
    for key,row in arms.items():
        f,a,b=key
        keymeta=next(meta for meta,_,_ in blocks(f) if meta['block_id']==b)
        need(row['start_utc']==keymeta['start_utc'] and row['end_utc']==keymeta['end_utc'] and
             row['logical_arm_window_id']==f'california_fold_{f}__arm_{a}', 'OUTPUT_BLOCK_BOUNDARIES')
        for k,v in check_arm(row).items(): maxima[k]=max(maxima.get(k,0.),v)
    for f in range(3):
        for a in ARMS:
            need(sum(r['target_count'] for (ff,aa,_),r in arms.items() if ff==f and aa==a)==TARGETS[f], 'WINDOW_TARGET_TOTAL')
        for meta,_,_ in blocks(f):
            need(len({arms[(f,a,meta['block_id'])]['target_count'] for a in ARMS})==1,'ARM_TARGET_ALIGNMENT')
    expected=contrast_rows(list(arms.values()))
    ckeys={(r['fold_id'],r['contrast_id'],r['block_id']) for r in expected}
    actual=keyed(obj['contrast_blocks'],('fold_id','contrast_id','block_id'),ckeys,'COMPLETE_45_CONTRAST_ROWS')
    for row in expected:
        got=actual[(row['fold_id'],row['contrast_id'],row['block_id'])]
        need(got['status']=='succeeded' and all(got[k]==row[k] for k in
             ('arm_A','arm_B','target_count','primary_component','start_utc','end_utc')), 'CONTRAST_METADATA_IDENTITY')
        for k in COMPONENTS+('primary_value','exposure_contrast'):
            value=close(got[k],row[k],'CONTRAST_ARITHMETIC')
            maxima['contrast_'+k]=max(maxima.get('contrast_'+k,0.),value)
        expected_mean=row['per_target_mean']
        if expected_mean is None: need(got.get('per_target_mean') is None,'ZERO_TARGET_CONTRAST_MEAN')
        elif 'per_target_mean' in got: close(got['per_target_mean'],expected_mean,'CONTRAST_MEAN')
    return arms,actual,maxima

def sums_for(arms,fold,arm):
    subset=[r for (f,a,_),r in arms.items() if f==fold and a==arm]
    sums={k:math.fsum(r[k] for r in subset) for k in COMPONENTS+DIAGNOSTICS[:3]}
    for k,size in (('cell_integrated_intensity',9),('zone_integrated_intensity',3)):
        sums[k]=[math.fsum(r[k][j] for r in subset) for j in range(size)]
    sums['timing_event_logscore']=sums['event_ground_log']
    sums['timing_exposure_logscore']=-sums['integrated_intensity']
    sums['event_log_ground_intensity_sum']=sums['event_ground_log']
    sums['event_log_point_intensity_sum']=math.fsum((sums['event_ground_log'],sums['conditional_location_logscore']))
    sums['event_log_intensity_sum']=sums['event_log_point_intensity_sum']
    return sums

def reconcile(independent_path,independent_sha256,production_path,production_sha256,
              authority_manifest_sha256,private_detail_path):
    # Consume/validate independent complete evidence before opening production.
    independent=read_pinned(independent_path,independent_sha256)
    need(independent.get('reconstruction_complete') is True and independent.get('phase')=='full', 'INDEPENDENT_FULL_OUTPUT_REQUIRED')
    ia,ic,imax=validate_output(independent,'independent')
    refs=keyed(independent['window_checks'],('fold_id','arm_id'),
               {(f,a) for f in range(3) for a in ARMS},'INDEPENDENT_ARCHIVE_REFERENCE_DENOMINATOR')
    need(all(r['status']=='succeeded' for r in refs.values()),'INDEPENDENT_ARCHIVE_CHECKS_INCOMPLETE')
    production=read_pinned(production_path,production_sha256)
    pa,pc,pmax=validate_output(production,'production')
    need(independent['authority_manifest_sha256']==production['authority_manifest_sha256']==authority_manifest_sha256,
         'AUTHORITY_BYTES_IDENTITY')
    need(independent['accepted_design_hashes']==production['accepted_design_hashes'],'DESIGN_OUTPUT_IDENTITY')
    ipins=pin_map(independent['source_pins']); ppins=pin_map(production['source_pins'])
    maxima=dict(production_vs_independent=0.,archived_window=0.,pooled_approved=0.,identity=max([0.,*imax.values(),*pmax.values()]))
    details=[]; identity_checks=0
    for key,a in ia.items():
        b=pa[key]
        need(all(a[k]==b[k] for k in ('target_count','logical_arm_window_id','actual_procedure_id','selected_candidate_id','start_utc','end_utc')),
             'PRODUCER_EVENT_OR_FIT_LINEAGE')
        errors={k:close(a[k],b[k],'BLOCK_PRODUCTION_ORACLE') for k in COMPONENTS+DIAGNOSTICS}
        maxima['production_vs_independent']=max(maxima['production_vs_independent'],*errors.values())
        details.append(dict(key=list(key),errors=errors)); identity_checks+=len(errors)
    for key,a in ic.items():
        for k in COMPONENTS+('primary_value','exposure_contrast'):
            value=close(a[k],pc[key][k],'CONTRAST_PRODUCTION_ORACLE')
            maxima['production_vs_independent']=max(maxima['production_vs_independent'],value); identity_checks+=1
    # Raw-independent archived scalar references, not archived event arrays.
    for (fold,arm),ref in refs.items():
        for producer,arms in (('independent',ia),('production',pa)):
            totals=sums_for(arms,fold,arm)
            for k,expected in ref['archived_reference'].items():
                if k not in totals: continue  # per-cell event diagnostics verified by independent window harness
                error=close(totals[k],expected,'SAVED_WINDOW_COMPONENT')
                maxima['archived_window']=max(maxima['archived_window'],error); identity_checks+=1
            # Every nine-component total must also equal independent full-window reduction.
            for k in COMPONENTS:
                error=close(totals[k],ref['component_sums'][k],'WINDOW_COMPONENT_REDUCTION')
                maxima['archived_window']=max(maxima['archived_window'],error); identity_checks+=1
    for cid,aa,bb,primary,approved in CONTRASTS:
        for arms,contrasts in ((ia,ic),(pa,pc)):
            for fold in range(3):
                sa,sb=sums_for(arms,fold,aa),sums_for(arms,fold,bb)
                for k in COMPONENTS:
                    error=close(math.fsum(r[k] for (f,c,_),r in contrasts.items() if f==fold and c==cid),sa[k]-sb[k],'CONTRAST_WINDOW_IDENTITY')
                    maxima['identity']=max(maxima['identity'],error); identity_checks+=1
            value=math.fsum(r[primary] for (_,c,_),r in contrasts.items() if c==cid)
            maxima['pooled_approved']=max(maxima['pooled_approved'],close(value,approved,'APPROVED_POOLED_CONTRAST'))
            if cid=='location_OC_minus_OL':
                value=math.fsum(r['within_cell_density_logscore'] for (_,c,_),r in contrasts.items() if c==cid)
                maxima['pooled_approved']=max(maxima['pooled_approved'],close(value,653.602228,'APPROVED_WITHIN_CELL_CONTRAST'))
    write_new(private_detail_path,dict(schema='score_robustness_private_reconciliation_detail_v1',rows=details,
                                      identity_checks=identity_checks,max_abs_discrepancies=maxima))
    return dict(schema='score_robustness_reconciliation_v1',status='passed',
                production_output_sha256=production_sha256,independent_output_sha256=independent_sha256,
                authority_manifest_sha256=authority_manifest_sha256,
                source_manifest_sha256=digest(dict(independent=ipins,production=ppins)),
                expected_counts=dict(arm_rows=60,contrast_rows=45,arm_component_slots=540,contrast_component_slots=405,arm_windows=12,targets=315),
                reached_counts=dict(arm_rows=len(ia),contrast_rows=len(ic),arm_component_slots=540,contrast_component_slots=405,arm_windows=len(refs),targets=315),
                identity_checks=dict(passed=True,count=identity_checks),max_abs_discrepancies=maxima,
                failure_codes=[],private_detail_path=str(private_detail_path),aggregate_release_approved=False)
