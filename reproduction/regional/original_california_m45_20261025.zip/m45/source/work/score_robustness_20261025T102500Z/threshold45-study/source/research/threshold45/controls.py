"""Handcrafted threshold and inherited numerical witnesses, root lease only."""
import argparse,copy,json,math,sys
from pathlib import Path
from . import scenario as S
from .run import verify,Geometry,core_pins
from ..external_replication.compiled_objective import Objective
from ..external_replication import geometry as G
from ..score_robustness import reducer as R
import numpy as np
def law_controls():
    rows=[dict(event_id=str(i),magnitude=float(token),source_tokens=dict(magnitude=token)) for i,token in enumerate(['4.4999999999999999','4.5','4.50','4.9999999999999999','5.0','5.0000000000000001'])]
    selected,crosswalk=S.derive_rows(rows)
    # Decimal eligibility precedes binary64 q; a sub-4.5 decimal rounding to4.5 stays excluded.
    S.require([r['event_id'] for r in selected]==['1','2','3','4','5'],'DECIMAL_THRESHOLD_BOUNDARY')
    S.require([x['base_index'] for x in crosswalk]==[1,2,3,4,5] and [x['scenario_index'] for x in crosswalk]==list(range(5)),'PARENT_SUBSET_INDEX')
    q=[float(S.magnitude(r))-4.5 for r in selected]
    S.require(q[:2]==[0.,0.] and q[2:]==[.5,.5,.5],'FROZEN_BINARY64_Q_SHIFT')
    S.require([x>=.5 for x in q]==[False,False,True,True,True],'RELATIVE_MARK_BIN_BINARY64')
    S.require(S.derive_rows([])==([],[]),'EMPTY_SUBSET_DEFINED')
    S.require(S.derive_rows([rows[0]])==([],[]),'EMPTY_TARGET_SUBSET_DEFINED')
    S.require(float(S.magnitude(rows[4]))-4 != q[3],'OLD_MARKS_NOT_REUSED')
    S.verify_selection(selected,crosswalk,rows)
    for mutation in ['event_id','magnitude','source_tokens','base_index','q_hex']:
        altered=copy.deepcopy(selected);altered_crosswalk=copy.deepcopy(crosswalk)
        if mutation=='source_tokens':altered[0]['source_tokens']['magnitude']='4.6'
        elif mutation in ['event_id','magnitude']:altered[0][mutation]='changed' if mutation=='event_id' else 4.6
        elif mutation=='base_index':altered_crosswalk[0]['base_index']=0
        else:altered_crosswalk[0]['q_hex']=(.1).hex()
        rejected=False
        try:S.verify_selection(altered,altered_crosswalk,rows)
        except ValueError:rejected=True
        S.require(rejected,'RAW_CANONICAL_MUTATION_NOT_REJECTED')
    return dict(passed=True,checks=12,empty_window_policy='Empirical fixed windows must retain exact positive census; empty synthetic windows are not fit/spread inputs')
def zero_history(out,dll):
    empty=np.empty(0);cells=np.empty(0,dtype=int);pi=np.full(9,1/9)
    arr,_=G.make_geometry(empty,empty,cells,empty,empty,1.,0.,1.,pi,family='center',sigma=50.,order=16,T0=2.,dll_path=dll,profile='california')
    path=out/'zero_history.npz';G.save_geometry(path,arr)
    with Objective(path,dll_path=dll) as obj:
        for model,pars in [('E_fixed',[-2.,0.,.2]),('E_free',[-2.,0.,.2,0.]),('E_omori',[-2.,0.,.2,0.,1.3])]:
            v=obj.evaluate(model,pars);S.require(abs(v['joint_nll']-math.exp(-2))<=1e-12 and v['trigger_exposure']==0. and v['mark_logscore']==0. and np.all(v['gradient'][2:]==0.),'ZERO_HISTORY_EMPTY_WINDOW')
    return dict(passed=True,checks=3)
def zero_annual():
    block=next(R.blocks(0));exposure=dict(immigrant_exposure=2.,trigger_exposure=3.,triggered_integrated_intensity=.6,integrated_intensity=2.6,cell_integrated_intensity=[2.6/9]*9,zone_integrated_intensity=[2.6/3]*3)
    state=dict(identity=dict(arm_id=S.PRIMARY[0],logical_arm_window_id='fixture',actual_procedure_id='fixture',selected_candidate_id=0),event_time=[],event_excess=[],beta=2.,logs={name:[] for name in ['point','cell','zone','ground']})
    row=R.reduce_block(state,block,exposure)
    S.require(row['target_count']==0 and row['event_ground_log']==row['mark_logscore']==row['conditional_location_logscore']==0 and row['timing_logscore']==row['joint_logscore']==-2.6 and all(v is None for v in row['per_target'].values()),'ZERO_ANNUAL_EXPOSURE_RETAINED')
    return dict(passed=True,checks=1)
def main():
    p=argparse.ArgumentParser();p.add_argument('--protocol',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    try:
        protocol=S.read(a.protocol);dll=verify(protocol);out=Path(a.output);out.mkdir(parents=True,exist_ok=True);law=law_controls();S.write(out/'threshold_controls.json',law);S.write(out/'zero_history_controls.json',zero_history(out,dll));S.write(out/'zero_annual_controls.json',zero_annual())
        from ..external_replication import machine_controls as M
        M.G=Geometry(dll,dict(scenario_id=S.ID,scenario_minimum_magnitude='4.5',scenario_excess_arithmetic=S.LAW,scenario_input_sha256=protocol['data']['sha256'],base_catalogue_sha256=S.BASE_SHA));M.Objective=lambda path:Objective(path,dll_path=dll);M.source_pins=lambda:core_pins(dll);M.verify=lambda p,mode:verify(p)
        old=sys.argv;sys.argv=['machine_controls','--protocol',a.protocol,'--output',str(out/'machine')]
        try:code=M.main()
        finally:sys.argv=old
        S.require(code==0,'INHERITED_NUMERICAL_CONTROLS');print(json.dumps(dict(status='passed',threshold_checks=12,zero_history_checks=3,inherited_machine_controls=True)));return 0
    except Exception as e:print(json.dumps(dict(status='failed',fixed_error_code='M45_CONTROLS_FAILED',error_type=type(e).__name__)));return 1
if __name__=='__main__':raise SystemExit(main())
