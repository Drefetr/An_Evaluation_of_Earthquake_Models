"""Bounded supplementary G3 controls; handcrafted data and explicitly mocked fits.

No empirical catalogue is read. Real numerical work is limited to existing DLL
fixed-parameter evaluations, analytic geometry and training nuisance arithmetic.
Real workflow scheduling is exercised with process-local fit/cache/forecast mocks;
those mocked80start/11floor slots are NOT executed optimization denominators.
"""
from pathlib import Path
import argparse,copy,hashlib,json,math,sys,time
import numpy as np

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def history_hash(raw):return hashlib.sha256(b''.join(np.ascontiguousarray(raw[k],dtype=np.float64).tobytes() for k in ['times','excess','latitude','longitude'])).hexdigest()
def scaffold():
    lat_edges=np.array([32.,32.+5/3,32.+10/3,37.]);lon_edges=np.array([-121.,-121.+7/3,-121.+14/3,-114.]);centers=np.array([[(lat_edges[i]+lat_edges[i+1])/2,(lon_edges[j]+lon_edges[j+1])/2] for i in range(3) for j in range(3)])
    ll=np.vstack([np.tile(centers,(12,1)),centers[[0,4,8]]+np.array([.01,.01])])
    return dict(times=np.r_[np.arange(108,dtype=float),[121.,125.,125.]],excess=np.r_[np.tile(-np.log1p(-np.linspace(.005,.995,18))/2.85,6),[.1,.4,.8]],latitude=ll[:,0],longitude=ll[:,1])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--study',default=str(Path(__file__).resolve().parents[3]));ap.add_argument('--protocol',required=True);ap.add_argument('--output',required=True);ap.add_argument('--expected-source-sha256',required=True);ap.add_argument('--stage-seconds',type=float,default=90.);args=ap.parse_args()
    if sha(__file__)!=args.expected_source_sha256:raise ValueError('SUPPLEMENT_SOURCE_IDENTITY')
    if not 0<args.stage_seconds<=300:raise ValueError('SUPPLEMENT_DEADLINE')
    sys.path.insert(0,str(Path(args.study).resolve()))
    from source.research.external_replication import geometry as G,workflow as W
    from source.research.external_replication.catalogue import Catalogue
    from source.research.external_replication.compiled_objective import Objective
    protocol=W.read(args.protocol);W.verify(protocol,'controls');out=Path(args.output);out.mkdir(parents=True,exist_ok=False);deadline=time.monotonic()+args.stage_seconds;checks=[];real_calls=0
    def tick():
        if time.monotonic()>=deadline:raise TimeoutError('SUPPLEMENT_STAGE_DEADLINE')
    def check(name,condition):
        if not bool(condition):raise ValueError('SUPPLEMENT_CONTROL_FAILED:'+name)
        checks.append(name)
    W.write(out/'case_plan.json',dict(kind='handcrafted_supplemental_controls',cases=['future_valid_mutation_and_append','duplicate_coordinate_row_identity_loo','real_workflow_mock_selector_lineage'],maximum_stage_seconds=args.stage_seconds,planned_fixed_parameter_dll_evaluations=18,planned_boundary_rectangle_batches=12,planned_mock_procedures=10,planned_mock_start_slots=80,planned_mock_floor_slots=11,executed_real_optimizer_fits=0,random_histories_generated=0,empirical_inputs=False))
    raw=scaffold();changed={k:v.copy() for k,v in raw.items()};future=changed['times']>=120.;changed['times'][future]+=1.;changed['excess'][future]=[1.2,.01,2.];changed['latitude'][future]+=[.11,-.12,.13];changed['longitude'][future]+=[.17,-.18,.19]
    append_values={'times':129.,'excess':.33,'latitude':raw['latitude'][0]+.02,'longitude':raw['longitude'][0]+.02};appended={k:np.r_[changed[k],append_values[k]] for k in raw}
    histories={'base':raw,'mutated_future':changed,'mutated_and_appended_future':appended};nuisance={};numerical={};scores={};feature_hashes={}
    check('three_distinct_full_input_identities',len({history_hash(v) for v in histories.values()})==3)
    fixed=[('E_fixed',[-2.,.1,.25]),('E_free',[-2.,.1,.25,math.log(.6)]),('E_omori',[-2.,.1,.25,math.log(.25),1.45])]
    for label,r in histories.items():
        tick();t,q,lat,lon=[r[k] for k in ['times','excess','latitude','longitude']];cells=G.cell_ids(lat,lon);tr=(t>=18.)&(t<120.);pi,counts,_=G.cell_proportions(cells,tr);beta,policy=G.fit_conditional_beta(q[tr]);xy=G.project(lat[tr],lon[tr]);kde=G.select_bandwidth(xy,pi,G.SCALES,training_cells=cells[tr]);nuisance[label]=dict(beta=beta,pi=pi,training_cell_counts=counts,loo=kde)
        if label!='base':
            check(label+'_beta_unchanged',beta==nuisance['base']['beta']);check(label+'_pi_counts_unchanged',np.array_equal(pi,nuisance['base']['pi']) and np.array_equal(counts,nuisance['base']['training_cell_counts']));check(label+'_all_six_loo_scores_and_selected_h_unchanged',kde==nuisance['base']['loo'])
        numerical[label]={};scores[label]={};feature_hashes[label]={}
        for spatial in ['cont','lift']:
            tick();arrays,metadata=G.make_geometry(t,q,cells,lat,lon,beta,18.,120.,pi,family='continuous' if spatial=='cont' else 'center',sigma=50.,T0=140.,background='kde',kde_bandwidth=kde['selected_bandwidth'],background_training_xy=xy,background_training_cells=cells[tr],metadata=dict(catalogue_sha256=history_hash(r),fixture_variant=label))
            values={k:v for k,v in arrays.items() if k!='metadata_json'};numerical[label][spatial]=values;feature_hashes[label][spatial]={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in values.items()};path=out/f'future_{label}_{spatial}.npz';G.save_geometry(path,arrays)
            if label!='base':check(label+'_'+spatial+'_every_numeric_cache_array_unchanged',set(values)==set(numerical['base'][spatial]) and all(np.array_equal(values[k],numerical['base'][spatial][k]) for k in values))
            with Objective(path) as obj:
                scores[label][spatial]={}
                for model,pars in fixed:
                    tick();v=obj.evaluate(model,pars);real_calls+=1;scores[label][spatial][model]=v
                    if label!='base':check(label+'_'+spatial+'_'+model+'_all_fixed_parameter_scores_and_gradient_unchanged',set(v)==set(scores['base'][spatial][model]) and all(np.array_equal(np.asarray(v[k]),np.asarray(scores['base'][spatial][model][k])) for k in v))
    check('bounded_real_dll_call_count',real_calls==18)
    W.write(out/'future_mutation_bundle.json',dict(kind='handcrafted_fixture',histories=histories,nuisance=nuisance,feature_hashes=feature_hashes,fixed_parameter_results=scores,numeric_comparison_excludes_only_metadata_json=True,metadata_policy='Full input identity and cache metadata identity may change; every actual numeric feature and score is invariant.'))

    # Independent row-index reconstruction: count and remove exactly one scored
    # identity; retain all other kernels even at identical coordinates.
    tick();r=raw;t=r['times'];tr=(t>=18.)&(t<120.);cells=G.cell_ids(r['latitude'],r['longitude'])[tr];xy=G.project(r['latitude'][tr],r['longitude'][tr]);_,area,_=G.support();N=len(cells);counts=np.bincount(cells,minlength=9);zones=counts.reshape(3,3).sum(axis=1);records=[]
    check('duplicate_scaffold_has_ten_rows_at_each_coordinate',all(np.count_nonzero(np.all(xy==point,axis=1))==10 for point in xy))
    for production in nuisance['base']['loo']['candidates']:
        tick();h=production['bandwidth'];F=G.rectangle_integrals(xy,h);Z=F.sum(axis=1);expected=[];row_records=[];wrong_drop_all=[];wrong_full_floor=[]
        check('each_duplicate_kernel_unit_domain_mass_'+str(h),np.allclose((F/Z[:,None]).sum(axis=1),1.,rtol=0,atol=1e-13))
        for i in range(N):
            keep=np.arange(N)!=i;c=int(cells[i]);loo_counts=counts.copy();loo_counts[c]-=1;loo_zones=loo_counts.reshape(3,3).sum(axis=1);pi_c=loo_zones[c//3]/(N-1)*(loo_counts[c]+.5)/(loo_zones[c//3]+1.5);floor_density=pi_c/area[c]
            distance2=np.sum((xy[i]-xy[keep])**2,axis=1);components=(1+distance2/h**2)**-2/Z[keep];kde_density=math.fsum(components)/(N-1);density=.05*floor_density+.95*kde_density;expected.append(math.log(density));full_floor=zones[c//3]/N*(counts[c]+.5)/(zones[c//3]+1.5)/area[c];wrong_full_floor.append(math.log(.05*full_floor+.95*kde_density));duplicate_keep=np.all(xy[keep]==xy[i],axis=1)
            check('one_row_count_and_nine_duplicates_'+str(h)+'_'+str(i),loo_counts.sum()==N-1 and loo_counts[c]==counts[c]-1 and int(duplicate_keep.sum())==9 and np.all(components[duplicate_keep]>0))
            drop=np.any(xy!=xy[i],axis=1);bad_components=(1+np.sum((xy[i]-xy[drop])**2,axis=1)/h**2)**-2/Z[drop];wrong_drop_all.append(math.log(.05*floor_density+.95*math.fsum(bad_components)/(N-1)))
            row_records.append(dict(row=i,cell=c,retained_rows=int(keep.sum()),retained_duplicates=int(duplicate_keep.sum()),floor_cell_count=int(loo_counts[c]),floor_zone_count=int(loo_zones[c//3]),floor_density=floor_density,kde_density=kde_density,duplicate_kernel_density_sum=math.fsum(components[duplicate_keep]),loo_density=density))
        value=math.fsum(expected);check('explicit_one_identity_loo_matches_production_'+str(h),abs(value-production['loo_logscore'])<=1e-10);check('not_refitting_floor_counts_is_detectably_wrong_'+str(h),abs(math.fsum(wrong_full_floor)-value)>1e-6);check('dropping_all_coordinate_duplicates_is_detectably_wrong_'+str(h),abs(math.fsum(wrong_drop_all)-value)>1e-6);records.append(dict(bandwidth=h,production_loo_logscore=production['loo_logscore'],explicit_row_identity_logscore=value,incorrect_drop_all_duplicate_logscore=math.fsum(wrong_drop_all),incorrect_full_training_floor_logscore=math.fsum(wrong_full_floor),rows=row_records))
    W.write(out/'duplicate_identity_loo.json',dict(kind='handcrafted_fixture',n_training=N,records=records,production_selection=nuisance['base']['loo']))

    # Generic antiderivative boundary witnesses for independent positive
    # quadrature. No scientific fit or random history is added by this matrix.
    boundary=[]
    for profile in ['california','new_zealand']:
        cfg=G.PROFILES[profile];la=np.asarray(cfg['latitude_edges']);lo=np.asarray(cfg['longitude_edges']);points=[];labels=[]
        for i in [0,3]:
            for j in [0,3]:points.append([la[i],lo[j]]);labels.append('outer_corner_'+str(i)+'_'+str(j))
        for i in [1,2]:
            for j in [0,1,2,3]:points.append([la[i],lo[j]]);labels.append('internal_lat_edge_'+str(i)+'_'+str(j))
        for a,b,label in [(np.nextafter(la[0],la[3]),np.nextafter(lo[0],lo[3]),'just_inside_southwest'),(np.nextafter(la[3],la[0]),np.nextafter(lo[3],lo[0]),'just_inside_northeast'),((la[0]+la[3])/2,lo[1],'internal_lon_edge_1'),((la[0]+la[3])/2,lo[2],'internal_lon_edge_2')]:points.append([a,b]);labels.append(label)
        ll=np.asarray(points);parent_xy=G.project(ll[:,0],ll[:,1],profile);rect,area,_=G.support(profile);cell=G.cell_ids(ll[:,0],ll[:,1],profile);matrices=[]
        for sigma in G.SCALES:
            tick();F=G.rectangle_integrals(parent_xy,sigma,profile=profile);total=F.sum(axis=1)
            # The rectangles override repeats the whole support9times, which
            # intentionally violates its tiling check; do NOT use that wrapper
            # for whole rectangles. The independent oracle reconstructs whole
            # masses from the saved exact bounds and positive quadrature.
            matrices.append(dict(sigma=sigma,rectangle_integrals=F,domain_integral=total))
            check('boundary_positive_finite_mass_'+profile+'_'+str(sigma),np.isfinite(F).all() and np.all(F>0) and np.all(total<np.pi*sigma*sigma))
        boundary.append(dict(profile=profile,labels=labels,latitude=ll[:,0],longitude=ll[:,1],parent_xy=parent_xy,cells=cell,rectangles=rect,cell_areas=area,records=matrices))
    W.write(out/'boundary_rectangle_witnesses.json',dict(kind='handcrafted_geometry_fixture',profiles=boundary,scales=G.SCALES,oracle_scope='Independent positive quadrature must reconstruct rectangle/domain masses; no DLL import in independent consumer.'))

    # Exercise REAL workflow.train_case / score_case using mocks only for fit,
    # cache I/O, nuisance selector and forecast primitives. No minimize is called.
    tick();lt=np.r_[raw['latitude'][:108],raw['latitude'][18:108],raw['latitude'][-3:]];ln=np.r_[raw['longitude'][:108],raw['longitude'][18:108],raw['longitude'][-3:]];qq=np.r_[raw['excess'][:108],raw['excess'][18:108],raw['excess'][-3:]];tt=np.r_[np.arange(198,dtype=float),[211.,215.,215.]];mockraw=dict(times=tt,excess=qq,latitude=lt,longitude=ln);cat=Catalogue(tt,qq,lt,ln,G.cell_ids(lt,ln),tuple('handcrafted-mock:'+str(i) for i in range(len(tt))),history_hash(mockraw),dict(kind='handcrafted_workflow_mock'))
    case=dict(case_id='handcrafted_selector_counterexample',train_start=18.,train_end=210.,test_start=210.,test_end=220.,T0=240.);folder=out/'workflow_mock';calls=[];cache_records=[]
    original=dict(fit_saved=W.fit_saved,Objective=W.Objective,score=W.score,make_geometry=G.make_geometry,save_geometry=G.save_geometry,select_bandwidth=G.select_bandwidth,fit_conditional_beta=G.fit_conditional_beta)
    def fit_stub(folder,spec,cache,starts,floors,deadline,seconds,dependency=True):
        tick()
        if not dependency or len(starts)!=8:raise ValueError('MOCK_DEPENDENCY')
        sigma=float(spec['sigma_km']);base=10. if sigma in [15.,50.] else 12.;candidates=[];slots=[];calls.append(dict(spec=copy.deepcopy(spec),starts=copy.deepcopy(starts),floors=copy.deepcopy(floors),cache=copy.deepcopy(cache)))
        for pars,origin in floors:
            c=dict(candidate_id=len(candidates),pars=pars,origin=origin,evaluation=dict(joint_nll=base+1.));candidates.append(c);slots.append(dict(kind='floor',origin=origin,status='complete',candidate_id=c['candidate_id']))
        for i,pars in enumerate(starts):
            nll=base+(0. if (sigma==15. and i==7) else .01+i*.001 if sigma==15. else i*.001);c=dict(candidate_id=len(candidates),pars=pars,origin='solver',evaluation=dict(joint_nll=nll));candidates.append(c);slots.append(dict(kind='start',slot=i,status='complete',attempts=[dict(finite_feasible=True,pars=pars,tier=0,accepted=True)]))
        selected=min(candidates,key=lambda c:(c['evaluation']['joint_nll'],c['candidate_id']));result=dict(procedure_id=spec['id'],case_id=spec['case'],model=W.TEMPORAL[spec['temporal']],temporal=spec['temporal'],background='smooth',spatial=spec['spatial'],sigma=sigma,role=spec['phase'],complete=True,status='complete',selected=selected,accepted_candidates=candidates,slots=slots,cache_paths=cache,classification='MOCK_NOT_OPTIMIZER_FIT');path=Path(folder)/('fit_'+spec['id']+'.json');W.write(path,result);return result,str(path.resolve())
    def geometry_stub(*pos,**kw):
        start,end=float(pos[6]),float(pos[7]);payload=dict(kind='MOCK_CACHE_NOT_NUMERICAL_NPZ',sigma=kw['sigma'],spatial=kw['family'],start=start,end=end,order=kw['order'],n_events=int(np.count_nonzero((pos[0]>=start)&(pos[0]<end))));cache_records.append(payload);return payload,dict(mock=True)
    def save_stub(path,arrays):W.write(path,arrays);return W.sha(path)
    class ForecastStub:
        def __init__(self,path):self.cache=W.read(path)
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def evaluate(self,*args):
            tick();value=100. if self.cache['sigma']==50. else 0.;return dict(joint_nll=-value,joint_logscore=value)
    try:
        W.fit_saved=fit_stub;G.make_geometry=geometry_stub;G.save_geometry=save_stub;G.fit_conditional_beta=lambda *a,**k:(2.85,dict(kind='MOCK_NUISANCE'));G.select_bandwidth=lambda *a,**k:dict(selected_bandwidth=50.,selected_index=2,candidates=[dict(bandwidth=h,loo_logscore=0.,n_loo=180) for h in G.SCALES],kind='MOCK_LOO_NOT_TRAINING_EVIDENCE')
        row=W.train_case(case,cat,folder,protocol,W.sha(args.protocol),deadline,1.)
        check('real_workflow_exact_six_sigma_selector_order',[c['spec']['sigma_km'] for c in calls if c['spec']['phase']=='primary_selector']==G.SCALES)
        check('real_workflow_tie_uses_first_schedule_ordinal_not_candidate_id',row['selected_sigma']==15. and row['models']['fixedML_smooth_cont']['selected']['candidate_id']>W.read(row['procedures'][2])['selected']['candidate_id'])
        check('main_alias_has_no_additional_fit',len(calls)==10 and row['model_aliases']['fixedML_smooth_cont']['no_additional_fit'] is True and row['model_aliases']['fixedML_smooth_cont']['source_path']==row['procedures'][1] and row['model_aliases']['fixedML_smooth_cont']['source_sha256']==W.sha(row['procedures'][1]))
        check('mock_slot_plan_is_80starts_11floors_not_executed_fits',sum(len(c['starts']) for c in calls)==80 and sum(len(c['floors']) for c in calls)==11)
        duration=case['train_end']-case['train_start'];apoint=float(np.clip(np.log(180./duration),-12,0));cont=row['models']['fixedML_smooth_cont']['selected']['pars'];lift=row['models']['fixedML_smooth_lift']['selected']['pars']
        for c in calls:
            temp=c['spec']['temporal'];floors=c['floors'];poisson=[apoint,0.,0.]+([0.] if temp=='commonML' else [0.,1.3] if temp=='Omori' else []);check('exact_prescribed_poisson_floor_'+c['spec']['id'],floors[0][1]=='poisson_floor' and floors[0][0]==poisson)
            if temp=='commonML':check('exact_nested_fixedML_floor_and_common_starts',floors[1][1]=='fixedML_tau1_floor' and floors[1][0]==cont+[0.] and c['starts']==[cont+[float(np.log(tau))] for tau in protocol['fit_policy']['commonML_tau_starts_days']])
            if temp=='Omori':point=cont if c['spec']['spatial']=='cont' else lift;check('matched_Omori_starts_'+c['spec']['spatial'],len(floors)==1 and c['starts']==[point+[float(np.log(x)),float(p)] for x,p in protocol['fit_policy']['Omori_cp_starts']])
        before_calls=len(calls);selected_before=copy.deepcopy(row['model_aliases']);W.Objective=ForecastStub;W.score=lambda value:dict(value);row=W.score_case(row,cat,folder,protocol)
        check('heldout_mock_preference_never_reselects_or_refits',row['selected_sigma']==15. and len(calls)==before_calls and row['model_aliases']==selected_before)
        pool=row['cross_grid_near_optimal_forecasts'];check('cross_grid_pool_retains_equal_best_15_and50',{p['sigma'] for p in pool}=={15.,50.} and len(pool)==2)
        check('cross_grid_spread_above_001_marks_unknown_without_reselection',row['cross_grid_forecast_spread_nats_per_event']==100./3. and row['cross_grid_forecast_stable'] is False and row['status']=='unknown_incomplete' and all(x['sigma']==15. for x in row['models'].values()))
        W.write(out/'workflow_mock_summary.json',dict(kind='MOCK_SCHEDULING_CONTROL_NOT_FIT_EVIDENCE',calls=calls,cache_records=cache_records,selected_sigma=row['selected_sigma'],mock_procedure_count=10,mock_start_slot_count=80,mock_floor_slot_count=11,executed_real_optimizer_fits=0,cross_grid_forecast_spread_nats_per_event=row['cross_grid_forecast_spread_nats_per_event'],case_status=row['status']))
    finally:
        W.fit_saved=original['fit_saved'];W.Objective=original['Objective'];W.score=original['score'];G.make_geometry=original['make_geometry'];G.save_geometry=original['save_geometry'];G.select_bandwidth=original['select_bandwidth'];G.fit_conditional_beta=original['fit_conditional_beta']
    result=dict(schema_version=1,kind='handcrafted_supplemental_controls',passed=True,checks=checks,check_count=len(checks),fixed_parameter_dll_evaluations=real_calls,executed_real_optimizer_fits=0,random_histories_generated=0,mocked_procedures=10,mocked_start_slots=80,mocked_floor_slots=11,mock_slots_excluded_from_scientific_fit_denominators=True,empirical_inputs=False,production_source_pins=W.source_pins(),supplement_source_sha256=sha(__file__),protocol_sha256=W.sha(args.protocol));W.write(out/'supplemental_controls.json',result);print(json.dumps(dict(passed=True,checks=len(checks),fixed_parameter_dll_evaluations=real_calls,real_optimizer_fits=0)))

if __name__=='__main__':
    try:main()
    except Exception as error:print(json.dumps(dict(passed=False,fixed_error_code='SUPPLEMENTAL_G3_FAILURE',error_type=type(error).__name__)));raise SystemExit(1)
