"""Validated fixed-issued-history ABI v2: no FFI occurs before full admission."""
from pathlib import Path
import ctypes as ct
import numpy as np
try:
    from .compiled_objective import Objective,library
except ImportError:
    from compiled_objective import Objective,library

REQUIRED={'parent_time','parent_excess','parent_fertility','parent_exposure_lo','parent_exposure_hi','parent_cell_mass','event_time','event_excess','event_cell','event_x','event_background_density','background_cell_mass','event_parent_density','mixture_weights','mixture_rates'}

def validate_query(arrays,metadata):
    """Return owned contiguous copies; reject malformed lengths before ctypes reads."""
    try:
        if not isinstance(arrays,dict) or not REQUIRED.issubset(arrays):raise ValueError()
        m={k:float(metadata[k]) for k in ['start','end','T0','beta']}
        if not np.isfinite(list(m.values())).all() or not 0<=m['start']<m['end'] or m['T0']<=0 or m['beta']<=0:raise ValueError()
        if metadata.get('history_policy')!='fixed_preissue' or metadata.get('profile')!='new_zealand':raise ValueError()
        a={k:np.array(arrays[k],dtype=np.float64,order='C',copy=True) for k in REQUIRED}
        if a['event_time'].ndim!=1 or a['parent_time'].ndim!=1:raise ValueError()
        ne=a['event_time'].size;np_=a['parent_time'].size
        if ne>2147483647 or np_>2147483647:raise ValueError()
        shapes={k:(ne,) for k in ['event_time','event_excess','event_cell','event_x','event_background_density']}
        shapes.update({k:(np_,) for k in ['parent_time','parent_excess','parent_fertility','parent_exposure_lo','parent_exposure_hi']})
        shapes.update(parent_cell_mass=(np_,9),event_parent_density=(ne,np_),background_cell_mass=(9,),mixture_weights=(195,),mixture_rates=(195,))
        if any(a[k].shape!=v for k,v in shapes.items()) or any(not np.isfinite(v).all() for v in a.values()):raise ValueError()
        t=a['parent_time'];et=a['event_time'];cell=a['event_cell']
        if np.any(t<0) or np.any(np.diff(t)<0) or np.any(t>=m['start']) or np.any(np.diff(et)<0) or np.any(et<m['start']) or np.any(et>=m['end']):raise ValueError()
        if np.any(a['event_excess']<0) or np.any(a['parent_excess']<0) or np.any(cell!=np.floor(cell)) or np.any(cell<0) or np.any(cell>=9):raise ValueError()
        if not np.array_equal(a['event_x'],2*et/m['T0']-1) or not np.array_equal(a['parent_exposure_lo'],m['start']-t) or not np.array_equal(a['parent_exposure_hi'],m['end']-t):raise ValueError()
        expected=.3*np.exp(.7*m['beta']*a['parent_excess'])
        if not np.isfinite(expected).all() or not np.allclose(a['parent_fertility'],expected,rtol=1e-13,atol=0):raise ValueError()
        for k in ['parent_fertility','parent_cell_mass','event_parent_density','event_background_density','background_cell_mass','mixture_weights','mixture_rates']:
            if np.any(a[k]<=0):raise ValueError()
        if abs(a['background_cell_mass'].sum()-1)>1e-12 or abs(a['mixture_weights'].sum()-1)>1e-12 or np.any(abs(a['parent_cell_mass'].sum(axis=1)-1)>1e-12):raise ValueError()
        mark_total=ne*np.log(m['beta'])-m['beta']*a['event_excess'].sum()
        if not np.isfinite(mark_total):raise ValueError()
        m['mark_log_density_sum']=float(mark_total)
        return a,m
    except Exception:raise ValueError('FIXED_QUERY_ADMISSION') from None

class FixedObjectiveV2(Objective):
    def __init__(self,arrays,metadata,dll_path=None):
        self.handle=None
        a,m=validate_query(arrays,metadata)  # This must precede library()/ct.CDLL().
        self.arrays=a;self.metadata=m;self.ne=len(a['event_time']);self.np=len(a['parent_time'])
        self.lib,self.dll_path=library(dll_path);pd=ct.POINTER(ct.c_double)
        self.lib.ts_create_query.argtypes=[ct.c_int]*3+[pd]*14;self.lib.ts_create_query.restype=ct.c_void_p
        names=['parent_time','event_time','event_x','event_cell','event_background_density','background_cell_mass','event_parent_density','parent_cell_mass','parent_fertility','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates']
        meta=np.array([m['start'],m['end'],m['T0'],m['mark_log_density_sum']],dtype=np.float64)
        if not np.isfinite(meta).all():raise ValueError('FIXED_QUERY_MARK_TOTAL')
        self.handle=self.lib.ts_create_query(self.ne,self.np,195,*[a[n].ctypes.data_as(pd) for n in names],meta.ctypes.data_as(pd))
        if not self.handle:raise ValueError('FIXED_QUERY_CREATE')
