"""Fail-closed metadata admission, fresh raw authority and selected-fit binding.

No production imports, cache loading, DLL loading or state exchange. Scientific
dependencies are imported only inside admitted local execution functions.
"""
from __future__ import annotations
import importlib.util
import os
import sys
from pathlib import Path
from .common import (ARMS, DESIGN_HASHES, TARGETS, TRAIN_COUNTS, THREAD_ENV,
                     YEARS, absolute, close, day, need, pin_map, pinned, read, read_pinned, sha)

INHERITED = ('__init__.py', 'oracle.py', 'raw_input.py', 'raw_input_v3.py',
             'empirical_io_v2.py', 'audit_machine_bundle.py',
             'oracle_known_v1.py', 'nuisance_oracle.py')
OWN = ('__init__.py', '__main__.py', 'common.py', 'authority.py', 'oracle.py',
       'compare.py', 'controls.py')
EXTENSIONS = frozenset(('.py', '.pyd', '.dll', '.exe', '.zip'))

def inventory(root):
    root = absolute(root); out = {}
    for p in root.rglob('*'):
        if p.is_file() and p.suffix.lower() in EXTENSIONS and '__pycache__' not in p.parts:
            need(not p.is_symlink(), 'RUNTIME_LINK_UNSUPPORTED')
            out[p.relative_to(root).as_posix()] = sha(p)
    return out

def runtime(metadata):
    need(all(os.environ.get(k) == '1' for k in THREAD_ENV), 'SINGLE_THREAD_ENV_REQUIRED')
    need(sys.flags.dont_write_bytecode == 1 and sys.pycache_prefix is not None, 'FRESH_BYTECODE_PREFIX_AND_B_REQUIRED')
    prefix = absolute(sys.pycache_prefix)
    need(prefix.is_dir() and not any(prefix.rglob('*.pyc')), 'BYTECODE_PREFIX_NOT_EMPTY')
    need(absolute(metadata['python_executable_path']) == Path(sys.executable).resolve(), 'INTERPRETER_PATH')
    pinned(sys.executable, metadata['python_executable_sha256'])
    trees = metadata['runtime_tree_pins']; need(isinstance(trees, dict) and trees, 'RUNTIME_TREES_REQUIRED')
    roots = {str(absolute(p)): v for p, v in trees.items()}
    required = {str(Path(sys.prefix).resolve()), str(Path(sys.base_prefix).resolve())}
    for package in ('numpy', 'scipy'):
        spec = importlib.util.find_spec(package)
        need(spec is not None and spec.submodule_search_locations, 'SCIENTIFIC_RUNTIME_MISSING')
        required.add(str(Path(next(iter(spec.submodule_search_locations))).resolve()))
    need(required <= set(roots), 'RUNTIME_ROOT_CLOSURE')
    for root, expected in roots.items():
        need(isinstance(expected, dict) and expected and inventory(root) == expected, 'RUNTIME_TREE_CHANGED')
    pin_map(metadata['external_runtime_pins'])

def source_closure(metadata):
    pins = pin_map(metadata['source_pins']); base = Path(__file__).resolve().parent
    imported = [base / name for name in OWN]
    imported += [base.parent / 'external_replication_validation' / name for name in INHERITED]
    for p in imported:
        need(str(p.resolve()) in pins, 'TRANSITIVE_SOURCE_PIN_MISSING')
        pinned(p, pins[str(p.resolve())])
    # Ensure namespace resolution cannot silently use a different validation tree.
    spec = importlib.util.find_spec('external_replication_validation')
    need(spec is not None and spec.origin is not None and
         Path(spec.origin).resolve() == (base.parent/'external_replication_validation/__init__.py').resolve(),
         'VALIDATION_IMPORT_ROOT')
    design = pin_map(metadata['accepted_design_hashes'])
    need(frozenset(design.values()) == DESIGN_HASHES and len(design) == 2, 'ACCEPTED_DESIGN_IDENTITY')
    return pins

def admission(path, expected_sha256, phase):
    obj = read_pinned(path, expected_sha256)
    need(obj.get('schema') == 'score_robustness_execution_admission_v1' and
         obj.get('phase') == phase and obj.get('status') == 'root_frozen', 'PHASE_ADMISSION')
    need(obj.get('upstream_calibration_accepted') is True and
         obj.get('source_review_accepted') is True and obj.get('external_machine_lease_asserted') is True,
         'UPSTREAM_SOURCE_LEASE_GATE')
    # The root owns the live scheduler/process lock. A receipt is identity evidence,
    # not a claim that this module can establish a machine-wide live lease.
    pinned(obj['numerical_lease_receipt_path'], obj['numerical_lease_receipt_sha256'])
    if phase in ('pilot', 'full'):
        need(obj.get('controls_accepted') is True, 'CONTROLS_ACCEPTANCE_REQUIRED')
    if phase == 'full':
        need(obj.get('measured_resource_admission_accepted') is True, 'MEASURED_RESOURCE_GATE')
        pinned(obj['resource_receipt_path'], obj['resource_receipt_sha256'])
    if phase == 'compare':
        need(obj.get('independent_process_terminal_verified') is True and
             obj.get('production_process_terminal_verified') is True, 'TERMINAL_PROCESSES_REQUIRED')
        for who in ('independent', 'production'):
            pinned(obj[who+'_terminal_receipt_path'], obj[who+'_terminal_receipt_sha256'])
    return obj

ORIGINAL_PROTOCOL_SHA256 = 'ea11c6b98f2d5dfdea8f5e758a4c1a54ab89ae52e8ae370666b27634365a672b'
ORIGINAL_DLL_SHA256 = 'c2452e74fcbe8d9d5c2ca11b99a15d6203f6a22f8361b6a9f8a52dd63819019b'
SEAL_PROTOCOL_ENTRY = 'design/california_observed_protocol_v1.json'

def build_receipts(authority):
    binaries = {str(absolute(authority[k+'_path'])): authority[k+'_sha256']
                for k in ('production_dll', 'exposure_dll')}
    external = pin_map(authority['external_runtime_pins']); found = set()
    for spec in authority['binary_build_receipts']:
        receipt = read_pinned(spec['receipt_path'], spec['receipt_sha256'])
        need(receipt.get('kind') in ('historical_preserved', 'new_root_build','sealed_inherited_identity'), 'BINARY_PROVENANCE_KIND')
        binary = str(pinned(receipt['binary_path'], receipt['binary_sha256']))
        need(binaries.get(binary) == receipt['binary_sha256'] and binary not in found, 'BINARY_BUILD_BINDING')
        if receipt['kind']=='sealed_inherited_identity':
            need(binary==str(absolute(authority['production_dll_path'])) and
                 receipt['compiler_provenance_status']=='unknown' and
                 receipt['seal_manifest_sha256']=='14ee65173bf5f4353cf9075c180b816f0bfeec863886ee2b9217fece0d9accca',
                 'SEALED_INHERITED_BINARY_POLICY')
            seal=read_pinned(receipt['seal_manifest_path'],receipt['seal_manifest_sha256'])
            root = Path(__file__).resolve().parents[6]
            original = root/'research_runs/california_schema_repair_20261025T044000Z'
            expected_binary = root/'work/california_schema_repair_20261025T044000Z/study/source/research/external_replication/objective.dll'
            sealpath = absolute(receipt['seal_manifest_path'])
            protocolpath = pinned(receipt['attesting_protocol_path'],receipt['attesting_protocol_sha256'])
            need(sealpath == (original/'seal_manifest.json').resolve() and
                 protocolpath == (sealpath.parent/SEAL_PROTOCOL_ENTRY).resolve() and
                 protocolpath == absolute(authority['protocol_path']) and
                 receipt['attesting_protocol_sha256'] == ORIGINAL_PROTOCOL_SHA256 and
                 receipt['seal_protocol_entry'] == SEAL_PROTOCOL_ENTRY and
                 Path(binary) == expected_binary.resolve() and receipt['binary_sha256'] == ORIGINAL_DLL_SHA256,
                 'SEALED_CHAIN_PATH_IDENTITY')
            need(all(receipt.get(k) is None for k in ('compiler_path','compiler_sha256','compiler_version','command')),
                 'UNKNOWN_COMPILER_FACTS')
            need(seal['files'][SEAL_PROTOCOL_ENTRY]['sha256'] == ORIGINAL_PROTOCOL_SHA256,'SEALED_PROTOCOL_ENTRY')
            protocol = read_pinned(protocolpath,ORIGINAL_PROTOCOL_SHA256)
            need(protocol['artifact_pins'].get(str(expected_binary.resolve())) == ORIGINAL_DLL_SHA256,
                 'SEALED_PROTOCOL_BINARY_PIN')
        else:
            for name in ('compiler_version', 'command', 'environment'):
                need(bool(receipt.get(name)), 'BUILD_RECEIPT_INCOMPLETE')
            pinned(receipt['compiler_path'], receipt['compiler_sha256'])
        if binary==str(absolute(authority['exposure_dll_path'])):
            need(receipt['kind']=='new_root_build','EXPOSURE_REQUIRES_NEW_BUILD')
        pin_map(receipt['source_pins'])
        dependencies = pin_map(receipt['dependency_pins'])
        need(all(external.get(p) == h for p, h in dependencies.items()), 'BINARY_DEPENDENCY_CLOSURE')
        found.add(binary)
    need(found == set(binaries), 'BOTH_BINARY_RECEIPTS_REQUIRED')

def prepare_authority(path, expected_sha256):
    authority_path = absolute(path); a = read_pinned(authority_path, expected_sha256)
    need(a.get('schema') == 'score_robustness_authority_v1' and a.get('profile') == 'california', 'AUTHORITY_SCHEMA')
    sources = source_closure(a); runtime(a); build_receipts(a)
    scientific = pin_map(a['raw_input_pins'])
    fit_pins = pin_map(a['fit_record_pins'])
    need(a['protocol_sha256']=='ea11c6b98f2d5dfdea8f5e758a4c1a54ab89ae52e8ae370666b27634365a672b', 'ORIGINAL_PROTOCOL_BYTES')
    protocol_path = absolute(a['protocol_path']); protocol = read_pinned(protocol_path,a['protocol_sha256'])
    need(protocol.get('status') == 'frozen' and protocol.get('science_gate_passed') is True and
         protocol.get('protected_release_authorized') is True, 'ORIGINAL_PROTOCOL_ADMISSION')
    need(protocol['data']['sha256'] == a['catalogue_sha256'] and
         absolute(protocol['data']['catalogue']) == absolute(a['catalogue_path']), 'PROTOCOL_CATALOGUE_BINDING')
    pinned(a['catalogue_path'], a['catalogue_sha256'])
    need(protocol['era']['T0_days'] == 16436 and len(protocol['cases']) == 3 and
         protocol['common_nuisance']['productivity']['r'] == .7 and
         protocol['common_nuisance']['excess_cut'] == .5, 'ORIGINAL_OBSERVATION_LAW')
    raw_run = absolute(a['raw_authority_run'])
    need(raw_run.is_dir(), 'RAW_AUTHORITY_RUN_REQUIRED')
    folds = a['folds']; need(len(folds) == 3 and {f['fold_id'] for f in folds} == {0,1,2}, 'FOLD_ROSTER')
    score_paths = []; training_paths = []
    for f in folds:
        fold = f['fold_id']; need(f['case_id'] == f'california_fold_{fold}', 'CASE_ID')
        training_paths.append(str(pinned(f['training_record_path'], f['training_record_sha256'])))
        records = f['score_records']
        need(len(records) == 4 and {r['arm_id'] for r in records} == set(ARMS), 'FOUR_ARM_ROSTER')
        for r in records: score_paths.append(str(pinned(r['score_path'], r['score_sha256'])))
        spec = protocol['cases'][fold]
        need(spec['id'] == f['case_id'] and spec['fold'] == fold and
             spec['test_start_utc'] == f'{YEARS[fold]}-01-01T00:00:00Z' and
             spec['test_end_utc'] == f'{YEARS[fold]+5}-01-01T00:00:00Z' and
             day(spec['history_start_utc']) == 0. and day(spec['train_start_utc']) == 1826. and
             spec['train_end_utc'] == spec['test_start_utc'], 'EXACT_ORIGINAL_WINDOWS')
    need(len(set(score_paths)) == 12 and len(set(training_paths)) == 3, 'UNIQUE_ARCHIVED_RECORDS')
    return dict(authority=a, protocol=protocol, authority_manifest_sha256=expected_sha256,
                source_pins=sources, raw_input_pins=scientific, fit_record_pins=fit_pins)

def bind_raw(context, budget):
    import numpy as np
    from external_replication_validation import empirical_io_v2 as I
    a = context['authority']; run = Path(a['raw_authority_run'])
    budget.checkpoint('raw_authority_begin', 0)
    train = I.load_ca_lane(run, 'train'); budget.checkpoint('raw_training_bound', 1)
    protected = I.load_ca_lane(run, 'protected'); budget.checkpoint('raw_protected_bound', 2)
    raw = I.merge_ca(train, protected)['raw']
    required = dict(train['bindings']); required.update(protected['bindings'])
    for p, h in required.items(): need(context['raw_input_pins'].get(p) == h, 'UNPINNED_RAW_AUTHORITY_INPUT')
    need(len(raw['times']) == 1272 and len(set(raw['row_ids'])) == 1272, 'POPULATION_1272_INCLUDES_WARMUP')
    need(int(np.count_nonzero(raw['times'] < 1826.)) == 106, 'WARMUP_106_INCLUDED')
    need(np.all(np.diff(raw['times']) >= 0) and np.all(raw['times'] >= 0), 'RAW_CHRONOLOGY')
    # Rebind merged canonical fields to the two independently raw-validated lanes.
    path = pinned(a['catalogue_path'], a['catalogue_sha256'])
    if path.suffix == '.jsonl':
        lines = [__import__('json').loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
        need(lines[0].get('record_type') == 'catalogue_header', 'CANONICAL_JSONL_HEADER')
        canonical = dict(lines[0], events=lines[1:])
    else: canonical = read(path)
    ca = read(run/'inputs/california/train/canonical_model.json')['events']
    cb = read(run/'protected/california/canonical_model.json')['events']
    expected = sorted(ca+cb, key=lambda r:(I.R.utc(r['origin_time_utc']),r['event_id']))
    need(canonical['schema_version'] == 1 and canonical['provenance']['source_snapshot'] == I.COMMIT and
         canonical['events'] == expected, 'MERGED_RAW_CANONICAL_ALL_FIELDS')
    check_event_identity([r['event_id'] for r in expected],raw['row_ids'])
    for p,h in required.items():pinned(p,h)
    for fold, spec in enumerate(context['protocol']['cases']):
        lo, hi = day(spec['test_start_utc']), day(spec['test_end_utc'])
        tr = (raw['times'] >= 1826.) & (raw['times'] < lo)
        need(int(tr.sum()) == TRAIN_COUNTS[fold] and
             int(((raw['times'] >= lo)&(raw['times'] < hi)).sum()) == TARGETS[fold], 'FROZEN_POPULATION_COUNTS')
        need(int((raw['times'] < lo).sum()) == TRAIN_COUNTS[fold]+106, 'FULL_PREHISTORY_COUNTS')
    context['raw_bindings'] = required
    return raw

def bind_window(context, raw, fold, arm):
    import numpy as np
    from external_replication_validation import oracle as O
    a = context['authority']; f = next(x for x in a['folds'] if x['fold_id'] == fold)
    case = read(pinned(f['training_record_path'], f['training_record_sha256']))
    spec = context['protocol']['cases'][fold]; start, end = day(spec['test_start_utc']), day(spec['test_end_utc'])
    expected_case = dict(case_id=f['case_id'], fold_id=fold, T0=16436.,
                         **{k:day(spec[k+'_utc']) for k in ('train_start','train_end','test_start','test_end','history_start')})
    need(case['case'] == expected_case and case['status'] == 'complete' and case['profile'] == 'california' and
         case['catalogue_sha256'] == a['catalogue_sha256'] and case['protocol_sha256'] == a['protocol_sha256'] and
         case['n_train'] == TRAIN_COUNTS[fold], 'SAVED_TRAINING_RECORD_BINDING')
    selected_model = case['models'][arm]
    need(selected_model['complete'] is True and selected_model.get('selected') is not None, 'SELECTED_PROCEDURE_INCOMPLETE')
    pid = selected_model['procedure_id']; alias = case['model_aliases']['fixedML_smooth_cont']
    if arm == 'fixedML_smooth_cont':
        check_alias(alias, selected_model, fold, case['selected_sigma'])
        fit_path = pinned(alias['source_path'], alias['source_sha256'])
        need(context['fit_record_pins'].get(str(fit_path)) == alias['source_sha256'], 'SELECTOR_FIT_PIN')
    else:
        need(pid == f'california_fold_{fold}__main_{arm}', 'ACTUAL_MAIN_PROCEDURE_ID')
        paths = [p for p in case['procedures'] if Path(p).name == f'fit_{pid}.json']
        need(len(paths) == 1, 'SELECTED_FIT_PATH_UNIQUE')
        key = str(absolute(paths[0])); need(key in context['fit_record_pins'], 'SELECTED_FIT_PIN_MISSING')
        fit_path = pinned(key, context['fit_record_pins'][key])
    fit = read(fit_path)
    need(fit['procedure_id'] == pid and fit['case_id'] == f['case_id'] and fit['complete'] is True and
         fit['selected'] == selected_model['selected'] and fit['sigma'] == case['selected_sigma'] and
         fit['sigma'] == selected_model['sigma'], 'ORIGINAL_FIT_RECORD_CONSISTENCY')
    temporal = 'Omori' if arm.startswith('Omori') else 'commonML' if arm.startswith('commonML') else 'fixedML'
    expected_model = {'fixedML':'E_fixed','commonML':'E_free','Omori':'E_omori'}[temporal]
    spatial = 'lift' if arm.endswith('_lift') else 'continuous'
    need(fit['model'] == expected_model and fit['temporal'] == temporal and fit['background'] == 'smooth' and
         fit['spatial'] == ('lift' if spatial == 'lift' else 'cont'), 'ARM_MODEL_MAPPING')
    pars = list(fit['selected']['pars']); bounds = [(-12.,0.),(-2.,2.),(0.,.98)]
    import math
    if temporal == 'commonML': bounds += [(math.log(.001),math.log(20.))]
    if temporal == 'Omori': bounds += [(math.log(.0001),math.log(20.)),(1.01,2.5)]
    need(len(pars) == len(bounds) and all(math.isfinite(x) and lo <= x <= hi for x,(lo,hi) in zip(pars,bounds)), 'PARAMETER_BOUNDS')
    candidates = fit['accepted_candidates']; cid = fit['selected']['candidate_id']
    need(len([c for c in candidates if c['candidate_id'] == cid and c == fit['selected']]) == 1,
         'SELECTED_CANDIDATE_LINEAGE')
    # Verify existing training selection, without replacing or refitting it.
    need(fit['selected'] == min(candidates, key=lambda c:(c['evaluation']['joint_nll'],c['candidate_id'])), 'TRAINING_ONLY_CANDIDATE_SELECTION')
    score_spec = next(r for r in f['score_records'] if r['arm_id'] == arm)
    score_path = pinned(score_spec['score_path'], score_spec['score_sha256']); saved = read(score_path)
    need(score_path.name == f'score_{pid}.json' and saved['procedure_id'] == pid and saved['status'] == 'complete' and
         absolute(saved['training_fit_path']) == fit_path and saved['training_fit_sha256'] == sha(fit_path), 'ARCHIVED_SCORE_FIT_LINEAGE')
    matching = [c for c in saved['all_candidate_forecasts'] if c['candidate_id'] == cid]
    need(len(matching) == 1 and matching[0]['pars'] == pars and
         matching[0]['training_joint_nll'] == fit['selected']['evaluation']['joint_nll'], 'ARCHIVED_FORECAST_SELECTION')
    # No saved event vectors are consumed. Extract scalar/finite-cell references only.
    forecast = saved['forecast']
    refs = {k:forecast[k] for k in ('joint_logscore','timing_logscore','conditional_location_logscore',
            'conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore',
            'timing_event_logscore','timing_exposure_logscore','event_log_point_intensity_sum',
            'event_log_ground_intensity_sum','event_log_intensity_sum','integrated_intensity','trigger_exposure',
            'cell_integrated_intensity','zone_integrated_intensity','cell_point_event_log_intensity_sum','cell_point_logscore')}
    need(all(matching[0]['forecast'][k] == v for k,v in refs.items()), 'SELECTED_SCALAR_SCORE_BINDING')
    tr = (raw['times'] >= 1826.) & (raw['times'] < start)
    pi = O.reference_mass(raw['cells'], tr)
    close(case['reference_pi'], pi.tolist(), 'RAW_REFERENCE_MASS', 1e-12)
    beta = float(case['beta']); need(math.isfinite(beta) and beta > 0, 'MARK_BETA')
    need(case['beta_policy']['policy'] == 'common_training_conditional_bin_MLE' and
         case['beta_policy']['cutoff'] == .5 and case['beta_policy']['n_train'] == TRAIN_COUNTS[fold], 'FROZEN_BETA_RECIPE')
    # Verify the saved conditional-MLE score equation without fitting or selecting.
    q = raw['excess'][tr]; high = q >= .5; nh, nl = int(high.sum()), int((~high).sum())
    residual = math.fsum(q[~high])+math.fsum(q[high]-.5); x = beta*.5
    low = .5*(.5-x/12+x**3/720) if x < 1e-5 else 1/beta-.5/math.expm1(x) if x < 700 else 1/beta
    need(nh>0 and nl>0 and abs(nh/beta+nl*low-residual)<=1e-8*len(q), 'RAW_SAVED_BETA_SCORE_EQUATION')
    bandwidth = float(case['kde_selection']['selected_bandwidth'])
    need(bandwidth in (5.,15.,50.,150.,500.,1500.) and fit['sigma'] in (5.,15.,50.,150.,500.,1500.), 'FROZEN_NUISANCE_GRID')
    need(case['kde_selection']['selection'] == 'training spatial LOO only; subsequent likelihood proper full training KDE', 'TRAINING_BANDWIDTH_RECIPE')
    return dict(fold_id=fold, arm_id=arm, logical_arm_window_id=f'california_fold_{fold}__arm_{arm}',
                actual_procedure_id=pid, selected_candidate_id=cid, start=start, end=end, T0=16436.,
                beta=beta, parameters=pars, temporal=temporal, spatial=spatial,
                sigma=float(fit['sigma']), bandwidth=bandwidth, pi=pi,
                training_mask=tr, archive_reference=refs,
                source_hash_lineage=dict(training_record_sha256=f['training_record_sha256'],
                                         fit_sha256=sha(fit_path), score_sha256=sha(score_path)))

def check_alias(alias, model, fold, sigma):
    need(model['procedure_id'] == alias['source_procedure_id'] and
         model['procedure_id'] == f'california_fold_{fold}__selector_fixedML_smooth_cont_sigma{sigma:g}' and
         alias['source_candidate_id'] == model['selected']['candidate_id'] and
         alias['sigma'] == sigma and alias['no_additional_fit'] is True, 'SELECTOR_ALIAS_BINDING')

def check_event_identity(canonical_ids,raw_ids):
    need(canonical_ids==raw_ids and len(set(raw_ids))==len(raw_ids),'RAW_EVENT_ID_ORDER')
