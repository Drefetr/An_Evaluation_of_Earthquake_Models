"""Data-free manifest validation; referenced scientific records load only in run()."""
import json
import hashlib
import os
import sys
from pathlib import Path
from .native import sha

ARMS=('Omori_smooth_cont','fixedML_smooth_cont','Omori_smooth_lift','commonML_smooth_cont')
INHERITED=('__init__.py','geometry.py','catalogue.py','compiled_objective.py','objective.cpp')
THREADS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')
RUNTIME_SUFFIXES={'.py','.pyd','.dll','.exe','.zip'}
BASELINE_SEAL_SHA256='14ee65173bf5f4353cf9075c180b816f0bfeec863886ee2b9217fece0d9accca'

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),parse_constant=lambda _: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))

def read_pinned(path,digest):
    raw=Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('PIN_CHANGED_AT_READ')
    return json.loads(raw.decode('utf-8-sig'),parse_constant=lambda _: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))

def pinned(path,digest):
    p=Path(path)
    if not p.is_absolute() or not isinstance(digest,str) or len(digest)!=64 or sha(p)!=digest: raise ValueError('PIN_MISSING_OR_CHANGED')
    return p.resolve()

def runtime_files(root):
    root=Path(root).resolve()
    return {str(p.relative_to(root)).replace('\\','/'):sha(p) for p in root.rglob('*') if p.is_file() and p.suffix.lower() in RUNTIME_SUFFIXES and '__pycache__' not in p.parts}

def bind_manifest(path):
    """Return parsed object and identity from the same single byte snapshot."""
    raw=Path(path).read_bytes()
    digest=hashlib.sha256(raw).hexdigest()
    m=json.loads(raw.decode('utf-8-sig'),parse_constant=lambda _: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    if not isinstance(m,dict):raise ValueError('AUTHORITY_OBJECT_REQUIRED')
    return m,digest

def bytecode_policy():
    """Check the launch policy; root creates/supervises a unique empty prefix."""
    prefix=os.environ.get('PYTHONPYCACHEPREFIX')
    if not sys.dont_write_bytecode or not prefix or not Path(prefix).is_absolute():raise ValueError('SOURCE_ONLY_BYTECODE_POLICY')
    directory=Path(prefix).resolve()
    if sys.pycache_prefix is None or Path(sys.pycache_prefix).resolve()!=directory or not directory.is_dir() or any(directory.iterdir()):raise ValueError('FRESH_BYTECODE_PREFIX_REQUIRED')
    return dict(mode='fresh_exclusive_prefix_plus_B',PYTHONPYCACHEPREFIX=str(directory),dont_write_bytecode=True,verified_empty_at_admission=True,exclusive_lifecycle_owner='root_process_supervisor')

def check_manifest(path):
    m,digest=bind_manifest(path)
    validate_manifest(m)
    # Additional metadata (including a caller's _digest) never replaces this
    # out-of-band identity. Later path replacement cannot relabel consumed m.
    return m,digest

ORIGINAL_PROTOCOL_SHA256 = 'ea11c6b98f2d5dfdea8f5e758a4c1a54ab89ae52e8ae370666b27634365a672b'
ORIGINAL_DLL_SHA256 = 'c2452e74fcbe8d9d5c2ca11b99a15d6203f6a22f8361b6a9f8a52dd63819019b'
SEAL_PROTOCOL_ENTRY = 'design/california_observed_protocol_v1.json'

def validate_sealed_inherited(receipt,production_path):
    """Identity admission only; absent original compiler facts stay unknown."""
    if Path(receipt['binary_path']).resolve()!=Path(production_path).resolve():raise ValueError('SEALED_KIND_ONLY_PRODUCTION_DLL')
    if receipt.get('compiler_provenance_status')!='unknown':raise ValueError('SEALED_COMPILER_PROVENANCE_STATUS')
    if any(receipt.get(k) is not None for k in ('compiler_path','compiler_sha256','compiler_version','command')):raise ValueError('UNKNOWN_COMPILER_FACTS_MUST_REMAIN_NULL')
    if receipt['seal_manifest_sha256']!=BASELINE_SEAL_SHA256:raise ValueError('SEALED_AUTHORITY_IDENTITY')
    sealpath=pinned(receipt['seal_manifest_path'],receipt['seal_manifest_sha256'])
    seal=read_pinned(sealpath,receipt['seal_manifest_sha256'])
    root=Path(__file__).resolve().parents[6]
    original=root/'research_runs/california_schema_repair_20261025T044000Z'
    expected_binary=root/'work/california_schema_repair_20261025T044000Z/study/source/research/external_replication/objective.dll'
    protocolpath=pinned(receipt['attesting_protocol_path'],receipt['attesting_protocol_sha256'])
    if (sealpath != (original/'seal_manifest.json').resolve() or
        protocolpath != (sealpath.parent/SEAL_PROTOCOL_ENTRY).resolve() or
        receipt['attesting_protocol_sha256'] != ORIGINAL_PROTOCOL_SHA256 or
        receipt['seal_protocol_entry'] != SEAL_PROTOCOL_ENTRY or
        Path(production_path).resolve() != expected_binary.resolve() or
        receipt['binary_sha256'] != ORIGINAL_DLL_SHA256):raise ValueError('SEALED_CHAIN_PATH_IDENTITY')
    if seal['files'][SEAL_PROTOCOL_ENTRY]['sha256'] != ORIGINAL_PROTOCOL_SHA256:raise ValueError('SEALED_PROTOCOL_ENTRY')
    protocol=read_pinned(protocolpath,ORIGINAL_PROTOCOL_SHA256)
    if protocol['artifact_pins'].get(str(expected_binary.resolve())) != ORIGINAL_DLL_SHA256:raise ValueError('SEALED_PROTOCOL_BINARY_PIN')

def validate_manifest(m):
    bytecode_policy()
    if m.get('schema')!='score_robustness_authority_v1' or m.get('profile')!='california': raise ValueError('AUTHORITY_SCHEMA')
    for prefix in ('protocol','catalogue','production_dll','exposure_dll','python_executable'):
        pinned(m[prefix+'_path'],m[prefix+'_sha256'])
    if Path(m['python_executable_path']).resolve()!=Path(sys.executable).resolve(): raise ValueError('PYTHON_EXECUTABLE')
    if any(os.environ.get(k)!='1' for k in THREADS): raise ValueError('SINGLE_THREAD_REQUIRED')
    sources={str(Path(p).resolve()):h for p,h in m['source_pins'].items()}
    module=Path(__file__).resolve().parent
    required=[p for p in module.iterdir() if p.suffix in ('.py','.cpp')]
    required += [module.parent/'external_replication'/n for n in INHERITED]
    for p in required:
        key=str(p.resolve())
        if key not in sources: raise ValueError('RUNTIME_SOURCE_PIN_INCOMPLETE')
    for p,h in sources.items(): pinned(p,h)
    # Includes compiler/CRT/OS loader dependencies outside Python package roots;
    # root freezes the dependency closure from a separately inspected DLL plan.
    external={str(Path(p).resolve()):h for p,h in m['external_runtime_pins'].items()}
    for p,h in external.items():pinned(p,h)
    receipts=m['binary_build_receipts']
    if not receipts:raise ValueError('BUILD_RECEIPTS_MISSING')
    built={}
    for item in receipts:
        receipt=read(pinned(item['receipt_path'],item['receipt_sha256']))
        kind=receipt.get('kind')
        if kind not in ('historical_preserved','new_root_build','sealed_inherited_identity'):raise ValueError('BUILD_RECEIPT_KIND')
        binary=pinned(receipt['binary_path'],receipt['binary_sha256'])
        if binary==Path(m['exposure_dll_path']).resolve() and kind!='new_root_build':raise ValueError('EXPOSURE_REQUIRES_NEW_BUILD_PROVENANCE')
        if kind=='sealed_inherited_identity':validate_sealed_inherited(receipt,m['production_dll_path'])
        else:
            pinned(receipt['compiler_path'],receipt['compiler_sha256'])
            if receipt.get('compiler_provenance_status','known')!='known' or not receipt.get('command') or not receipt.get('compiler_version') or not receipt.get('environment'):raise ValueError('BUILD_RECEIPT_INCOMPLETE')
        if not receipt.get('source_pins'):raise ValueError('BUILD_SOURCE_PINS')
        for p,h in receipt['source_pins'].items():
            pinned(p,h)
            if sources.get(str(Path(p).resolve()))!=h:raise ValueError('BUILD_SOURCE_BINDING')
        if not receipt.get('dependency_pins'):raise ValueError('BUILD_DEPENDENCY_PINS')
        for p,h in receipt['dependency_pins'].items():
            pinned(p,h)
            if external.get(str(Path(p).resolve()))!=h:raise ValueError('BUILD_DEPENDENCY_BINDING')
        if str(binary) in built:raise ValueError('DUPLICATE_BUILD_RECEIPT')
        built[str(binary)]=receipt['binary_sha256']
    for prefix in ('production_dll','exposure_dll'):
        if built.get(str(Path(m[prefix+'_path']).resolve()))!=m[prefix+'_sha256']:raise ValueError('BUILD_BINARY_BINDING')
    if not m.get('accepted_design_hashes'): raise ValueError('DESIGN_PINS')
    for p,h in m['accepted_design_hashes'].items(): pinned(p,h)
    # Every Python source/extension/DLL/executable in interpreter and numpy/scipy
    # trees is pinned. No package imports occur until this comparison succeeds.
    trees={str(Path(p).resolve()):v for p,v in m['runtime_tree_pins'].items()}
    required_roots={str(Path(sys.base_prefix).resolve()),str(Path(sys.prefix).resolve())}
    for name in ('numpy','scipy'):
        candidates=[(Path(p)/name).resolve() for p in sys.path if p and (Path(p)/name/'__init__.py').is_file()]
        if not candidates: raise ValueError('RUNTIME_PACKAGE_MISSING')
        required_roots.add(str(candidates[0]))
    if not required_roots.issubset(trees): raise ValueError('RUNTIME_TREE_PINS_INCOMPLETE')
    for root,expected in trees.items():
        if runtime_files(root)!=expected: raise ValueError('RUNTIME_TREE_CHANGED')
    folds=m['folds']
    if len(folds)!=3 or sorted(x['fold_id'] for x in folds)!=[0,1,2]: raise ValueError('FOLD_ROSTER')
    seen=set()
    for f in folds:
        if f['case_id']!=f"california_fold_{f['fold_id']}": raise ValueError('CASE_ID')
        pinned(f['training_record_path'],f['training_record_sha256'])
        scores=f['score_records']
        if len(scores)!=4 or sorted(s['arm_id'] for s in scores)!=sorted(ARMS): raise ValueError('ARM_ROSTER')
        for s in scores:
            p=pinned(s['score_path'],s['score_sha256'])
            if p in seen: raise ValueError('DUPLICATE_SCORE_PATH')
            seen.add(p)
    # Referenced fit paths are hash-pinned metadata, never guessed filenames.
    for p,h in m['fit_record_pins'].items(): pinned(p,h)

def bind_fit(row,arm,score,manifest):
    if row.get('status')!='complete' or row.get('selector_complete') is not True:raise ValueError('INCOMPLETE_TRAINING_RECORD')
    r=row['models'][arm]
    if not r.get('complete') or not r.get('selected'): raise ValueError('INCOMPLETE_FIT')
    selected=r['selected']; pid=r['procedure_id']; cid=selected['candidate_id']
    if arm=='fixedML_smooth_cont':
        alias=row['model_aliases'][arm]
        if alias['source_procedure_id']!=pid or alias['source_candidate_id']!=cid or alias['sigma']!=row['selected_sigma'] or r['sigma']!=row['selected_sigma'] or alias.get('no_additional_fit') is not True: raise ValueError('FIXEDML_ALIAS')
        if alias['source_path']!=score['training_fit_path'] or alias['source_sha256']!=score['training_fit_sha256']: raise ValueError('FIXEDML_ALIAS_SOURCE')
        expected=f"{row['case']['case_id']}__selector_fixedML_smooth_cont_sigma{row['selected_sigma']:g}"
    else: expected=f"{row['case']['case_id']}__main_{arm}"
    if pid!=expected or score['procedure_id']!=pid or score.get('status')!='complete': raise ValueError('PROCEDURE_IDENTITY')
    fitpath=pinned(score['training_fit_path'],score['training_fit_sha256'])
    pins={str(Path(p).resolve()):h for p,h in manifest['fit_record_pins'].items()}
    if pins.get(str(fitpath))!=score['training_fit_sha256']: raise ValueError('FIT_NOT_ADMITTED')
    saved=read_pinned(fitpath,score['training_fit_sha256'])
    for key in ('procedure_id','case_id','model','temporal','spatial','sigma','selected','complete'):
        if saved.get(key)!=r.get(key): raise ValueError('FIT_EMBEDDING_CHANGED')
    if saved.get('case_id')!=row['case']['case_id']: raise ValueError('FIT_CASE')
    if r['sigma']!=row['selected_sigma']:raise ValueError('FROZEN_SIGMA')
    candidates=[c for c in score['all_candidate_forecasts'] if c['candidate_id']==cid]
    if len(candidates)!=1 or candidates[0]['pars']!=selected['pars'] or candidates[0]['forecast']!=score['forecast']: raise ValueError('SELECTED_CANDIDATE')
    temporal={'fixedML':'E_fixed','commonML':'E_free','Omori':'E_omori'}[arm.split('_')[0]]
    if r['model']!=temporal or r['spatial']!=('lift' if arm.endswith('_lift') else 'cont'): raise ValueError('MODEL_MAPPING')
    return r
