"""Optional resource-admitted annual reconstruction for the fresh M4.5 law.

Reuses independent numerical primitives only. Original M4 target constants and
approved pooled references are never used for M4.5 acceptance.
"""
import argparse
import json
import math
from pathlib import Path
from external_replication_validation import empirical_io_v2 as I
from external_replication_validation import oracle as O
from score_robustness_validation import common as C
from score_robustness_validation import oracle as B
from .source import SCENARIO, TEST, bind_source, pin_protocol


def selected_state(root, protocol, raw, fold, arm):
    """All files were full-audited and are pinned again before this call."""
    import numpy as np
    folder = Path(root)/f'california_fold_{fold}'
    training_path = folder/'training_case.json'
    training = I.read(training_path)
    case = training['case']
    model = training['models'][arm]
    paths = [p for p in training['procedures']
             if Path(p).name == 'fit_'+model['procedure_id']+'.json']
    I.require(len(paths) == 1, 'ANNUAL_SELECTED_FIT_UNIQUE')
    fit_path = Path(paths[0]).resolve()
    fit = I.read(fit_path)
    score_path = folder/('score_'+model['procedure_id']+'.json')
    score = I.read(score_path)
    I.require(I.read(folder/'case.json')['status'] == 'complete' and training['status'] == 'complete'
              and fit['complete'] is True and score['status'] == 'complete',
              'ANNUAL_SCIENTIFIC_PRIMARY_STATUS_REQUIRED')
    I.require(fit['selected'] == model['selected'] and fit['procedure_id'] == model['procedure_id']
              and score['training_fit_sha256'] == I.sha(fit_path)
              and score['forecast'] == next(x['forecast'] for x in score['all_candidate_forecasts']
                                          if x['candidate_id'] == fit['selected']['candidate_id']),
              'ANNUAL_SELECTED_SAVED_BINDING')
    tr = (raw['times'] >= case['train_start']) & (raw['times'] < case['train_end'])
    pi = O.reference_mass(raw['cells'], tr)
    I.require(np.max(abs(pi-np.asarray(training['reference_pi']))) <= 1e-12,
              'ANNUAL_FRESH_REFERENCE_MASS')
    reference_keys = ['joint_logscore', 'timing_logscore', 'conditional_location_logscore',
                      'conditional_zone_logscore', 'conditional_cell_logscore',
                      'within_cell_density_logscore', 'mark_logscore',
                      'timing_event_logscore', 'timing_exposure_logscore',
                      'event_log_point_intensity_sum', 'event_log_ground_intensity_sum',
                      'event_log_intensity_sum', 'integrated_intensity', 'trigger_exposure',
                      'cell_integrated_intensity', 'zone_integrated_intensity',
                      'cell_point_event_log_intensity_sum', 'cell_point_logscore']
    return dict(fold_id=fold, arm_id=arm, logical_arm_window_id=f'california_fold_{fold}__arm_{arm}',
                actual_procedure_id=fit['procedure_id'], selected_candidate_id=fit['selected']['candidate_id'],
                start=case['test_start'], end=case['test_end'], T0=case['T0'], beta=training['beta'],
                train_start=case['train_start'], train_end=case['train_end'],
                parameters=fit['selected']['pars'], temporal=fit['temporal'],
                spatial='continuous' if fit['spatial'] == 'cont' else 'lift',
                sigma=fit['sigma'], bandwidth=training['kde_selection']['selected_bandwidth'],
                pi=pi, training_mask=tr,
                archive_reference={k:score['forecast'][k] for k in reference_keys},
                source_hash_lineage=dict(training_record_sha256=I.sha(training_path),
                                         fit_sha256=I.sha(fit_path), score_sha256=I.sha(score_path)))


def reconstruct_window(raw, state, budget):
    """Independent direct event queries and all calendar exposures, including zero-target years."""
    parent = raw['times'] < state['end']
    event = (raw['times'] >= state['start']) & (raw['times'] < state['end'])
    I.require(int(event.sum()) == TEST[state['fold_id']], 'M45_ANNUAL_WINDOW_TARGET_COUNT')
    g = B.geometry(raw, state, parent, event, budget)
    mixture = O.mixture()
    I.require(len(mixture[0]) == 195, 'DECLARED_195_MODE_MIXTURE')
    logs = B.event_terms(raw, state, parent, event, g, budget, mixture)
    out = []
    for key, lo, hi in C.blocks(state['fold_id']):
        subset = [v for v in logs if lo <= v['time'] < hi]
        row = dict(key, **{k:state[k] for k in ['arm_id', 'logical_arm_window_id',
                                              'actual_procedure_id', 'selected_candidate_id']},
                   target_count=len(subset), status='succeeded', failure_codes=[])
        for component in ('event_ground_log', *C.ATOMIC[2:]):
            row[component] = math.fsum(v[component] for v in subset)
        row.update(B.block_exposure(state['temporal'], state['parameters'], raw['times'][parent],
                                    raw['excess'][parent], state['beta'], lo, hi, state['T0'],
                                    g['parent_cell'], g['background_cell'], budget, mixture))
        C.derived(row)
        row['per_target_mean'] = row['joint_logscore']/len(subset) if subset else None
        out.append(row)
        budget.checkpoint('m45_independent_annual_block', len(out))
    sums = {k:math.fsum(r[k] for r in out) for k in C.COMPONENTS + C.DIAGNOSTICS[:3]}
    sums['cell_integrated_intensity'] = [math.fsum(r['cell_integrated_intensity'][c] for r in out) for c in range(9)]
    sums['zone_integrated_intensity'] = [math.fsum(r['zone_integrated_intensity'][z] for r in out) for z in range(3)]
    sums['cell_point_event_log_intensity_sum'] = [math.fsum(v['point_log'] for v in logs if v['cell'] == c) for c in range(9)]
    sums['cell_point_logscore'] = [sums['cell_point_event_log_intensity_sum'][c]-sums['cell_integrated_intensity'][c] for c in range(9)]
    sums['event_log_point_intensity_sum'] = math.fsum(v['point_log'] for v in logs)
    sums['event_log_intensity_sum'] = sums['event_log_point_intensity_sum']
    sums['event_log_ground_intensity_sum'] = sums['event_ground_log']
    sums['timing_event_logscore'] = sums['event_ground_log']
    sums['timing_exposure_logscore'] = -sums['integrated_intensity']
    whole = B.block_exposure(state['temporal'], state['parameters'], raw['times'][parent],
                             raw['excess'][parent], state['beta'], state['start'], state['end'],
                             state['T0'], g['parent_cell'], g['background_cell'], budget, mixture)
    errors = {k:C.close(sums[k], value, 'M45_ANNUAL_INTERVAL_ADDITIVITY') for k, value in whole.items()}
    for key, expected in state['archive_reference'].items():
        errors['archive_'+key] = C.close(sums[key], expected, 'M45_ANNUAL_WINDOW_RECONCILIATION')
    C.close(sums['joint_logscore'], sums['event_log_point_intensity_sum']-sums['integrated_intensity']+sums['mark_logscore'],
            'M45_ANNUAL_POINT_JOINT_IDENTITY')
    return out, dict(fold_id=state['fold_id'], arm_id=state['arm_id'], status='succeeded',
                     target_count=len(logs), actual_procedure_id=state['actual_procedure_id'],
                     selected_candidate_id=state['selected_candidate_id'], source_hash_lineage=state['source_hash_lineage'],
                     component_sums=sums, archived_reference=state['archive_reference'],
                     max_abs_discrepancies=errors)


def pooled(contrasts):
    out = []
    for cid, _, _, primary, _ in C.CONTRASTS:
        rows = [r for r in contrasts if r['contrast_id'] == cid]
        ok = len(rows) == 15 and all(r['status'] == 'succeeded' for r in rows)
        sums = {k:math.fsum(r[k] for r in rows) for k in C.COMPONENTS} if ok else None
        out.append(dict(contrast_id=cid, status='succeeded' if ok else 'unresolved',
                        target_count=87, primary_component=primary, component_sums=sums,
                        per_target_mean=sums[primary]/87 if ok else None))
    return out


def full_audit_binding(report_path, expected_sha, root, protocol_path, protocol):
    I.require(I.sha(report_path) == expected_sha, 'ANNUAL_FULL_AUDIT_REPORT_HASH')
    report = I.read(report_path)
    I.require(report['schema'] == 'california_m45_independent_audit_v1'
              and report['passed'] is True and report['independent'] is True
              and report['folds'] == [0, 1, 2] and report['full_summary_checked'] is True
              and report['protocol_sha256'] == I.sha(protocol_path)
              and report['input_sha256'] == protocol['data']['sha256']
              and report['denominators']['procedures'] == 30
              and report['denominators']['starts'] == 240 and report['denominators']['floors'] == 33
              and report['denominators']['candidates'] == 273
              and len(report['bindings']) == 103 and len(report['cache_bindings']) == 84,
              'ANNUAL_FULL_AUDIT_REQUIRED')
    I.require(str((Path(root)/'summary_private.json').resolve()) in report['bindings'],
              'ANNUAL_EXACT_AUDITED_OUTPUT_ROOT')
    for group in ['source_bindings', 'bindings', 'cache_bindings','planning_bindings']:
        for path, digest in report[group].items():
            I.require(I.sha(path) == digest, 'ANNUAL_AUDITED_INPUT_CHANGED')


def admission_binding(path, expected_sha, protocol_path, full_audit_sha):
    I.require(I.sha(path) == expected_sha, 'ANNUAL_RESOURCE_ADMISSION_HASH')
    gate = I.read(path)
    I.require(gate['accepted'] is True and gate['protocol_sha256'] == I.sha(protocol_path)
              and gate['full_audit_sha256'] == full_audit_sha
              and gate['scientific_scores_used_for_admission'] is False,
              'ANNUAL_MEASURED_RESOURCE_ADMISSION_REQUIRED')
    I.require(I.sha(gate['exposure_dll']['path']) == gate['exposure_dll']['sha256'],
              'ANNUAL_ADMITTED_EXPOSURE_DLL_HASH_ONLY')
    return gate


def zero_target_year_control():
    """Handcrafted independent empty-year exposure with null per-target mean.

    No empirical data, producer state or DLL. Root executes under its lease.
    """
    import numpy as np
    class FixtureBudget:
        def check(self):
            pass
    row = dict(target_count=0, event_ground_log=0., conditional_zone_logscore=0.,
               conditional_cell_logscore=0., within_cell_density_logscore=0., mark_logscore=0.)
    exposure = B.block_exposure('fixedML', [-2., .1, .25], np.asarray([-1.]), np.asarray([.2]),
                                2., 0., 365., 730., np.full((1, 9), 1./9),
                                np.full(9, 1./9), FixtureBudget(), O.mixture())
    row.update(exposure)
    C.derived(row)
    row['per_target_mean'] = row['joint_logscore']/row['target_count'] if row['target_count'] else None
    I.require(row['integrated_intensity'] > 0 and row['joint_logscore'] < 0
              and row['timing_logscore'] == -row['integrated_intensity']
              and row['joint_logscore'] == -row['integrated_intensity']
              and row['per_target_mean'] is None
              and all(math.isfinite(x) for x in row['cell_integrated_intensity']),
              'INDEPENDENT_ZERO_TARGET_YEAR_EXPOSURE')
    return dict(passed=True, zero_target_year_retained=True, compensator_positive=True,
                event_sums_zero=True, joint_score_negative_compensator=True, per_target_mean_is_null=True)


def compare_production(result, production_path, production_sha, protocol_path,
                       full_audit_sha, admission_path, admission_sha):
    """Compare complete components after independent raw reconstruction."""
    I.require(I.sha(production_path) == production_sha, 'ANNUAL_PRODUCTION_REPORT_HASH')
    production = I.read(production_path)
    I.require(production['schema'] == 'california_m45_annual_v1'
              and production['status'] == 'complete'
              and production['scenario_id'] == SCENARIO
              and production['protocol_sha256'] == I.sha(protocol_path)
              and production['input_sha256'] == result['input_sha256']
              and production['full_audit_sha256'] == full_audit_sha
              and Path(production['full_audit_path']).resolve() == Path(result['full_audit_path']).resolve()
              and production['annual_admission_sha256'] == admission_sha
              and Path(production['annual_admission_path']).resolve() == Path(admission_path).resolve()
              and production['denominators'] == dict(arm_blocks=60, contrast_blocks=45, targets=87),
              'ANNUAL_PRODUCTION_FROZEN_BINDINGS')
    I.require(production['exposure_dll'] == I.read(admission_path)['exposure_dll'],
              'ANNUAL_PRODUCTION_ADMITTED_DLL_BINDING')
    maximum = 0.
    comparisons = 0
    for group, identity in [('arm_blocks', ('fold_id', 'arm_id', 'block_id')),
                            ('contrast_blocks', ('fold_id', 'contrast_id', 'block_id'))]:
        independent_rows = result[group]
        producer_rows = production[group]
        expected_n = 60 if group == 'arm_blocks' else 45
        index = {tuple(r[k] for k in identity):r for r in producer_rows}
        I.require(len(producer_rows) == len(index) == len(independent_rows) == expected_n,
                  'ANNUAL_COMPLETE_UNIQUE_ROW_DENOMINATOR')
        for row in independent_rows:
            saved = index[tuple(row[k] for k in identity)]
            I.require(saved['status'] == row['status'] == 'succeeded'
                      and saved['target_count'] == row['target_count'], 'ANNUAL_ROW_STATUS_TARGET_BINDING')
            names = C.COMPONENTS + (C.DIAGNOSTICS if group == 'arm_blocks' else ())
            if group == 'contrast_blocks':
                names += ('primary_value',)
            for name in names:
                maximum = max(maximum, C.close(row[name], saved[name], 'ANNUAL_PRODUCTION_COMPONENT_RECONCILIATION'))
                comparisons += 1
            for name in C.COMPONENTS:
                if row['target_count'] == 0:
                    I.require(saved['per_target'][name] is None, 'ANNUAL_ZERO_TARGET_MEAN_NULL')
                else:
                    maximum = max(maximum, C.close(row[name]/row['target_count'], saved['per_target'][name],
                                                   'ANNUAL_PRODUCTION_PER_TARGET_RECONCILIATION'))
                    comparisons += 1
            if group == 'contrast_blocks':
                maximum = max(maximum, C.close(row['exposure_contrast'], saved['exposure_contribution'],
                                               'ANNUAL_EXPOSURE_CONTRAST_RECONCILIATION'))
                denominator = math.fsum(r['primary_value'] for r in independent_rows if r['contrast_id'] == row['contrast_id'])
                if denominator:
                    maximum = max(maximum, C.close(row['primary_value']/denominator, saved['signed_share'],
                                                   'ANNUAL_SIGNED_SHARE_RECONCILIATION'))
                else:
                    I.require(saved['signed_share'] is None, 'ANNUAL_ZERO_POOLED_SHARE_NULL')
                comparisons += 2
            if group == 'arm_blocks':
                for name in ['logical_arm_window_id', 'actual_procedure_id', 'selected_candidate_id', 'start_utc', 'end_utc']:
                    I.require(saved[name] == row[name], 'ANNUAL_ROW_SELECTED_WINDOW_LINEAGE')
    checks = {(r['fold_id'], r['arm_id']):r for r in production['window_checks']}
    I.require(len(checks) == len(production['window_checks']) == 12, 'ANNUAL_PRODUCTION_WINDOW_CHECK_DENOMINATOR')
    windows = {(r['fold_id'], r['arm_id']):r for r in production['windows']}
    I.require(len(windows) == len(production['windows']) == 12, 'ANNUAL_PRODUCTION_SELECTED_WINDOW_DENOMINATOR')
    for check in result['window_checks']:
        saved = checks[(check['fold_id'], check['arm_id'])]
        window = windows[(check['fold_id'], check['arm_id'])]
        I.require(saved['target_count'] == check['target_count'] and saved['status'] == 'succeeded', 'ANNUAL_WINDOW_TARGET_BINDING')
        for discrepancy in saved['discrepancies'].values():
            I.require(isinstance(discrepancy, (int, float)) and math.isfinite(discrepancy)
                      and 0 <= discrepancy <= 1e-4, 'ANNUAL_PRODUCER_RECONCILIATION_TOLERANCE')
        for name, value in check['archived_reference'].items():
            maximum = max(maximum, C.close(value, window['archive_reference'][name], 'ANNUAL_WINDOW_ARCHIVE_REFERENCE'))
            comparisons += 1
        for name in ['actual_procedure_id', 'selected_candidate_id']:
            I.require(window[name] == check[name], 'ANNUAL_SELECTED_WINDOW_FIT_LINEAGE')
        lineage = window['source_hash_lineage']
        I.require(lineage['protocol_sha256'] == I.sha(protocol_path) and lineage['input_sha256'] == result['input_sha256']
                  and lineage['training_case_sha256'] == check['source_hash_lineage']['training_record_sha256']
                  and lineage['score_sha256'] == check['source_hash_lineage']['score_sha256'],
                  'ANNUAL_SELECTED_WINDOW_HASH_LINEAGE')
        independent_state = next(s for s in result['selected_states']
                                 if s['fold_id'] == check['fold_id'] and s['arm_id'] == check['arm_id'])
        for name in ['logical_arm_window_id', 'temporal', 'spatial']:
            I.require(window[name] == independent_state[name], 'ANNUAL_SELECTED_STATE_MODEL_BINDING')
        for name in ['start', 'end', 'T0', 'parameters', 'sigma', 'beta', 'bandwidth', 'train_start', 'train_end']:
            maximum = max(maximum, C.close(window[name], independent_state[name],
                                           'ANNUAL_SELECTED_STATE_NUMERIC_BINDING', tol=1e-12))
            comparisons += 1
    pools = {r['contrast_id']:r for r in production['pooled_checks']}
    I.require(len(pools) == len(production['pooled_checks']) == 3, 'ANNUAL_PRODUCTION_POOLED_DENOMINATOR')
    for pool in result['pooled_checks']:
        saved = pools[pool['contrast_id']]
        I.require(saved['target_count'] == 87 and saved['primary_component'] == pool['primary_component'],
                  'ANNUAL_POOLED_TARGET_PRIMARY_BINDING')
        for name in C.COMPONENTS:
            maximum = max(maximum, C.close(pool['component_sums'][name], saved['component_sums'][name],
                                           'ANNUAL_POOLED_COMPONENT_RECONCILIATION'))
            maximum = max(maximum, C.close(pool['component_sums'][name]/87, saved['per_target'][name],
                                           'ANNUAL_POOLED_MEAN_RECONCILIATION'))
            comparisons += 2
    return dict(passed=True, production_sha256=production_sha, component_comparisons=comparisons,
                maximum_absolute_discrepancy=maximum, absolute_tolerance=1e-4,
                aggregate_release_approved=False)


def reconstruct(root, protocol_path, methods_path, report_path, report_sha, admission_path,
                admission_sha, budget):
    protocol = I.read(protocol_path)
    pin_protocol(protocol, methods_path)
    admission_binding(admission_path, admission_sha, protocol_path, report_sha)
    full_audit_binding(report_path, report_sha, root, protocol_path, protocol)
    raw, source_bindings, admissions = bind_source(protocol)
    rows = C.blank_rows()
    cases = []
    checks = []
    selected_states = []
    budget.reached_state = dict(rows=rows, cases=cases, checks=checks)
    for fold in range(3):
        for arm in C.ARMS:
            status = dict(fold_id=fold, arm_id=arm, status='attempted', failure_codes=[])
            affected = [r for r in rows if r['fold_id'] == fold and r['arm_id'] == arm]
            try:
                budget.check()
                state = selected_state(root, protocol, raw, fold, arm)
                selected_states.append({k:v for k,v in state.items() if k not in ['pi', 'training_mask']})
                rebuilt, check = reconstruct_window(raw, state, budget)
                byid = {r['block_id']:r for r in rebuilt}
                rows = [byid[r['block_id']] if r['fold_id'] == fold and r['arm_id'] == arm else r for r in rows]
                budget.reached_state['rows'] = rows
                checks.append(check)
                status['status'] = 'succeeded'
            except Exception as error:
                code = error.code if isinstance(error, C.AuditError) else 'M45_PRIVATE_ANNUAL_FAILURE'
                status.update(status='unresolved' if isinstance(error, C.Deadline) else 'failed',
                              failure_codes=[code], error_type=type(error).__name__)
                for row in affected:
                    row.update(status=status['status'], failure_codes=[code])
                checks.append(dict(fold_id=fold, arm_id=arm, status=status['status'], failure_codes=[code]))
            cases.append(status)
    contrasts = C.contrast_rows(rows)
    pools = pooled(contrasts)
    complete = all(c['status'] == 'succeeded' for c in cases)
    I.require(len(rows) == 60 and len(contrasts) == 45 and len(cases) == 12, 'ANNUAL_PLANNED_DENOMINATORS')
    return dict(schema='california_m45_annual_blocks_v1', scenario_id=SCENARIO, producer='independent',
                status='succeeded' if complete else 'unresolved', reconstruction_complete=complete,
                protocol_sha256=I.sha(protocol_path), input_sha256=protocol['data']['sha256'],
                full_audit_sha256=report_sha, source_bindings=source_bindings,
                full_audit_path=str(Path(report_path).resolve()),
                annual_admission_path=str(Path(admission_path).resolve()), annual_admission_sha256=admission_sha,
                denominators=dict(arm_blocks=60, contrast_blocks=45, primary_windows=12, targets=87),
                training_admissions=admissions, case_statuses=cases, arm_blocks=rows,
                selected_states=selected_states,
                contrast_blocks=contrasts, window_checks=checks, pooled_checks=pools,
                aggregate_release_approved=False)


def main():
    parser = argparse.ArgumentParser()
    for name in ['root', 'protocol', 'methods', 'full-audit', 'full-audit-sha256',
                 'admission', 'admission-sha256', 'production', 'production-sha256', 'output', 'checkpoints']:
        parser.add_argument('--'+name, required=True)
    parser.add_argument('--seconds', type=float, required=True)
    args = parser.parse_args()
    budget = C.Budget(args.seconds, args.checkpoints)
    try:
        result = reconstruct(args.root, args.protocol, args.methods, args.full_audit,
                             args.full_audit_sha256, args.admission, args.admission_sha256, budget)
        result['zero_target_year_control'] = zero_target_year_control()
        if result['reconstruction_complete']:
            result['production_comparison'] = compare_production(result, args.production, args.production_sha256,
                                                                 args.protocol, args.full_audit_sha256,
                                                                 args.admission, args.admission_sha256)
    except Exception as error:
        state = getattr(budget, 'reached_state', dict(rows=C.blank_rows(), cases=[], checks=[]))
        reached = {(c['fold_id'], c['arm_id']):c for c in state['cases']}
        cases = [reached.get((fold, arm), dict(fold_id=fold, arm_id=arm, status='planned', failure_codes=[]))
                 for fold in range(3) for arm in C.ARMS]
        result = dict(schema='california_m45_annual_blocks_v1', scenario_id=SCENARIO, producer='independent',
                      status='unresolved', reconstruction_complete=False,
                      fixed_error_code='M45_ANNUAL_AUDIT_FAILED', error_type=type(error).__name__,
                      denominators=dict(arm_blocks=60, contrast_blocks=45, primary_windows=12, targets=87),
                      arm_blocks=state['rows'], contrast_blocks=C.contrast_rows(state['rows']),
                      case_statuses=cases, window_checks=state['checks'], aggregate_release_approved=False)
    C.write_new(args.output, result)
    print(json.dumps({k:result[k] for k in ['status', 'reconstruction_complete', 'denominators']}, allow_nan=False))
    return 0 if result['reconstruction_complete'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
