"""Handcrafted v4 completion-time and guarded-query rejection controls. Root leases execution; no network or fits."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse,copy,json,tempfile
import numpy as np
try:
    from . import prospective_v5 as P,typed_query_adapter_v2 as Q
except ImportError:
    import prospective_v5 as P,typed_query_adapter_v2 as Q

def _attach_preparation_fixture(root,P,reg,*,capture_changes=None,completion_changes=None,audit_changes=None,event_changes=None):
    """All-local synthetic receipt graph; no actual source or audit is claimed."""
    import csv,io
    root.mkdir(parents=True,exist_ok=False);parser=Path(reg['capture_policy']['parser_path']);contract=parser.with_name('cohort_contract_v1.json');collector=parser.with_name('capture_v1.py')
    if not collector.exists():collector.write_text('# SYNTHETIC collector identity only\n')
    auditor=root/'audit_geonet_wfs_source_v1.py';auditor.write_text('# SYNTHETIC independent raw-reader identity only\n');fixture=root/'fixture_controls.json';P.write(fixture,dict(kind='fixture_controls',status='passed'))
    historical=root/'historical_acceptance.json';historical_audit=root/'historical_raw_audit.json';P.write(historical,dict(kind='synthetic_history_acceptance',status='passed'));P.write(historical_audit,dict(kind='synthetic_history_audit',status='passed'))
    cutoff='2029-12-30T00:00:00Z';design_frozen='2029-12-30T00:01:00Z';began='2029-12-30T00:02:00Z';received='2029-12-30T00:03:00Z';provenance=dict(source_snapshot='SYN_NONISSUED_WFS_PREPARATION',raw_manifest_sha256='',retrieved_utc=received)
    tokens=dict(publicid='SYN_A',eventtype='earthquake',origintime='2029-12-29T00:00:00Z',modificationtime='',longitude='172',latitude='-41',magnitude=' 5.1 ',depth='-8',magnitudetype='',depthtype='',evaluationmethod='',evaluationstatus='',evaluationmode='',earthmodel='private\taux\x01',usedphasecount='',usedstationcount='',magnitudestationcount='',minimumdistance='',azimuthalgap='',originerror='',magnitudeuncertainty='')
    buffer=io.StringIO(newline='');writer=csv.writer(buffer,lineterminator='\n');writer.writerow(tokens);writer.writerow(tokens.values());raw=root/'raw_response.csv';raw.write_bytes(buffer.getvalue().encode());provenance['raw_manifest_sha256']=P.sha(raw)
    event=dict(event_id='geonet:SYN_A',event_type='earthquake',origin_time_utc=tokens['origintime'],magnitude=tokens['magnitude'],depth_km=tokens['depth'],latitude=tokens['latitude'],longitude=tokens['longitude'],magnitude_type='',source_year=2029,source_line_1based=2,source_public_id='SYN_A',source_tokens=tokens)
    if event_changes:event.update(event_changes)
    broad=root/'canonical_broad_preferred_history.json';canonical=root/'canonical_shallow_m5_history.json';ledger=root/'cohort_reference_exclusion_ledger.json';doc=dict(schema_version=1,catalogue_id='synthetic-preparation',provenance=provenance,events=[event]);P.write(broad,doc);P.write(canonical,doc);P.write(ledger,dict(kind='synthetic_allrow_ledger',rows=[]))
    artifacts={name:P.ref(path) for name,path in dict(raw=raw,broad=broad,canonical=canonical,ledger=ledger).items()};design=root/'frozen_preparation_design.json';query=P.render_query(cutoff);P.write(design,dict(kind='initialization_history_capture_design_nonissued',status='frozen',endpoint=P.WFS_ENDPOINT,cutoff_utc=cutoff,design_frozen_at_utc=design_frozen,query=query,controls=P.EXPECTED_WFS_CONTROLS));admission=root/'preparation_admission.json'
    dependencies={name:P.sha(parser.with_name(name)) for name in P.PARSER_DEPENDENCY_NAMES};source_pins=dict(dependencies,**{'capture_v1.py':P.sha(collector)});P.write(admission,dict(status='accepted',independent_review=True,controls_passed=True,design_sha256=P.sha(design),source_files_sha256=source_pins,cohort_contract_sha256=P.WFS_COHORT_CONTRACT_SHA,fixture_control_receipt=P.ref(fixture)))
    governance={name:P.ref(path) for name,path in dict(design=design,admission=admission,source_program=collector,fixture_control_receipt=fixture,cohort_contract=contract,historical_source_acceptance=historical,historical_raw_source_audit=historical_audit).items()}
    capture=dict(kind='registration_initialization_history_nonissued',status='complete',issued=False,operational_capture=False,cutoff_utc=cutoff,design_frozen_at_utc=design_frozen,actual_request_start_utc=began,actual_receipt_utc=received,archive_data_completed_utc='2029-12-30T00:04:00Z',artifact_refs=artifacts,governance_refs=governance,controls=P.EXPECTED_WFS_CONTROLS,query=query,provenance=provenance,raw_path=str(raw.resolve()),raw_sha256=artifacts['raw']['sha256'],canonical_sha256=artifacts['canonical']['sha256'],broad_canonical_sha256=artifacts['broad']['sha256'],cohort_ledger_sha256=artifacts['ledger']['sha256'],parser_sha256=dependencies['parse_capture.py'],parser_dependency_pins=dependencies,design_sha256=P.sha(design))
    if capture_changes:capture.update(capture_changes)
    capture_path=root/'capture_receipt.json';P.write(capture_path,capture);completion=dict(kind='registration_initialization_history_nonissued_completion',status='complete',issued=False,cutoff_utc=capture['cutoff_utc'],design_frozen_at_utc=capture['design_frozen_at_utc'],actual_request_start_utc=capture['actual_request_start_utc'],actual_receipt_utc=capture['actual_receipt_utc'],actual_archive_completed_utc='2029-12-30T00:05:00Z',capture_receipt=P.ref(capture_path),artifact_refs=artifacts,governance_refs=governance,design=P.ref(design),parser_dependency_pins=dependencies,controls=P.EXPECTED_WFS_CONTROLS,does_not_satisfy_future_daily_capture=True,actual_registration_freeze_must_follow_this_completion=True)
    if completion_changes:completion.update(completion_changes)
    completion_path=root/'capture_completion_receipt.json';P.write(completion_path,completion)
    bound=[raw,broad,canonical,ledger,capture_path,completion_path,parser,contract,*[Path(r['path']) for r in governance.values()]];audit=dict(status='passed',passed=True,independent=True,data_classification='local_verified_source_WFS_CSV',raw_sha256=P.sha(raw),canonical_sha256=P.sha(canonical),capture_receipt=P.ref(capture_path),completion_receipt=P.ref(completion_path),parser_dependency_pins=dependencies,cohort_records=1,bindings={str(path.resolve()):P.sha(path) for path in bound})
    if audit_changes:audit.update(audit_changes)
    audit_path=root/'raw_source_audit.json';P.write(audit_path,audit)
    reg['initial_history']=dict(capture_receipt=P.ref(capture_path),completion_receipt=P.ref(completion_path),raw_source_audit=P.ref(audit_path),raw_auditor_source=P.ref(auditor))
    for path in root.iterdir():
        if path.is_file():reg['artifact_pins'][str(path.resolve())]=P.sha(path)
    reg['artifact_pins'][str(collector.resolve())]=P.sha(collector)
    return reg

def fixture():
    t=np.array([1.,1.,2.]);et=np.array([4.,4.,4.5]);beta=2.;q=np.array([0.,.2,.7]);weights=np.full(195,1/195.)
    a=dict(parent_time=t,parent_excess=q,parent_fertility=.3*np.exp(.7*beta*q),parent_exposure_lo=4.-t,parent_exposure_hi=5.-t,parent_cell_mass=np.full((3,9),1/9),event_time=et,event_excess=np.array([0.,.1,.4]),event_cell=np.array([0.,4.,8.]),event_x=2*et/20.-1,event_background_density=np.full(3,.1),background_cell_mass=np.full(9,1/9),event_parent_density=np.full((3,3),.1),mixture_weights=weights,mixture_rates=np.ones(195))
    return a,dict(start=4.,end=5.,T0=20.,beta=beta,profile='new_zealand',history_policy='fixed_preissue')

def run_controls(output):
    checks=[]
    def passed(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def reject(name,func):
        try:func()
        except (ValueError,KeyError,TypeError):checks.append(name);return
        raise AssertionError(name)
    a,m=fixture();admitted,_=Q.validate_query(a,m);passed('valid_fixture_admitted_without_dll',all(v.flags.c_contiguous for v in admitted.values()))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);del bad[key];reject('missing_'+key,lambda bad=bad:Q.validate_query(bad,m))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);bad[key]=bad[key].reshape(-1)[:-1];reject('short_shape_'+key,lambda bad=bad:Q.validate_query(bad,m))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);bad[key].reshape(-1)[0]=np.nan;reject('nonfinite_'+key,lambda bad=bad:Q.validate_query(bad,m))
    mutations=[('same_day_parent','parent_time',lambda v:np.array([1.,2.,4.])),('parent_unsorted','parent_time',lambda v:v[::-1]),('negative_parent_mark','parent_excess',lambda v:np.array([-.1,.2,.7])),('noninteger_cell','event_cell',lambda v:np.array([.1,4.,8.])),('zero_background','background_cell_mass',lambda v:np.r_[0.,v[1:]]),('wrong_mass','parent_cell_mass',lambda v:v*2),('zero_rate','mixture_rates',lambda v:v*0),('wrong_exposure','parent_exposure_lo',lambda v:v+1),('wrong_trend','event_x',lambda v:v+.01),('wrong_fertility','parent_fertility',lambda v:v*2),('query_at_end','event_time',lambda v:np.array([4.,4.,5.]))]
    for name,key,change in mutations:
        bad=copy.deepcopy(a);bad[key]=change(bad[key]);reject(name,lambda bad=bad:Q.validate_query(bad,m))
    for key,value in [('start',float('nan')),('end',4.),('T0',0.),('beta',-1.),('profile','california'),('history_policy','continuous')]:
        bad=dict(m,**{key:value});reject('metadata_'+key,lambda bad=bad:Q.validate_query(a,bad))
    old_library=Q.library
    def forbidden(*args,**kwargs):raise AssertionError('FFI loaded before shape validation')
    Q.library=forbidden
    try:
        bad=copy.deepcopy(a);bad['parent_cell_mass']=np.zeros((1,9));reject('ffi_preflight_before_library',lambda:Q.FixedObjectiveV2(bad,m))
    finally:Q.library=old_library
    passed('WFS_query_renderer_exact_halfopen_CQL_and_seven_keys',P.render_query('2030-01-01T22:55:00Z')==dict(P.EXPECTED_WFS_QUERY,cql_filter="origintime>='1960-01-01T00:00:00Z' AND origintime<'2030-01-01T22:55:00Z' AND magnitude>=5 AND BBOX(origin_geom,165,-48.5,180,-33.5)") and len(P.render_query('2030-01-01T22:55:00Z'))==7)
    freeze=P.utc('2028-02-28T23:59:59Z');start,end=P.horizon(freeze);passed('leap_day_fixed_endpoint',P.iso(start)=='2028-02-29T00:00:00Z' and P.iso(end)=='2038-02-28T00:00:00Z')
    with tempfile.TemporaryDirectory(prefix='prospective-v5-fixtures-') as td:
        root=Path(td);regpath=root/'fixture_registration.json';P.write(regpath,dict(kind='fixture'));regsha=P.sha(regpath);archive=root/'archive';db=P.connect(archive,regsha,kind='fixture')
        body=dict(kind='fixture',status='missing_unknown',day='2030-01-01');P.append_day(db,regsha,'2030-01-01',body);reject('unique_day_prevents_backfill',lambda:P.append_day(db,regsha,'2030-01-01',dict(kind='fixture',status='issued')));passed('hashchain_verifies',len(P.verify_chain(db,regsha))==1);db.close()
        reject('fixture_archive_rejected_operational',lambda:P.connect(archive,regsha,kind='operational'))
        # Stale capture fails before opening referenced files or trusting caller data.
        capture=root/'stale_capture.json';P.write(capture,dict(schema_version=5,kind='operational_capture',status='complete',registration_sha256=regsha,validity_start_utc='2030-01-02T00:00:00Z',actual_request_start_utc='2029-12-01T22:55:00Z',actual_receipt_utc='2029-12-01T22:56:00Z'))
        reject('old_capture_rejected',lambda:P.validate_capture(P.ref(capture),dict(capture_policy={},freeze_utc='2029-12-31T00:00:00Z'),regsha,P.utc('2030-01-02T00:00:00Z')))
        canonical=root/'non_earthquake.json';P.write(canonical,dict(schema_version=1,events=[dict(event_type='quarry_blast')]))
        reject('non_earthquake_parent_rejected',lambda:P.validate_canonical(canonical,P.sha(canonical)))
        P.write(root/'missing_type.json',dict(schema_version=1,events=[{}]));reject('missing_event_type_rejected',lambda:P.validate_canonical(root/'missing_type.json',P.sha(root/'missing_type.json')))
        for label,depth in [('deep','40.00001'),('unknown','-9'),('nonfinite','NaN'),('missing',None),('rounded_json_number',40.0),('near_boundary','40.000000000000001')]:
            event=dict(event_type='earthquake')
            if depth is not None:event['depth_km']=depth
            bad=root/('depth_'+label+'.json');P.write(bad,dict(schema_version=1,events=[event]));reject('shallow_'+label+'_rejected',lambda bad=bad:P.validate_canonical(bad,P.sha(bad)))
        provenance=dict(source_snapshot='fixture',raw_manifest_sha256='0'*64,retrieved_utc='2030-01-01T00:00:00Z')
        event=dict(event_type='earthquake',event_id='SYN_DEPTH',origin_time_utc='2030-01-01T00:00:00Z',latitude='-41',longitude='172',magnitude='5',magnitude_type='Mw',depth_km='-8',source_year=2030,source_line_1based=1)
        good=root/'other_negative_depth.json';P.write(good,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[event]));passed('other_negative_depth_retained',len(P.validate_canonical(good,P.sha(good)).times)==1)
        event['depth_km']='40';good2=root/'exact_depth40.json';P.write(good2,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[event]));passed('exact40_depth_retained',len(P.validate_canonical(good2,P.sha(good2)).times)==1)
        for label,change in [('magnitude_rounded_below5',dict(magnitude='4.9999999999999999999')),('latitude_rounded_internal_edge',dict(latitude='-43.500000000000001')),('longitude_rounded_internal_edge',dict(longitude='169.99999999999999999')),('longitude_rounded_outside_support',dict(longitude='180.000000000000001'))]:
            altered=dict(event,**change);path=root/(label+'.json');P.write(path,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[altered]));reject(label,lambda path=path:P.validate_canonical(path,P.sha(path)))
        lexical=dict(event,magnitude_type='',magnitude='\t 5.0000 \t',depth_km=' -8 ',source_tokens={'earthmodel':'private\taux\x01','magnitude':'\t 5.0000 \t'})
        lp=root/'allowed_lexical_controls.json';P.write(lp,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[lexical]));passed('blank_magnitude_type_and_outer_numeric_whitespace_and_private_aux_controls_retained',len(P.validate_canonical(lp,P.sha(lp)).times)==1)
        for label,changes in [('global_NUL',{'source_tokens':{'earthmodel':'bad\x00'}}),('embedded_CR',{'source_tokens':{'earthmodel':'bad\r'}}),('embedded_LF',{'source_tokens':{'earthmodel':'bad\n'}}),('ID_C0',{'event_id':'geonet:SYN\tID'}),('ID_DEL',{'event_id':'geonet:SYN\x7fID'}),('cohort_unknown_coordinate',{'latitude':None})]:
            item=dict(lexical,**changes);lp=root/(label+'.json');P.write(lp,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[item]));reject(label,lambda lp=lp:P.validate_canonical(lp,P.sha(lp)))
        # Hash mismatch must be detected even if JSON remains parseable.
        packet=root/'fixture_packet.json';P.write(packet,dict(kind='fixture',status='fixture'));anchored=P.ref(packet);packet.write_text('{"kind":"operational","status":"issued"}')
        reject('mutated_packet_sha_rejected',lambda:P.checked_ref(anchored))
        another=root/'another_archive';reject('unregistered_archive_root_rejected',lambda:P.require_archive(dict(archive_root=str(archive.resolve())),another))
        # A fixture packet can never be admitted through the operational boundary.
        operational=root/'fixture_operational_db';db=P.connect(operational,regsha);packet2=root/'packet2.json';P.write(packet2,dict(schema_version=5,kind='fixture',status='fixture'));P.append_day(db,regsha,'2030-01-02',dict(kind='operational',status='issued',packet=P.ref(packet2)));db.close()
        original=P.verify_registration;P.verify_registration=lambda p:(dict(archive_root=str(operational.resolve())),{})
        try:reject('fixture_packet_rejected_operational_scorer',lambda:P.admitted_packet(regpath,operational,'2030-01-02'))
        finally:P.verify_registration=original
    with tempfile.TemporaryDirectory(prefix='prospective-v5-registration-bindings-') as td:
        root=Path(td);pop=root/'population.json';final=root/'finalization.json';audit=root/'audit.json';parser=root/'parse_capture.py';contract=root/'cohort_contract_v1.json';clarify=root/'control_character_adjudication.json'
        for path in [pop,final,audit,contract,clarify]:P.write(path,dict(kind='handcrafted_test_only'))
        parser.write_text("DEPENDENCY_FILENAMES=('parse_capture.py','cohort_contract_v1.json')\n")
        pins={str((P.HERE/n).resolve()):P.sha(P.HERE/n) for n in P.SOURCE_FILES+P.SOURCE_EXTENSION}
        pins.update({str(path.resolve()):P.sha(path) for path in [pop,final,audit,parser,contract,clarify]})
        policy=dict(completion_window_minutes_before_start=[70,60],max_request_span_seconds=600,canonical_event_type='earthquake',parser_entrypoint='parse_capture',endpoint=P.WFS_ENDPOINT,accept='text/csv',query=dict(P.EXPECTED_WFS_QUERY),completeness_controls=dict(P.EXPECTED_WFS_CONTROLS),max_bytes=1024,timeout_seconds=1,parser_path=str(parser.resolve()),parser_dependencies={path.name:P.ref(path) for path in [parser,contract]})
        reg=dict(schema_version=5,status='frozen',kind='operational',endpoint_rule='same_calendar_date_or_last_day_of_month',freeze_utc='2029-12-31T23:00:00Z',start_utc='2030-01-01T00:00:00Z',end_utc='2040-01-01T00:00:00Z',artifact_pins=pins,population_contract=P.ref(pop),finalization_contract=P.ref(final),control_character_adjudication=P.ref(clarify),archive_root=str((root/'external_archive').resolve()),capture_policy=policy,initialization=dict(independent_audit=P.ref(audit)))
        original=(P.CORRECTED_POPULATION_SHA,P.CORRECTED_FINALIZATION_SHA,P.WFS_COHORT_CONTRACT_SHA,P.CONTROL_CHARACTER_ADJUDICATION_SHA,P.initialization_bindings)
        P.CORRECTED_POPULATION_SHA=P.sha(pop);P.CORRECTED_FINALIZATION_SHA=P.sha(final);P.WFS_COHORT_CONTRACT_SHA=P.sha(contract);P.CONTROL_CHARACTER_ADJUDICATION_SHA=P.sha(clarify);P.initialization_bindings=lambda init:({},{})
        try:
            good=root/'registered_fixture.json';_attach_preparation_fixture(root/'preparation_baseline',P,reg);P.write(good,reg);passed('registration_design_and_dependency_baseline',P.verify_registration(good)[0]==reg)
            mutations=[]
            bad=copy.deepcopy(reg);del bad['population_contract'];mutations.append(('registration_missing_population_contract',bad))
            bad=copy.deepcopy(reg);bad['finalization_contract']['sha256']='0'*64;mutations.append(('registration_wrong_finalization_hash',bad))
            bad=copy.deepcopy(reg);del bad['capture_policy']['parser_dependencies']['cohort_contract_v1.json'];mutations.append(('registration_missing_parser_dependency',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['parser_dependencies']['parse_capture.py']['sha256']='0'*64;mutations.append(('registration_changed_parser_dependency',bad))
            bad=copy.deepcopy(reg);del bad['artifact_pins'][str(contract.resolve())];mutations.append(('registration_unpinned_parser_contract',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['query']['outputFormat']='xml';mutations.append(('registration_wrong_source_format',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['completeness_controls']['schema']='wrong';mutations.append(('registration_wrong_WFS_controls',bad))
            for label,bad in mutations:
                path=root/(label+'.json');P.write(path,bad);reject(label,lambda path=path:P.verify_registration(path))
            bad=copy.deepcopy(reg);del bad['control_character_adjudication'];path=root/'missing_lexical_contract.json';P.write(path,bad);reject('registration_missing_control_character_contract',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);bad['capture_policy']['completeness_controls']['minimum_records']=True;path=root/'typed_boolean_count.json';P.write(path,bad);reject('registration_typed_boolean_not_integer_count',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);bad['capture_policy']['completeness_controls']['forbid_pagination']=1;path=root/'typed_integer_boolean.json';P.write(path,bad);reject('registration_typed_integer_not_boolean_flag',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);bad['capture_policy']['query']['resultType']='hits';path=root/'forbidden_hits.json';P.write(path,bad);reject('registration_forbidden_hits_key',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);del bad['initial_history'];path=root/'no_initial_history.json';P.write(path,bad);reject('registration_missing_initial_history',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);del bad['initial_history']['raw_source_audit'];path=root/'no_raw_audit.json';P.write(path,bad);reject('registration_missing_initial_raw_audit',lambda:P.verify_registration(path))
            bad=copy.deepcopy(reg);del bad['artifact_pins'][bad['initial_history']['capture_receipt']['path']];path=root/'unpinned_preparation.json';P.write(path,bad);reject('registration_unpinned_initial_capture',lambda:P.verify_registration(path))
            baseline_without_history=copy.deepcopy(reg);baseline_without_history.pop('initial_history')
            cases=[
                ('initial_history_cutoff_after_request',dict(capture_changes={'cutoff_utc':'2029-12-31T00:00:00Z'})),
                ('initial_history_request_after_response',dict(capture_changes={'actual_request_start_utc':'2029-12-30T00:03:30Z'})),
                ('initial_history_completion_at_freeze',dict(completion_changes={'actual_archive_completed_utc':reg['freeze_utc']})),
                ('initial_history_wrong_audit_class',dict(audit_changes={'data_classification':'self_reported_fixture'})),
                ('initial_history_audit_not_independent',dict(audit_changes={'independent':False})),
                ('initial_history_audit_passed_flag_only',dict(audit_changes={'bindings':{}})),
                ('initial_history_audit_wrong_raw_hash',dict(audit_changes={'raw_sha256':'0'*64})),
                ('initial_history_audit_wrong_cohort_hash',dict(audit_changes={'canonical_sha256':'0'*64})),
                ('initial_history_canonical_unknown_depth',dict(event_changes={'depth_km':None})),
                ('initial_history_canonical_deep',dict(event_changes={'depth_km':'40.0000000001'})),
                ('initial_history_canonical_unknown_magnitude',dict(event_changes={'magnitude':None})),
                ('initial_history_canonical_nonEQ',dict(event_changes={'event_type':'quarry_blast'}))]
            for label,options in cases:
                bad=copy.deepcopy(baseline_without_history);_attach_preparation_fixture(root/label,P,bad,**options);path=root/(label+'.json');P.write(path,bad);reject(label,lambda path=path:P.verify_registration(path))
            tampered=Path(reg['initial_history']['completion_receipt']['path']);before=tampered.read_bytes();tampered.write_bytes(before+b' ');reject('initial_history_completion_byte_tamper',lambda:P.verify_registration(good));tampered.write_bytes(before)
            P.WFS_COHORT_CONTRACT_SHA='0'*64;reject('registration_wrong_semantic_contract_identity',lambda:P.verify_registration(good))
            P.WFS_COHORT_CONTRACT_SHA=P.sha(contract);parser.write_text("DEPENDENCY_FILENAMES=('parse_capture.py',)\n");bad=copy.deepcopy(reg);bad['artifact_pins'][str(parser.resolve())]=P.sha(parser);bad['capture_policy']['parser_dependencies']['parse_capture.py']=P.ref(parser);wrong=root/'wrong_declared_closure.json';P.write(wrong,bad);reject('registration_wrong_static_parser_closure',lambda:P.verify_registration(wrong))
        finally:P.CORRECTED_POPULATION_SHA,P.CORRECTED_FINALIZATION_SHA,P.WFS_COHORT_CONTRACT_SHA,P.CONTROL_CHARACTER_ADJUDICATION_SHA,P.initialization_bindings=original
    with tempfile.TemporaryDirectory(prefix='prospective-v5-mocked-transport-') as td:
        # Entire end-to-end archive is temporary and uses a mocked transport and
        # test clock. No resulting packet is exported or counts as issued.
        root=Path(td);archive=root/'archive';regpath=root/'mock_registration.json';P.write(regpath,dict(kind='fixture_test_only'))
        parser=root/'mock_parser.py';parser.write_text("def parse_capture(raw,query,provenance,controls):\n    return dict(schema_version=1,catalogue_id='synthetic',provenance=provenance,events=[dict(event_type='earthquake',event_id='geonet:SYN_MOCK',origin_time_utc='2029-12-29T00:00:00Z',latitude='-41',longitude='172',magnitude='5',magnitude_type='',depth_km='-8',source_year=2029,source_line_1based=2)]),dict(complete=True,controls=controls,truncation_detected=False)\n")
        cache=root/'mock_cache.npz';cache.write_bytes(b'fixture-only-not-a-numerical-cache')
        audit=root/'mock_audit.json';P.write(audit,dict(kind='fixture_test_only'));params=root/'mock_params.json';P.write(params,{})
        training=dict(beta=2.,reference_pi=[1/9]*9,kde_selection=dict(selected_bandwidth=50.),selected_sigma=50.,models={mid:dict(model='E_fixed',selected=dict(pars=[-2.,0.,.2]),spatial='cont',sigma=50.,cache_paths=dict(train16=str(cache.resolve()))) for mid in P.MODELS})
        reg=dict(archive_root=str(archive.resolve()),freeze_utc='2029-12-31T23:00:00Z',start_utc='2030-01-01T00:00:00Z',end_utc='2040-01-01T00:00:00Z',capture_policy=dict(endpoint='https://fixture.invalid/no-network',query=dict(P.EXPECTED_WFS_QUERY),accept='text/csv',parser_path=str(parser.resolve()),completeness_controls=dict(fixture=True),max_bytes=1024,timeout_seconds=1),initialization=dict(independent_audit=P.ref(audit),parameter_manifest=P.ref(params)))
        class Response:
            status=200;headers={'Date':'fixture','Last-Modified':None,'Content-Length':'2','Content-Type':'text/csv'}
            def __init__(self,url):self.done=False;self.url=url
            def geturl(self):return self.url
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):
                if self.done:return b''
                self.done=True;return b'{}'
        original_verify=P.verify_registration;original_now=P.now;original_transport=P.urllib.request.urlopen;original_write=P.write;original_ref=P.ref;archive_events=[]
        def tracked_write(path,value):
            result=original_write(path,value)
            if Path(path).name=='forecast_candidate.json':archive_events.append('closed')
            return result
        def tracked_ref(path):
            result=original_ref(path)
            if Path(path).name=='forecast_candidate.json':archive_events.append('hashed')
            return result
        P.write=tracked_write;P.ref=tracked_ref
        clocks=iter([P.utc('2030-01-01T22:55:00Z'),P.utc('2030-01-01T22:56:00Z'),P.utc('2030-01-01T23:05:00Z'),P.utc('2030-01-01T23:05:01Z'),P.utc('2030-01-01T23:05:02Z'),P.utc('2030-01-01T23:05:03Z'),P.utc('2030-01-01T23:06:00Z')])
        def tracked_now():
            value=next(clocks)
            if value==P.utc('2030-01-01T23:05:02Z'):
                passed('completion_sample_follows_close_and_hash',archive_events[-2:]==['closed','hashed']);archive_events.append('completion_sample')
            return value
        P.verify_registration=lambda path:(reg,training);P.now=tracked_now;P.urllib.request.urlopen=lambda request,**kwargs:Response(request.full_url)
        try:
            capture=P.capture_source(regpath,'2030-01-02T00:00:00Z',archive)
            result=P.issue_day(regpath,capture,archive);passed('mock_capture_and_unique_issue',result['status']=='issued' and result['archive_completed_utc']=='2030-01-01T23:05:02Z')
            candidate=P.read(result['packet']['path']);passed('candidate_bytes_alone_stay_unissued',candidate['status']=='prepared_unissued' and candidate['kind']=='forecast_candidate')
            admitted=P.admitted_packet(regpath,archive,'2030-01-02');passed('issued_status_comes_from_ledger',admitted['_verified_ledger_status']=='issued' and admitted['status']=='prepared_unissued');passed('mock_packet_hash_and_capture_mint_verified',admitted['_verified_packet_sha256']==result['packet']['sha256'])
            reject('duplicate_day_issue_rejected',lambda:P.issue_day(regpath,capture,archive))
            packet_path=Path(result['packet']['path']);packet_path.write_text(packet_path.read_text()+' ')
            reject('archived_packet_byte_mutation_rejected',lambda:P.admitted_packet(regpath,archive,'2030-01-02'))
            # A candidate completed at or after midnight is terminally unissued.
            for label,began,prepared,completed in [
                ('cross_midnight','2030-01-01T23:59:59Z','2030-01-01T23:59:59.500000Z','2030-01-02T00:00:00.100000Z'),
                ('early_prepare_exact_boundary','2030-01-01T23:05:00Z','2030-01-01T23:06:00Z','2030-01-02T00:00:00Z')]:
                late_archive=root/label;reg['archive_root']=str(late_archive.resolve())
                complete_dt=P.utc(completed);clocks=iter([P.utc('2030-01-01T22:55:00Z'),P.utc('2030-01-01T22:56:00Z'),P.utc(began),P.utc(prepared),complete_dt,complete_dt+timedelta(microseconds=1)])
                P.now=lambda:next(clocks)
                cap=P.capture_source(regpath,'2030-01-02T00:00:00Z',late_archive)
                late=P.issue_day(regpath,cap,late_archive)
                passed(label+'_unissued',late['status']=='unissued' and late['reason_code']=='ARCHIVE_COMPLETED_LATE' and late['ledger_state']=='missing_unknown')
                failed=P.read(late['attempt']['path']);candidate=P.read(late['candidate']['path'])
                passed(label+'_failure_schema_and_bindings',failed['schema_version']==5 and failed['day']=='2030-01-02' and failed['capture']==cap and failed['packet']==late['candidate'] and failed['source']==dict(path=candidate['source_snapshot_path'],sha256=candidate['source_snapshot_sha256']) and failed['source']['sha256']==P.read(P.checked_ref(cap))['canonical']['sha256'] and P.checked_ref(failed['source']).read_bytes()==P.checked_ref(P.read(P.checked_ref(cap))['canonical']).read_bytes())
                passed(label+'_failure_and_candidate_preserved',failed['status']=='unissued' and failed['archive_completed_utc']==P.iso(complete_dt) and candidate['status']=='prepared_unissued')
                db=P.connect(late_archive,P.sha(regpath));rows=P.verify_chain(db,P.sha(regpath));db.close()
                passed(label+'_no_issued_row',rows['2030-01-02'][0]['status']=='missing_unknown' and not any(v[0]['status']=='issued' for v in rows.values()))
                reject(label+'_operational_admission_rejected',lambda:P.admitted_packet(regpath,late_archive,'2030-01-02'))
                # Even a test clock moved backwards cannot promote the terminal day.
                P.now=lambda:P.utc('2030-01-01T23:59:59.900000Z')
                reject(label+'_cannot_promote_late_candidate',lambda:P.issue_day(regpath,cap,late_archive))
            for label,content_type,changed_url in [('WFS_finalURL_change','text/csv',True),('WFS_XML_content_type','application/xml',False)]:
                bad_archive=root/label;reg['archive_root']=str(bad_archive.resolve());P.now=lambda:P.utc('2030-01-01T22:55:00Z')
                def bad_transport(request,content_type=content_type,changed_url=changed_url,**kwargs):
                    response=Response(request.full_url+('&resultType=hits' if changed_url else ''));response.headers=dict(Response.headers,**{'Content-Type':content_type});return response
                P.urllib.request.urlopen=bad_transport;reject(label,lambda:P.capture_source(regpath,'2030-01-02T00:00:00Z',bad_archive))
        finally:P.verify_registration=original_verify;P.now=original_now;P.urllib.request.urlopen=original_transport;P.write=original_write;P.ref=original_ref
    P.write(output,dict(schema_version=5,kind='fixture_controls',status='passed',checks=checks,check_count=len(checks),network_requests=0,dll_loads=0,fits=0,source_pins={str(Path(__file__).resolve()):P.sha(__file__),str(Path(P.__file__).resolve()):P.sha(P.__file__),str(Path(Q.__file__).resolve()):P.sha(Q.__file__)},scope='handcrafted rejection and archive controls only; no operational issuance or external timestamp attestation'))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args();run_controls(args.output)
