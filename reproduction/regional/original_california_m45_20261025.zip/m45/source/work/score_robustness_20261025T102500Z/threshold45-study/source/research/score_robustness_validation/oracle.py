"""Independently authored raw-history block integrals and proper-score reduction.

The inherited independent positive-integrand rectangle quadrature is reused;
production geometry, caches, event logs, state and DLLs are never consumed.
"""
from __future__ import annotations
import math
import time
from pathlib import Path
from .common import (ARMS, ATOMIC, COMPONENTS, CONTRASTS, DIAGNOSTICS, PLANNED,
                     TARGETS, TOL, AuditError, Deadline, blank_rows, blocks, close,
                     contrast_rows, derived, need)

def background_integral(a, d, lo, hi, T0):
    need(hi >= lo and T0 > 0, 'BACKGROUND_INTERVAL')
    midpoint = (lo+hi)/T0-1.; z = d*(hi-lo)/T0
    factor = 1.+z*z/6.+z**4/120.+z**6/5040. if abs(z) < 1e-4 else math.sinh(z)/z
    result = math.exp(a+d*midpoint)*(hi-lo)*factor
    need(math.isfinite(result) and result >= 0, 'BACKGROUND_EXPOSURE_FINITE')
    return result

def interval_mass(model, parameters, lower, upper, mixture=None):
    """Positive-lag kernel mass, independently evaluated per parent/interval."""
    need(0 <= lower <= upper, 'PARENT_INTERVAL')
    if model in ('fixedML', 'commonML'):
        need(mixture is not None, 'DECLARED_MIXTURE_REQUIRED')
        tau = math.exp(parameters[3]) if model == 'commonML' else 1.
        weights, rates = mixture
        value = math.fsum(float(w)*math.exp(-float(r)*lower/tau)*
                          (-math.expm1(-float(r)*(upper-lower)/tau))
                          for w, r in zip(weights, rates))
    elif model == 'Omori':
        c, p = math.exp(parameters[3]), parameters[4]
        need(p > 1, 'OMORI_UNIT_MASS')
        value = math.exp((1-p)*math.log1p(lower/c)) * (
            -math.expm1((1-p)*math.log1p((upper-lower)/(c+lower))))
    else: raise AuditError('TEMPORAL_MODEL')
    need(math.isfinite(value) and 0 <= value <= 1.+1e-12, 'TEMPORAL_MASS_RANGE')
    return value

def block_exposure(model, parameters, parent_time, parent_excess, beta,
                   lo, hi, T0, parent_cell, background_cell, budget, mixture):
    """All parents before hi, including in-block events, retain original weights."""
    a, d, n = parameters[:3]; B = background_integral(a, d, lo, hi, T0)
    masses = []; cellterms = [[] for _ in range(9)]
    for j, (t, q) in enumerate(zip(parent_time, parent_excess)):
        budget.check()
        if t >= hi: continue
        J = interval_mass(model, parameters, max(lo-float(t), 0.), hi-float(t), mixture)
        term = .3*math.exp(.7*beta*float(q))*J
        masses.append(term)
        for cell in range(9): cellterms[cell].append(term*float(parent_cell[j, cell]))
    K = math.fsum(masses); triggered = n*K
    cells = [B*float(background_cell[c])+n*math.fsum(cellterms[c]) for c in range(9)]
    total = B+triggered
    close(math.fsum(cells), total, 'BLOCK_SPATIAL_EXPOSURE_CONSERVATION')
    return dict(immigrant_exposure=B, trigger_exposure=K,
                triggered_integrated_intensity=triggered, integrated_intensity=total,
                cell_integrated_intensity=cells,
                zone_integrated_intensity=[math.fsum(cells[3*z:3*z+3]) for z in range(3)])

def geometry(raw, state, parent_mask, event_mask, budget):
    """Fresh independent rectangle integrals, finite-domain masses and KDE."""
    import numpy as np
    from external_replication_validation import oracle as O
    parent_xy, event_xy = raw['xy'][parent_mask], raw['xy'][event_mask]
    training_xy = raw['xy'][state['training_mask']]
    rect = raw['rectangles']; pi = state['pi']
    area = (rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]); density = pi/area
    event_cell = O.labels(event_xy, rect); sigma = state['sigma']
    if state['spatial'] == 'continuous':
        mass = np.empty((len(parent_xy),9))
        for j, p in enumerate(parent_xy):
            for c, bounds in enumerate(rect):
                budget.check(); mass[j,c] = O.rectangle_mass(bounds,p,sigma)[0]
            if j % 32 == 0: budget.checkpoint('independent_parent_geometry', j+1)
        normalizer = mass@density
        parent_cell = mass*density[None,:]/normalizer[:,None]
    else:
        centers = np.column_stack(((rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2))
        weighted = O.kernel(parent_xy,centers,sigma)*pi[None,:]
        normalizer = weighted.sum(axis=1); parent_cell = weighted/normalizer[:,None]
    # KDE law is frozen by the saved training-only bandwidth, never selected here.
    kmass = np.empty((len(training_xy),9))
    for j, p in enumerate(training_xy):
        for c, bounds in enumerate(rect):
            budget.check(); kmass[j,c] = O.rectangle_mass(bounds,p,state['bandwidth'])[0]
        if j % 32 == 0: budget.checkpoint('independent_background_geometry', j+1)
    kz = kmass.sum(axis=1)
    bcell = .05*pi+.95*np.mean(kmass/kz[:,None],axis=0)
    need(np.all(np.isfinite(parent_cell)) and np.all(parent_cell > 0) and
         np.max(abs(parent_cell.sum(axis=1)-1),initial=0) <= 1e-12 and
         abs(math.fsum(bcell)-1) <= 1e-12, 'INDEPENDENT_UNIT_SPATIAL_MASS')
    return dict(parent_xy=parent_xy,event_xy=event_xy,training_xy=training_xy,
                event_cell=event_cell,area=area,density=density,parent_cell=parent_cell,
                parent_normalizer=normalizer,background_cell=bcell,kde_normalizer=kz)

def event_terms(raw, state, parent_mask, event_mask, g, budget, mixture):
    """Direct raw queries with strictly positive lag; no archived event vector."""
    import numpy as np
    from external_replication_validation import oracle as O
    t, q = raw['times'][parent_mask], raw['excess'][parent_mask]
    te, qe = raw['times'][event_mask], raw['excess'][event_mask]
    a, d, n = state['parameters'][:3]; beta = state['beta']
    fert = .3*np.exp(.7*beta*q); logs = []
    for i, (ti, qi) in enumerate(zip(te,qe)):
        budget.check(); valid = t < ti; lag = ti-t[valid]
        # Inherited independently authored density; new event/space reduction.
        k, _, _ = O.temporal(state['temporal'],state['parameters'],lag,np.empty(0),np.empty(0))
        weighted = fert[valid]*k
        mu = math.exp(a+d*(2*float(ti)/state['T0']-1)); cell = int(g['event_cell'][i])
        kernel = O.kernel(g['event_xy'][i:i+1],g['training_xy'],state['bandwidth'])[0]
        bg = .05*g['density'][cell]+.95*math.fsum(kernel/g['kde_normalizer'])/len(g['training_xy'])
        if state['spatial'] == 'continuous':
            pointweights = O.kernel(g['event_xy'][i:i+1],g['parent_xy'][valid],state['sigma'])[0]
            pointweights = pointweights*g['density'][cell]/g['parent_normalizer'][valid]
        else: pointweights = g['parent_cell'][valid,cell]/g['area'][cell]
        point = mu*bg+n*math.fsum(weighted*pointweights)
        ground = mu+n*math.fsum(weighted)
        cells = [mu*float(g['background_cell'][c])+n*math.fsum(weighted*g['parent_cell'][valid,c]) for c in range(9)]
        zone = math.fsum(cells[3*(cell//3):3*(cell//3)+3])
        need(all(math.isfinite(v) and v > 0 for v in (point,ground,zone,cells[cell])), 'POSITIVE_EVENT_INTENSITY')
        close(math.fsum(cells),ground,'EVENT_SPATIAL_MASS_CONSERVATION')
        lp, lg, lc, lz = map(math.log,(point,ground,cells[cell],zone))
        logs.append(dict(time=float(ti),cell=cell,event_ground_log=lg,
                         conditional_zone_logscore=lz-lg,conditional_cell_logscore=lc-lz,
                         within_cell_density_logscore=lp-lc,
                         mark_logscore=math.log(beta)-beta*float(qi),point_log=lp))
        if i % 16 == 0: budget.checkpoint('independent_event_queries',i+1)
    return logs

def reconstruct_window(raw, state, budget):
    import numpy as np
    from external_replication_validation import oracle as O
    parent = raw['times'] < state['end']
    event = (raw['times'] >= state['start']) & (raw['times'] < state['end'])
    need(int(event.sum()) == TARGETS[state['fold_id']], 'WINDOW_TARGET_COUNT')
    g = geometry(raw,state,parent,event,budget)
    mixture = O.mixture(); need(len(mixture[0]) == 195, 'DECLARED_195_MODE_MIXTURE')
    logs = event_terms(raw,state,parent,event,g,budget,mixture)
    out = []
    for key, lo, hi in blocks(state['fold_id']):
        subset = [v for v in logs if lo <= v['time'] < hi]
        row = dict(key, **{k:state[k] for k in ('arm_id','logical_arm_window_id','actual_procedure_id','selected_candidate_id')},
                   target_count=len(subset),status='succeeded',failure_codes=[])
        for component in ('event_ground_log',*ATOMIC[2:]):
            row[component] = math.fsum(v[component] for v in subset)
        row.update(block_exposure(state['temporal'],state['parameters'],raw['times'][parent],raw['excess'][parent],
                                  state['beta'],lo,hi,state['T0'],g['parent_cell'],g['background_cell'],budget,mixture))
        derived(row); row['per_target_mean'] = row['joint_logscore']/len(subset) if subset else None
        out.append(row); budget.checkpoint('independent_annual_block',len(out))
    sums = {k:math.fsum(r[k] for r in out) for k in COMPONENTS}
    sums.update({k:math.fsum(r[k] for r in out) for k in DIAGNOSTICS[:3]})
    sums['cell_integrated_intensity'] = [math.fsum(r['cell_integrated_intensity'][c] for r in out) for c in range(9)]
    sums['zone_integrated_intensity'] = [math.fsum(r['zone_integrated_intensity'][z] for r in out) for z in range(3)]
    sums['cell_point_event_log_intensity_sum'] = [math.fsum(v['point_log'] for v in logs if v['cell']==c) for c in range(9)]
    sums['cell_point_logscore'] = [sums['cell_point_event_log_intensity_sum'][c]-sums['cell_integrated_intensity'][c] for c in range(9)]
    sums['event_log_point_intensity_sum'] = math.fsum(v['point_log'] for v in logs)
    sums['event_log_intensity_sum'] = sums['event_log_point_intensity_sum']
    sums['event_log_ground_intensity_sum'] = sums['event_ground_log']
    sums['timing_event_logscore'] = sums['event_ground_log']
    sums['timing_exposure_logscore'] = -sums['integrated_intensity']
    whole = block_exposure(state['temporal'],state['parameters'],raw['times'][parent],raw['excess'][parent],
                           state['beta'],state['start'],state['end'],state['T0'],g['parent_cell'],g['background_cell'],budget,mixture)
    errors = {k:close(sums[k],whole[k],'ANNUAL_FULL_INTERVAL_ADDITIVITY') for k in whole}
    for k, expected in state['archive_reference'].items():
        errors['archive_'+k] = close(sums[k],expected,'ARCHIVED_WINDOW_RECONCILIATION')
    close(sums['joint_logscore'],sums['event_log_point_intensity_sum']-sums['integrated_intensity']+sums['mark_logscore'],'POINT_JOINT_IDENTITY')
    check = dict(fold_id=state['fold_id'],arm_id=state['arm_id'],status='succeeded',target_count=len(logs),
                 actual_procedure_id=state['actual_procedure_id'],selected_candidate_id=state['selected_candidate_id'],
                 source_hash_lineage=state['source_hash_lineage'],component_sums=sums,
                 archived_reference=state['archive_reference'],max_abs_discrepancies=errors,
                 work_counts=dict(parents=int(parent.sum()),training_events=int(state['training_mask'].sum()),
                                  targets=int(event.sum()),event_parent_pair_upper_bound=int(parent.sum())*int(event.sum()),
                                  annual_parent_integral_terms=sum(int((raw['times']<hi).sum()) for _,_,hi in blocks(state['fold_id'])),
                                  parent_rectangle_calls=9*int(parent.sum()) if state['spatial']=='continuous' else 0,
                                  background_rectangle_calls=9*int(state['training_mask'].sum())))
    return out, check

def pooled(contrasts):
    results = []
    for cid, _, _, primary, reference in CONTRASTS:
        rows = [r for r in contrasts if r['contrast_id']==cid]
        ok = len(rows)==15 and all(r['status']=='succeeded' for r in rows)
        result = dict(contrast_id=cid,status='succeeded' if ok else 'unresolved',
                      target_count=315,primary_component=primary,source_reported_primary=reference,
                      component_sums=None,max_abs_discrepancy=None,per_target_mean=None)
        if ok:
            result['component_sums'] = {k:math.fsum(r[k] for r in rows) for k in COMPONENTS}
            result['max_abs_discrepancy'] = close(result['component_sums'][primary],reference,'POOLED_APPROVED_PRIMARY')
            if cid == 'location_OC_minus_OL':
                result['within_cell_approved_discrepancy'] = close(result['component_sums']['within_cell_density_logscore'],653.602228,'POOLED_APPROVED_WITHIN_CELL')
            result['per_target_mean'] = result['component_sums'][primary]/315
        results.append(result)
    return results

def reconstruct(context, raw, budget, phase):
    from .authority import bind_window
    rows = blank_rows(); checks = []; cases = []
    budget.reached_state=dict(rows=rows,checks=checks,cases=cases)
    for fold in range(3):
        for arm in ARMS:
            status = dict(fold_id=fold,arm_id=arm,status='planned',failure_codes=[])
            if phase == 'pilot' and fold != 0:
                cases.append(status); checks.append(dict(fold_id=fold,arm_id=arm,status='planned')); continue
            affected = [r for r in rows if r['fold_id']==fold and r['arm_id']==arm]
            status['status'] = 'attempted'
            for row in affected: row['status'] = 'attempted'
            try:
                budget.check(); state = bind_window(context,raw,fold,arm)
                rebuilt, check = reconstruct_window(raw,state,budget)
                byid = {r['block_id']:r for r in rebuilt}
                # Replace using fixed positions; no partial arm is labeled succeeded.
                rows = [byid[r['block_id']] if r.get('fold_id')==fold and r.get('arm_id')==arm else r for r in rows]
                budget.reached_state['rows']=rows
                status['status'] = 'succeeded'; checks.append(check)
            except Exception as error:
                code = error.code if isinstance(error,AuditError) else 'PRIVATE_RECONSTRUCTION_FAILURE'
                status.update(status='unresolved' if isinstance(error,Deadline) else 'failed',failure_codes=[code],error_type=type(error).__name__)
                for row in affected:
                    row.update(status=status['status'],failure_codes=[code])
                checks.append(dict(fold_id=fold,arm_id=arm,status=status['status'],failure_codes=[code]))
            cases.append(status)
            try: budget.checkpoint('independent_arm_window_terminal',len(cases))
            except Deadline: pass
    contrasts = contrast_rows(rows)
    try: pools = pooled(contrasts)
    except Exception as error:
        code = error.code if isinstance(error,AuditError) else 'POOLED_RECONCILIATION_FAILURE'
        pools = [dict(contrast_id=c[0],status='failed',failure_codes=[code]) for c in CONTRASTS]
    complete = all(c['status']=='succeeded' for c in cases) and all(c['status']=='succeeded' for c in pools)
    return dict(schema='score_robustness_blocks_v1',producer='independent',
                authority_manifest_sha256=context['authority_manifest_sha256'],
                accepted_design_hashes=context['authority']['accepted_design_hashes'],
                source_pins=context['source_pins'],planned_denominators=PLANNED,
                phase=phase,status='succeeded' if complete else 'unresolved',
                case_statuses=cases,arm_blocks=rows,contrast_blocks=contrasts,
                window_checks=checks,pooled_checks=pools,
                raw_binding_counts=dict(population=1272,warmup_in_population=106,fold_targets=list(TARGETS)),
                raw_input_pins=context['raw_input_pins'],
                reconstruction_complete=complete,aggregate_release_approved=False)

def interrupted_output(context,budget,phase,code):
    """Preserve already reached cases on an unexpected outer-harness failure."""
    state=getattr(budget,'reached_state',dict(rows=blank_rows(),checks=[],cases=[]))
    reached={(c['fold_id'],c['arm_id']):c for c in state['cases']}
    cases=[reached.get((f,a),dict(fold_id=f,arm_id=a,status='planned',failure_codes=[])) for f in range(3) for a in ARMS]
    try: contrasts=contrast_rows(state['rows'])
    except Exception: contrasts=contrast_rows(blank_rows())
    return dict(schema='score_robustness_blocks_v1',producer='independent',status='unresolved',phase=phase,
                authority_manifest_sha256=context['authority_manifest_sha256'],
                accepted_design_hashes=context['authority']['accepted_design_hashes'],source_pins=context['source_pins'],
                raw_input_pins=context['raw_input_pins'],planned_denominators=PLANNED,
                case_statuses=cases,arm_blocks=state['rows'],contrast_blocks=contrasts,
                window_checks=state['checks'],pooled_checks=[dict(contrast_id=c[0],status='unresolved') for c in CONTRASTS],
                failure_codes=[code],reconstruction_complete=False,aggregate_release_approved=False)
