"""Handcrafted controls, authored UNRUN. Later explicit root-leased invocation only.

Expected integrals below are analytic expressions, not stored empirical results.
These controls do not replace the separately authored independent oracle.
"""
import argparse
import copy
import hashlib
import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from .native import Exposure,sha
from .authority import pinned,bind_fit,read_pinned,ARMS
from .reducer import day,blocks,derive,reduce_block,contrasts,reconcile_window,close,COMPONENTS

ENGINE=None

def integral(model='E_omori',pars=None,times=(),excess=None,start=1.,end=2.):
    pars=pars if pars is not None else [0.,0.,.25,0.,2.]
    return ENGINE.evaluate(model,pars,times,[0.]*len(times) if excess is None else excess,1.,start,end,16436.,[1/195]*195,[1.]*195,[1/9]*9,[1/9]*(9*len(times)))

def synthetic_state(times=(),beta=1.,excess=None,rate=1.):
    n=len(times);ground=[math.log(rate)]*n
    return dict(identity=dict(arm_id='Omori_smooth_cont',logical_arm_window_id='fixture',actual_procedure_id='fixture',selected_candidate_id='fixture'),event_time=list(times),event_excess=[0.]*n if excess is None else excess,beta=beta,logs=dict(ground=ground,zone=[v-math.log(3) for v in ground],cell=[v-math.log(9) for v in ground],point=[v-math.log(18) for v in ground]))

def constant_exposure(rate,width):
    E=rate*width
    return dict(immigrant_exposure=E,trigger_exposure=0.,triggered_integrated_intensity=0.,integrated_intensity=E,cell_integrated_intensity=[E/9]*9,zone_integrated_intensity=[E/3]*3)

def unit_block(start,end):return dict(fold_id=0,block_id=f'fixture_{start}',start_utc='fixture',end_utc='fixture',start_day=start,end_day=end)

class AnalyticControls(unittest.TestCase):
    def test_manifest_replacement_preserves_consumed_byte_identity(self):
        """M0 -> M1 path replacement must never relabel the consumed M0."""
        from . import authority
        # Deliberate BOM/spacing/trailing newline and hostile-looking extra key:
        # digest must identify captured bytes, not JSON reserialization or _digest.
        original=b'\xef\xbb\xbf{ "schema": "fixture-M0", "_digest": "untrusted" }\n'
        replacement=b'{"schema":"fixture-M1","_digest":"replacement"}'
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'authority.json';path.write_bytes(original)
            def replace_during_validation(value):
                self.assertEqual(value['schema'],'fixture-M0')
                path.write_bytes(replacement)
            with mock.patch.object(authority,'validate_manifest',side_effect=replace_during_validation):
                consumed,digest=authority.check_manifest(path)
            self.assertEqual(digest,hashlib.sha256(original).hexdigest())
            self.assertNotEqual(digest,hashlib.sha256(path.read_bytes()).hexdigest())
            self.assertEqual(consumed['schema'],'fixture-M0')
            self.assertEqual(consumed['_digest'],'untrusted')
            # The runner carries this out-of-band digest into admission,
            # checkpoints, final output and receipts; it never rehashes the path.

    def test_failure_accounting_keeps_startup_and_reached_cases_distinct(self):
        from .run import planned_ledger,failure_accounting
        ledger,receipt=failure_accounting(dict(phase='pre_admission'))
        self.assertEqual(receipt['failure_code'],'PRE_ADMISSION_FAILED')
        self.assertEqual(receipt['attempted_arm_cases'],0)
        self.assertEqual(receipt['terminal_case_counts']['unresolved'],12)
        self.assertEqual((len(ledger['arm_blocks']),len(ledger['contrast_blocks'])),(60,45))
        planned=planned_ledger();case=dict(planned['case_statuses'][0],status='succeeded',attempted=True)
        block=next(blocks(0));row=reduce_block(synthetic_state(),block,constant_exposure(1.,block['end_day']-block['start_day']))
        ledger,receipt=failure_accounting(dict(phase='global_reconciliation',authority_manifest_sha256='fixture-consumed-digest',case_statuses=[case],arm_blocks=[row],evaluated_arm_blocks=1))
        self.assertEqual(receipt['failure_code'],'POST_ADMISSION_PROCESS_FAILED')
        self.assertEqual(receipt['attempted_arm_cases'],1)
        self.assertEqual(receipt['terminal_case_counts']['succeeded'],1)
        self.assertEqual(receipt['completed_arm_blocks'],1)
        self.assertEqual(ledger['authority_manifest_sha256'],'fixture-consumed-digest')
        self.assertEqual((len(ledger['case_statuses']),len(ledger['arm_blocks']),len(ledger['contrast_blocks'])),(12,60,45))

    def test_sealed_inherited_identity_is_explicit_and_production_only(self):
        from . import authority
        with tempfile.TemporaryDirectory() as d:
            root=Path(d).resolve()
            original=root/'research_runs/california_schema_repair_20261025T044000Z'
            binary=root/'work/california_schema_repair_20261025T044000Z/study/source/research/external_replication/objective.dll'
            binary.parent.mkdir(parents=True)
            binary.write_bytes(b'handcrafted identity only; never loaded')
            protocol=original/authority.SEAL_PROTOCOL_ENTRY
            protocol.parent.mkdir(parents=True)
            seal=original/'seal_manifest.json'
            protocol_value=dict(artifact_pins={str(binary):sha(binary)})
            def freeze_chain(value=protocol_value,entry_hash=None):
                protocol.write_text(json.dumps(value),encoding='utf-8')
                seal.write_text(json.dumps(dict(files={authority.SEAL_PROTOCOL_ENTRY:
                    dict(sha256=sha(protocol) if entry_hash is None else entry_hash)})),encoding='utf-8')
            freeze_chain()
            receipt=dict(kind='sealed_inherited_identity',binary_path=str(binary),binary_sha256=sha(binary),
                seal_manifest_path=str(seal),seal_manifest_sha256=sha(seal),
                attesting_protocol_path=str(protocol),attesting_protocol_sha256=sha(protocol),
                seal_protocol_entry=authority.SEAL_PROTOCOL_ENTRY,compiler_provenance_status='unknown',
                compiler_path=None,compiler_sha256=None,compiler_version=None,command=None,
                source_pins={},dependency_pins={})
            # Patch only trusted identities and module location to a wholly
            # handcrafted tree; the exact original path relationships remain.
            fixture_module=root/'work/fixture_campaign/study/source/research/score_robustness/authority.py'
            def validate(value,production=binary):
                with mock.patch.multiple(authority,BASELINE_SEAL_SHA256=sha(seal),
                     ORIGINAL_PROTOCOL_SHA256=sha(protocol),ORIGINAL_DLL_SHA256=sha(binary),
                     __file__=str(fixture_module)):
                    authority.validate_sealed_inherited(value,str(production))
            validate(receipt)
            with self.assertRaises(ValueError):validate(receipt,root/'exposure.dll')
            with self.assertRaises(ValueError):validate(dict(receipt,binary_sha256='0'*64))
            with self.assertRaises(ValueError):validate(dict(receipt,compiler_version='invented'))
            with self.assertRaises(ValueError):validate(dict(receipt,seal_protocol_entry='other.json'))
            # Identical protocol bytes at a different path cannot replace the
            # exact seal-parent/design entry relationship.
            elsewhere=root/'elsewhere.json';elsewhere.write_bytes(protocol.read_bytes())
            with self.assertRaises(ValueError):validate(dict(receipt,attesting_protocol_path=str(elsewhere)))
            # A validly hashed handcrafted seal with the wrong entry hash fails
            # even if its bytes are otherwise accepted as the synthetic seal.
            freeze_chain(entry_hash='0'*64)
            with self.assertRaises(ValueError):validate(dict(receipt,seal_manifest_sha256=sha(seal)))
            # Rebind both handcrafted hashes but put the DLL digest under the
            # wrong absolute artifact key: no arbitrary matching leaf suffices.
            freeze_chain(dict(artifact_pins={str(root/'wrong.dll'):sha(binary)}))
            wrong=dict(receipt,seal_manifest_sha256=sha(seal),attesting_protocol_sha256=sha(protocol))
            with self.assertRaises(ValueError):validate(wrong)
            freeze_chain()
            # Same binary bytes at a different path are not the original DLL.
            relocated=root/'relocated.dll';relocated.write_bytes(binary.read_bytes())
            with self.assertRaises(ValueError):validate(dict(receipt,binary_path=str(relocated)),relocated)
            # Post-freeze byte replacement remains caught by the seal hash pin.
            seal.write_text(json.dumps(dict(files={})),encoding='utf-8')
            with self.assertRaises(ValueError):validate(receipt)

    def test_constant_two_vs_one_empty_first(self):
        # First interval has no events: timing contrast = -(2-1)=-1.
        # Second interval has one event: timing contrast = log(2)-1.
        for start,end,expected in ((0.,1.,-1.),(1.,2.,math.log(2)-1)):
            A=reduce_block(synthetic_state([1.5],rate=2.),unit_block(start,end),constant_exposure(2.,1.))
            B=reduce_block(synthetic_state([1.5],rate=1.),unit_block(start,end),constant_exposure(1.,1.))
            self.assertAlmostEqual(A['timing_logscore']-B['timing_logscore'],expected,places=12)
            if start==0:self.assertIsNone(A['per_target']['joint_logscore'])

    def test_parent_before_at_inside_end(self):
        # Omori c=1,p=2 has survival S(u)=1/(1+u).
        # Parents at 0,1,1.5,2 contribute .3*(1/2-1/3 + 1-1/2 + 1-1/1.5 + 0).
        v=integral(times=[0.,1.,1.5,2.]);K=.3*((1/2-1/3)+(1-1/2)+(1-1/1.5))
        self.assertAlmostEqual(v['trigger_exposure'],K,places=12)
        self.assertAlmostEqual(v['integrated_intensity'],1+.25*K,places=12)
        self.assertGreater(abs(v['integrated_intensity']-(1+K)),1e-3)

    def test_pre_epoch_parent_retained(self):
        v=integral(times=[-1.],start=0.,end=1.)
        self.assertAlmostEqual(v['trigger_exposure'],.3*(1/2-1/3),places=12)
        self.assertAlmostEqual(v['integrated_intensity'],1+.25*.3*(1/2-1/3),places=12)

    def test_all_history_additivity_and_reset_negative(self):
        t=[0.,1.,1.5,2.5]
        a=integral(times=t,start=1.,end=2.);b=integral(times=t,start=2.,end=3.);whole=integral(times=t,start=1.,end=3.)
        self.assertAlmostEqual(a['integrated_intensity']+b['integrated_intensity'],whole['integrated_intensity'],places=12)
        reset=integral(times=[2.5],start=2.,end=3.)
        self.assertGreater(b['integrated_intensity'],reset['integrated_intensity'])

    def test_calendar_year_full_window_additivity(self):
        bb=list(blocks(0));start=bb[0]['start_day'];end=bb[-1]['end_day']
        times=[start-100.,start,bb[1]['start_day'],end]
        annual=[integral(times=times,start=b['start_day'],end=b['end_day']) for b in bb]
        whole=integral(times=times,start=start,end=end)
        for name in ('immigrant_exposure','trigger_exposure','triggered_integrated_intensity','integrated_intensity'):
            self.assertAlmostEqual(math.fsum(a[name] for a in annual),whole[name],places=10)

    def test_ml_stable_difference_and_common_scale(self):
        # All 195 equal rates make a unit exponential law, exactly.
        fixed=integral('E_fixed',[0.,0.,.25],times=[0.],start=1.,end=2.)
        common=integral('E_free',[0.,0.,.25,math.log(2)],times=[0.],start=1.,end=2.)
        self.assertAlmostEqual(fixed['trigger_exposure'],.3*math.exp(-1)*(-math.expm1(-1)),places=12)
        self.assertAlmostEqual(common['trigger_exposure'],.3*math.exp(-.5)*(-math.expm1(-.5)),places=12)
        narrow=integral('E_free',[0.,0.,.25,0.],times=[0.],start=1.,end=1.+1e-10)
        self.assertGreater(narrow['trigger_exposure'],0.)

    def test_zero_history_and_nzero(self):
        self.assertAlmostEqual(integral()['integrated_intensity'],1.,places=12)
        for model,p in [('E_fixed',[0.,0.,0.]),('E_free',[0.,0.,0.,0.]),('E_free',[0.,0.,0.,math.log(.001)]),('E_omori',[0.,0.,0.,0.,2.]),('E_omori',[0.,0.,0.,math.log(20.),1.01])]:
            # A parent at the block start retains representable unscaled mass,
            # including tau=.001; a one-day lag instead underflows exp(-1000).
            v=integral(model,p,times=[1.])
            self.assertEqual(v['integrated_intensity'],1.)
            self.assertGreater(v['trigger_exposure'],0.)

    def test_trend_small_d_and_empty_targets(self):
        v=integral('E_fixed',[0.,1e-12,.25],start=1.,end=2.)
        self.assertAlmostEqual(v['immigrant_exposure'],1.,places=10)
        row=reduce_block(synthetic_state(),unit_block(1.,2.),v)
        self.assertEqual(row['target_count'],0)
        self.assertEqual(row['timing_logscore'],-v['integrated_intensity'])
        self.assertEqual(row['mark_logscore'],0.)

    def test_ties_halfopen_and_mark_once(self):
        state=synthetic_state([1.,1.,2.],beta=2.,excess=[.5,1.,2.])
        a=reduce_block(state,unit_block(1.,2.),constant_exposure(1.,1.))
        self.assertEqual(a['target_count'],2)
        self.assertAlmostEqual(a['mark_logscore'],2*math.log(2)-3,places=12)
        self.assertAlmostEqual(a['conditional_location_logscore'],-2*math.log(18),places=12)
        self.assertAlmostEqual(a['joint_logscore'],a['timing_logscore']+a['conditional_location_logscore']+a['mark_logscore'],places=12)
        other=reduce_block(synthetic_state([1.,1.,2.],beta=2.,excess=[.5,1.,2.],rate=2.),unit_block(1.,2.),constant_exposure(2.,1.))
        self.assertEqual(a['mark_logscore']-other['mark_logscore'],0.)
        self.assertAlmostEqual(a['joint_logscore']-other['joint_logscore'],a['timing_logscore']-other['timing_logscore'],places=12)
        # Strict event excitation itself is additionally exercised against the
        # inherited event ABI by event_abi_tie_control(), below.

    def test_finite_mass_zone_cell(self):
        v=integral(times=[0.,1.5]);self.assertAlmostEqual(math.fsum(v['cell_integrated_intensity']),v['integrated_intensity'],places=12)
        for z in range(3):self.assertAlmostEqual(math.fsum(v['cell_integrated_intensity'][z*3:z*3+3]),v['zone_integrated_intensity'][z],places=12)

    def test_leap_utc(self):
        self.assertEqual(day('2013-01-01T00:00:00Z')-day('2012-01-01T00:00:00Z'),366.)
        self.assertEqual(day('2021-01-01T00:00:00Z')-day('2020-01-01T00:00:00Z'),366.)
        self.assertEqual(day('2026-01-01T00:00:00Z'),16436.)

    def test_reject_changed_hash_alias_nonfinite_omitted(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'pin';path.write_bytes(b'old');digest=sha(path);path.write_bytes(b'new')
            with self.assertRaises(ValueError):pinned(str(path.resolve()),digest)
        row={'status':'complete','selector_complete':True,'models':{'fixedML_smooth_cont':dict(complete=True,selected=dict(candidate_id='A'),procedure_id='selector',sigma=5.)},'selected_sigma':5.,'model_aliases':{'fixedML_smooth_cont':dict(source_procedure_id='wrong',source_candidate_id='A',sigma=5.,no_additional_fit=True)}}
        with self.assertRaises(ValueError):bind_fit(row,'fixedML_smooth_cont',{}, {})
        with self.assertRaises(ValueError):close(float('nan'),0.)
        with self.assertRaises(ValueError):reconcile_window([],{}, {})

    def test_reject_changed_fit_and_wrong_bandwidth(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'training.json'
            original=dict(selected=dict(candidate_id='fixture',pars=[0.,0.,.25]),kde_selection=dict(selected_bandwidth=50.))
            path.write_text(json.dumps(original),encoding='utf-8');digest=sha(path)
            for mutation in ('fit','bandwidth'):
                altered=copy.deepcopy(original)
                if mutation=='fit':altered['selected']['pars'][2]=.5
                else:altered['kde_selection']['selected_bandwidth']=150.
                path.write_text(json.dumps(altered),encoding='utf-8')
                with self.assertRaises(ValueError):read_pinned(path,digest)

    def test_exact_full_roster_roundtrip(self):
        rows=[]
        for f in range(3):
            for b in blocks(f):
                for arm in ARMS:
                    state=synthetic_state();state['identity']['arm_id']=arm
                    rows.append(reduce_block(state,b,constant_exposure(1.,b['end_day']-b['start_day'])))
        c=contrasts(rows);self.assertEqual((len(rows),len(c)),(60,45))
        self.assertEqual(len(rows)*len(COMPONENTS),540);self.assertEqual(len(c)*len(COMPONENTS),405)
        self.assertEqual(json.loads(json.dumps(dict(arm_blocks=rows,contrast_blocks=c),allow_nan=False))['contrast_blocks'],c)
        with self.assertRaises((ValueError,KeyError)):contrasts(rows[:-1])
        with self.assertRaises(ValueError):contrasts(rows+[rows[0]])

    def test_permuted_vectors_and_duplicate_or_permuted_ids(self):
        from .run import verify_event_vectors
        from ..external_replication.catalogue import load_catalogue
        logs=[[1.,2.,3.,4.],[5.,6.,7.,8.]]
        forecast={'event_log_'+name+'_intensity':[logs[0][j],logs[1][j]] for j,name in enumerate(('point','cell','zone','ground'))}
        verify_event_vectors(forecast,logs)
        forecast['event_log_ground_intensity'].reverse()
        with self.assertRaises(ValueError):verify_event_vectors(forecast,logs)
        base=dict(latitude=34.,longitude=-118.,magnitude=4.5,depth_km=5.,magnitude_type='w',event_type='eq',source_year=2011,source_line_1based=1,origin_time_utc='2011-01-01T00:00:00Z')
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'catalogue.json'
            for ids in (('A','A'),('B','A')):
                value=dict(schema_version=1,catalogue_id='handcrafted',provenance=dict(source_snapshot='handcrafted',raw_manifest_sha256='handcrafted',retrieved_utc='2011-01-01T00:00:00Z'),events=[dict(base,event_id=i) for i in ids])
                path.write_text(json.dumps(value),encoding='utf-8')
                with self.assertRaises(ValueError):load_catalogue(path,sha(path),profile='california')

def event_abi_tie_control(production_dll):
    """Later root control: all parents/targets tied at day 1, no excitation.

    This uses manufactured source-native arrays, not a catalogue or cache file.
    """
    import numpy as np
    from .run import evaluate_events
    a={k:np.ascontiguousarray(v,dtype='float64') for k,v in dict(parent_time=[1.,1.],event_time=[1.,1.],event_excess=[0.,0.],event_x=[2/16436-1]*2,event_cell=[0.,0.],event_background_density=[1.,1.],background_cell_mass=[1/9]*9,event_parent_density=[[1.,1.],[1.,1.]],parent_cell_mass=[[1/9]*9]*2,parent_fertility=[.3,.3],parent_exposure_lo=[0.,0.],parent_exposure_hi=[1.,1.],mixture_weights=[1/195]*195,mixture_rates=[1.]*195).items()}
    out,logs=evaluate_events(a,dict(start=1.,end=2.,T0=16436.,beta=1.),dict(model='E_fixed',selected=dict(pars=[0.,0.,.25])),production_dll)
    for value in logs[:,3]:close(value,0.)

def main():
    global ENGINE
    p=argparse.ArgumentParser();p.add_argument('--dll',required=True);p.add_argument('--dll-sha256',required=True);p.add_argument('--production-dll',required=True);p.add_argument('--production-dll-sha256',required=True);a=p.parse_args()
    pinned(str(Path(a.production_dll).resolve()),a.production_dll_sha256)
    ENGINE=Exposure(a.dll,a.dll_sha256)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(AnalyticControls)
    result=unittest.TextTestRunner(verbosity=0).run(suite)
    if not result.wasSuccessful():return 2
    event_abi_tie_control(a.production_dll)
    print(json.dumps(dict(status='controls_passed',tests=result.testsRun+1,empirical_execution=False)));return 0

if __name__=='__main__':raise SystemExit(main())
