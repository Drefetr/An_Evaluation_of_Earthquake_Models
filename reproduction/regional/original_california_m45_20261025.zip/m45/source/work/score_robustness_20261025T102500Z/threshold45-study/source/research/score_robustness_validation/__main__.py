"""Explicit local commands. No hidden rebuilds, numerical imports or data at import.

Every numerical invocation requires the root's frozen phase admission and live
external numerical lease. Source preparation does not execute these commands.
"""
from __future__ import annotations
import argparse
import sys
import time
from .common import (ARMS, CONTRASTS, PLANNED, AuditError, Budget, blank_rows,
                     contrast_rows, need, read_pinned, write_new)

def parser():
    p=argparse.ArgumentParser(prog='score_robustness_validation')
    sub=p.add_subparsers(dest='command',required=True)
    for command in ('reconstruct','controls','compare'):
        q=sub.add_parser(command)
        q.add_argument('--admission',required=True);q.add_argument('--admission-sha256',required=True)
        q.add_argument('--output',required=True);q.add_argument('--planned-ledger',required=True)
        q.add_argument('--checkpoint-dir',required=True);q.add_argument('--seconds',type=float,required=True)
        if command=='reconstruct':
            q.add_argument('--phase',choices=('pilot','full'),required=True)
            q.add_argument('--authority',required=True);q.add_argument('--authority-sha256',required=True)
        else:
            q.add_argument('--source-manifest',required=True);q.add_argument('--source-manifest-sha256',required=True)
        if command=='controls':q.add_argument('--fixture-dir',required=True)
        if command=='compare':
            q.add_argument('--independent',required=True);q.add_argument('--independent-sha256',required=True)
            q.add_argument('--production',required=True);q.add_argument('--production-sha256',required=True)
            q.add_argument('--authority-sha256',required=True);q.add_argument('--private-detail',required=True)
    return p

def planned(args):
    return dict(schema='score_robustness_independent_planned_ledger_v1',
                command=args.command,phase=getattr(args,'phase',args.command),
                planned_denominators=PLANNED,attempted_cases=0,admission_state='not_yet_checked',
                case_statuses=[dict(fold_id=f,arm_id=a,status='planned') for f in range(3) for a in ARMS],
                arm_blocks=blank_rows(),contrast_blocks=contrast_rows(blank_rows()),
                empirical_values_present=False,aggregate_release_approved=False)

def failed_reconstruction(context,code):
    rows=blank_rows()
    for r in rows:r.update(status='unresolved',failure_codes=[code])
    return dict(schema='score_robustness_blocks_v1',producer='independent',status='unresolved',
                authority_manifest_sha256=context['authority_manifest_sha256'],
                accepted_design_hashes=context['authority']['accepted_design_hashes'],
                source_pins=context['source_pins'],raw_input_pins=context['raw_input_pins'],
                planned_denominators=PLANNED,reconstruction_complete=False,
                input_binding_status='failed',failure_codes=[code],
                case_statuses=[dict(fold_id=f,arm_id=a,status='unresolved',failure_codes=[code]) for f in range(3) for a in ARMS],
                arm_blocks=rows,contrast_blocks=contrast_rows(rows),
                window_checks=[dict(fold_id=f,arm_id=a,status='unresolved') for f in range(3) for a in ARMS],
                pooled_checks=[dict(contrast_id=c[0],status='unresolved') for c in CONTRASTS],
                aggregate_release_approved=False)

def main(argv=None):
    args=parser().parse_args(argv);start=time.perf_counter();phase=getattr(args,'phase',args.command)
    admitted=False;context=None;result=None;stage='startup'
    # Immutable sidecar records all planned cases even if admission subsequently fails.
    # An output path already present is never overwritten or silently resumed.
    write_new(args.planned_ledger,planned(args))
    try:
        from .authority import admission,prepare_authority,runtime,source_closure
        budget=Budget(args.seconds,args.checkpoint_dir)
        receipt=admission(args.admission,args.admission_sha256,phase)
        need(args.seconds<=receipt['maximum_seconds'],'PHASE_BUDGET_EXCEEDED')
        if phase=='pilot':need(args.seconds<=600.,'PILOT_600_SECONDS')
        if phase=='full':need(args.seconds<=21600.,'FULL_CAMPAIGN_21600_SECONDS')
        if args.command=='reconstruct':
            context=prepare_authority(args.authority,args.authority_sha256)
        else:
            manifest=read_pinned(args.source_manifest,args.source_manifest_sha256)
            source_closure(manifest);runtime(manifest)
        budget.check();admitted=True;stage='admitted'
        if args.command=='reconstruct':
            from .authority import bind_raw
            from .oracle import reconstruct
            stage='raw_input_binding';raw=bind_raw(context,budget)
            stage='arm_window_reconstruction';result=reconstruct(context,raw,budget,phase)
        elif args.command=='controls':
            from .controls import run
            stage='handcrafted_controls';result=run(args.fixture_dir,budget)
        else:
            from .compare import reconcile
            stage='separate_reconciliation'
            result=reconcile(args.independent,args.independent_sha256,args.production,args.production_sha256,
                             args.authority_sha256,args.private_detail)
        result.update(elapsed_seconds=time.perf_counter()-start,admission_phase=phase,
                      execution_admission_sha256=args.admission_sha256)
    except Exception as error:
        code=error.code if isinstance(error,AuditError) else 'PRIVATE_LOCAL_EXECUTION_FAILURE'
        if admitted and context is not None and stage=='raw_input_binding':
            result=failed_reconstruction(context,code)
            result['phase']=phase
        elif admitted and context is not None and stage=='arm_window_reconstruction':
            from .oracle import interrupted_output
            result=interrupted_output(context,budget,phase,code)
        elif admitted and args.command=='compare':
            result=dict(schema='score_robustness_reconciliation_v1',status='failed',
                        production_output_sha256=args.production_sha256,independent_output_sha256=args.independent_sha256,
                        authority_manifest_sha256=args.authority_sha256,
                        source_manifest_sha256=args.source_manifest_sha256,
                        expected_counts=dict(arm_rows=60,contrast_rows=45,arm_component_slots=540,contrast_component_slots=405,arm_windows=12,targets=315),
                        reached_counts=None,identity_checks=dict(passed=False,count=None),
                        max_abs_discrepancies=None,failure_codes=[code],
                        private_detail_path=args.private_detail,aggregate_release_approved=False,
                        note='Fail-closed comparison stopped before a complete accepted reached-count receipt; unknown values are null.')
            write_new(args.private_detail,dict(status='failed',failure_codes=[code],error_type=type(error).__name__))
        else:
            result=dict(schema='score_robustness_independent_execution_failure_v1',status='failed',
                        admission_state='passed' if admitted else 'failed_before_scientific_admission',
                        stage=stage,attempted_cases=0,
                        planned_denominators=PLANNED,failure_codes=[code],error_type=type(error).__name__,
                        planned_ledger_path=args.planned_ledger,aggregate_release_approved=False)
        result['elapsed_seconds']=time.perf_counter()-start
    write_new(args.output,result)
    # Never print exceptions, paths, rows, parameters, scores or arrays.
    public={k:result[k] for k in ('status','admission_state','stage','failure_codes','elapsed_seconds',
                                 'passed_controls','failed_controls','max_abs_discrepancies') if k in result}
    if 'case_statuses' in result:
        public['case_counts']={s:sum(c['status']==s for c in result['case_statuses'])
                               for s in ('planned','attempted','succeeded','failed','unresolved')}
    import json
    print(json.dumps(public,sort_keys=True,allow_nan=False))
    return 0 if result.get('status') in ('passed','succeeded') else 1

if __name__=='__main__':raise SystemExit(main())
