"""Handcrafted v4 completion-time and guarded-query rejection controls. Root leases execution; no network or fits."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
import argparse,copy,json,tempfile
import numpy as np
try:
    from . import prospective_v4 as P,typed_query_adapter_v2 as Q
except ImportError:
    import prospective_v4 as P,typed_query_adapter_v2 as Q

def fixture():
    t=np.array([1.,1.,2.]);et=np.array([4.,4.,4.5]);beta=2.;q=np.array([0.,.2,.7]);weights=np.full(195,1/195.)
    a=dict(parent_time=t,parent_excess=q,parent_fertility=.3*np.exp(.7*beta*q),parent_exposure_lo=4.-t,parent_exposure_hi=5.-t,parent_cell_mass=np.full((3,9),1/9),event_time=et,event_excess=np.array([0.,.1,.4]),event_cell=np.array([0.,4.,8.]),event_x=2*et/20.-1,event_background_density=np.full(3,.1),background_cell_mass=np.full(9,1/9),event_parent_density=np.full((3,3),.1),mixture_weights=weights,mixture_rates=np.ones(195))
    return a,dict(start=4.,end=5.,T0=20.,beta=beta,profile='new_zealand',history_policy='fixed_preissue')

def run_controls(output):
    checks=[]
    def passed(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def reject(name,func):
        try:func()
        except (ValueError,KeyError,TypeError):checks.append(name);return
        raise AssertionError(name)
    a,m=fixture();admitted,_=Q.validate_query(a,m);passed('valid_fixture_admitted_without_dll',all(v.flags.c_contiguous for v in admitted.values()))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);del bad[key];reject('missing_'+key,lambda bad=bad:Q.validate_query(bad,m))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);bad[key]=bad[key].reshape(-1)[:-1];reject('short_shape_'+key,lambda bad=bad:Q.validate_query(bad,m))
    for key in sorted(Q.REQUIRED):
        bad=copy.deepcopy(a);bad[key].reshape(-1)[0]=np.nan;reject('nonfinite_'+key,lambda bad=bad:Q.validate_query(bad,m))
    mutations=[('same_day_parent','parent_time',lambda v:np.array([1.,2.,4.])),('parent_unsorted','parent_time',lambda v:v[::-1]),('negative_parent_mark','parent_excess',lambda v:np.array([-.1,.2,.7])),('noninteger_cell','event_cell',lambda v:np.array([.1,4.,8.])),('zero_background','background_cell_mass',lambda v:np.r_[0.,v[1:]]),('wrong_mass','parent_cell_mass',lambda v:v*2),('zero_rate','mixture_rates',lambda v:v*0),('wrong_exposure','parent_exposure_lo',lambda v:v+1),('wrong_trend','event_x',lambda v:v+.01),('wrong_fertility','parent_fertility',lambda v:v*2),('query_at_end','event_time',lambda v:np.array([4.,4.,5.]))]
    for name,key,change in mutations:
        bad=copy.deepcopy(a);bad[key]=change(bad[key]);reject(name,lambda bad=bad:Q.validate_query(bad,m))
    for key,value in [('start',float('nan')),('end',4.),('T0',0.),('beta',-1.),('profile','california'),('history_policy','continuous')]:
        bad=dict(m,**{key:value});reject('metadata_'+key,lambda bad=bad:Q.validate_query(a,bad))
    old_library=Q.library
    def forbidden(*args,**kwargs):raise AssertionError('FFI loaded before shape validation')
    Q.library=forbidden
    try:
        bad=copy.deepcopy(a);bad['parent_cell_mass']=np.zeros((1,9));reject('ffi_preflight_before_library',lambda:Q.FixedObjectiveV2(bad,m))
    finally:Q.library=old_library
    freeze=P.utc('2028-02-28T23:59:59Z');start,end=P.horizon(freeze);passed('leap_day_fixed_endpoint',P.iso(start)=='2028-02-29T00:00:00Z' and P.iso(end)=='2038-02-28T00:00:00Z')
    with tempfile.TemporaryDirectory(prefix='prospective-v4-fixtures-') as td:
        root=Path(td);regpath=root/'fixture_registration.json';P.write(regpath,dict(kind='fixture'));regsha=P.sha(regpath);archive=root/'archive';db=P.connect(archive,regsha,kind='fixture')
        body=dict(kind='fixture',status='missing_unknown',day='2030-01-01');P.append_day(db,regsha,'2030-01-01',body);reject('unique_day_prevents_backfill',lambda:P.append_day(db,regsha,'2030-01-01',dict(kind='fixture',status='issued')));passed('hashchain_verifies',len(P.verify_chain(db,regsha))==1);db.close()
        reject('fixture_archive_rejected_operational',lambda:P.connect(archive,regsha,kind='operational'))
        # Stale capture fails before opening referenced files or trusting caller data.
        capture=root/'stale_capture.json';P.write(capture,dict(schema_version=4,kind='operational_capture',status='complete',registration_sha256=regsha,validity_start_utc='2030-01-02T00:00:00Z',actual_request_start_utc='2029-12-01T22:55:00Z',actual_receipt_utc='2029-12-01T22:56:00Z'))
        reject('old_capture_rejected',lambda:P.validate_capture(P.ref(capture),dict(capture_policy={},freeze_utc='2029-12-31T00:00:00Z'),regsha,P.utc('2030-01-02T00:00:00Z')))
        canonical=root/'non_earthquake.json';P.write(canonical,dict(schema_version=1,events=[dict(event_type='quarry_blast')]))
        reject('non_earthquake_parent_rejected',lambda:P.validate_canonical(canonical,P.sha(canonical)))
        P.write(root/'missing_type.json',dict(schema_version=1,events=[{}]));reject('missing_event_type_rejected',lambda:P.validate_canonical(root/'missing_type.json',P.sha(root/'missing_type.json')))
        for label,depth in [('deep','40.00001'),('unknown','-9'),('nonfinite','NaN'),('missing',None),('rounded_json_number',40.0),('near_boundary','40.000000000000001')]:
            event=dict(event_type='earthquake')
            if depth is not None:event['depth_km']=depth
            bad=root/('depth_'+label+'.json');P.write(bad,dict(schema_version=1,events=[event]));reject('shallow_'+label+'_rejected',lambda bad=bad:P.validate_canonical(bad,P.sha(bad)))
        provenance=dict(source_snapshot='fixture',raw_manifest_sha256='0'*64,retrieved_utc='2030-01-01T00:00:00Z')
        event=dict(event_type='earthquake',event_id='SYN_DEPTH',origin_time_utc='2030-01-01T00:00:00Z',latitude='-41',longitude='172',magnitude='5',magnitude_type='Mw',depth_km='-8',source_year=2030,source_line_1based=1)
        good=root/'other_negative_depth.json';P.write(good,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[event]));passed('other_negative_depth_retained',len(P.validate_canonical(good,P.sha(good)).times)==1)
        event['depth_km']='40';good2=root/'exact_depth40.json';P.write(good2,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[event]));passed('exact40_depth_retained',len(P.validate_canonical(good2,P.sha(good2)).times)==1)
        for label,change in [('magnitude_rounded_below5',dict(magnitude='4.9999999999999999999')),('latitude_rounded_internal_edge',dict(latitude='-43.500000000000001')),('longitude_rounded_internal_edge',dict(longitude='169.99999999999999999')),('longitude_rounded_outside_support',dict(longitude='180.000000000000001'))]:
            altered=dict(event,**change);path=root/(label+'.json');P.write(path,dict(schema_version=1,catalogue_id='fixture',provenance=provenance,events=[altered]));reject(label,lambda path=path:P.validate_canonical(path,P.sha(path)))
        # Hash mismatch must be detected even if JSON remains parseable.
        packet=root/'fixture_packet.json';P.write(packet,dict(kind='fixture',status='fixture'));anchored=P.ref(packet);packet.write_text('{"kind":"operational","status":"issued"}')
        reject('mutated_packet_sha_rejected',lambda:P.checked_ref(anchored))
        another=root/'another_archive';reject('unregistered_archive_root_rejected',lambda:P.require_archive(dict(archive_root=str(archive.resolve())),another))
        # A fixture packet can never be admitted through the operational boundary.
        operational=root/'fixture_operational_db';db=P.connect(operational,regsha);packet2=root/'packet2.json';P.write(packet2,dict(schema_version=4,kind='fixture',status='fixture'));P.append_day(db,regsha,'2030-01-02',dict(kind='operational',status='issued',packet=P.ref(packet2)));db.close()
        original=P.verify_registration;P.verify_registration=lambda p:(dict(archive_root=str(operational.resolve())),{})
        try:reject('fixture_packet_rejected_operational_scorer',lambda:P.admitted_packet(regpath,operational,'2030-01-02'))
        finally:P.verify_registration=original
    with tempfile.TemporaryDirectory(prefix='prospective-v4-registration-bindings-') as td:
        root=Path(td);pop=root/'population.json';final=root/'finalization.json';audit=root/'audit.json';parser=root/'parse_capture_xml.py';contract=root/'xml_cohort_contract_v1.json'
        for path in [pop,final,audit,contract]:P.write(path,dict(kind='handcrafted_test_only'))
        parser.write_text("DEPENDENCY_FILENAMES=('parse_capture_xml.py','xml_cohort_contract_v1.json')\n")
        pins={str((P.HERE/n).resolve()):P.sha(P.HERE/n) for n in P.SOURCE_FILES+P.SOURCE_EXTENSION}
        pins.update({str(path.resolve()):P.sha(path) for path in [pop,final,audit,parser,contract]})
        policy=dict(completion_window_minutes_before_start=[70,60],max_request_span_seconds=600,canonical_event_type='earthquake',parser_entrypoint='parse_capture',endpoint='https://service.geonet.org.nz/fdsnws/event/1/query',accept='application/xml',query=dict(P.EXPECTED_XML_QUERY),completeness_controls=dict(P.EXPECTED_XML_CONTROLS),max_bytes=1024,timeout_seconds=1,parser_path=str(parser.resolve()),parser_dependencies={path.name:P.ref(path) for path in [parser,contract]})
        reg=dict(schema_version=4,status='frozen',kind='operational',endpoint_rule='same_calendar_date_or_last_day_of_month',freeze_utc='2029-12-31T23:00:00Z',start_utc='2030-01-01T00:00:00Z',end_utc='2040-01-01T00:00:00Z',artifact_pins=pins,population_contract=P.ref(pop),finalization_contract=P.ref(final),capture_policy=policy,initialization=dict(independent_audit=P.ref(audit)))
        original=(P.CORRECTED_POPULATION_SHA,P.CORRECTED_FINALIZATION_SHA,P.XML_COHORT_CONTRACT_SHA,P.initialization_bindings)
        P.CORRECTED_POPULATION_SHA=P.sha(pop);P.CORRECTED_FINALIZATION_SHA=P.sha(final);P.XML_COHORT_CONTRACT_SHA=P.sha(contract);P.initialization_bindings=lambda init:({},{})
        try:
            good=root/'registered_fixture.json';P.write(good,reg);passed('registration_design_and_dependency_baseline',P.verify_registration(good)[0]==reg)
            mutations=[]
            bad=copy.deepcopy(reg);del bad['population_contract'];mutations.append(('registration_missing_population_contract',bad))
            bad=copy.deepcopy(reg);bad['finalization_contract']['sha256']='0'*64;mutations.append(('registration_wrong_finalization_hash',bad))
            bad=copy.deepcopy(reg);del bad['capture_policy']['parser_dependencies']['xml_cohort_contract_v1.json'];mutations.append(('registration_missing_parser_dependency',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['parser_dependencies']['parse_capture_xml.py']['sha256']='0'*64;mutations.append(('registration_changed_parser_dependency',bad))
            bad=copy.deepcopy(reg);del bad['artifact_pins'][str(contract.resolve())];mutations.append(('registration_unpinned_parser_contract',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['query']['format']='text';mutations.append(('registration_wrong_source_format',bad))
            bad=copy.deepcopy(reg);bad['capture_policy']['completeness_controls']['schema']='wrong';mutations.append(('registration_wrong_XML_controls',bad))
            for label,bad in mutations:
                path=root/(label+'.json');P.write(path,bad);reject(label,lambda path=path:P.verify_registration(path))
            P.XML_COHORT_CONTRACT_SHA='0'*64;reject('registration_wrong_semantic_contract_identity',lambda:P.verify_registration(good))
            P.XML_COHORT_CONTRACT_SHA=P.sha(contract);parser.write_text("DEPENDENCY_FILENAMES=('parse_capture_xml.py',)\n");bad=copy.deepcopy(reg);bad['artifact_pins'][str(parser.resolve())]=P.sha(parser);bad['capture_policy']['parser_dependencies']['parse_capture_xml.py']=P.ref(parser);wrong=root/'wrong_declared_closure.json';P.write(wrong,bad);reject('registration_wrong_static_parser_closure',lambda:P.verify_registration(wrong))
        finally:P.CORRECTED_POPULATION_SHA,P.CORRECTED_FINALIZATION_SHA,P.XML_COHORT_CONTRACT_SHA,P.initialization_bindings=original
    with tempfile.TemporaryDirectory(prefix='prospective-v4-mocked-transport-') as td:
        # Entire end-to-end archive is temporary and uses a mocked transport and
        # test clock. No resulting packet is exported or counts as issued.
        root=Path(td);archive=root/'archive';regpath=root/'mock_registration.json';P.write(regpath,dict(kind='fixture_test_only'))
        parser=root/'mock_parser.py';parser.write_text("def parse_capture(raw,query,provenance,controls):\n    return dict(schema_version=1,catalogue_id='synthetic',provenance=provenance,events=[]),dict(complete=True,controls=controls,truncation_detected=False)\n")
        cache=root/'mock_cache.npz';cache.write_bytes(b'fixture-only-not-a-numerical-cache')
        audit=root/'mock_audit.json';P.write(audit,dict(kind='fixture_test_only'));params=root/'mock_params.json';P.write(params,{})
        training=dict(beta=2.,reference_pi=[1/9]*9,kde_selection=dict(selected_bandwidth=50.),selected_sigma=50.,models={mid:dict(model='E_fixed',selected=dict(pars=[-2.,0.,.2]),spatial='cont',sigma=50.,cache_paths=dict(train16=str(cache.resolve()))) for mid in P.MODELS})
        reg=dict(archive_root=str(archive.resolve()),freeze_utc='2029-12-31T23:00:00Z',start_utc='2030-01-01T00:00:00Z',end_utc='2040-01-01T00:00:00Z',capture_policy=dict(endpoint='https://fixture.invalid/no-network',query=dict(starttime='1960-01-01T00:00:00Z'),accept='application/xml',parser_path=str(parser.resolve()),completeness_controls=dict(fixture=True),max_bytes=1024,timeout_seconds=1),initialization=dict(independent_audit=P.ref(audit),parameter_manifest=P.ref(params)))
        class Response:
            status=200;headers={'Date':'fixture','Last-Modified':None,'Content-Length':'2','Content-Type':'application/xml'}
            def __init__(self):self.done=False
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):
                if self.done:return b''
                self.done=True;return b'{}'
        original_verify=P.verify_registration;original_now=P.now;original_transport=P.urllib.request.urlopen;original_write=P.write;original_ref=P.ref;archive_events=[]
        def tracked_write(path,value):
            result=original_write(path,value)
            if Path(path).name=='forecast_candidate.json':archive_events.append('closed')
            return result
        def tracked_ref(path):
            result=original_ref(path)
            if Path(path).name=='forecast_candidate.json':archive_events.append('hashed')
            return result
        P.write=tracked_write;P.ref=tracked_ref
        clocks=iter([P.utc('2030-01-01T22:55:00Z'),P.utc('2030-01-01T22:56:00Z'),P.utc('2030-01-01T23:05:00Z'),P.utc('2030-01-01T23:05:01Z'),P.utc('2030-01-01T23:05:02Z'),P.utc('2030-01-01T23:05:03Z'),P.utc('2030-01-01T23:06:00Z')])
        def tracked_now():
            value=next(clocks)
            if value==P.utc('2030-01-01T23:05:02Z'):
                passed('completion_sample_follows_close_and_hash',archive_events[-2:]==['closed','hashed']);archive_events.append('completion_sample')
            return value
        P.verify_registration=lambda path:(reg,training);P.now=tracked_now;P.urllib.request.urlopen=lambda *args,**kwargs:Response()
        try:
            capture=P.capture_source(regpath,'2030-01-02T00:00:00Z',archive)
            result=P.issue_day(regpath,capture,archive);passed('mock_capture_and_unique_issue',result['status']=='issued' and result['archive_completed_utc']=='2030-01-01T23:05:02Z')
            candidate=P.read(result['packet']['path']);passed('candidate_bytes_alone_stay_unissued',candidate['status']=='prepared_unissued' and candidate['kind']=='forecast_candidate')
            admitted=P.admitted_packet(regpath,archive,'2030-01-02');passed('issued_status_comes_from_ledger',admitted['_verified_ledger_status']=='issued' and admitted['status']=='prepared_unissued');passed('mock_packet_hash_and_capture_mint_verified',admitted['_verified_packet_sha256']==result['packet']['sha256'])
            reject('duplicate_day_issue_rejected',lambda:P.issue_day(regpath,capture,archive))
            packet_path=Path(result['packet']['path']);packet_path.write_text(packet_path.read_text()+' ')
            reject('archived_packet_byte_mutation_rejected',lambda:P.admitted_packet(regpath,archive,'2030-01-02'))
            # A candidate completed at or after midnight is terminally unissued.
            for label,began,prepared,completed in [
                ('cross_midnight','2030-01-01T23:59:59Z','2030-01-01T23:59:59.500000Z','2030-01-02T00:00:00.100000Z'),
                ('early_prepare_exact_boundary','2030-01-01T23:05:00Z','2030-01-01T23:06:00Z','2030-01-02T00:00:00Z')]:
                late_archive=root/label;reg['archive_root']=str(late_archive.resolve())
                complete_dt=P.utc(completed);clocks=iter([P.utc('2030-01-01T22:55:00Z'),P.utc('2030-01-01T22:56:00Z'),P.utc(began),P.utc(prepared),complete_dt,complete_dt+timedelta(microseconds=1)])
                P.now=lambda:next(clocks)
                cap=P.capture_source(regpath,'2030-01-02T00:00:00Z',late_archive)
                late=P.issue_day(regpath,cap,late_archive)
                passed(label+'_unissued',late['status']=='unissued' and late['reason_code']=='ARCHIVE_COMPLETED_LATE' and late['ledger_state']=='missing_unknown')
                failed=P.read(late['attempt']['path']);candidate=P.read(late['candidate']['path'])
                passed(label+'_failure_schema_and_bindings',failed['schema_version']==4 and failed['day']=='2030-01-02' and failed['capture']==cap and failed['packet']==late['candidate'] and failed['source']==dict(path=candidate['source_snapshot_path'],sha256=candidate['source_snapshot_sha256']) and failed['source']['sha256']==P.read(P.checked_ref(cap))['canonical']['sha256'] and P.checked_ref(failed['source']).read_bytes()==P.checked_ref(P.read(P.checked_ref(cap))['canonical']).read_bytes())
                passed(label+'_failure_and_candidate_preserved',failed['status']=='unissued' and failed['archive_completed_utc']==P.iso(complete_dt) and candidate['status']=='prepared_unissued')
                db=P.connect(late_archive,P.sha(regpath));rows=P.verify_chain(db,P.sha(regpath));db.close()
                passed(label+'_no_issued_row',rows['2030-01-02'][0]['status']=='missing_unknown' and not any(v[0]['status']=='issued' for v in rows.values()))
                reject(label+'_operational_admission_rejected',lambda:P.admitted_packet(regpath,late_archive,'2030-01-02'))
                # Even a test clock moved backwards cannot promote the terminal day.
                P.now=lambda:P.utc('2030-01-01T23:59:59.900000Z')
                reject(label+'_cannot_promote_late_candidate',lambda:P.issue_day(regpath,cap,late_archive))
        finally:P.verify_registration=original_verify;P.now=original_now;P.urllib.request.urlopen=original_transport;P.write=original_write;P.ref=original_ref
    P.write(output,dict(schema_version=4,kind='fixture_controls',status='passed',checks=checks,check_count=len(checks),network_requests=0,dll_loads=0,fits=0,source_pins={str(Path(__file__).resolve()):P.sha(__file__),str(Path(P.__file__).resolve()):P.sha(P.__file__),str(Path(Q.__file__).resolve()):P.sha(Q.__file__)},scope='handcrafted rejection and archive controls only; no operational issuance or external timestamp attestation'))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);args=ap.parse_args();run_controls(args.output)
