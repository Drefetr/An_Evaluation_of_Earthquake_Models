"""Prospective v2 local archive. Local hashes do not attest external timestamps.

Operational clocks are obtained inside capture/issue functions. Fixtures use a
separate archive kind and cannot enter operational scoring or denominators.
"""
from datetime import datetime,timedelta,timezone
from pathlib import Path
import calendar,hashlib,importlib.util,json,sqlite3,urllib.parse,urllib.request,uuid
import numpy as np
try:
    from . import geometry as G
    from .catalogue import load_catalogue,utc,day
    from .workflow import MODELS,SOURCE_FILES,schedule,read,write,sha
    from .prospective import fixed_arrays
    from .typed_query_adapter_v2 import FixedObjectiveV2,validate_query
except ImportError:
    import geometry as G
    from catalogue import load_catalogue,utc,day
    from workflow import MODELS,SOURCE_FILES,schedule,read,write,sha
    from prospective import fixed_arrays
    from typed_query_adapter_v2 import FixedObjectiveV2,validate_query
HERE=Path(__file__).resolve().parent
SOURCE_V2=['prospective_v2.py','typed_query_adapter_v2.py']
NZ_HASH='feacccb7581d1c4c33f88874cd6b198c41639da6930a7fc35e46f910a594fb3e'
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def objsha(v):return hashlib.sha256(canon(v)).hexdigest()
def iso(t):return t.isoformat().replace('+00:00','Z')
def now():return datetime.now(timezone.utc)
def ref(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def checked_ref(r):
    if not isinstance(r,dict) or sha(r['path'])!=r['sha256']:raise ValueError('ARTIFACT_IDENTITY')
    return Path(r['path']).resolve()
def anniversary(start,years=10):
    year=start.year+years
    return start.replace(year=year,day=min(start.day,calendar.monthrange(year,start.month)[1]))
def horizon(freeze):
    start=(freeze+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
    return start,anniversary(start)
def model_manifest(training):
    return dict(beta=training['beta'],reference_pi=training['reference_pi'],kde_selection=training['kde_selection'],selected_sigma=training['selected_sigma'],models={mid:dict(model=training['models'][mid]['model'],pars=training['models'][mid]['selected']['pars'],spatial=training['models'][mid]['spatial'],sigma=training['models'][mid]['sigma'],cache_paths=training['models'][mid]['cache_paths']) for mid in MODELS})

def initialization_bindings(init):
    """Validate the full procedure, then return the exact map an auditor signs."""
    refs=[init[k] for k in ['methods_protocol','protocol','catalogue','training_case','parameter_manifest']]+init['fit_outputs']+init['nuisance_outputs']
    bindings={str(checked_ref(r)):r['sha256'] for r in refs}
    if len(bindings)!=len(refs):raise ValueError('DUPLICATE_INITIALIZATION_BINDING')
    training=read(init['training_case']['path']);protocol=read(init['protocol']['path']);methods=read(init['methods_protocol']['path']);params=read(init['parameter_manifest']['path'])
    for key in ['models','parameter_bounds','parameter_order','fit_policy','primary_selection','background','kernel_contract']:
        if protocol.get(key)!=methods.get(key):raise ValueError('INITIALIZATION_REGISTERED_PROCEDURE')
    if init['catalogue']['sha256']!=NZ_HASH or training['catalogue_sha256']!=NZ_HASH or training['profile']!='new_zealand' or training['n_train']!=913 or training['status']!='complete':raise ValueError('INITIALIZATION_POPULATION')
    case=training['case']
    if case['train_start']!=0. or case['train_end']!=24394. or case['T0']!=24394. or case['case_id']!='nz_full_training':raise ValueError('INITIALIZATION_WINDOW')
    if training['protocol_sha256']!=init['protocol']['sha256'] or protocol['status']!='frozen' or protocol['models']!=MODELS or protocol['fit_policy']['starts_per_procedure']!=8 or protocol['primary_selection']['sigma_km']!=G.SCALES or protocol['background']['bandwidth_km']!=G.SCALES:raise ValueError('INITIALIZATION_PROCEDURE')
    if set(training['models'])!=set(MODELS) or params!=model_manifest(training):raise ValueError('INITIALIZATION_PARAMETERS')
    fits=[read(r['path']) for r in init['fit_outputs']];expected=schedule('nz_full_training')
    if len(fits)!=10 or [f['procedure_id'] for f in fits]!=[s['id'] for s in expected] or set(str(Path(p).resolve()) for p in training['procedures'])!=set(r['path'] for r in init['fit_outputs']):raise ValueError('INITIALIZATION_ROSTER')
    starts=floors=0;cachepaths=set()
    for f in fits:
        ss=[s for s in f['slots'] if s['kind']=='start'];ff=[s for s in f['slots'] if s['kind']=='floor'];starts+=len(ss);floors+=len(ff)
        if not f['complete'] or len(ss)!=8 or any(s['status']!='complete' for s in ss+ff) or f['selected'] is None:raise ValueError('INITIALIZATION_CANDIDATES')
        if len(f['accepted_candidates'])!=8+len(ff) or len({c['candidate_id'] for c in f['accepted_candidates']})!=len(f['accepted_candidates']):raise ValueError('INITIALIZATION_CANDIDATES')
        cachepaths.update(str(Path(p).resolve()) for p in f['cache_paths'].values())
    alias=training['model_aliases'].get('fixedML_smooth_cont',{})
    winning=training['models']['fixedML_smooth_cont']
    if alias.get('source_procedure_id')!=winning['procedure_id'] or alias.get('source_candidate_id')!=winning['selected']['candidate_id'] or alias.get('no_additional_fit') is not True:raise ValueError('INITIALIZATION_ALIAS')
    if starts!=80 or floors!=11 or cachepaths!=set(str(checked_ref(r)) for r in init['nuisance_outputs']):raise ValueError('INITIALIZATION_ACCOUNTING')
    byid={f['procedure_id']:f for f in fits}
    for mid,m in training['models'].items():
        f=byid[m['procedure_id']]
        if not m['complete'] or m['selected']!=f['selected'] or m['cache_paths']!=f['cache_paths']:raise ValueError('INITIALIZATION_MODEL_BINDING')
    audit=read(checked_ref(init['independent_audit']))
    if audit.get('status')!='passed' or audit.get('independent') is not True or audit.get('bindings')!=bindings or audit.get('denominators')!=dict(procedures=10,starts=80,floors=11) or audit.get('model_roster')!=MODELS:raise ValueError('INITIALIZATION_INDEPENDENT_AUDIT')
    return bindings,training

def verify_registration(path):
    reg=read(path)
    if reg.get('schema_version')!=2 or reg.get('status')!='frozen' or reg.get('kind')!='operational' or reg.get('endpoint_rule')!='same_calendar_date_or_last_day_of_month':raise ValueError('REGISTRATION_V2')
    start,end=horizon(utc(reg['freeze_utc']))
    if utc(reg['start_utc'])!=start or utc(reg['end_utc'])!=end:raise ValueError('REGISTRATION_HORIZON')
    pins=reg['artifact_pins']
    for p in [HERE/n for n in SOURCE_FILES+SOURCE_V2]:
        if pins.get(str(p.resolve()))!=sha(p):raise ValueError('REGISTRATION_SOURCE_PIN')
    for p,digest in pins.items():
        if sha(p)!=digest:raise ValueError('REGISTRATION_ARTIFACT_PIN')
    if reg['capture_policy']['completion_window_minutes_before_start']!=[70,60] or reg['capture_policy']['max_request_span_seconds']!=600 or reg['capture_policy']['canonical_event_type']!='earthquake' or reg['capture_policy']['parser_entrypoint']!='parse_capture':raise ValueError('CAPTURE_POLICY')
    policy=reg['capture_policy']
    if not policy['endpoint'].startswith('https://') or not isinstance(policy['query'],dict) or not isinstance(policy['completeness_controls'],dict) or not 0<policy['max_bytes']<=134217728 or not 0<policy['timeout_seconds']<=60:raise ValueError('CAPTURE_TRANSPORT_POLICY')
    if pins.get(str(Path(policy['parser_path']).resolve()))!=sha(policy['parser_path']):raise ValueError('CAPTURE_PARSER_PIN')
    bindings,training=initialization_bindings(reg['initialization'])
    for p,digest in bindings.items():
        if pins.get(p)!=digest:raise ValueError('INITIALIZATION_FROZEN_PIN')
    a=reg['initialization']['independent_audit']
    if pins.get(str(checked_ref(a)))!=a['sha256']:raise ValueError('INITIALIZATION_AUDIT_PIN')
    return reg,training

def connect(root,registration_sha,kind='operational'):
    root=Path(root);root.mkdir(parents=True,exist_ok=True);db=sqlite3.connect(root/'day_ledger.sqlite',timeout=30,isolation_level=None)
    db.execute('PRAGMA foreign_keys=ON');db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS records(seq INTEGER PRIMARY KEY,day TEXT UNIQUE NOT NULL,body TEXT NOT NULL,previous_sha TEXT NOT NULL,record_sha TEXT NOT NULL UNIQUE)')
    db.execute('CREATE TABLE IF NOT EXISTS captures(day TEXT PRIMARY KEY,receipt_path TEXT UNIQUE NOT NULL,receipt_sha TEXT UNIQUE NOT NULL)')
    for table in ['metadata','records','captures']:
        for op in ['UPDATE','DELETE']:db.execute(f'CREATE TRIGGER IF NOT EXISTS no_{op.lower()}_{table} BEFORE {op} ON {table} BEGIN SELECT RAISE(ABORT,"append only"); END')
    db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)',('registration_sha256',registration_sha));db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)',('kind',kind))
    if dict(db.execute('SELECT key,value FROM metadata'))!=dict(registration_sha256=registration_sha,kind=kind):db.close();raise ValueError('ARCHIVE_IDENTITY')
    return db

def verify_chain(db,registration_sha):
    previous=registration_sha;out={}
    for seq,key,body,prior,digest in db.execute('SELECT seq,day,body,previous_sha,record_sha FROM records ORDER BY seq'):
        v=json.loads(body)
        if seq!=len(out)+1 or prior!=previous or digest!=objsha(dict(seq=seq,day=key,body=v,previous_sha=prior)) or key in out:raise ValueError('DAY_CHAIN_IDENTITY')
        out[key]=(v,digest);previous=digest
    return out

def append_day(db,registration_sha,key,body):
    db.execute('BEGIN IMMEDIATE')
    try:
        rows=verify_chain(db,registration_sha)
        if key in rows:raise ValueError('DAY_ALREADY_FINAL')
        seq=len(rows)+1;prior=next(reversed(rows.values()))[1] if rows else registration_sha;digest=objsha(dict(seq=seq,day=key,body=body,previous_sha=prior))
        db.execute('INSERT INTO records VALUES (?,?,?,?,?)',(seq,key,canon(body).decode(),prior,digest));db.execute('COMMIT');return digest
    except Exception:db.execute('ROLLBACK');raise

def validate_canonical(path,digest,*,snapshot=None,received=None,raw_sha=None):
    obj=read(path)
    if obj.get('schema_version')!=1 or not isinstance(obj.get('events'),list):raise ValueError('SOURCE_CANONICAL_SCHEMA')
    if any(e.get('event_type')!='earthquake' for e in obj['events']):raise ValueError('SOURCE_EARTHQUAKE_TYPE')
    if snapshot is not None and obj['provenance']!=dict(source_snapshot=snapshot,raw_manifest_sha256=raw_sha,retrieved_utc=received):raise ValueError('SOURCE_PROVENANCE_BINDING')
    return load_catalogue(path,digest,profile='new_zealand')

def require_archive(reg,archive_root):
    if str(Path(archive_root).resolve())!=reg['archive_root']:raise ValueError('REGISTERED_ARCHIVE_ROOT')

def capture_source(registration_path,validity_start_utc,archive_root):
    """One actual bounded HTTPS capture; never accepts a caller asserted clock."""
    reg,_=verify_registration(registration_path);require_archive(reg,archive_root);start=utc(validity_start_utc);policy=reg['capture_policy'];began=now();lower=start-timedelta(minutes=70);upper=start-timedelta(minutes=60)
    if not utc(reg['start_utc'])<=start<utc(reg['end_utc']) or began<utc(reg['freeze_utc']) or began<lower or began>upper:raise ValueError('CAPTURE_OUTSIDE_WINDOW')
    if start!=start.replace(hour=0,minute=0,second=0,microsecond=0):raise ValueError('CAPTURE_DAY_BOUNDARY')
    key=start.date().isoformat();folder=Path(archive_root)/'captures'/key;folder.mkdir(parents=True,exist_ok=False)
    query=dict(policy['query']);query['endtime']=iso(began);url=policy['endpoint']+'?'+urllib.parse.urlencode(query);chunks=[];total=0
    request=urllib.request.Request(url,headers={'Accept':policy['accept'],'User-Agent':'external-replication-prospective-v2'})
    with urllib.request.urlopen(request,timeout=policy['timeout_seconds']) as response:
        if response.status!=200:raise ValueError('CAPTURE_HTTP_STATUS')
        headers={k:response.headers.get(k) for k in ['Date','Last-Modified','Content-Length','Content-Type']}
        while True:
            part=response.read(65536)
            if not part:break
            total+=len(part)
            if total>policy['max_bytes']:raise ValueError('CAPTURE_SIZE_CAP')
            chunks.append(part)
    completed=now();raw=b''.join(chunks)
    if completed>upper or completed<lower or (completed-began).total_seconds()>600:raise ValueError('CAPTURE_LATE_OR_STALE')
    if headers['Content-Length'] is not None and int(headers['Content-Length'])!=len(raw):raise ValueError('CAPTURE_TRUNCATED')
    raw_path=folder/'raw_response.bin'
    with raw_path.open('xb') as f:f.write(raw)
    capture_id='capture:'+str(uuid.uuid4());raw_sha=sha(raw_path);provenance=dict(source_snapshot=capture_id,raw_manifest_sha256=raw_sha,retrieved_utc=iso(completed))
    spec=importlib.util.spec_from_file_location('_frozen_geonet_capture_parser',policy['parser_path']);parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    canonical,evidence=parser.parse_capture(raw,query,provenance,policy['completeness_controls'])
    if not isinstance(evidence,dict) or evidence.get('complete') is not True or evidence.get('controls')!=policy['completeness_controls'] or evidence.get('truncation_detected') is not False:raise ValueError('CAPTURE_COMPLETENESS')
    canonical_path=folder/'canonical_parents.json';write(canonical_path,canonical);cat=validate_canonical(canonical_path,sha(canonical_path),snapshot=capture_id,received=iso(completed),raw_sha=raw_sha)
    if np.any(cat.times>=day(validity_start_utc,'new_zealand')):raise ValueError('CAPTURE_FUTURE_PARENT')
    receipt=dict(schema_version=2,kind='operational_capture',status='complete',registration_sha256=sha(registration_path),validity_start_utc=validity_start_utc,actual_request_start_utc=iso(began),actual_receipt_utc=iso(completed),capture_id=capture_id,request=dict(url=url,query=query,headers={'Accept':policy['accept']}),response_headers=headers,raw=ref(raw_path),canonical=ref(canonical_path),parser=ref(policy['parser_path']),completeness=evidence)
    receipt_path=folder/'capture_receipt.json';write(receipt_path,receipt);capture_ref=ref(receipt_path)
    db=connect(archive_root,sha(registration_path))
    try:db.execute('INSERT INTO captures VALUES (?,?,?)',(key,capture_ref['path'],capture_ref['sha256']))
    finally:db.close()
    return capture_ref

def validate_capture(r,reg,regsha,start):
    receipt=read(checked_ref(r));policy=reg['capture_policy'];began=utc(receipt['actual_request_start_utc']);received=utc(receipt['actual_receipt_utc']);lower=start-timedelta(minutes=70);upper=start-timedelta(minutes=60)
    if receipt.get('kind')!='operational_capture' or receipt.get('status')!='complete' or receipt['registration_sha256']!=regsha or utc(receipt['validity_start_utc'])!=start or began<utc(reg['freeze_utc']) or not lower<=began<=received<=upper or (received-began).total_seconds()>600:raise ValueError('CAPTURE_RECEIPT_POLICY')
    raw=checked_ref(receipt['raw']);canonical=checked_ref(receipt['canonical']);checked_ref(receipt['parser'])
    if receipt['parser']!=ref(policy['parser_path']) or receipt['completeness'].get('complete') is not True or receipt['completeness'].get('controls')!=policy['completeness_controls'] or receipt['completeness'].get('truncation_detected') is not False:raise ValueError('CAPTURE_PROCEDURE_BINDING')
    query=dict(policy['query']);query['endtime']=iso(began)
    if receipt['request']['query']!=query or receipt['request']['url']!=policy['endpoint']+'?'+urllib.parse.urlencode(query):raise ValueError('CAPTURE_QUERY_BINDING')
    cat=validate_canonical(canonical,receipt['canonical']['sha256'],snapshot=receipt['capture_id'],received=receipt['actual_receipt_utc'],raw_sha=receipt['raw']['sha256'])
    if np.any(cat.times>=day(iso(start),'new_zealand')):raise ValueError('CAPTURE_PARENT_COHORT')
    return receipt,cat

def issue_day(registration_path,capture_ref,archive_root):
    reg,training=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);capture=read(checked_ref(capture_ref));start=utc(capture['validity_start_utc']);end=start+timedelta(days=1);actual=now();key=start.date().isoformat()
    receipt,cat=validate_capture(capture_ref,reg,regsha,start)
    capturedb=connect(archive_root,regsha)
    try:
        minted=capturedb.execute('SELECT receipt_path,receipt_sha FROM captures WHERE day=?',(key,)).fetchone()
        if minted!=(capture_ref['path'],capture_ref['sha256']):raise ValueError('CAPTURE_NOT_COLLECTOR_MINTED')
    finally:capturedb.close()
    if actual<utc(reg['freeze_utc']) or actual<utc(receipt['actual_receipt_utc']) or actual>=start or not utc(reg['start_utc'])<=start<end<=utc(reg['end_utc']):raise ValueError('ISSUE_LATE_OR_OUTSIDE_HORIZON')
    db=connect(archive_root,regsha)
    try:
        if key in verify_chain(db,regsha):raise ValueError('DAY_ALREADY_FINAL')
        folder=Path(archive_root)/'days'/key;folder.mkdir(parents=True,exist_ok=False);source=folder/'issued_parent_snapshot.json'
        with source.open('xb') as f:f.write(checked_ref(receipt['canonical']).read_bytes())
        models={mid:dict(model=training['models'][mid]['model'],pars=training['models'][mid]['selected']['pars'],spatial=training['models'][mid]['spatial'],sigma=training['models'][mid]['sigma'],nuisance_cache=training['models'][mid]['cache_paths']['train16'],nuisance_cache_sha256=sha(training['models'][mid]['cache_paths']['train16'])) for mid in MODELS}
        packet=dict(schema_version=2,status='issued',kind='operational',registration_path=str(Path(registration_path).resolve()),registration_sha256=regsha,validity_start_utc=iso(start),validity_end_utc=iso(end),actual_issue_utc=iso(actual),source_received_utc=receipt['actual_receipt_utc'],capture_receipt=capture_ref,source_snapshot_path=str(source.resolve()),source_snapshot_sha256=sha(source),models=models,beta=training['beta'],T0=24394.,history_policy='fixed_preissue',backfill=False)
        packet_path=folder/'issued_packet.json';write(packet_path,packet);body=dict(status='issued',kind='operational',day=key,packet=ref(packet_path),capture=capture_ref,actual_issue_utc=iso(actual),validity_start_utc=iso(start),validity_end_utc=iso(end),source=ref(source),initialization_audit=reg['initialization']['independent_audit'],parameter_manifest=reg['initialization']['parameter_manifest'])
        chain=append_day(db,regsha,key,body);return dict(status='issued',day=key,packet=ref(packet_path),chain_sha256=chain,local_timestamp_attestation_only=True)
    finally:db.close()

def finalize_missing_days(registration_path,archive_root):
    reg,_=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);actual=now();db=connect(archive_root,regsha);closed=[]
    try:
        t=utc(reg['start_utc']);end=min(actual,utc(reg['end_utc']))
        while t+timedelta(days=1)<=end:
            key=t.date().isoformat()
            if key not in verify_chain(db,regsha):
                append_day(db,regsha,key,dict(kind='operational',status='missing_unknown',day=key,validity_start_utc=iso(t),validity_end_utc=iso(t+timedelta(days=1)),actual_recorded_utc=iso(actual),reason='no archived prevalidity packet; never backfill'));closed.append(key)
            t+=timedelta(days=1)
        return dict(status='complete',missing_days_recorded=len(closed))
    finally:db.close()

def admitted_packet(registration_path,archive_root,validity_day):
    reg,training=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);db=connect(archive_root,regsha)
    try:
        rows=verify_chain(db,regsha)
        if validity_day not in rows:raise ValueError('DAY_UNISSUED_UNKNOWN')
        body,_=rows[validity_day]
        if body.get('kind')!='operational' or body.get('status')!='issued':raise ValueError('DAY_NOT_OPERATIONALLY_ISSUED')
        packet=read(checked_ref(body['packet']))
        if packet.get('kind')!='operational' or packet.get('status')!='issued' or packet.get('schema_version')!=2 or packet.get('backfill') is not False or packet['registration_sha256']!=regsha:raise ValueError('PACKET_NOT_OPERATIONAL')
        start=utc(packet['validity_start_utc']);end=utc(packet['validity_end_utc']);actual=utc(packet['actual_issue_utc'])
        if validity_day!=start.date().isoformat() or start!=start.replace(hour=0,minute=0,second=0,microsecond=0) or end!=start+timedelta(days=1) or not utc(reg['freeze_utc'])<=actual<start or not utc(reg['start_utc'])<=start<end<=utc(reg['end_utc']):raise ValueError('PACKET_TEMPORAL_BINDING')
        if body['actual_issue_utc']!=packet['actual_issue_utc'] or body['capture']!=packet['capture_receipt'] or body['source']!=dict(path=packet['source_snapshot_path'],sha256=packet['source_snapshot_sha256']):raise ValueError('PACKET_LEDGER_BINDING')
        validate_capture(packet['capture_receipt'],reg,regsha,start);checked_ref(body['source'])
        minted=db.execute('SELECT receipt_path,receipt_sha FROM captures WHERE day=?',(validity_day,)).fetchone()
        if minted!=(body['capture']['path'],body['capture']['sha256']):raise ValueError('CAPTURE_NOT_COLLECTOR_MINTED')
        expected=model_manifest(training)
        if packet['beta']!=expected['beta'] or packet['T0']!=24394. or set(packet['models'])!=set(MODELS):raise ValueError('PACKET_PARAMETER_BINDING')
        for mid,m in packet['models'].items():
            refm=expected['models'][mid]
            if m['model']!=refm['model'] or m['pars']!=refm['pars'] or m['spatial']!=refm['spatial'] or m['sigma']!=refm['sigma'] or m['nuisance_cache']!=refm['cache_paths']['train16'] or sha(m['nuisance_cache'])!=m['nuisance_cache_sha256']:raise ValueError('PACKET_PARAMETER_BINDING')
        packet['_verified_packet_sha256']=body['packet']['sha256'];return packet
    finally:db.close()

def evaluate_issued_day(registration_path,archive_root,validity_day,mid,target_catalogue_path,target_catalogue_sha256):
    packet=admitted_packet(registration_path,archive_root,validity_day)
    if mid not in MODELS:raise ValueError('MODEL_ROSTER')
    targets=validate_canonical(target_catalogue_path,target_catalogue_sha256);start=day(packet['validity_start_utc'],'new_zealand');end=day(packet['validity_end_utc'],'new_zealand');mask=(targets.times>=start)&(targets.times<end)
    arrays,meta=fixed_arrays(packet,mid,targets.times[mask],targets.excess[mask],targets.latitude[mask],targets.longitude[mask]);parents=validate_canonical(packet['source_snapshot_path'],packet['source_snapshot_sha256']);arrays['parent_excess']=parents.excess;meta.update(history_policy='fixed_preissue',profile='new_zealand')
    with FixedObjectiveV2(arrays,meta) as objective:return dict(kind='operational',status='issued_score',day=validity_day,packet_sha256=packet['_verified_packet_sha256'],target_catalogue_sha256=target_catalogue_sha256,model=mid,evaluation=objective.evaluate(packet['models'][mid]['model'],packet['models'][mid]['pars']))
