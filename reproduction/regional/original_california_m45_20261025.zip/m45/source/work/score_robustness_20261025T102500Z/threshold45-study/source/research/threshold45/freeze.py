"""Create a new immutable protocol after raw derivation and independent source review."""
import argparse,datetime,json,sys
from pathlib import Path
from . import scenario as S
from .run import core_pins
BASE_PROTOCOL_SHA='ea11c6b98f2d5dfdea8f5e758a4c1a54ab89ae52e8ae370666b27634365a672b'
METHODS_SHA='8bc5cad81349f9746e56a756abbb26cb9d04ad4d874e834e249a5ad85f770138'
def freeze(base_protocol,methods,derived,dll,design,review,output,audit_reserve):
    S.require(S.sha(base_protocol)==BASE_PROTOCOL_SHA and S.sha(methods)==METHODS_SHA and S.sha(dll)==S.DLL_SHA,'BASE_AUTHORITY_IDENTITY')
    base=S.read(base_protocol);spec=S.read(design);accepted=S.read(review)
    S.require(accepted.get('accepted') is True and accepted.get('scope')=='m45_source_protocol_review' and accepted.get('design_sha256')==S.sha(design),'INDEPENDENT_SOURCE_REVIEW_REQUIRED')
    data=S.read(derived);S.validate_object(data);S.require(audit_reserve>=1200,'MINIMUM_AUDIT_RESERVE')
    protocol={k:base[k] for k in ['schema_version','era','cases','history','spatial','geometry_contract','background','kernel_contract','common_nuisance','parameter_order','parameter_bounds','models','primary_selection','fit_policy','schedule','score']}
    protocol.update(protocol_id=S.ID,status='frozen',science_gate_passed=True,protected_release_authorized=True,scope='One retrospective stricter-observation-law sensitivity, no threshold search or causal/completeness claims',frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),design=spec,design_path=str(Path(design).resolve()),methods_path=str(Path(methods).resolve()),primary_arms=S.PRIMARY,comparisons=base['comparisons'][:3],denominators=spec['denominators'],scenario=dict(id=S.ID,minimum_magnitude='4.5',excess_arithmetic=S.LAW,population=391,warmup=33,training_counts=list(S.TRAIN),test_counts=list(S.TEST),base_run=data['base_run'],base_catalogue=data['base_catalogue'],base_catalogue_sha256=S.BASE_SHA,derived_input_sha256=S.sha(derived)),data=dict(catalogue=str(Path(derived).resolve()),sha256=S.sha(derived),legacy_csv=False),admitted_objective_dll=dict(path=str(Path(dll).resolve()),sha256=S.DLL_SHA,build=False,historical_compiler_provenance='unknown; unchanged admitted binary'),resources=dict(deadline_utc=spec['resources']['deadline_utc'],compute_budget_seconds=21600,audit_reserve_seconds=audit_reserve,seconds_per_procedure=2000,all_rows_retained=True),pilot=spec['pilot'],failure_policy=spec['failure_policy'],adequacy=dict(training_minimum_total=180,training_minimum_each_latitude_zone=30,baseline_descriptive_reference=dict(protected_minimum_total=100,protected_minimum_each_five_year_window=20),known_sensitivity_targets=[16,53,18],interpretation='Below inherited descriptive target-count adequacy; report finite-window exploratory sensitivity with no event-count stopping or exclusion.'))
    protocol['gate_semantics']=dict(science_gate_passed='Independent source/protocol design review only; no numerical control or empirical result is implied',protected_release_authorized='Original source/canonical derivation and full independent audit are authorized locally',fit_execution='Separate pinned pilot_control_admission.json required after passed production and independent controls; remainder requires accepted audited pilot resource gate')
    # Pin all inherited runtime/source dependencies, adding current scenario/core source.
    # Historical source pins remain explicit provenance; they are never relabelled.
    current_core=core_pins(dll);core_names={Path(p).name for p in current_core}
    pins={p:d for p,d in base['artifact_pins'].items() if not (Path(p).parent.name=='external_replication' and Path(p).name in core_names)};pins.update(current_core);source=Path(__file__).resolve().parents[1]
    for package in ['threshold45','threshold45_validation','external_replication','external_replication_validation','score_robustness','score_robustness_validation']:
        for path in sorted((source/package).glob('*.py')):pins[str(path.resolve())]=S.sha(path)
    for path in [Path(sys.executable),Path(methods),Path(design),Path(review),Path(derived),Path(base_protocol)]:pins[str(path.resolve())]=S.sha(path)
    pins.update(data['base_bindings']);protocol['artifact_pins']=pins
    # Reviewer must bind actual reviewed new sources, so post-review changes fail.
    required={str(path.resolve()) for package in ['threshold45','threshold45_validation'] for path in (source/package).glob('*.py')}
    S.require(required and required.issubset(accepted['source_pins']),'COMPLETE_REVIEWED_SCENARIO_ROSTER')
    for path,digest in accepted['source_pins'].items():S.require(pins.get(path)==digest and S.sha(path)==digest,'REVIEWED_SOURCE_CHANGED')
    S.write(output,protocol);return dict(status='frozen',protocol_path=str(Path(output).resolve()),protocol_sha256=S.sha(output),source_pins=len(pins))
def main():
    p=argparse.ArgumentParser()
    for name in ['base-protocol','methods','derived','dll','design','review','output']:p.add_argument('--'+name,required=True)
    p.add_argument('--audit-reserve',type=float,required=True);a=p.parse_args()
    try:r=freeze(a.base_protocol,a.methods,a.derived,a.dll,a.design,a.review,a.output,a.audit_reserve)
    except Exception as e:print(json.dumps(dict(status='failed',fixed_error_code='M45_FREEZE_FAILED',error_type=type(e).__name__)));return 1
    print(json.dumps(r));return 0
if __name__=='__main__':raise SystemExit(main())
