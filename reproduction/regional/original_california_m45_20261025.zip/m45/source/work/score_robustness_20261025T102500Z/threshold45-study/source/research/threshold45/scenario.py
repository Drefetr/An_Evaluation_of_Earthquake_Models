"""Local deterministic scenario adapter. Never print row-bearing values."""
from decimal import Decimal
from pathlib import Path
import hashlib,json
import numpy as np
from ..external_replication.catalogue import Catalogue,day
from ..external_replication import geometry as G

ID='california_m45_v1'
LAW='float(Decimal(raw_magnitude_token))-4.5'
BASE_SHA='46656c01b309b0c546618148f099aa59a8854584c51a7fc1fc0edbe1382dbbf4'
DLL_SHA='c2452e74fcbe8d9d5c2ca11b99a15d6203f6a22f8361b6a9f8a52dd63819019b'
TRAIN=(271,287,340)
TEST=(16,53,18)
PRIMARY=['fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def require(ok,code):
    if not bool(ok):raise ValueError(code)
def magnitude(row):return Decimal(row['source_tokens']['magnitude'])
def derive_rows(rows):
    selected=[];crosswalk=[]
    for i,row in enumerate(rows):
        m=magnitude(row)
        require(m.is_finite(),'NONFINITE_RAW_MAGNITUDE')
        if m<Decimal('4.5'):continue
        q=float(m)-4.5
        require(q>=0 and float(m)==row['magnitude'],'RAW_MAGNITUDE_BINDING')
        crosswalk.append(dict(event_id=row['event_id'],base_index=i,scenario_index=len(selected),q_hex=q.hex()))
        selected.append(row)
    return selected,crosswalk
def verify_selection(events,crosswalk,base_rows):
    expected,expected_crosswalk=derive_rows(base_rows)
    require(events==expected and crosswalk==expected_crosswalk,'RAW_CANONICAL_SCENARIO_SELECTION')
def prepare(base_run,base_catalogue,output):
    # Original M4 binder first; no modified minimum enters the sealed binder.
    from ..external_replication_validation import empirical_io_v2 as I
    from ..external_replication_validation.audit_ca_saved_v3 import merged_input
    base_run=Path(base_run).resolve();base_catalogue=Path(base_catalogue).resolve()
    require(sha(base_catalogue)==BASE_SHA,'BASE_CATALOGUE_HASH')
    train=I.load_ca_lane(base_run,'train');protected=I.load_ca_lane(base_run,'protected')
    merged_input(base_catalogue,base_run/'inputs/california/train/canonical_model.json',base_run/'protected/california/canonical_model.json',BASE_SHA)
    source=I.merge_ca(train,protected);rows=read(base_catalogue)['events']
    require(len(rows)==1272 and [r['event_id'] for r in rows]==source['raw']['row_ids'],'BASE_SUPERSET_CENSUS')
    events,crosswalk=derive_rows(rows)
    bindings=dict(train['bindings']);bindings.update(protected['bindings']);bindings[str(base_catalogue)]=BASE_SHA
    obj=dict(schema='california_m45_derived_v1',scenario_id=ID,minimum_magnitude='4.5',excess_arithmetic=LAW,base_run=str(base_run),base_catalogue=str(base_catalogue),base_catalogue_sha256=BASE_SHA,base_bindings=bindings,events=events,crosswalk=crosswalk)
    validate_object(obj);write(output,obj)
    return dict(status='prepared',scenario_id=ID,population=391,warmup=33,training_counts=list(TRAIN),test_counts=list(TEST),input_path=str(Path(output).resolve()),input_sha256=sha(output))
def validate_object(obj):
    require(obj['schema']=='california_m45_derived_v1' and obj['scenario_id']==ID and obj['minimum_magnitude']=='4.5' and obj['excess_arithmetic']==LAW and obj['base_catalogue_sha256']==BASE_SHA,'SCENARIO_LAW')
    rows=obj['events'];require(len(rows)==391 and len(obj['crosswalk'])==391,'SCENARIO_POPULATION')
    times=np.asarray([day(r['origin_time_utc'],'california') for r in rows]);ids=[r['event_id'] for r in rows]
    require(len(set(ids))==391 and sorted(zip(times,ids))==list(zip(times,ids)),'SCENARIO_CHRONOLOGY')
    for j,(row,entry) in enumerate(zip(rows,obj['crosswalk'])):
        m=magnitude(row);require(m>=Decimal('4.5') and float(m)==row['magnitude'] and entry['event_id']==row['event_id'] and entry['scenario_index']==j and entry['q_hex']==(float(m)-4.5).hex(),'SCENARIO_ROW_CROSSWALK')
    require(sum(times<1826.)==33,'SCENARIO_WARMUP')
    boundaries=[day(x,'california') for x in ['2011-01-01T00:00:00Z','2016-01-01T00:00:00Z','2021-01-01T00:00:00Z','2026-01-01T00:00:00Z']]
    require(tuple(int(((times>=1826)&(times<b)).sum()) for b in boundaries[:3])==TRAIN,'SCENARIO_TRAINING_CENSUS')
    require(tuple(int(((times>=s)&(times<e)).sum()) for s,e in zip(boundaries,boundaries[1:]))==TEST,'SCENARIO_TARGET_CENSUS')
    lat=np.asarray([r['latitude'] for r in rows],float);lon=np.asarray([r['longitude'] for r in rows],float);cells=G.cell_ids(lat,lon,'california');q=np.asarray([float(magnitude(r))-4.5 for r in rows],float)
    for end in boundaries[:3]:
        tr=(times>=1826)&(times<end);marks=q[tr];require(np.all(np.bincount(cells[tr]//3,minlength=3)>=30),'SCENARIO_ZONE_GATE');require(np.any(marks<.5) and np.any(marks>=.5) and float(marks.sum()-.5*(marks>=.5).sum())>0,'SCENARIO_MARK_GATE')
    return times,q,lat,lon,cells,tuple(ids)
def load(path,expected_sha):
    require(sha(path)==expected_sha,'SCENARIO_INPUT_HASH');obj=read(path)
    for p,digest in obj['base_bindings'].items():require(sha(p)==digest,'SCENARIO_BASE_INPUT_CHANGED')
    verify_selection(obj['events'],obj['crosswalk'],read(obj['base_catalogue'])['events'])
    t,q,lat,lon,cells,ids=validate_object(obj)
    return Catalogue(t,q,lat,lon,cells,ids,expected_sha,dict(scenario_id=ID,base_catalogue_sha256=BASE_SHA,minimum_magnitude='4.5',excess_arithmetic=LAW))
