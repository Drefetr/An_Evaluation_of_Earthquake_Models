"""Training-only fixed-parameter resource measurement; no optimizer or test data."""
from pathlib import Path
import argparse,hashlib,json,math,time
import numpy as np
from . import geometry as G
from .catalogue import load_catalogue,day
from .compiled_objective import Objective
from .workflow import verify,source_pins,write

def main():
 p=argparse.ArgumentParser();p.add_argument('--protocol',required=True);p.add_argument('--catalogue',required=True);p.add_argument('--catalogue-sha256',required=True);p.add_argument('--output',required=True);p.add_argument('--expected-source-sha256',required=True);a=p.parse_args()
 own=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 if own!=a.expected_source_sha256:raise ValueError('BENCHMARK_SOURCE_CHANGED')
 protocol=json.loads(Path(a.protocol).read_text());verify(protocol,'controls');out=Path(a.output);out.mkdir(parents=True,exist_ok=True);began=time.perf_counter()
 cat=load_catalogue(a.catalogue,a.catalogue_sha256);start=day('1986-01-01T00:00:00Z','california');end=day('2011-01-01T00:00:00Z','california')
 if np.any(cat.times>=end):raise ValueError('PROTECTED_INPUT_FORBIDDEN')
 tr=cat.times>=start;pi,counts,_=G.cell_proportions(cat.cells,tr);beta,_=G.fit_conditional_beta(cat.excess[tr]);xy=G.project(cat.latitude[tr],cat.longitude[tr]);tic=time.perf_counter();kde=G.select_bandwidth(xy,pi,G.SCALES,training_cells=cat.cells[tr]);loo_seconds=time.perf_counter()-tic;rows=[]
 for sigma in G.SCALES:
  tic=time.perf_counter();arr,meta=G.make_geometry(cat.times,cat.excess,cat.cells,cat.latitude,cat.longitude,beta,start,end,pi,family='continuous',sigma=sigma,order=16,T0=16436.,background='kde',kde_bandwidth=kde['selected_bandwidth'],background_training_xy=xy,background_training_cells=cat.cells[tr],metadata=dict(production_source_pins=source_pins(),catalogue_sha256=cat.source_sha256,protocol_sha256=hashlib.sha256(Path(a.protocol).read_bytes()).hexdigest()))
  path=out/f'benchmark_sigma{sigma:g}.npz';G.save_geometry(path,arr);geom_seconds=time.perf_counter()-tic;measure=[]
  with Objective(path) as objective:
   for model,pars in [('E_fixed',[-3.,0.,.25]),('E_free',[-3.,0.,.25,math.log(.6)]),('E_omori',[-3.,0.,.25,math.log(.01),1.2])]:
    tic=time.perf_counter();result=objective.evaluate(model,pars);cold=time.perf_counter()-tic
    tic=time.perf_counter();objective.evaluate(model,pars);warm=time.perf_counter()-tic
    if not np.isfinite(result['joint_nll']):raise ValueError('NONFINITE_BENCHMARK')
    measure.append(dict(model=model,cold_seconds=cold,warm_seconds=warm,calls=2))
  rows.append(dict(sigma_km=sigma,geometry_seconds=geom_seconds,evaluations=measure))
 receipt=dict(passed=True,kind='training_only_fixed_parameter_benchmark',scored_training_events=int(tr.sum()),history_events=len(cat.times),zone_training_counts=counts.reshape(3,3).sum(axis=1).tolist(),loo_seconds=loo_seconds,measurements=rows,elapsed_seconds=time.perf_counter()-began,optimizer_runs=0,heldout_evaluations=0,input_sha256=cat.source_sha256,source_sha256=own,source_pins=source_pins())
 write(out/'benchmark.json',receipt);print(json.dumps({k:receipt[k] for k in ['passed','scored_training_events','history_events','elapsed_seconds','optimizer_runs','heldout_evaluations']}))

if __name__=='__main__':
 try:main()
 except Exception as error:print(json.dumps(dict(passed=False,fixed_error_code='TRAINING_BENCHMARK_FAILED',error_type=type(error).__name__)));raise SystemExit(1)
