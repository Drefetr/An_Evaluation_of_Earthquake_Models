"""Full-component calendar reducer. Numerical entrypoints require later root lease."""
import math
from datetime import datetime,timezone,timedelta

ATOMIC=('event_ground_log','integrated_intensity','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore')
DERIVED=('timing_logscore','conditional_location_logscore','joint_logscore')
COMPONENTS=ATOMIC+DERIVED
CONTRASTS=(('timing_OC_minus_fixedML','Omori_smooth_cont','fixedML_smooth_cont','timing_logscore'),('location_OC_minus_OL','Omori_smooth_cont','Omori_smooth_lift','conditional_location_logscore'),('joint_OC_minus_commonML','Omori_smooth_cont','commonML_smooth_cont','joint_logscore'))
TOL=1e-4
EPOCH=datetime(1981,1,1,tzinfo=timezone.utc)

def day(value):
    t=datetime.fromisoformat(value.replace('Z','+00:00'))
    if t.utcoffset()!=timedelta(0): raise ValueError('UTC_REQUIRED')
    delta=t-EPOCH
    return (delta//timedelta(microseconds=1))/86400000000

def blocks(fold):
    for year in range(2011+5*fold,2016+5*fold):
        start=f'{year}-01-01T00:00:00Z';end=f'{year+1}-01-01T00:00:00Z'
        yield dict(fold_id=fold,block_id=f'california_fold_{fold}__year_{year}',start_utc=start,end_utc=end,start_day=day(start),end_day=day(end))

def close(a,b):
    if not math.isfinite(float(a)) or not math.isfinite(float(b)) or abs(float(a)-float(b))>TOL: raise ValueError('RECONCILIATION_FAILED')
    return abs(float(a)-float(b))

def derive(row):
    row['timing_logscore']=row['event_ground_log']-row['integrated_intensity']
    row['conditional_location_logscore']=math.fsum(row[k] for k in ('conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore'))
    row['joint_logscore']=math.fsum(row[k] for k in ('timing_logscore','conditional_location_logscore','mark_logscore'))
    return row

def reduce_block(state,block,exposure):
    et=state['event_time']; indices=[i for i,t in enumerate(et) if block['start_day']<=t<block['end_day']]
    logs=state['logs'];beta=state['beta'];q=state['event_excess']
    row={**{k:v for k,v in block.items() if not k.endswith('_day')},**state['identity'],'status':'succeeded','target_count':len(indices),**exposure}
    row.update(event_ground_log=math.fsum(logs['ground'][i] for i in indices),conditional_zone_logscore=math.fsum(logs['zone'][i]-logs['ground'][i] for i in indices),conditional_cell_logscore=math.fsum(logs['cell'][i]-logs['zone'][i] for i in indices),within_cell_density_logscore=math.fsum(logs['point'][i]-logs['cell'][i] for i in indices),mark_logscore=len(indices)*math.log(beta)-beta*math.fsum(q[i] for i in indices))
    derive(row)
    row['per_target']={k:row[k]/len(indices) if indices else None for k in COMPONENTS}
    row['timing_exposure_logscore']=-row['integrated_intensity']
    close(math.fsum(exposure['cell_integrated_intensity']),exposure['integrated_intensity'])
    for z in range(3):close(math.fsum(exposure['cell_integrated_intensity'][z*3:z*3+3]),exposure['zone_integrated_intensity'][z])
    close(exposure['integrated_intensity'],exposure['immigrant_exposure']+exposure['triggered_integrated_intensity'])
    return row

def contrasts(rows):
    lookup={(r['fold_id'],r['arm_id'],r['block_id']):r for r in rows};output=[]
    if len(lookup)!=len(rows): raise ValueError('DUPLICATE_ARM_BLOCK')
    for fold in range(3):
        for block in blocks(fold):
            for cid,A,B,primary in CONTRASTS:
                a=lookup[(fold,A,block['block_id'])];b=lookup[(fold,B,block['block_id'])]
                row={k:block[k] for k in ('fold_id','block_id','start_utc','end_utc')}
                row.update(contrast_id=cid,arm_A=A,arm_B=B,primary_component=primary,status='unresolved',target_count=None)
                if a['status']==b['status']=='succeeded':
                    if a['target_count']!=b['target_count']: raise ValueError('POPULATION_MISMATCH')
                    row.update(status='succeeded',target_count=a['target_count'],**{k:a[k]-b[k] for k in COMPONENTS})
                    row['primary_value']=row[primary];row['exposure_contribution']=-(a['integrated_intensity']-b['integrated_intensity'])
                    row['per_target']={k:row[k]/row['target_count'] if row['target_count'] else None for k in COMPONENTS}
                else:
                    row.update({k:None for k in COMPONENTS});row.update(primary_value=None,exposure_contribution=None)
                output.append(row)
    if len(rows)!=60 or len(output)!=45: raise ValueError('BLOCK_ROSTER')
    for cid,_,_,primary in CONTRASTS:
        group=[r for r in output if r['contrast_id']==cid]
        denominator=math.fsum(r[primary] for r in group) if all(r['status']=='succeeded' for r in group) else None
        for r in group:r['signed_share']=r[primary]/denominator if denominator else None
    return output

def reconcile_window(rows,forecast,full_exposure):
    if len(rows)!=5 or len({r['block_id'] for r in rows})!=5: raise ValueError('OMITTED_BLOCK')
    discrepancies={}
    for k in COMPONENTS:
        reference=forecast['event_log_ground_intensity_sum'] if k=='event_ground_log' else forecast[k]
        discrepancies[k]=close(math.fsum(r[k] for r in rows),reference)
    for k in ('immigrant_exposure','trigger_exposure','triggered_integrated_intensity','integrated_intensity'):
        discrepancies[k]=close(math.fsum(r[k] for r in rows),full_exposure[k])
    close(full_exposure['trigger_exposure'],forecast['trigger_exposure'])
    for k,size in (('cell_integrated_intensity',9),('zone_integrated_intensity',3)):
        discrepancies[k]=max(close(math.fsum(r[k][j] for r in rows),forecast[k][j]) for j in range(size))
    return discrepancies
