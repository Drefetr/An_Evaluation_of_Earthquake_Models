"""Scenario-only annual accounting; unchanged C++ exposure ABI and reducer math."""
import argparse,json,math
from pathlib import Path
import numpy as np
from . import scenario as S
from .run import verify
from ..external_replication import geometry as G
from ..score_robustness.native import Exposure
from ..score_robustness import reducer as R

def blank():
    rows=[]
    for f in range(3):
        for arm in S.PRIMARY:
            for b in R.blocks(f):rows.append(dict(**{k:v for k,v in b.items() if not k.endswith('_day')},arm_id=arm,status='unresolved',target_count=None,**{k:None for k in R.COMPONENTS}))
    return dict(schema='california_m45_annual_v1',scenario_id=S.ID,status='unresolved',arm_blocks=rows,contrast_blocks=R.contrasts(rows),windows=[],window_checks=[],denominators=dict(arm_blocks=60,contrast_blocks=45,targets=87))
def annual(protocol_path,root,full_audit_path,admission_path,exposure_dll,exposure_sha256,output):
    result=blank();protocol=S.read(protocol_path);dll=verify(protocol);protocol_sha=S.sha(protocol_path);audit=S.read(full_audit_path);admission=S.read(admission_path)
    S.require(audit.get('passed') is True and audit.get('independent') is True and audit['protocol_sha256']==protocol_sha and audit['folds']==[0,1,2],'FULL_RAW_AUDIT_REQUIRED')
    S.require(str((Path(root)/'summary_private.json').resolve()) in audit['bindings'],'EXACT_AUDITED_OUTPUT_ROOT')
    for collection in ['bindings','cache_bindings','source_bindings','planning_bindings']:
        for path,digest in audit[collection].items():S.require(S.sha(path)==digest,'AUDITED_OUTPUT_CHANGED')
    S.require(admission.get('accepted') is True and admission['protocol_sha256']==protocol_sha and admission['full_audit_sha256']==S.sha(full_audit_path) and admission.get('scientific_scores_used_for_admission') is False,'ANNUAL_RESOURCE_GATE')
    S.require(admission['exposure_dll']==dict(path=str(Path(exposure_dll).resolve()),sha256=exposure_sha256),'EXPOSURE_ADMISSION_BINDING')
    engine=Exposure(exposure_dll,exposure_sha256);cat=S.load(protocol['data']['catalogue'],protocol['data']['sha256']);root=Path(root);rows=[];states=[];checks=[]
    for f in range(3):
        folder=root/f'california_fold_{f}';row=S.read(folder/'training_case.json');case=row['case'];final=S.read(folder/'case.json');S.require(row['status']=='complete' and final['status']=='complete' and row['catalogue_sha256']==cat.source_sha256 and row['protocol_sha256']==protocol_sha,'ANNUAL_CASE_BINDING')
        tr=(cat.times>=case['train_start'])&(cat.times<case['train_end']);te=(cat.times>=case['test_start'])&(cat.times<case['test_end']);S.require(int(te.sum())==S.TEST[f],'ANNUAL_TARGET_CENSUS')
        for arm in S.PRIMARY:
            fit=row['models'][arm];saved=S.read(folder/f"score_{fit['procedure_id']}.json");forecast=saved['forecast'];S.require(fit['complete'] and saved['status']=='complete','ANNUAL_FIT_STATUS')
            identity=dict(arm_id=arm,logical_arm_window_id=f'california_fold_{f}__arm_{arm}',actual_procedure_id=fit['procedure_id'],selected_candidate_id=fit['selected']['candidate_id'])
            arr,_=G.make_geometry(cat.times,cat.excess,cat.cells,cat.latitude,cat.longitude,row['beta'],case['test_start'],case['test_end'],row['reference_pi'],family='continuous' if fit['spatial']=='cont' else 'center',sigma=fit['sigma'],order=16,T0=case['T0'],background='kde',kde_bandwidth=row['kde_selection']['selected_bandwidth'],background_training_xy=G.project(cat.latitude[tr],cat.longitude[tr],'california'),background_training_cells=cat.cells[tr],profile='california',dll_path=dll)
            def integral(lo,hi):return engine.evaluate(fit['model'],fit['selected']['pars'],arr['parent_time'],arr['parent_excess'],row['beta'],lo,hi,case['T0'],arr['mixture_weights'],arr['mixture_rates'],arr['background_cell_mass'],arr['parent_cell_mass'].ravel())
            state=dict(identity=identity,event_time=arr['event_time'].tolist(),event_excess=arr['event_excess'].tolist(),beta=row['beta'],logs={name:forecast['event_log_'+name+'_intensity'] for name in ['point','cell','zone','ground']})
            local=[R.reduce_block(state,b,integral(b['start_day'],b['end_day'])) for b in R.blocks(f)];full=integral(case['test_start'],case['test_end']);discrepancy=R.reconcile_window(local,forecast,full);rows.extend(local);checks.append(dict(fold_id=f,arm_id=arm,target_count=S.TEST[f],status='succeeded',discrepancies=discrepancy))
            archive={k:v for k,v in forecast.items() if k not in ['event_log_point_intensity','event_log_cell_intensity','event_log_zone_intensity','event_log_ground_intensity']}
            states.append(dict(**identity,fold_id=f,start=case['test_start'],end=case['test_end'],T0=case['T0'],parameters=fit['selected']['pars'],temporal=fit['temporal'],spatial='continuous' if fit['spatial']=='cont' else 'lift',sigma=fit['sigma'],beta=row['beta'],bandwidth=row['kde_selection']['selected_bandwidth'],train_start=case['train_start'],train_end=case['train_end'],source_hash_lineage=dict(protocol_sha256=protocol_sha,input_sha256=cat.source_sha256,training_case_sha256=S.sha(folder/'training_case.json'),score_sha256=S.sha(folder/f"score_{fit['procedure_id']}.json")),archive_reference=archive))
    contrasts=R.contrasts(rows);pooled=[]
    for cid,A,B,primary in R.CONTRASTS:
        group=[r for r in contrasts if r['contrast_id']==cid];sums={k:math.fsum(r[k] for r in group) for k in R.COMPONENTS};pooled.append(dict(contrast_id=cid,primary_component=primary,target_count=87,component_sums=sums,per_target={k:v/87 for k,v in sums.items()}))
    result.update(status='complete',protocol_sha256=protocol_sha,input_sha256=cat.source_sha256,full_audit_path=str(Path(full_audit_path).resolve()),full_audit_sha256=S.sha(full_audit_path),annual_admission_path=str(Path(admission_path).resolve()),annual_admission_sha256=S.sha(admission_path),exposure_dll=dict(path=str(Path(exposure_dll).resolve()),sha256=exposure_sha256),arm_blocks=rows,contrast_blocks=contrasts,windows=states,window_checks=checks,pooled_checks=pooled,aggregate_release_approved=False)
    S.write(output,result);return dict(status='complete',arm_blocks=60,contrast_blocks=45,targets=87,aggregate_release_approved=False)
def main():
    p=argparse.ArgumentParser()
    for name in ['protocol','root','full-audit','admission','exposure-dll','exposure-sha256','output']:p.add_argument('--'+name,required=True)
    a=p.parse_args()
    try:r=annual(a.protocol,a.root,a.full_audit,a.admission,a.exposure_dll,a.exposure_sha256,a.output)
    except Exception as e:
        result=blank();result.update(fixed_error_code='M45_ANNUAL_FAILED',error_type=type(e).__name__)
        if not Path(a.output).exists():S.write(a.output,result)
        print(json.dumps(dict(status='failed',fixed_error_code='M45_ANNUAL_FAILED',error_type=type(e).__name__)));return 1
    print(json.dumps(r));return 0
if __name__=='__main__':raise SystemExit(main())
