"""Source-prepared annual decomposition. Importing this package builds/runs nothing."""
