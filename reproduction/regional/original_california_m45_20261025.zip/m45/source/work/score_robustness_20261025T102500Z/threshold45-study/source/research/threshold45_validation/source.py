"""Independent observation-law binding after original M4 raw verification."""
from decimal import Decimal
from pathlib import Path
import math
import json
import numpy as np
from external_replication_validation import empirical_io_v2 as I
from external_replication_validation.audit_ca_saved_v3 import merged_input, frozen_case

SCENARIO = 'california_m45_v1'
LAW = 'float(Decimal(raw_magnitude_token))-4.5'
BASE_SHA = '46656c01b309b0c546618148f099aa59a8854584c51a7fc1fc0edbe1382dbbf4'
METHODS_SHA = '8bc5cad81349f9746e56a756abbb26cb9d04ad4d874e834e249a5ad85f770138'
DLL_SHA = 'c2452e74fcbe8d9d5c2ca11b99a15d6203f6a22f8361b6a9f8a52dd63819019b'
TRAIN = [271, 287, 340]
TEST = [16, 53, 18]
CORE = ['__init__.py', 'objective.cpp', 'objective.dll', 'compiled_objective.py',
        'geometry.py', 'fitting.py', 'catalogue.py', 'workflow.py',
        'prospective.py', 'synthetic.py', 'build_objective.cmd']
MATH_KEYS = ['models', 'parameter_bounds', 'parameter_order', 'fit_policy',
             'primary_selection', 'background', 'kernel_contract', 'common_nuisance']


def exact_json(actual, expected):
    """JSON field equality also distinguishes booleans, integers and floats."""
    return json.dumps(actual, sort_keys=True, separators=(',', ':'), allow_nan=False) == json.dumps(
        expected, sort_keys=True, separators=(',', ':'), allow_nan=False)


def repository_root():
    return Path(__file__).resolve().parents[6]


def pin_protocol(protocol, methods_path):
    """Admit exact inherited math, original DLL and copied core source bytes."""
    I.require(protocol['status'] == 'frozen' and protocol['science_gate_passed'] is True
              and protocol['protected_release_authorized'] is True,
              'SCENARIO_FROZEN_RELEASE_GATE')
    for path, digest in protocol['artifact_pins'].items():
        I.require(I.sha(path) == digest, 'SCENARIO_FROZEN_DEPENDENCY_CHANGED')
    I.require(I.sha(methods_path) == METHODS_SHA and
              str(Path(methods_path).resolve()) in protocol['artifact_pins'] and
              protocol['artifact_pins'][str(Path(methods_path).resolve())] == METHODS_SHA,
              'EXACT_INHERITED_METHODS')
    methods = I.read(methods_path)
    for key in MATH_KEYS:
        I.require(protocol[key] == methods[key], 'UNCHANGED_INHERITED_MATHEMATICS')
    core = {p: h for p, h in protocol['artifact_pins'].items()
            if Path(p).name in CORE and Path(p).parent.name == 'external_replication'}
    I.require(len(core) == 11 and {Path(p).name for p in core} == set(CORE),
              'EXACT_CORE_PIN_ROSTER')
    original_protocol_path = repository_root() / 'research_runs/california_schema_repair_20261025T044000Z/design/california_observed_protocol_v1.json'
    I.require(I.sha(original_protocol_path) == 'ea11c6b98f2d5dfdea8f5e758a4c1a54ab89ae52e8ae370666b27634365a672b',
              'ORIGINAL_CORE_SOURCE_AUTHORITY')
    original_protocol = I.read(original_protocol_path)
    original_core = {Path(p).name:h for p,h in original_protocol['artifact_pins'].items()
                     if Path(p).name in CORE and Path(p).parent.name == 'external_replication'}
    I.require(set(original_core) == set(CORE), 'ORIGINAL_CORE_SOURCE_ROSTER')
    expected_dll = repository_root() / 'work/california_schema_repair_20261025T044000Z/study/source/research/external_replication/objective.dll'
    for p, digest in core.items():
        if Path(p).name == 'objective.dll':
            I.require(Path(p).resolve() == expected_dll.resolve() and digest == DLL_SHA,
                      'EXACT_ORIGINAL_ADMITTED_DLL')
        else:
            I.require(digest == original_core[Path(p).name], 'UNCHANGED_CORE_SOURCE_BYTES')
    I.require(protocol['era']['T0_days'] == 16436. and len(protocol['cases']) == 3,
              'FROZEN_THREE_ORIGIN_ERA')
    for fold, spec in enumerate(protocol['cases']):
        year = 2011 + 5 * fold
        I.require(spec['id'] == f'california_fold_{fold}' and spec['fold'] == fold
                  and spec['history_start_utc'] == '1981-01-01T00:00:00Z'
                  and spec['train_start_utc'] == '1986-01-01T00:00:00Z'
                  and spec['train_end_utc'] == spec['test_start_utc'] == f'{year}-01-01T00:00:00Z'
                  and spec['test_end_utc'] == f'{year+5}-01-01T00:00:00Z',
                  'FROZEN_CASE_CALENDAR')


def bind_source(protocol):
    """Bind raw/canonical superset, then derive fresh threshold and q locally.

    Canonical magnitude tokens are consumed only after load_ca_lane validates
    every source field against original raw bytes; no producer arrays are read.
    """
    scenario = protocol['scenario']
    base_run = repository_root() / 'research_runs/california_schema_repair_20261025T044000Z'
    base_catalogue = base_run / 'inputs/california/canonical_merged_v1.json'
    expected = dict(id=SCENARIO, minimum_magnitude='4.5', excess_arithmetic=LAW,
                    population=391, warmup=33, training_counts=TRAIN, test_counts=TEST,
                    base_run=str(base_run.resolve()), base_catalogue=str(base_catalogue.resolve()),
                    base_catalogue_sha256=BASE_SHA,
                    derived_input_sha256=protocol['data']['sha256'])
    I.require(exact_json(scenario, expected), 'EXACT_SCENARIO_OBSERVATION_LAW')
    train = I.load_ca_lane(base_run, 'train')
    protected = I.load_ca_lane(base_run, 'protected')
    merged = I.merge_ca(train, protected)
    merged_input(base_catalogue, base_run/'inputs/california/train/canonical_model.json',
                 base_run/'protected/california/canonical_model.json', BASE_SHA)
    base = I.read(base_catalogue)
    raw = merged['raw']
    I.require(len(raw['times']) == 1272 and len(set(raw['row_ids'])) == 1272
              and int(np.count_nonzero(raw['times'] < 1826.)) == 106
              and [e['event_id'] for e in base['events']] == raw['row_ids'],
              'ORIGINAL_RAW_BOUND_SUPERSET')
    bindings = dict(train['bindings'])
    for path, digest in protected['bindings'].items():
        I.require(path not in bindings or bindings[path] == digest, 'SOURCE_BINDING_CONFLICT')
        bindings[path] = digest
    bindings[str(base_catalogue.resolve())] = BASE_SHA
    indices = [i for i, event in enumerate(base['events'])
               if Decimal(event['source_tokens']['magnitude']) >= Decimal('4.5')]
    events = [base['events'][i] for i in indices]
    q = np.asarray([float(Decimal(event['source_tokens']['magnitude'])) - 4.5
                    for event in events], dtype=float)
    derived_path = Path(protocol['data']['catalogue']).resolve()
    I.require(derived_path != base_catalogue.resolve() and derived_path.suffix == '.json'
              and protocol['data'].get('legacy_csv', False) is False
              and I.sha(derived_path) == protocol['data']['sha256'],
              'SEPARATE_DERIVED_INPUT_IDENTITY')
    crosswalk = [dict(event_id=event['event_id'], base_index=i, scenario_index=j,
                      q_hex=float(q[j]).hex()) for j, (i, event) in enumerate(zip(indices, events))]
    expected_derived = dict(schema='california_m45_derived_v1', scenario_id=SCENARIO,
                            minimum_magnitude='4.5', excess_arithmetic=LAW,
                            base_run=str(base_run.resolve()), base_catalogue=str(base_catalogue.resolve()),
                            base_catalogue_sha256=BASE_SHA, base_bindings=bindings,
                            events=events, crosswalk=crosswalk)
    I.require(exact_json(I.read(derived_path), expected_derived), 'EXACT_RAW_DERIVED_EVENTS_Q_CROSSWALK')
    # Fresh independent arrays, with original geometry and complete eligible history.
    subset = {key: raw[key][indices].copy() for key in
              ['times', 'latitude', 'longitude', 'xy', 'cells', 'source_year', 'source_line', 'origin_us']}
    subset.update(excess=q, row_ids=[e['event_id'] for e in events], rectangles=raw['rectangles'].copy())
    t = subset['times']
    I.require(len(t) == 391 and len(set(subset['row_ids'])) == 391
              and int(np.count_nonzero(t < 1826.)) == 33
              and np.all(np.diff(t) >= 0) and np.all(t >= 0.)
              and np.isfinite(q).all() and np.all(q >= 0.), 'SCENARIO_CENSUS_WARMUP_CHRONOLOGY')
    admissions = []
    for fold, spec in enumerate(protocol['cases']):
        case = frozen_case(spec, protocol['era']['T0_days'])
        tr = (t >= case['train_start']) & (t < case['train_end'])
        te = (t >= case['test_start']) & (t < case['test_end'])
        zone = np.bincount(subset['cells'][tr]//3, minlength=3)
        high = q[tr] >= .5
        residual = math.fsum(q[tr][~high]) + math.fsum(q[tr][high]-.5)
        I.require(int(tr.sum()) == TRAIN[fold] and int(te.sum()) == TEST[fold]
                  and int((t < case['train_end']).sum()) == TRAIN[fold]+33
                  and int(tr.sum()) >= 180 and np.all(zone >= 30)
                  and high.any() and (~high).any() and residual > 0,
                  'SCENARIO_TRAIN_TARGET_ZONE_MARK_ELIGIBILITY')
        # Retain the historical M2 training-only screen as a separate admission.
        completeness = I.ca_training_admission(raw, merged['diagnostic'], 2011+5*fold)
        I.require(completeness['admitted'], 'INHERITED_TRAINING_ONLY_SCREEN')
        admissions.append(dict(fold=fold, training_events=int(tr.sum()), target_events=int(te.sum()),
                               training_zone_counts=zone.tolist(), low_mark_events=int((~high).sum()),
                               high_mark_events=int(high.sum()), positive_mark_residual=True,
                               inherited_training_screen= completeness))
    return subset, bindings, admissions


def scenario_cache_metadata(path, protocol):
    """Additional scenario bindings; inherited audit validates every feature."""
    with np.load(path, allow_pickle=False) as saved:
        meta = json.loads(str(saved['metadata_json'].item()))
    expected = dict(scenario_id=SCENARIO, scenario_minimum_magnitude='4.5',
                    scenario_excess_arithmetic=LAW, scenario_input_sha256=protocol['data']['sha256'],
                    base_catalogue_sha256=BASE_SHA)
    I.require(all(meta.get(k) == value for k, value in expected.items()), 'CACHE_SCENARIO_IDENTITY')
    return I.sha(path)
