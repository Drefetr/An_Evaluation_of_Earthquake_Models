"""Root-leased M4.5 full-procedure audit; scalar stdout and private report."""
import argparse
import json
from pathlib import Path
from external_replication_validation import empirical_io_v2 as I
from external_replication_validation.audit_ca_saved_v3 import frozen_case
from external_replication_validation.audit_ca_training_v2 import audit_training
from external_replication_validation.audit_ca_forecast_v2 import audit_forecast
from .source import bind_source, pin_protocol, scenario_cache_metadata, SCENARIO

PRIMARY = ['fixedML_smooth_cont', 'commonML_smooth_cont',
           'Omori_smooth_cont', 'Omori_smooth_lift']


def procedure_plan(case):
    cid = case['case_id']
    schedule = [dict(id=f'{cid}__selector_fixedML_smooth_cont_sigma{sigma:g}', case=cid,
                     phase='primary_selector', temporal='fixedML', background='smooth',
                     spatial='cont', sigma_km=sigma, starts=8)
                for sigma in [5., 15., 50., 150., 500., 1500.]]
    for mid in ['fixedML_smooth_lift', 'commonML_smooth_cont',
                'Omori_smooth_cont', 'Omori_smooth_lift']:
        temporal, background, spatial = mid.split('_')
        schedule.append(dict(id=f'{cid}__main_{mid}', case=cid, phase='primary_main',
                             temporal=temporal, background=background, spatial=spatial,
                             sigma_km='selected_baseline_sigma', starts=8))
    return dict(case=case, schedule=schedule, procedures=10, mandatory_starts=80, exact_floor_slots=11)


def audit(root, protocol_path, methods_path, folds):
    root = Path(root).resolve()
    I.require(folds in [[0], [1, 2], [0, 1, 2]], 'DECLARED_PILOT_REMAINING_FINAL_FOLDS')
    protocol = I.read(protocol_path)
    pin_protocol(protocol, methods_path)
    raw, source_bindings, admissions = bind_source(protocol)
    plan_path = root/'all_procedure_plan.json'
    I.require(I.read(plan_path) == dict(scenario_id=SCENARIO, schedule=protocol['schedule'],
              procedures=30, mandatory_starts=240, exact_floor_slots=33,
              model_window_statuses=15, primary_arm_windows=12, targets=87),
              'EXACT_GLOBAL_PLANNED_DENOMINATOR')
    planning_bindings = {str(plan_path.resolve()):I.sha(plan_path)}
    results = []
    final_cases = []
    bindings = {}
    cache_bindings = {}
    model_statuses = []

    def bind(path):
        path = Path(path).resolve()
        I.require(str(path) not in bindings, 'UNIQUE_SAVED_ARTIFACT_BINDINGS')
        bindings[str(path)] = I.sha(path)

    for fold in folds:
        spec = protocol['cases'][fold]
        case = frozen_case(spec, protocol['era']['T0_days'])
        folder = root / case['case_id']
        training, context = audit_training(folder/'training_case.json', protocol_path,
                                            methods_path, raw, protocol['data']['sha256'], case)
        forecast = audit_forecast(folder, raw, context)
        final = I.read(folder/'case.json')
        final_cases.append(final)
        I.require(I.read(folder/'procedure_plan.json') == procedure_plan(case), 'EXACT_PROCEDURE_PLAN')
        for name in ['training_case.json', 'case.json', 'procedure_plan.json', 'alias_fixedML_smooth_cont.json']:
            bind(folder/name)
        for path in context['paths']:
            fit = I.read(path)
            bind(path)
            bind(folder/('registry_'+fit['procedure_id']+'.json'))
            bind(folder/('score_'+fit['procedure_id']+'.json'))
            score = I.read(folder/('score_'+fit['procedure_id']+'.json'))
            for cache in list(fit['cache_paths'].values()) + list(score['forecast_cache_paths'].values()):
                cache = str(Path(cache).resolve())
                if cache not in cache_bindings:
                    cache_bindings[cache] = scenario_cache_metadata(cache, protocol)
        expected_models = PRIMARY + ['fixedML_smooth_lift']
        I.require(set(final['models']) == set(expected_models), 'FIVE_SAVED_MODEL_STATUSES_PER_FOLD')
        for mid in expected_models:
            status = final['models'][mid]['status']
            I.require(status in ['complete', 'unknown_incomplete'], 'EXACT_MODEL_STATUS_DOMAIN')
            model_statuses.append(dict(fold=fold, model=mid, primary=mid in PRIMARY, status=status))
        results.append(dict(fold=fold, training=training, forecast=forecast))
    nf = len(folds)
    I.require(len(bindings) == 34*nf and len(cache_bindings) == 28*nf,
              'COMPLETE_REPORT_AND_CACHE_BINDING_DENOMINATORS')
    summary_checked = folds == [0, 1, 2]
    summary_name = ('summary_private.json' if summary_checked else
                    'pilot_summary_private.json' if folds == [0] else 'remainder_summary_private.json')
    expected_summary = dict(status='complete' if all(c['status'] == 'complete' for c in final_cases)
                            else 'unknown_incomplete', mode='california_m45', scenario_id=SCENARIO,
                            protocol_sha256=I.sha(protocol_path), cases=final_cases,
                            procedures=10*nf, mandatory_starts=80*nf, exact_floor_slots=11*nf)
    if summary_checked:
        expected_summary['pilot_reused'] = True
    I.require(I.read(root/summary_name) == expected_summary, 'EXACT_SAVED_SCENARIO_SUMMARY_ALL_CASE_BINDING')
    bind(root/summary_name)
    I.require(len(model_statuses) == 5*nf and sum(x['primary'] for x in model_statuses) == 4*nf,
              'EXACT_MODEL_PRIMARY_WINDOW_DENOMINATORS')
    numeric = [r[phase]['numerical'] for r in results for phase in ['training', 'forecast']]
    totals = dict(procedures=10*nf, starts=80*nf, floors=11*nf,
                  candidates=sum(r['training']['candidate_count'] for r in results),
                  finite_solver_returns=sum(r['training']['finite_solver_returns'] for r in results),
                  model_statuses=5*nf, primary_windows=4*nf)
    I.require(totals['candidates'] == 91*nf, 'ALL_ACCEPTED_CANDIDATES_AUDITED')
    return dict(schema='california_m45_independent_audit_v1', scenario_id=SCENARIO,
                status='passed', passed=True, independent=True, folds=folds,
                scope='Original raw/canonical verification, independent M4.5 Decimal-token membership/q and private crosswalk; every saved candidate, finite return, floor, nuisance/cache and forecast; selected-fit and final summary binding',
                no_production_imports_or_dll_loading=True,
                data_classification='local_verified_empirical_rows',
                protocol_sha256=I.sha(protocol_path), methods_sha256=I.sha(methods_path),
                input_sha256=protocol['data']['sha256'], source_commit=I.COMMIT,
                source_bindings=source_bindings, bindings=bindings, cache_bindings=cache_bindings,
                planning_bindings=planning_bindings,
                denominators=totals, training_admissions=admissions, model_statuses=model_statuses,
                full_summary_checked=summary_checked,
                # Fixed M4.5 test counts are sensitivity diagnostics, not a new
                # post-outcome population gate or a claim of physical completeness.
                target_adequacy=dict(total_events=87, window_events=[16, 53, 18],
                                     inherited_descriptive_threshold_met=False,
                                     role='descriptive_only_no_population_change'),
                maximum_absolute_score_error=max(n['maximum_absolute_score_error'] for n in numeric),
                maximum_absolute_gradient_error=max(n['maximum_absolute_gradient_error'] for n in numeric),
                maximum_gradient_criterion_ratio=max(n['maximum_gradient_criterion_ratio'] for n in numeric),
                gradient_criterion='abs(delta)<=2e-5+2e-10*maxabs_per_coordinate',
                score_absolute_tolerance=1e-4, cases=results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True)
    parser.add_argument('--protocol', required=True)
    parser.add_argument('--methods', required=True)
    parser.add_argument('--folds', nargs='+', type=int, required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        result = audit(args.root, args.protocol, args.methods, args.folds)
    except Exception as error:
        # Do not disclose data-bearing messages, arrays, identifiers or tracebacks.
        result = dict(schema='california_m45_independent_audit_v1', status='failed',
                      passed=False, independent=True, fixed_error_code='M45_SAVED_AUDIT_FAILED',
                      error_type=type(error).__name__)
    with Path(args.output).open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    keys = ['status', 'passed', 'folds', 'denominators', 'full_summary_checked',
            'maximum_absolute_score_error', 'maximum_absolute_gradient_error',
            'maximum_gradient_criterion_ratio', 'fixed_error_code', 'error_type']
    print(json.dumps({k: result[k] for k in keys if k in result}, allow_nan=False))
    return 0 if result['passed'] else 1
