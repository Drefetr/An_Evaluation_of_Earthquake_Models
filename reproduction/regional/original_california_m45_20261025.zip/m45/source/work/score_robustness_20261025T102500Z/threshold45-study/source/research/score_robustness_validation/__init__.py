"""Independent source-prepared calendar-block reconstruction; never imports production."""
