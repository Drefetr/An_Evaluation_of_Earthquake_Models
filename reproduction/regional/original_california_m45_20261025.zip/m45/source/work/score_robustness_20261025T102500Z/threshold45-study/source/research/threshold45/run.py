"""Root-leased scenario fit/score runner; complete per-fold denominator retained."""
import argparse,datetime,json,os,sys,time
from pathlib import Path
from . import scenario as S
from ..external_replication import workflow as W,geometry as G
from ..external_replication.compiled_objective import Objective

class Geometry:
    def __init__(self,dll,metadata):self.dll=dll;self.metadata=metadata
    def __getattr__(self,name):return getattr(G,name)
    def select_bandwidth(self,*args,**kwargs):return G.select_bandwidth(*args,**dict(kwargs,dll_path=self.dll))
    def make_geometry(self,*args,**kwargs):
        meta=dict(kwargs.pop('metadata',{}) or {});meta.update(self.metadata)
        return G.make_geometry(*args,**dict(kwargs,metadata=meta,dll_path=self.dll))
def core_pins(dll):
    return {str((Path(dll) if name=='objective.dll' else W.HERE/name).resolve()):S.sha(Path(dll) if name=='objective.dll' else W.HERE/name) for name in W.SOURCE_FILES}
def verify(protocol):
    S.require(protocol['status']=='frozen' and protocol['science_gate_passed'] is True and protocol['protected_release_authorized'] is True,'SCENARIO_FROZEN_GATE')
    sc=protocol['scenario'];S.require(sc['id']==S.ID and sc['minimum_magnitude']=='4.5' and sc['excess_arithmetic']==S.LAW and sc['population']==391 and sc['warmup']==33 and sc['training_counts']==list(S.TRAIN) and sc['test_counts']==list(S.TEST),'SCENARIO_PROTOCOL_LAW')
    S.require(protocol['models']==W.MODELS and protocol['primary_arms']==S.PRIMARY and protocol['schedule']==sum([W.schedule(f'california_fold_{i}') for i in range(3)],[]),'SCENARIO_SCHEDULE')
    methods=S.read(protocol['methods_path'])
    for key in ['models','parameter_bounds','parameter_order','fit_policy','primary_selection','background','kernel_contract']:S.require(protocol[key]==methods[key],'INHERITED_MATHEMATICS')
    S.require(protocol['common_nuisance']['excess_cut']==.5 and protocol['common_nuisance']['productivity']['r']==.7,'SCENARIO_MARK_RECIPE')
    dll=Path(protocol['admitted_objective_dll']['path']).resolve();S.require(protocol['admitted_objective_dll']['sha256']==S.DLL_SHA and S.sha(dll)==S.DLL_SHA,'ADMITTED_OBJECTIVE_DLL')
    pins=protocol['artifact_pins']
    for p,digest in pins.items():S.require(S.sha(p)==digest,'FROZEN_SOURCE_CHANGED')
    for p,digest in core_pins(dll).items():S.require(pins.get(p)==digest,'CORE_PIN_ROSTER')
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:S.require(os.environ.get(name)=='1','SINGLE_THREAD_REQUIRED')
    return dll
def configure(protocol,dll):
    meta=dict(scenario_id=S.ID,scenario_minimum_magnitude='4.5',scenario_excess_arithmetic=S.LAW,scenario_input_sha256=protocol['data']['sha256'],base_catalogue_sha256=S.BASE_SHA)
    W.G=Geometry(dll,meta);W.source_pins=lambda:core_pins(dll)
    W.Objective=lambda path:Objective(path,dll_path=dll)
def cases(protocol):
    return [dict(case_id=c['id'],fold_id=c['fold'],T0=protocol['era']['T0_days'],**{n:W.day(c[n+'_utc'],'california') for n in ['train_start','train_end','test_start','test_end','history_start']}) for c in protocol['cases']]
def run(protocol_path,output,folds,stage_seconds,seconds_per_procedure,admission_path=None):
    protocol=S.read(protocol_path);dll=verify(protocol);configure(protocol,dll);cat=S.load(protocol['data']['catalogue'],protocol['data']['sha256']);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    S.require(folds in [[0],[1,2]],'PILOT_OR_REMAINDER_ONLY')
    if folds==[0]:
        S.require(admission_path is not None,'PILOT_CONTROL_ADMISSION_REQUIRED');admission=S.read(admission_path)
        S.require(admission.get('accepted') is True and admission['protocol_sha256']==S.sha(protocol_path) and admission.get('fit_performance_used_for_admission') is False,'PILOT_CONTROL_GATE')
        controls=admission['controls'];S.require(set(controls)=={'threshold','zero_history','zero_annual','machine','independent_machine','independent_oracle'},'COMPLETE_CONTROL_ROSTER')
        for control in controls.values():
            S.require(S.sha(control['path'])==control['sha256'],'CONTROL_REPORT_PIN');report=S.read(control['path']);S.require(report.get('passed') is True,'CONTROL_NOT_PASSED')
    if folds==[1,2]:
        gate=S.read(output/'pilot_acceptance.json');S.require(gate.get('accepted') is True and gate.get('protocol_sha256')==S.sha(protocol_path) and gate.get('fit_performance_used_for_admission') is False,'PILOT_CORRECTNESS_RESOURCE_GATE')
        S.require(gate['pilot_case_sha256']==S.sha(output/'california_fold_0/case.json'),'ACCEPTED_PILOT_IMMUTABLE')
        S.require(S.sha(gate['audit_path'])==gate['audit_sha256'],'PILOT_AUDIT_PIN');audit=S.read(gate['audit_path'])
        S.require(audit.get('passed') is True and audit.get('independent') is True and audit['protocol_sha256']==S.sha(protocol_path) and audit['folds']==[0],'PILOT_INDEPENDENT_AUDIT')
        S.require(audit['bindings'].get(str((output/'california_fold_0/case.json').resolve()))==gate['pilot_case_sha256'],'EXACT_AUDITED_PILOT_ROOT')
        S.require(S.read(output/'california_fold_0/case.json')['status']=='complete','PILOT_INCOMPLETE')
        for collection in ['bindings','cache_bindings','planning_bindings']:
            for path,digest in audit[collection].items():S.require(S.sha(path)==digest,'ACCEPTED_PILOT_ARTIFACT_CHANGED')
    deadline=min(time.perf_counter()+stage_seconds,time.perf_counter()+(datetime.datetime.fromisoformat(protocol['resources']['deadline_utc'].replace('Z','+00:00'))-datetime.datetime.now(datetime.timezone.utc)).total_seconds()-protocol['resources']['audit_reserve_seconds'])
    S.require(deadline>time.perf_counter(),'AUDIT_RESERVE_EXHAUSTED')
    if folds==[0]:W.write(output/'all_procedure_plan.json',dict(scenario_id=S.ID,schedule=protocol['schedule'],procedures=30,mandatory_starts=240,exact_floor_slots=33,model_window_statuses=15,primary_arm_windows=12,targets=87))
    for f in folds:
        case=cases(protocol)[f];folder=output/case['case_id'];S.require(not folder.exists(),'NO_HIDDEN_REFIT_OR_RESUME')
        row=W.train_case(case,cat,folder,protocol,S.sha(protocol_path),deadline,seconds_per_procedure,profile='california');W.score_case(row,cat,folder,protocol)
    rows=[S.read(output/f'california_fold_{f}/case.json') for f in folds]
    summary=dict(status='complete' if all(r['status']=='complete' for r in rows) else 'unknown_incomplete',mode='california_m45',scenario_id=S.ID,protocol_sha256=S.sha(protocol_path),cases=rows,procedures=10*len(rows),mandatory_starts=80*len(rows),exact_floor_slots=11*len(rows))
    W.write(output/('pilot_summary_private.json' if folds==[0] else 'remainder_summary_private.json'),summary)
    if folds==[1,2]:
        rows=[S.read(output/f'california_fold_{f}/case.json') for f in range(3)];W.write(output/'summary_private.json',dict(summary,status='complete' if all(r['status']=='complete' for r in rows) else 'unknown_incomplete',cases=rows,procedures=30,mandatory_starts=240,exact_floor_slots=33,pilot_reused=True))
    return dict(status=summary['status'],folds=folds,procedures=10*len(rows) if folds==[0] else 20,starts=80*len(folds),floors=11*len(folds))
def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('prepare');a.add_argument('--base-run',required=True);a.add_argument('--base-catalogue',required=True);a.add_argument('--output',required=True)
    a=sub.add_parser('fit');a.add_argument('--protocol',required=True);a.add_argument('--output',required=True);a.add_argument('--folds',nargs='+',type=int,required=True);a.add_argument('--stage-seconds',type=float,default=21600);a.add_argument('--seconds-per-procedure',type=float,default=2000);a.add_argument('--admission')
    args=p.parse_args()
    try:result=S.prepare(args.base_run,args.base_catalogue,args.output) if args.command=='prepare' else run(args.protocol,args.output,args.folds,args.stage_seconds,args.seconds_per_procedure,args.admission)
    except Exception as error:print(json.dumps(dict(status='failed',fixed_error_code='M45_SCENARIO_FAILED',error_type=type(error).__name__)));return 1
    print(json.dumps(result));return 1 if result['status']=='unknown_incomplete' else 0
if __name__=='__main__':raise SystemExit(main())
