"""Standard-library metadata guards and canonical, complete accounting schemas."""
from __future__ import annotations
import hashlib
import json
import math
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ARMS = ('Omori_smooth_cont', 'fixedML_smooth_cont', 'Omori_smooth_lift', 'commonML_smooth_cont')
ATOMIC = ('event_ground_log', 'integrated_intensity', 'conditional_zone_logscore',
          'conditional_cell_logscore', 'within_cell_density_logscore', 'mark_logscore')
DERIVED = ('timing_logscore', 'conditional_location_logscore', 'joint_logscore')
COMPONENTS = ATOMIC + DERIVED
DIAGNOSTICS = ('immigrant_exposure', 'trigger_exposure', 'triggered_integrated_intensity',
               'cell_integrated_intensity', 'zone_integrated_intensity')
CONTRASTS = (
    ('timing_OC_minus_fixedML', ARMS[0], ARMS[1], 'timing_logscore', 37.790339),
    ('location_OC_minus_OL', ARMS[0], ARMS[2], 'conditional_location_logscore', 674.323522),
    ('joint_OC_minus_commonML', ARMS[0], ARMS[3], 'joint_logscore', 21.177884),
)
TARGETS = (79, 167, 69)
TRAIN_COUNTS = (851, 930, 1097)
YEARS = (2011, 2016, 2021)
TOL = 1e-4
PLANNED = dict(targets=315, fold_targets=list(TARGETS), archived_arm_window_records=12,
               arm_block_rows=60, contrast_block_rows=45, arm_component_slots=540,
               contrast_component_slots=405, primary_block_values=45,
               primary_window_values=9, primary_pooled_values=3, fits=0,
               optimizer_starts=0, nuisance_searches=0, sensitivity_scenarios=0)
DESIGN_HASHES = frozenset((
    '72d7830c0da0c04b688dd89bffd31f5595f97d1a19b2191e6b0f51f5e461490a',
    'e18c90a6b228955b14cfdcffc47b23c8ceba4aef2d5f3462b8d009de130adf25'))
THREAD_ENV = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS')

class AuditError(Exception):
    """Only fixed codes may reach a sanitized receipt."""
    def __init__(self, code):
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', code):
            code = 'UNCLASSIFIED_FAILURE'
        self.code = code
        super().__init__(code)

class Deadline(AuditError):
    def __init__(self): super().__init__('FINITE_DEADLINE_REACHED')

def need(condition, code):
    if not bool(condition): raise AuditError(code)

def absolute(path):
    p = Path(path)
    need(p.is_absolute(), 'ABSOLUTE_PATH_REQUIRED')
    return p.resolve(strict=True)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                     allow_nan=False).encode('utf-8')).hexdigest()

def parse_json(text):
    def reject(_): raise AuditError('NONFINITE_JSON')
    def unique(pairs):
        obj = {}
        for k, v in pairs:
            need(k not in obj, 'DUPLICATE_JSON_KEY'); obj[k] = v
        return obj
    return json.loads(text,
                      parse_constant=reject, object_pairs_hook=unique)

def read(path):
    return parse_json(Path(path).read_text(encoding='utf-8-sig'))

def read_pinned(path, expected):
    raw = absolute(path).read_bytes()
    need(hashlib.sha256(raw).hexdigest() == expected, 'PIN_MISMATCH')
    return parse_json(raw.decode('utf-8-sig'))

def write_new(path, obj):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(obj, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')

def pinned(path, expected):
    p = absolute(path)
    need(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected), 'INVALID_SHA256')
    need(sha(p) == expected, 'PIN_MISMATCH')
    return p

def pin_map(pins, nonempty=True):
    need(isinstance(pins, dict) and (bool(pins) or not nonempty), 'PIN_MAP_REQUIRED')
    normalized = {}
    for p, h in pins.items():
        key = str(pinned(p, h)); need(key not in normalized, 'DUPLICATE_PIN_PATH'); normalized[key] = h
    return normalized

def utc(text):
    need(isinstance(text, str) and bool(re.fullmatch(
        r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)', text)), 'UTC_SCHEMA')
    return datetime.fromisoformat(text.replace('Z', '+00:00'))

def day(text):
    delta = utc(text) - datetime(1981, 1, 1, tzinfo=timezone.utc)
    # Match the inherited binary64 datetime/86400 policy exactly, including microseconds.
    return delta.total_seconds() / 86400.

def blocks(fold):
    for year in range(YEARS[fold], YEARS[fold] + 5):
        start = f'{year}-01-01T00:00:00Z'; end = f'{year+1}-01-01T00:00:00Z'
        yield dict(fold_id=fold, block_id=f'california_fold_{fold}__year_{year}',
                   start_utc=start, end_utc=end), day(start), day(end)

def derived(row):
    row['timing_logscore'] = row['event_ground_log'] - row['integrated_intensity']
    row['conditional_location_logscore'] = math.fsum(row[k] for k in ATOMIC[2:5])
    row['joint_logscore'] = math.fsum(row[k] for k in ('timing_logscore', 'conditional_location_logscore', 'mark_logscore'))
    return row

def finite_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)

def difference(a, b):
    if isinstance(a, list) and isinstance(b, list):
        need(len(a) == len(b), 'NUMERIC_SHAPE_MISMATCH')
        return max((difference(x, y) for x, y in zip(a, b)), default=0.)
    need(finite_number(a) and finite_number(b), 'NONFINITE_OR_NONNUMERIC')
    return abs(a - b)

def close(a, b, code='NUMERIC_RECONCILIATION', tol=TOL):
    error = difference(a, b); need(error <= tol, code); return error

def blank_rows():
    rows = []
    for fold in range(3):
        for arm in ARMS:
            for key, _, _ in blocks(fold):
                row = dict(key, arm_id=arm, logical_arm_window_id=f'california_fold_{fold}__arm_{arm}',
                           actual_procedure_id=None, selected_candidate_id=None, target_count=None,
                           status='planned', failure_codes=[], per_target_mean=None)
                row.update({k: None for k in COMPONENTS + DIAGNOSTICS}); rows.append(row)
    return rows

def contrast_rows(rows):
    index = {(r['fold_id'], r['arm_id'], r['block_id']): r for r in rows}; out = []
    for fold in range(3):
        for key, _, _ in blocks(fold):
            for cid, aa, bb, primary, _ in CONTRASTS:
                a, b = (index[(fold, arm, key['block_id'])] for arm in (aa, bb))
                ok = a['status'] == b['status'] == 'succeeded'
                row = dict(key, contrast_id=cid, arm_A=aa, arm_B=bb,
                           target_count=a['target_count'] if ok else None,
                           status='succeeded' if ok else 'unresolved',
                           primary_component=primary, primary_value=None,
                           per_target_mean=None, exposure_contrast=None)
                row.update({k: a[k]-b[k] if ok else None for k in COMPONENTS})
                if ok:
                    need(a['target_count'] == b['target_count'], 'CONTRAST_TARGET_MAPPING')
                    row['primary_value'] = row[primary]
                    row['exposure_contrast'] = -row['integrated_intensity']
                    row['per_target_mean'] = row[primary]/row['target_count'] if row['target_count'] else None
                out.append(row)
    return out

class Budget:
    def __init__(self, seconds, checkpoint_dir):
        need(finite_number(seconds) and seconds > 0, 'FINITE_BUDGET_REQUIRED')
        self.start = time.perf_counter(); self.end = self.start + seconds
        self.directory = Path(checkpoint_dir); self.counter = 0
        self.directory.mkdir(parents=True, exist_ok=False)
    def check(self):
        if time.perf_counter() >= self.end: raise Deadline()
    def checkpoint(self, stage, completed):
        self.counter += 1
        write_new(self.directory / f'checkpoint_{self.counter:06d}.json',
                  dict(stage=stage, completed_work_items=completed,
                       elapsed_seconds=time.perf_counter()-self.start,
                       pid=os.getpid(), scientific_values_disclosed=False))
        self.check()
