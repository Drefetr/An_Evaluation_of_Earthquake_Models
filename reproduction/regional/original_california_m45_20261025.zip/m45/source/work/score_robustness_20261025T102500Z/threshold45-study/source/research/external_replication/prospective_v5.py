"""Prospective v5 preferred WFS/CSV shallow-cohort local archive with after-close/hash issuance completion. Local hashes do not attest external timestamps.

Operational clocks are obtained inside capture/issue functions. Fixtures use a
separate archive kind and cannot enter operational scoring or denominators.
"""
from datetime import datetime,timedelta,timezone
from decimal import Decimal,InvalidOperation
from pathlib import Path
import ast,calendar,hashlib,re,importlib.util,json,sqlite3,urllib.parse,urllib.request,uuid
import numpy as np
try:
    from . import geometry as G
    from .catalogue import load_catalogue,utc,day
    from .workflow import MODELS,SOURCE_FILES,schedule,read,write,sha
    from .prospective import fixed_arrays
    from .typed_query_adapter_v2 import FixedObjectiveV2,validate_query
except ImportError:
    import geometry as G
    from catalogue import load_catalogue,utc,day
    from workflow import MODELS,SOURCE_FILES,schedule,read,write,sha
    from prospective import fixed_arrays
    from typed_query_adapter_v2 import FixedObjectiveV2,validate_query
HERE=Path(__file__).resolve().parent
SOURCE_EXTENSION=['prospective_v2.py','typed_query_adapter_v2.py','prospective_v3.py','prospective_v4.py','prospective_v5.py']
NZ_HASH='feacccb7581d1c4c33f88874cd6b198c41639da6930a7fc35e46f910a594fb3e'
CORRECTED_POPULATION_SHA='d5530cbcaee55341b0bd5e1c8a0873469848a165c26fd535fa4d541717340a6f'
CORRECTED_FINALIZATION_SHA='2362886a447b20f6ce3e33b33624eae75f2a41be7f9a67eee323f7be65531a04'
PARSER_DEPENDENCY_NAMES=('parse_capture.py','cohort_contract_v1.json')
WFS_COHORT_CONTRACT_SHA='2fb2e290a0a9b967cb82b4726a5dd28b6b313b58a053a407b93895a8c8b0feda'
CONTROL_CHARACTER_ADJUDICATION_SHA='74d4b8daf7da9b4caf65e53267dfce157b922563fba459bdb6bd1a8fe89e5001'
EXPECTED_WFS_CONTROLS={'schema':'geonet-wfs-csv-preferred-v1','max_records':5000,'minimum_records':1,'forbid_pagination':True,'reject_at_max_records':True,'require_final_newline':True,'rely_on_unpaginated_service_contract':True}
WFS_ENDPOINT='https://wfs.geonet.org.nz/geonet/ows'
WFS_CQL_TEMPLATE="origintime>='1960-01-01T00:00:00Z' AND origintime<'{cutoff_utc}' AND magnitude>=5 AND BBOX(origin_geom,165,-48.5,180,-33.5)"
EXPECTED_WFS_QUERY={'service':'WFS','version':'1.0.0','request':'GetFeature','typeName':'geonet:quake_search_v1','outputFormat':'csv','maxFeatures':'5000','cql_filter':WFS_CQL_TEMPLATE}

def same_typed(left,right):
    if type(left) is not type(right):return False
    if type(left) is dict:return set(left)==set(right) and all(same_typed(left[k],right[k]) for k in left)
    if type(left) in [list,tuple]:return len(left)==len(right) and all(same_typed(a,b) for a,b in zip(left,right))
    return left==right

def render_query(cutoff_utc):
    cutoff=utc(cutoff_utc)
    if cutoff<=utc('1960-01-01T00:00:00Z'):raise ValueError('WFS_QUERY_CUTOFF')
    return dict(EXPECTED_WFS_QUERY,cql_filter=WFS_CQL_TEMPLATE.format(cutoff_utc=iso(cutoff)))

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def objsha(v):return hashlib.sha256(canon(v)).hexdigest()
def iso(t):return t.isoformat().replace('+00:00','Z')
def now():return datetime.now(timezone.utc)
def ref(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def checked_ref(r):
    if not isinstance(r,dict) or sha(r['path'])!=r['sha256']:raise ValueError('ARTIFACT_IDENTITY')
    return Path(r['path']).resolve()
def anniversary(start,years=10):
    year=start.year+years
    return start.replace(year=year,day=min(start.day,calendar.monthrange(year,start.month)[1]))
def horizon(freeze):
    start=(freeze+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
    return start,anniversary(start)
def model_manifest(training):
    return dict(beta=training['beta'],reference_pi=training['reference_pi'],kde_selection=training['kde_selection'],selected_sigma=training['selected_sigma'],models={mid:dict(model=training['models'][mid]['model'],pars=training['models'][mid]['selected']['pars'],spatial=training['models'][mid]['spatial'],sigma=training['models'][mid]['sigma'],cache_paths=training['models'][mid]['cache_paths']) for mid in MODELS})

def initialization_bindings(init):
    """Validate the full procedure, then return the exact map an auditor signs."""
    refs=[init[k] for k in ['methods_protocol','protocol','catalogue','training_case','parameter_manifest']]+init['fit_outputs']+init['nuisance_outputs']
    bindings={str(checked_ref(r)):r['sha256'] for r in refs}
    if len(bindings)!=len(refs):raise ValueError('DUPLICATE_INITIALIZATION_BINDING')
    training=read(init['training_case']['path']);protocol=read(init['protocol']['path']);methods=read(init['methods_protocol']['path']);params=read(init['parameter_manifest']['path'])
    for key in ['models','parameter_bounds','parameter_order','fit_policy','primary_selection','background','kernel_contract']:
        if protocol.get(key)!=methods.get(key):raise ValueError('INITIALIZATION_REGISTERED_PROCEDURE')
    if init['catalogue']['sha256']!=NZ_HASH or training['catalogue_sha256']!=NZ_HASH or training['profile']!='new_zealand' or training['n_train']!=913 or training['status']!='complete':raise ValueError('INITIALIZATION_POPULATION')
    case=training['case']
    if case['train_start']!=0. or case['train_end']!=24394. or case['T0']!=24394. or case['case_id']!='nz_full_training':raise ValueError('INITIALIZATION_WINDOW')
    if training['protocol_sha256']!=init['protocol']['sha256'] or protocol['status']!='frozen' or protocol['models']!=MODELS or protocol['fit_policy']['starts_per_procedure']!=8 or protocol['primary_selection']['sigma_km']!=G.SCALES or protocol['background']['bandwidth_km']!=G.SCALES:raise ValueError('INITIALIZATION_PROCEDURE')
    if set(training['models'])!=set(MODELS) or params!=model_manifest(training):raise ValueError('INITIALIZATION_PARAMETERS')
    fits=[read(r['path']) for r in init['fit_outputs']];expected=schedule('nz_full_training')
    if len(fits)!=10 or [f['procedure_id'] for f in fits]!=[s['id'] for s in expected] or set(str(Path(p).resolve()) for p in training['procedures'])!=set(r['path'] for r in init['fit_outputs']):raise ValueError('INITIALIZATION_ROSTER')
    starts=floors=0;cachepaths=set()
    for f in fits:
        ss=[s for s in f['slots'] if s['kind']=='start'];ff=[s for s in f['slots'] if s['kind']=='floor'];starts+=len(ss);floors+=len(ff)
        if not f['complete'] or len(ss)!=8 or any(s['status']!='complete' for s in ss+ff) or f['selected'] is None:raise ValueError('INITIALIZATION_CANDIDATES')
        if len(f['accepted_candidates'])!=8+len(ff) or len({c['candidate_id'] for c in f['accepted_candidates']})!=len(f['accepted_candidates']):raise ValueError('INITIALIZATION_CANDIDATES')
        cachepaths.update(str(Path(p).resolve()) for p in f['cache_paths'].values())
    alias=training['model_aliases'].get('fixedML_smooth_cont',{})
    winning=training['models']['fixedML_smooth_cont']
    if alias.get('source_procedure_id')!=winning['procedure_id'] or alias.get('source_candidate_id')!=winning['selected']['candidate_id'] or alias.get('no_additional_fit') is not True:raise ValueError('INITIALIZATION_ALIAS')
    if starts!=80 or floors!=11 or cachepaths!=set(str(checked_ref(r)) for r in init['nuisance_outputs']):raise ValueError('INITIALIZATION_ACCOUNTING')
    byid={f['procedure_id']:f for f in fits}
    for mid,m in training['models'].items():
        f=byid[m['procedure_id']]
        if not m['complete'] or m['selected']!=f['selected'] or m['cache_paths']!=f['cache_paths']:raise ValueError('INITIALIZATION_MODEL_BINDING')
    audit=read(checked_ref(init['independent_audit']))
    if audit.get('status')!='passed' or audit.get('independent') is not True or audit.get('bindings')!=bindings or audit.get('denominators')!=dict(procedures=10,starts=80,floors=11) or audit.get('model_roster')!=MODELS:raise ValueError('INITIALIZATION_INDEPENDENT_AUDIT')
    return bindings,training

def verify_registration(path):
    reg=read(path)
    if reg.get('schema_version')!=5 or reg.get('status')!='frozen' or reg.get('kind')!='operational' or reg.get('endpoint_rule')!='same_calendar_date_or_last_day_of_month':raise ValueError('REGISTRATION_V5')
    start,end=horizon(utc(reg['freeze_utc']))
    if utc(reg['start_utc'])!=start or utc(reg['end_utc'])!=end:raise ValueError('REGISTRATION_HORIZON')
    pins=reg['artifact_pins']
    for key,expected in [('population_contract',CORRECTED_POPULATION_SHA),('finalization_contract',CORRECTED_FINALIZATION_SHA),('control_character_adjudication',CONTROL_CHARACTER_ADJUDICATION_SHA)]:
        contract=reg.get(key,{})
        if contract.get('sha256')!=expected or pins.get(str(checked_ref(contract)))!=expected:raise ValueError('CORRECTED_DESIGN_CONTRACT_PIN')
    for p in [HERE/n for n in SOURCE_FILES+SOURCE_EXTENSION]:
        if pins.get(str(p.resolve()))!=sha(p):raise ValueError('REGISTRATION_SOURCE_PIN')
    for p,digest in pins.items():
        if sha(p)!=digest:raise ValueError('REGISTRATION_ARTIFACT_PIN')
    if reg['capture_policy']['completion_window_minutes_before_start']!=[70,60] or reg['capture_policy']['max_request_span_seconds']!=600 or reg['capture_policy']['canonical_event_type']!='earthquake' or reg['capture_policy']['parser_entrypoint']!='parse_capture':raise ValueError('CAPTURE_POLICY')
    policy=reg['capture_policy']
    if not policy['endpoint'].startswith('https://') or not isinstance(policy['query'],dict) or not isinstance(policy['completeness_controls'],dict) or not 0<policy['max_bytes']<=134217728 or not 0<policy['timeout_seconds']<=60:raise ValueError('CAPTURE_TRANSPORT_POLICY')
    if pins.get(str(Path(policy['parser_path']).resolve()))!=sha(policy['parser_path']):raise ValueError('CAPTURE_PARSER_PIN')
    if policy['endpoint']!=WFS_ENDPOINT or policy['accept']!='text/csv' or not same_typed(policy['query'],EXPECTED_WFS_QUERY) or not same_typed(policy['completeness_controls'],EXPECTED_WFS_CONTROLS):raise ValueError('WFS_REGISTERED_SOURCE_POLICY')
    parserpath=Path(policy['parser_path']).resolve();dependencies=policy.get('parser_dependencies',{})
    if parserpath.name!='parse_capture.py' or set(dependencies)!=set(PARSER_DEPENDENCY_NAMES):raise ValueError('WFS_PARSER_DEPENDENCY_ROSTER')
    for name in PARSER_DEPENDENCY_NAMES:
        dependency=dependencies[name];target=checked_ref(dependency)
        if target!=parserpath.with_name(name) or pins.get(str(target))!=dependency['sha256']:raise ValueError('WFS_PARSER_DEPENDENCY_PIN')
    if dependencies['cohort_contract_v1.json']['sha256']!=WFS_COHORT_CONTRACT_SHA:raise ValueError('WFS_COHORT_CONTRACT_IDENTITY')
    tree=ast.parse(parserpath.read_text(encoding='utf-8'));declared=[node.value for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='DEPENDENCY_FILENAMES' for target in node.targets)]
    if len(declared)!=1 or ast.literal_eval(declared[0])!=PARSER_DEPENDENCY_NAMES:raise ValueError('WFS_STATIC_DEPENDENCY_DECLARATION')
    bindings,training=initialization_bindings(reg['initialization'])
    for p,digest in bindings.items():
        if pins.get(p)!=digest:raise ValueError('INITIALIZATION_FROZEN_PIN')
    a=reg['initialization']['independent_audit']
    if pins.get(str(checked_ref(a)))!=a['sha256']:raise ValueError('INITIALIZATION_AUDIT_PIN')
    verify_archive_location(reg)
    verify_initial_history(reg)
    return reg,training

def _frozen_ref(reg,reference):
    if type(reference) is not dict or type(reference.get('path')) is not str or not Path(reference['path']).is_absolute():raise ValueError('INITIAL_HISTORY_REFERENCE')
    target=checked_ref(reference)
    if reg['artifact_pins'].get(str(target))!=reference['sha256']:raise ValueError('INITIAL_HISTORY_UNPINNED_ARTIFACT')
    return target

def verify_initial_history(reg):
    """Actual nonissued source + independent directRAW audit, all before freeze."""
    init=reg.get('initial_history')
    if type(init) is not dict or set(init)!={'capture_receipt','completion_receipt','raw_source_audit','raw_auditor_source'}:raise ValueError('INITIAL_HISTORY_REQUIRED')
    refs={name:_frozen_ref(reg,value) for name,value in init.items()};capture=read(refs['capture_receipt']);completion=read(refs['completion_receipt']);audit=read(refs['raw_source_audit']);policy=reg['capture_policy'];dependencies={name:policy['parser_dependencies'][name]['sha256'] for name in PARSER_DEPENDENCY_NAMES}
    if refs['raw_auditor_source'].name!='audit_geonet_wfs_source_v1.py':raise ValueError('INITIAL_HISTORY_RAW_AUDITOR_IDENTITY')
    if capture.get('kind')!='registration_initialization_history_nonissued' or capture.get('status')!='complete' or capture.get('issued') is not False or capture.get('operational_capture') is not False:raise ValueError('INITIAL_HISTORY_NOT_NONISSUED_PREPARATION')
    if completion.get('kind')!='registration_initialization_history_nonissued_completion' or completion.get('status')!='complete' or completion.get('issued') is not False or completion.get('does_not_satisfy_future_daily_capture') is not True or completion.get('actual_registration_freeze_must_follow_this_completion') is not True:raise ValueError('INITIAL_HISTORY_COMPLETION_SCOPE')
    if not same_typed(completion.get('capture_receipt'),init['capture_receipt']):raise ValueError('INITIAL_HISTORY_COMPLETION_CAPTURE_BINDING')
    for key in ['cutoff_utc','design_frozen_at_utc','actual_request_start_utc','actual_receipt_utc']:
        if capture.get(key)!=completion.get(key):raise ValueError('INITIAL_HISTORY_CLOCK_BINDING')
    cutoff=utc(capture['cutoff_utc']);frozen=utc(capture['design_frozen_at_utc']);began=utc(capture['actual_request_start_utc']);received=utc(capture['actual_receipt_utc']);data_completed=utc(capture['archive_data_completed_utc']);completed=utc(completion['actual_archive_completed_utc'])
    if cutoff<=utc('2026-10-15T00:00:00Z') or not cutoff<=frozen<=began<=received<=data_completed<=completed<utc(reg['freeze_utc']):raise ValueError('INITIAL_HISTORY_PREFREEZE_CLOCK_ORDER')
    expected_query=render_query(capture['cutoff_utc'])
    if not same_typed(capture.get('query'),expected_query) or not same_typed(capture.get('controls'),EXPECTED_WFS_CONTROLS) or not same_typed(completion.get('controls'),EXPECTED_WFS_CONTROLS):raise ValueError('INITIAL_HISTORY_SOURCE_POLICY')
    artifacts=capture.get('artifact_refs')
    if type(artifacts) is not dict or set(artifacts)!={'raw','broad','canonical','ledger'} or not same_typed(artifacts,completion.get('artifact_refs')):raise ValueError('INITIAL_HISTORY_ARTIFACT_ROSTER')
    paths={key:_frozen_ref(reg,value) for key,value in artifacts.items()};fields={'raw':'raw_sha256','broad':'broad_canonical_sha256','canonical':'canonical_sha256','ledger':'cohort_ledger_sha256'}
    for key,field in fields.items():
        if capture.get(field)!=artifacts[key]['sha256']:raise ValueError('INITIAL_HISTORY_ARTIFACT_HASH_BINDING')
    if Path(capture['raw_path']).resolve()!=paths['raw'] or not 0<paths['raw'].stat().st_size<=134217728:raise ValueError('INITIAL_HISTORY_RAW_PATH_CAP')
    governance=capture.get('governance_refs')
    if type(governance) is not dict or not {'design','admission','source_program','fixture_control_receipt','cohort_contract','historical_source_acceptance','historical_raw_source_audit'}.issubset(governance) or not same_typed(governance,completion.get('governance_refs')):raise ValueError('INITIAL_HISTORY_GOVERNANCE')
    governance_paths={name:_frozen_ref(reg,value) for name,value in governance.items()};parserpath=Path(policy['parser_path']).resolve()
    preparation_source=governance_paths['cohort_contract'].parent
    if governance_paths['source_program']!=preparation_source/'capture_v1.py' or governance['cohort_contract']['sha256']!=WFS_COHORT_CONTRACT_SHA:raise ValueError('INITIAL_HISTORY_COLLECTOR_CLOSURE')
    for name in PARSER_DEPENDENCY_NAMES:_frozen_ref(reg,dict(path=str((preparation_source/name).resolve()),sha256=dependencies[name]))
    if capture.get('parser_dependency_pins')!=dependencies or completion.get('parser_dependency_pins')!=dependencies or capture.get('parser_sha256')!=dependencies['parse_capture.py']:raise ValueError('INITIAL_HISTORY_PARSER_BINDING')
    if completion.get('design')!=governance['design'] or capture.get('design_sha256')!=governance['design']['sha256']:raise ValueError('INITIAL_HISTORY_DESIGN_BINDING')
    design=read(governance_paths['design']);admission=read(governance_paths['admission'])
    if design.get('kind')!='initialization_history_capture_design_nonissued' or design.get('status')!='frozen' or design.get('endpoint')!=WFS_ENDPOINT or design.get('cutoff_utc')!=capture['cutoff_utc'] or design.get('design_frozen_at_utc')!=capture['design_frozen_at_utc'] or not same_typed(design.get('query'),expected_query) or not same_typed(design.get('controls'),EXPECTED_WFS_CONTROLS):raise ValueError('INITIAL_HISTORY_FROZEN_DESIGN')
    source_pins={name:sha(preparation_source/name) for name in ['capture_v1.py',*PARSER_DEPENDENCY_NAMES]}
    if admission.get('status')!='accepted' or admission.get('independent_review') is not True or admission.get('controls_passed') is not True or admission.get('design_sha256')!=governance['design']['sha256'] or admission.get('source_files_sha256')!=source_pins or admission.get('cohort_contract_sha256')!=WFS_COHORT_CONTRACT_SHA:raise ValueError('INITIAL_HISTORY_SOURCE_ADMISSION')
    fixture=admission.get('fixture_control_receipt',{});actual_fixture=governance['fixture_control_receipt']
    if type(fixture) is not dict or fixture.get('sha256')!=actual_fixture['sha256'] or type(fixture.get('path')) is not str:raise ValueError('INITIAL_HISTORY_FIXTURE_BINDING')
    fixture_path=Path(fixture['path'])
    if fixture_path.is_absolute():
        if fixture_path.resolve()!=governance_paths['fixture_control_receipt']:raise ValueError('INITIAL_HISTORY_FIXTURE_BINDING')
    elif '..' in fixture_path.parts or tuple(governance_paths['fixture_control_receipt'].parts[-len(fixture_path.parts):])!=fixture_path.parts:raise ValueError('INITIAL_HISTORY_FIXTURE_BINDING')
    if audit.get('status')!='passed' or audit.get('passed') is not True or audit.get('independent') is not True or audit.get('data_classification')!='local_verified_source_WFS_CSV' or audit.get('raw_sha256')!=artifacts['raw']['sha256'] or audit.get('canonical_sha256')!=artifacts['canonical']['sha256'] or audit.get('capture_receipt')!=init['capture_receipt'] or audit.get('completion_receipt')!=init['completion_receipt'] or audit.get('parser_dependency_pins')!=dependencies:raise ValueError('INITIAL_HISTORY_INDEPENDENT_RAW_AUDIT')
    bindings=audit.get('bindings');required={str(v) for v in paths.values()}|{str(refs['capture_receipt']),str(refs['completion_receipt'])}|{str(v) for v in governance_paths.values()}|{str((preparation_source/name).resolve()) for name in PARSER_DEPENDENCY_NAMES}
    if type(bindings) is not dict or not required.issubset(bindings):raise ValueError('INITIAL_HISTORY_AUDIT_BINDINGS')
    for path,digest in bindings.items():_frozen_ref(reg,dict(path=path,sha256=digest))
    cat=validate_canonical(paths['canonical'],artifacts['canonical']['sha256'],snapshot=capture['provenance']['source_snapshot'],received=capture['actual_receipt_utc'],raw_sha=artifacts['raw']['sha256'])
    if type(audit.get('cohort_records')) is not int or audit['cohort_records']!=len(cat.times) or not 1<=len(cat.times)<5000 or np.any(cat.times>=day(capture['cutoff_utc'],'new_zealand')):raise ValueError('INITIAL_HISTORY_CANONICAL_COHORT')
    return dict(capture_receipt=init['capture_receipt'],completion_receipt=init['completion_receipt'],raw_source_audit=init['raw_source_audit'],cutoff_utc=capture['cutoff_utc'])

def verify_archive_location(reg):
    value=reg.get('archive_root')
    if type(value) is not str or not Path(value).is_absolute() or str(Path(value).resolve())!=value:raise ValueError('REGISTERED_ARCHIVE_ABSOLUTE')
    archive=Path(value)
    # Future mutable artifacts may not be appended to any known research/worktree
    # ancestor of this runtime or its frozen evidence paths.
    for path in [HERE,*[Path(v) for v in reg['artifact_pins']]]:
        for parent in [path,*path.parents]:
            if parent.name.lower() in ['research_runs','work'] and archive.is_relative_to(parent):raise ValueError('ARCHIVE_INSIDE_SEALED_RESEARCH_OR_WORKTREE')

def connect(root,registration_sha,kind='operational'):
    root=Path(root);root.mkdir(parents=True,exist_ok=True);db=sqlite3.connect(root/'day_ledger.sqlite',timeout=30,isolation_level=None)
    db.execute('PRAGMA foreign_keys=ON');db.execute('PRAGMA journal_mode=WAL')
    db.execute('CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
    db.execute('CREATE TABLE IF NOT EXISTS records(seq INTEGER PRIMARY KEY,day TEXT UNIQUE NOT NULL,body TEXT NOT NULL,previous_sha TEXT NOT NULL,record_sha TEXT NOT NULL UNIQUE)')
    db.execute('CREATE TABLE IF NOT EXISTS captures(day TEXT PRIMARY KEY,receipt_path TEXT UNIQUE NOT NULL,receipt_sha TEXT UNIQUE NOT NULL)')
    for table in ['metadata','records','captures']:
        for op in ['UPDATE','DELETE']:db.execute(f'CREATE TRIGGER IF NOT EXISTS no_{op.lower()}_{table} BEFORE {op} ON {table} BEGIN SELECT RAISE(ABORT,"append only"); END')
    db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)',('registration_sha256',registration_sha));db.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)',('kind',kind))
    if dict(db.execute('SELECT key,value FROM metadata'))!=dict(registration_sha256=registration_sha,kind=kind):db.close();raise ValueError('ARCHIVE_IDENTITY')
    return db

def verify_chain(db,registration_sha):
    previous=registration_sha;out={}
    for seq,key,body,prior,digest in db.execute('SELECT seq,day,body,previous_sha,record_sha FROM records ORDER BY seq'):
        v=json.loads(body)
        if seq!=len(out)+1 or prior!=previous or digest!=objsha(dict(seq=seq,day=key,body=v,previous_sha=prior)) or key in out:raise ValueError('DAY_CHAIN_IDENTITY')
        out[key]=(v,digest);previous=digest
    return out

def append_day(db,registration_sha,key,body):
    db.execute('BEGIN IMMEDIATE')
    try:
        rows=verify_chain(db,registration_sha)
        if key in rows:raise ValueError('DAY_ALREADY_FINAL')
        seq=len(rows)+1;prior=next(reversed(rows.values()))[1] if rows else registration_sha;digest=objsha(dict(seq=seq,day=key,body=body,previous_sha=prior))
        db.execute('INSERT INTO records VALUES (?,?,?,?,?)',(seq,key,canon(body).decode(),prior,digest));db.execute('COMMIT');return digest
    except Exception:db.execute('ROLLBACK');raise

def canonical_field_controls(value):
    if type(value) is str and any(c in value for c in ['\x00','\r','\n']):raise ValueError('SOURCE_CANONICAL_FIELD_CONTROLS')
    if type(value) is dict:
        for key,item in value.items():canonical_field_controls(key);canonical_field_controls(item)
    if type(value) is list:
        for item in value:canonical_field_controls(item)

def scientific_decimal(token):
    if type(token) is not str or len(token)>1000 or any(c in token for c in ['\x00','\r','\n']) or re.fullmatch(r'[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][-+]?[0-9]+)?',token.strip()) is None:raise ValueError('SOURCE_FINITE_NUMERIC_GRAMMAR')
    return Decimal(token.strip())

def validate_canonical(path,digest,*,snapshot=None,received=None,raw_sha=None):
    obj=read(path)
    if obj.get('schema_version')!=1 or not isinstance(obj.get('events'),list):raise ValueError('SOURCE_CANONICAL_SCHEMA')
    if any(type(e) is not dict for e in obj['events']):raise ValueError('SOURCE_CANONICAL_EVENT_SCHEMA')
    if any(e.get('event_type')!='earthquake' for e in obj['events']):raise ValueError('SOURCE_EARTHQUAKE_TYPE')
    if not 1<=len(obj['events'])<5000:raise ValueError('SOURCE_COHORT_COUNT')
    for event in obj['events']:
        canonical_field_controls(event)
        if 'source_public_id' in event:
            publicid=event['source_public_id']
            if type(publicid) is not str or not publicid or publicid!=publicid.strip() or any(ord(c)<32 or ord(c)==127 for c in publicid):raise ValueError('SOURCE_PUBLIC_ID_CONTROLS')
        if type(event.get('magnitude_type')) is not str:raise ValueError('SOURCE_MAGNITUDE_TYPE_LABEL')
        identity=event.get('event_id')
        if type(identity) is not str or not identity or identity!=identity.strip() or any(ord(c)<32 or ord(c)==127 for c in identity):raise ValueError('SOURCE_EVENT_ID_CONTROLS')
        tokens=event.get('source_tokens',{})
        if type(tokens) is not dict or any(type(v) is not str or any(c in v for c in ['\x00','\r','\n']) for v in tokens.values()):raise ValueError('SOURCE_TOKEN_CONTROLS')
        if type(event.get('depth_km')) is not str:raise ValueError('SOURCE_DEPTH_DECIMAL_TOKEN_REQUIRED')
        try:depth=scientific_decimal(event['depth_km'])
        except (ValueError,KeyError,TypeError,OverflowError,InvalidOperation):raise ValueError('SOURCE_SHALLOW_DEPTH_SCHEMA') from None
        if not depth.is_finite() or depth>Decimal(40) or depth==Decimal(-9):raise ValueError('SOURCE_SHALLOW_POPULATION')
        if type(event.get('magnitude')) is not str:raise ValueError('SOURCE_MAGNITUDE_DECIMAL_TOKEN_REQUIRED')
        try:magnitude=scientific_decimal(event['magnitude'])
        except (ValueError,InvalidOperation):raise ValueError('SOURCE_MAGNITUDE_DECIMAL_SCHEMA') from None
        if not magnitude.is_finite() or magnitude<Decimal(5):raise ValueError('SOURCE_EXACT_MAGNITUDE_POPULATION')
        for key,edges in [('latitude',[-48.5,-43.5,-38.5,-33.5]),('longitude',[165.,170.,175.,180.])]:
            if type(event.get(key)) is not str:raise ValueError('SOURCE_COORDINATE_DECIMAL_TOKEN_REQUIRED')
            try:value=scientific_decimal(event[key]);binary=float(value)
            except (ValueError,InvalidOperation,OverflowError):raise ValueError('SOURCE_COORDINATE_DECIMAL_SCHEMA') from None
            if not value.is_finite() or not np.isfinite(binary):raise ValueError('SOURCE_COORDINATE_FINITE')
            exact_edges=[Decimal(str(v)) for v in edges]
            if value<exact_edges[0] or value>exact_edges[-1]:raise ValueError('SOURCE_EXACT_SPATIAL_POPULATION')
            exact=int(value>=exact_edges[1])+int(value>=exact_edges[2]);converted=-1 if binary<edges[0] or binary>edges[-1] else int(binary>=edges[1])+int(binary>=edges[2])
            if exact!=converted:raise ValueError('SOURCE_BINARY64_BOUNDARY_DISAGREEMENT')
    if snapshot is not None and obj['provenance']!=dict(source_snapshot=snapshot,raw_manifest_sha256=raw_sha,retrieved_utc=received):raise ValueError('SOURCE_PROVENANCE_BINDING')
    return load_catalogue(path,digest,profile='new_zealand')

def require_archive(reg,archive_root):
    if str(Path(archive_root).resolve())!=reg['archive_root']:raise ValueError('REGISTERED_ARCHIVE_ROOT')

def capture_source(registration_path,validity_start_utc,archive_root):
    """One actual bounded HTTPS capture; never accepts a caller asserted clock."""
    reg,_=verify_registration(registration_path);require_archive(reg,archive_root);start=utc(validity_start_utc);policy=reg['capture_policy'];began=now();lower=start-timedelta(minutes=70);upper=start-timedelta(minutes=60)
    if not utc(reg['start_utc'])<=start<utc(reg['end_utc']) or began<utc(reg['freeze_utc']) or began<lower or began>upper:raise ValueError('CAPTURE_OUTSIDE_WINDOW')
    if start!=start.replace(hour=0,minute=0,second=0,microsecond=0):raise ValueError('CAPTURE_DAY_BOUNDARY')
    key=start.date().isoformat();folder=Path(archive_root)/'captures'/key;folder.mkdir(parents=True,exist_ok=False)
    query=render_query(iso(began));url=policy['endpoint']+'?'+urllib.parse.urlencode(query);chunks=[];total=0
    request=urllib.request.Request(url,headers={'Accept':policy['accept'],'Accept-Encoding':'identity','User-Agent':'external-replication-prospective-v5'})
    with urllib.request.urlopen(request,timeout=policy['timeout_seconds']) as response:
        if response.status!=200:raise ValueError('CAPTURE_HTTP_STATUS')
        headers={k:response.headers.get(k) for k in ['Date','Last-Modified','ETag','Content-Length','Content-Type','Content-Encoding']}
        final_url=response.geturl()
        if final_url!=url:raise ValueError('WFS_CAPTURE_FINAL_URL')
        if (headers['Content-Encoding'] or '').strip().lower() not in ['', 'identity']:raise ValueError('WFS_CAPTURE_CONTENT_ENCODING')
        if (headers['Content-Type'] or '').split(';',1)[0].strip().lower() not in ['text/csv','application/csv']:raise ValueError('WFS_CAPTURE_CONTENT_TYPE')
        while True:
            part=response.read(65536)
            if not part:break
            total+=len(part)
            if total>policy['max_bytes']:raise ValueError('CAPTURE_SIZE_CAP')
            chunks.append(part)
    completed=now();raw=b''.join(chunks)
    if completed>upper or completed<lower or (completed-began).total_seconds()>600:raise ValueError('CAPTURE_LATE_OR_STALE')
    if headers['Content-Length'] is not None and (re.fullmatch(r'[0-9]+',headers['Content-Length'].strip()) is None or int(headers['Content-Length'])!=len(raw)):raise ValueError('CAPTURE_TRUNCATED')
    raw_path=folder/'raw_response.csv'
    with raw_path.open('xb') as f:f.write(raw)
    capture_id='capture:'+str(uuid.uuid4());raw_sha=sha(raw_path);provenance=dict(source_snapshot=capture_id,raw_manifest_sha256=raw_sha,retrieved_utc=iso(completed))
    spec=importlib.util.spec_from_file_location('_frozen_geonet_capture_parser',policy['parser_path']);parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
    canonical,evidence=parser.parse_capture(raw,query,provenance,policy['completeness_controls'])
    if not isinstance(evidence,dict) or evidence.get('complete') is not True or not same_typed(evidence.get('controls'),policy['completeness_controls']) or evidence.get('truncation_detected') is not False:raise ValueError('CAPTURE_COMPLETENESS')
    canonical_path=folder/'canonical_parents.json';write(canonical_path,canonical);cat=validate_canonical(canonical_path,sha(canonical_path),snapshot=capture_id,received=iso(completed),raw_sha=raw_sha)
    if np.any(cat.times>=day(validity_start_utc,'new_zealand')):raise ValueError('CAPTURE_FUTURE_PARENT')
    receipt=dict(schema_version=5,kind='operational_capture',status='complete',registration_sha256=sha(registration_path),validity_start_utc=validity_start_utc,actual_request_start_utc=iso(began),actual_receipt_utc=iso(completed),capture_id=capture_id,request=dict(url=url,query=query,headers={'Accept':policy['accept']}),response_headers=headers,final_url=final_url,closed_eof=True,raw=ref(raw_path),canonical=ref(canonical_path),parser=ref(policy['parser_path']),completeness=evidence)
    receipt_path=folder/'capture_receipt.json';write(receipt_path,receipt);capture_ref=ref(receipt_path)
    db=connect(archive_root,sha(registration_path))
    try:db.execute('INSERT INTO captures VALUES (?,?,?)',(key,capture_ref['path'],capture_ref['sha256']))
    finally:db.close()
    return capture_ref

def validate_capture(r,reg,regsha,start):
    receipt=read(checked_ref(r));policy=reg['capture_policy'];began=utc(receipt['actual_request_start_utc']);received=utc(receipt['actual_receipt_utc']);lower=start-timedelta(minutes=70);upper=start-timedelta(minutes=60)
    if receipt.get('schema_version')!=5 or receipt.get('kind')!='operational_capture' or receipt.get('status')!='complete' or receipt['registration_sha256']!=regsha or utc(receipt['validity_start_utc'])!=start or began<utc(reg['freeze_utc']) or not lower<=began<=received<=upper or (received-began).total_seconds()>600:raise ValueError('CAPTURE_RECEIPT_POLICY')
    raw=checked_ref(receipt['raw']);canonical=checked_ref(receipt['canonical']);checked_ref(receipt['parser'])
    if receipt['parser']!=ref(policy['parser_path']) or receipt['completeness'].get('complete') is not True or not same_typed(receipt['completeness'].get('controls'),policy['completeness_controls']) or receipt['completeness'].get('truncation_detected') is not False:raise ValueError('CAPTURE_PROCEDURE_BINDING')
    query=render_query(iso(began))
    if receipt['request']['query']!=query or receipt['request']['url']!=policy['endpoint']+'?'+urllib.parse.urlencode(query):raise ValueError('CAPTURE_QUERY_BINDING')
    if receipt.get('final_url')!=receipt['request']['url'] or receipt.get('closed_eof') is not True:raise ValueError('WFS_CAPTURE_TRANSPORT_BINDING')
    headers=receipt['response_headers']
    if (headers.get('Content-Encoding') or '').strip().lower() not in ['', 'identity'] or (headers.get('Content-Type') or '').split(';',1)[0].strip().lower() not in ['text/csv','application/csv']:raise ValueError('WFS_CAPTURE_REPRESENTATION')
    if headers.get('Content-Length') is not None and (re.fullmatch(r'[0-9]+',str(headers['Content-Length']).strip()) is None or int(headers['Content-Length'])!=raw.stat().st_size):raise ValueError('WFS_CAPTURE_LENGTH')
    cat=validate_canonical(canonical,receipt['canonical']['sha256'],snapshot=receipt['capture_id'],received=receipt['actual_receipt_utc'],raw_sha=receipt['raw']['sha256'])
    if np.any(cat.times>=day(iso(start),'new_zealand')):raise ValueError('CAPTURE_PARENT_COHORT')
    return receipt,cat

def issue_day(registration_path,capture_ref,archive_root):
    reg,training=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);capture=read(checked_ref(capture_ref));start=utc(capture['validity_start_utc']);end=start+timedelta(days=1);began=now();key=start.date().isoformat()
    receipt,cat=validate_capture(capture_ref,reg,regsha,start)
    capturedb=connect(archive_root,regsha)
    try:
        minted=capturedb.execute('SELECT receipt_path,receipt_sha FROM captures WHERE day=?',(key,)).fetchone()
        if minted!=(capture_ref['path'],capture_ref['sha256']):raise ValueError('CAPTURE_NOT_COLLECTOR_MINTED')
    finally:capturedb.close()
    if began<utc(reg['freeze_utc']) or began<utc(receipt['actual_receipt_utc']) or began>=start or not utc(reg['start_utc'])<=start<end<=utc(reg['end_utc']):raise ValueError('ISSUE_LATE_OR_OUTSIDE_HORIZON')
    db=connect(archive_root,regsha)
    try:
        if key in verify_chain(db,regsha):raise ValueError('DAY_ALREADY_FINAL')
        folder=Path(archive_root)/'days'/key;folder.mkdir(parents=True,exist_ok=False);source=folder/'issued_parent_snapshot.json'
        with source.open('xb') as f:f.write(checked_ref(receipt['canonical']).read_bytes())
        source_ref=ref(source)
        models={mid:dict(model=training['models'][mid]['model'],pars=training['models'][mid]['selected']['pars'],spatial=training['models'][mid]['spatial'],sigma=training['models'][mid]['sigma'],nuisance_cache=training['models'][mid]['cache_paths']['train16'],nuisance_cache_sha256=sha(training['models'][mid]['cache_paths']['train16'])) for mid in MODELS}
        prepared=now()
        # Candidate bytes never claim issued status. Only a validated ledger row
        # can establish operational issuance after the exact bytes/hash exist.
        packet=dict(schema_version=5,status='prepared_unissued',kind='forecast_candidate',registration_path=str(Path(registration_path).resolve()),registration_sha256=regsha,validity_start_utc=iso(start),validity_end_utc=iso(end),preparation_started_utc=iso(began),packet_prepared_utc=iso(prepared),source_received_utc=receipt['actual_receipt_utc'],capture_receipt=capture_ref,source_snapshot_path=str(source.resolve()),source_snapshot_sha256=source_ref['sha256'],models=models,beta=training['beta'],T0=24394.,history_policy='fixed_preissue',backfill=False)
        packet_path=folder/'forecast_candidate.json';write(packet_path,packet)
        candidate_ref=ref(packet_path)  # File is closed; exact byte SHA now exists.
        completed=now()                 # Sample AFTER close AND byte-hash read.
        recorded=now()
        if not began<=prepared<=completed<=recorded or completed>=start:
            reason='ARCHIVE_COMPLETED_LATE' if completed>=start else 'LOCAL_CLOCK_REVERSAL'
            failure=dict(schema_version=5,status='unissued',kind='failed_issue_attempt',reason_code=reason,day=key,packet=candidate_ref,preparation_started_utc=iso(began),packet_prepared_utc=iso(prepared),archive_completed_utc=iso(completed),receipt_recorded_utc=iso(recorded),validity_start_utc=iso(start),validity_end_utc=iso(end),source=source_ref,capture=capture_ref)
            failed_path=folder/'unissued_attempt.json';write(failed_path,failure)
            body=dict(status='missing_unknown',kind='operational',day=key,reason_code=reason,attempt=ref(failed_path),unissued_candidate=candidate_ref,archive_completed_utc=iso(completed),receipt_recorded_utc=iso(recorded),validity_start_utc=iso(start),validity_end_utc=iso(end))
            chain=append_day(db,regsha,key,body)
            return dict(status='unissued',day=key,reason_code=reason,attempt=ref(failed_path),candidate=candidate_ref,chain_sha256=chain,ledger_state='missing_unknown',local_timestamp_attestation_only=True)
        body=dict(status='issued',kind='operational',day=key,packet=candidate_ref,capture=capture_ref,preparation_started_utc=iso(began),packet_prepared_utc=iso(prepared),archive_completed_utc=iso(completed),receipt_recorded_utc=iso(recorded),validity_start_utc=iso(start),validity_end_utc=iso(end),source=source_ref,initialization_audit=reg['initialization']['independent_audit'],parameter_manifest=reg['initialization']['parameter_manifest'])
        chain=append_day(db,regsha,key,body)
        return dict(status='issued',day=key,packet=candidate_ref,archive_completed_utc=iso(completed),receipt_recorded_utc=iso(recorded),chain_sha256=chain,local_timestamp_attestation_only=True)
    finally:db.close()

def finalize_missing_days(registration_path,archive_root):
    reg,_=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);actual=now();db=connect(archive_root,regsha);closed=[]
    try:
        t=utc(reg['start_utc']);end=min(actual,utc(reg['end_utc']))
        while t+timedelta(days=1)<=end:
            key=t.date().isoformat()
            if key not in verify_chain(db,regsha):
                append_day(db,regsha,key,dict(kind='operational',status='missing_unknown',day=key,validity_start_utc=iso(t),validity_end_utc=iso(t+timedelta(days=1)),actual_recorded_utc=iso(actual),reason='no archived prevalidity packet; never backfill'));closed.append(key)
            t+=timedelta(days=1)
        return dict(status='complete',missing_days_recorded=len(closed))
    finally:db.close()

def admitted_packet(registration_path,archive_root,validity_day):
    reg,training=verify_registration(registration_path);require_archive(reg,archive_root);regsha=sha(registration_path);db=connect(archive_root,regsha)
    try:
        rows=verify_chain(db,regsha)
        if validity_day not in rows:raise ValueError('DAY_UNISSUED_UNKNOWN')
        body,_=rows[validity_day]
        if body.get('kind')!='operational' or body.get('status')!='issued':raise ValueError('DAY_NOT_OPERATIONALLY_ISSUED')
        packet=read(checked_ref(body['packet']))
        if packet.get('kind')!='forecast_candidate' or packet.get('status')!='prepared_unissued' or packet.get('schema_version')!=5 or packet.get('backfill') is not False or packet['registration_sha256']!=regsha:raise ValueError('PACKET_NOT_OPERATIONAL')
        start=utc(packet['validity_start_utc']);end=utc(packet['validity_end_utc']);began=utc(packet['preparation_started_utc']);prepared=utc(packet['packet_prepared_utc']);completed=utc(body['archive_completed_utc']);recorded=utc(body['receipt_recorded_utc'])
        if validity_day!=start.date().isoformat() or start!=start.replace(hour=0,minute=0,second=0,microsecond=0) or end!=start+timedelta(days=1) or not utc(reg['freeze_utc'])<=began<=prepared<=completed<start or recorded<completed or not utc(reg['start_utc'])<=start<end<=utc(reg['end_utc']):raise ValueError('PACKET_TEMPORAL_BINDING')
        if body['preparation_started_utc']!=packet['preparation_started_utc'] or body['packet_prepared_utc']!=packet['packet_prepared_utc'] or body['validity_start_utc']!=packet['validity_start_utc'] or body['validity_end_utc']!=packet['validity_end_utc'] or body['capture']!=packet['capture_receipt'] or body['source']!=dict(path=packet['source_snapshot_path'],sha256=packet['source_snapshot_sha256']):raise ValueError('PACKET_LEDGER_BINDING')
        validate_capture(packet['capture_receipt'],reg,regsha,start);checked_ref(body['source'])
        minted=db.execute('SELECT receipt_path,receipt_sha FROM captures WHERE day=?',(validity_day,)).fetchone()
        if minted!=(body['capture']['path'],body['capture']['sha256']):raise ValueError('CAPTURE_NOT_COLLECTOR_MINTED')
        expected=model_manifest(training)
        if packet['beta']!=expected['beta'] or packet['T0']!=24394. or set(packet['models'])!=set(MODELS):raise ValueError('PACKET_PARAMETER_BINDING')
        for mid,m in packet['models'].items():
            refm=expected['models'][mid]
            if m['model']!=refm['model'] or m['pars']!=refm['pars'] or m['spatial']!=refm['spatial'] or m['sigma']!=refm['sigma'] or m['nuisance_cache']!=refm['cache_paths']['train16'] or sha(m['nuisance_cache'])!=m['nuisance_cache_sha256']:raise ValueError('PACKET_PARAMETER_BINDING')
        packet['_verified_packet_sha256']=body['packet']['sha256'];packet['_verified_ledger_status']='issued';packet['_verified_archive_completed_utc']=body['archive_completed_utc'];return packet
    finally:db.close()

def evaluate_issued_day(registration_path,archive_root,validity_day,mid,target_catalogue_path,target_catalogue_sha256):
    packet=admitted_packet(registration_path,archive_root,validity_day)
    if mid not in MODELS:raise ValueError('MODEL_ROSTER')
    targets=validate_canonical(target_catalogue_path,target_catalogue_sha256);start=day(packet['validity_start_utc'],'new_zealand');end=day(packet['validity_end_utc'],'new_zealand');mask=(targets.times>=start)&(targets.times<end)
    # Explicit in-memory bridge: legacy array construction accepts status=issued;
    # only this fully validated unique ledger can authorize that bridge.
    legacy_packet=dict(packet,status='issued')
    arrays,meta=fixed_arrays(legacy_packet,mid,targets.times[mask],targets.excess[mask],targets.latitude[mask],targets.longitude[mask]);parents=validate_canonical(packet['source_snapshot_path'],packet['source_snapshot_sha256']);arrays['parent_excess']=parents.excess;meta.update(history_policy='fixed_preissue',profile='new_zealand')
    with FixedObjectiveV2(arrays,meta) as objective:return dict(kind='operational',status='issued_score',day=validity_day,archive_completed_utc=packet['_verified_archive_completed_utc'],packet_sha256=packet['_verified_packet_sha256'],target_catalogue_sha256=target_catalogue_sha256,model=mid,evaluation=objective.evaluate(packet['models'][mid]['model'],packet['models'][mid]['pars']))
