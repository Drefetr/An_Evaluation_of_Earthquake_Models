"""Aggregate-only fixed-roster California saved-output summary; never fits."""
from pathlib import Path
import argparse,hashlib,json,math

MODELS=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
COMPARISONS=[('primary_timing','Omori_smooth_cont','fixedML_smooth_cont','timing_logscore'),('primary_location','Omori_smooth_cont','Omori_smooth_lift','conditional_location_logscore'),('context_freeML','Omori_smooth_cont','commonML_smooth_cont','joint_logscore'),('context_fixedML_spatial','fixedML_smooth_cont','fixedML_smooth_lift','conditional_location_logscore'),('complete_procedure','Omori_smooth_cont','fixedML_smooth_lift','joint_logscore')]
COMPONENTS=['joint_logscore','timing_logscore','conditional_location_logscore','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore','timing_event_logscore','timing_exposure_logscore','integrated_intensity']

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def number(v):
 if isinstance(v,bool) or not isinstance(v,(float,int)) or not math.isfinite(v):raise ValueError('NONFINITE_SUMMARY_COMPONENT')
 return float(v)

def summarize(source):
 raw=read(source);cases=raw['cases']
 if raw['mode']!='california' or len(cases)!=3 or [r['case']['case_id'] for r in cases]!=[f'california_fold_{i}' for i in range(3)]:raise ValueError('SUMMARY_CASE_ROSTER')
 if raw['procedures']!=30 or raw['mandatory_starts']!=240 or raw['exact_floor_slots']!=33:raise ValueError('SUMMARY_DENOMINATORS')
 rows=[];bindings={str(Path(source).resolve()):sha(source)}
 for case in cases:
  if set(case['models'])!=set(MODELS):raise ValueError('SUMMARY_MODEL_ROSTER')
  row=dict(case_id=case['case']['case_id'],status=case['status'],n_train=case['n_train'],n_test=case['n_test'],training_cell_counts=case['training_cell_counts'],test_cell_counts=case['test_cell_counts'],accounting=case['accounting'],beta=case['beta'],selected_bandwidth_km=case['kde_selection']['selected_bandwidth'],selected_sigma_km=case['selected_sigma'],models={},comparisons=[])
  for path in case['procedures']:
   bindings[str(Path(path).resolve())]=sha(path)
  for mid in MODELS:
   model=case['models'][mid];entry=dict(status=model['status'],complete=model['complete'],procedure_id=model['procedure_id'])
   if model.get('selected'):
    entry['parameters']=model['selected']['pars'];entry['training_joint_nll']=number(model['selected']['evaluation']['joint_nll'])
   if model.get('forecast'):
    entry['scores']={k:number(model['forecast'][k]) for k in COMPONENTS};entry['forecast_spread_nats_per_event']=model['forecast_spread_nats_per_event']
    scores=entry['scores']
    if abs(scores['joint_logscore']-scores['timing_logscore']-scores['conditional_location_logscore']-scores['mark_logscore'])>1e-7:raise ValueError('SUMMARY_PROPER_SCORE_IDENTITY')
    if abs(scores['timing_logscore']-scores['timing_event_logscore']-scores['timing_exposure_logscore'])>1e-7:raise ValueError('SUMMARY_EVENT_EXPOSURE_IDENTITY')
   row['models'][mid]=entry
  for ident,candidate,reference,component in COMPARISONS:
   c=row['models'][candidate];b=row['models'][reference];item=dict(id=ident,candidate=candidate,reference=reference,primary_component=component,status='unknown_incomplete')
   if case['status']=='complete' and 'scores' in c and 'scores' in b:
    delta={k:c['scores'][k]-b['scores'][k] for k in COMPONENTS};n=int(case['n_test'])
    if n<=0:raise ValueError('SUMMARY_EMPTY_TEST_WINDOW')
    item.update(status='complete',n_test=n,delta=delta,primary_delta_nats=delta[component],primary_delta_nats_per_event=delta[component]/n,timing_decomposition=dict(event=delta['timing_event_logscore'],compensator=delta['timing_exposure_logscore'],total=delta['timing_logscore']))
   row['comparisons'].append(item)
  rows.append(row)
 aggregates=[]
 for index,(ident,candidate,reference,component) in enumerate(COMPARISONS):
  parts=[row['comparisons'][index] for row in rows];entry=dict(id=ident,candidate=candidate,reference=reference,primary_component=component,status='unknown_incomplete',planned_windows=3,complete_windows=sum(p['status']=='complete' for p in parts))
  if all(p['status']=='complete' for p in parts):
   n=sum(p['n_test'] for p in parts);delta={k:math.fsum(p['delta'][k] for p in parts) for k in COMPONENTS};entry.update(status='complete',n_test=n,delta=delta,primary_delta_nats=delta[component],primary_delta_nats_per_event=delta[component]/n,positive_windows=sum(p['primary_delta_nats']>0 for p in parts),window_deltas_nats=[p['primary_delta_nats'] for p in parts])
  aggregates.append(entry)
 return dict(schema_version=1,status='complete' if all(r['status']=='complete' for r in rows) else 'unknown_incomplete',scope='Revised-catalogue hindsight external retrospective replication; conditional regional history; not historical as-issued forecasting or causal evidence.',denominators=dict(planned_windows=3,procedures=30,starts=240,floors=33,all_test_targets=sum(r['n_test'] for r in rows)),cases=rows,comparisons=aggregates,input_bindings=bindings,source_sha256=sha(__file__),claim_limits=['Event-weighted differences over fixed windows; no event-iid confidence intervals or p-values.','No omission of unknown windows or additional tuning on test scores.','Prospective New Zealand future results are separate and pending.'])

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--output',required=True);p.add_argument('--expected-source-sha256',required=True);a=p.parse_args()
 if sha(__file__)!=a.expected_source_sha256:raise ValueError('SUMMARY_SOURCE_CHANGED')
 result=summarize(a.source);out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print(json.dumps(dict(status=result['status'],planned_windows=3,summary_sha256=sha(out))))

if __name__=='__main__':
 try:main()
 except Exception as error:print(json.dumps(dict(status='failed',fixed_error_code='CALIFORNIA_SUMMARY_FAILURE',error_type=type(error).__name__)));raise SystemExit(1)
