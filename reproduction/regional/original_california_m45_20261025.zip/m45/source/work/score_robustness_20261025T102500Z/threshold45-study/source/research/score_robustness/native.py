"""Explicit pinned DLL adapter; no fallback compiler or implicit build."""
import ctypes as ct
import hashlib
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''): h.update(block)
    return h.hexdigest()

class Exposure:
    def __init__(self,path,digest):
        path=Path(path).resolve()
        if not digest or sha(path)!=digest: raise ValueError('EXPOSURE_DLL_PIN')
        self.lib=ct.CDLL(str(path)); pd=ct.POINTER(ct.c_double)
        self.lib.rb_exposure.argtypes=[ct.c_int,ct.c_int,pd,ct.c_int,pd,pd]+[ct.c_double]*4+[pd]*5
        self.lib.rb_exposure.restype=ct.c_int
    def evaluate(self,model,pars,parent_time,parent_excess,beta,start,end,T0,weights,rates,background_mass,parent_mass):
        mid={'E_fixed':0,'E_free':1,'E_omori':2}[model]
        def array(v):
            values=list(v);return (ct.c_double*len(values))(*values)
        p,t,q,w,r,b,W=[array(v) for v in (pars,parent_time,parent_excess,weights,rates,background_mass,parent_mass)]
        if len(p)!=3+mid or len(t)!=len(q) or len(W)!=9*len(t) or len(w)!=195 or len(r)!=195 or len(b)!=9: raise ValueError('EXPOSURE_SHAPE')
        out=(ct.c_double*16)()
        if self.lib.rb_exposure(mid,len(p),p,len(t),t,q,beta,start,end,T0,w,r,b,W,out): raise ValueError('EXPOSURE_NATIVE')
        return dict(immigrant_exposure=out[0],trigger_exposure=out[1],triggered_integrated_intensity=out[2],integrated_intensity=out[3],cell_integrated_intensity=list(out[4:13]),zone_integrated_intensity=list(out[13:16]))
