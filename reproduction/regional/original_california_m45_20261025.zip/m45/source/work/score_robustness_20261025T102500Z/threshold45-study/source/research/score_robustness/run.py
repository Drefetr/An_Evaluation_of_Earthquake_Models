"""Private deterministic runner; stdout contains only status/counts/discrepancies."""
import argparse
import ctypes as ct
import hashlib
import json
import math
import sys
import time
import traceback
from pathlib import Path
from .authority import ARMS,check_manifest,bind_fit,read,read_pinned
from .native import Exposure
from .reducer import blocks,day,reduce_block,reconcile_window,contrasts,COMPONENTS,CONTRASTS,close

def write(path,value):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)

def planned_ledger():
    """Data-free fixed denominator, available before any authority admission."""
    cases=[];rows=[]
    for f in range(3):
        for arm in ARMS:
            cases.append(dict(fold_id=f,arm_id=arm,status='unresolved',attempted=False))
            for b in blocks(f):
                rows.append(dict(**{k:v for k,v in b.items() if not k.endswith('_day')},arm_id=arm,logical_arm_window_id=f'california_fold_{f}__arm_{arm}',actual_procedure_id=None,selected_candidate_id=None,status='unresolved',target_count=None,**{k:None for k in COMPONENTS},**{k:None for k in ('immigrant_exposure','trigger_exposure','triggered_integrated_intensity','cell_integrated_intensity','zone_integrated_intensity')}))
    return dict(schema='score_robustness_planned_ledger_v1',planned_denominators=dict(arm_cases=12,arm_blocks=60,contrast_blocks=45,arm_component_slots=540,contrast_component_slots=405),case_statuses=cases,arm_blocks=rows,contrast_blocks=contrasts(rows),aggregate_release_approved=False)

def failure_accounting(lifecycle):
    """Keep pre-admission distinct from failures after genuine case attempts."""
    ledger=planned_ledger()
    reached={(c['fold_id'],c['arm_id']):c for c in lifecycle.get('case_statuses',[])}
    for i,c in enumerate(ledger['case_statuses']):
        if (c['fold_id'],c['arm_id']) in reached:
            current=dict(reached[(c['fold_id'],c['arm_id'])])
            if current['status'] in ('planned','attempted'):current['status']='unresolved'
            ledger['case_statuses'][i]=current
    known={(r['fold_id'],r['arm_id'],r['block_id']):r for r in lifecycle.get('arm_blocks',[])}
    ledger['arm_blocks']=[known.get((r['fold_id'],r['arm_id'],r['block_id']),r) for r in ledger['arm_blocks']]
    if lifecycle.get('contrast_blocks'):ledger['contrast_blocks']=lifecycle['contrast_blocks']
    phase=lifecycle.get('phase','pre_admission')
    code={'pre_admission':'PRE_ADMISSION_FAILED','admitted_initialization':'ADMITTED_INITIALIZATION_FAILED'}.get(phase,'POST_ADMISSION_PROCESS_FAILED')
    ledger.update(status='unresolved',failure_phase=phase,failure_code=code,authority_manifest_sha256=lifecycle.get('authority_manifest_sha256'))
    receipt=dict(status='failed',failure_phase=phase,failure_code=code,authority_manifest_sha256=lifecycle.get('authority_manifest_sha256'),planned_arm_cases=12,attempted_arm_cases=sum(c['attempted'] for c in ledger['case_statuses']),terminal_case_counts={s:sum(c['status']==s for c in ledger['case_statuses']) for s in ('planned','attempted','succeeded','failed','unresolved')},planned_arm_blocks=60,completed_arm_blocks=sum(r['status']=='succeeded' for r in ledger['arm_blocks']),evaluated_arm_blocks=lifecycle.get('evaluated_arm_blocks',0),planned_contrast_blocks=45,completed_contrast_blocks=sum(r['status']=='succeeded' for r in ledger['contrast_blocks']),aggregate_release_approved=False)
    return ledger,receipt

def verify_event_vectors(forecast,logs):
    maximum=0.
    for j,name in enumerate(('point','cell','zone','ground')):
        original=forecast['event_log_'+name+'_intensity']
        if len(original)!=len(logs):raise ValueError('EVENT_VECTOR_SHAPE')
        for i,v in enumerate(original):maximum=max(maximum,close(v,logs[i][j]))
    return maximum

def evaluate_events(arrays,meta,fit,dll):
    # Use the inherited production ABI with rebuilt geometry, never an NPZ cache.
    import numpy as np
    from ..external_replication.compiled_objective import library,MODELS
    names=('parent_time','event_x','event_cell','event_background_density','background_cell_mass','event_parent_density','parent_cell_mass','parent_fertility','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates')
    # Match Objective.__init__: never reinterpret integer/noncontiguous buffers.
    # Keep every converted allocation alive through the finally/ts_destroy.
    a={name:np.ascontiguousarray(arrays[name],dtype='float64') for name in names+('event_time','event_excess')}
    lib,_=library(dll);ne=len(a['event_time']);np_=len(a['parent_time']);pd=ct.POINTER(ct.c_double)
    shapes={k:(ne,) for k in ('event_time','event_excess','event_x','event_cell','event_background_density')}
    shapes.update({k:(np_,) for k in ('parent_time','parent_fertility','parent_exposure_lo','parent_exposure_hi')})
    shapes.update(background_cell_mass=(9,),event_parent_density=(ne,np_),parent_cell_mass=(np_,9),mixture_weights=(195,),mixture_rates=(195,))
    if any(a[k].shape!=shape or not np.isfinite(a[k]).all() for k,shape in shapes.items()):raise ValueError('EVENT_ABI_ARRAY_SHAPE')
    m=np.asarray([meta['start'],meta['end'],meta['T0'],ne*math.log(meta['beta'])-meta['beta']*math.fsum(a['event_excess'])],dtype='float64')
    handle=lib.ts_create(ne,np_,195,*[a[n].ctypes.data_as(pd) for n in names],m.ctypes.data_as(pd))
    if not handle:raise ValueError('EVENT_NATIVE_CREATE')
    try:
        mid,dim=MODELS[fit['model']];p=np.ascontiguousarray(fit['selected']['pars'],dtype='float64')
        if p.shape!=(dim,) or not np.isfinite(p).all():raise ValueError('PARAMETER_SHAPE')
        out=np.empty(28);gradient=np.empty(dim);logs=np.empty((ne,4))
        if lib.ts_eval(handle,mid,p.ctypes.data_as(pd),dim,out.ctypes.data_as(pd),gradient.ctypes.data_as(pd),logs.ctypes.data_as(pd)):raise ValueError('EVENT_NATIVE_EVAL')
        if not np.isfinite(out).all() or not np.isfinite(logs).all():raise ValueError('EVENT_NATIVE_NONFINITE')
        return out,logs
    finally:lib.ts_destroy(handle)

def prepare_state(manifest,fold,row,score,arm,cat,exposure):
    import numpy as np
    from ..external_replication import geometry as G
    fit=bind_fit(row,arm,score,manifest);case=row['case'];f=fold['fold_id'];bb=list(blocks(f));start=bb[0]['start_day'];end=bb[-1]['end_day']
    if row['profile']!='california' or row['catalogue_sha256']!=manifest['catalogue_sha256'] or row['protocol_sha256']!=manifest['protocol_sha256'] or case['case_id']!=fold['case_id'] or case['fold_id']!=f or case['test_start']!=start or case['test_end']!=end or case['T0']!=16436.:raise ValueError('WINDOW_AUTHORITY')
    tr=(cat.times>=case['train_start'])&(cat.times<case['train_end']);te=(cat.times>=start)&(cat.times<end)
    if int(tr.sum())!=row['n_train'] or not np.array_equal(np.bincount(cat.cells[tr],minlength=9),np.asarray(row['training_cell_counts'])):raise ValueError('TRAINING_POPULATION')
    if int(te.sum())!=(79,167,69)[f]:raise ValueError('TARGET_POPULATION')
    arr,meta=G.make_geometry(cat.times,cat.excess,cat.cells,cat.latitude,cat.longitude,row['beta'],start,end,row['reference_pi'],family='continuous' if fit['spatial']=='cont' else 'center',sigma=fit['sigma'],order=16,T0=16436.,background='kde',kde_bandwidth=row['kde_selection']['selected_bandwidth'],background_training_xy=G.project(cat.latitude[tr],cat.longitude[tr],'california'),background_training_cells=cat.cells[tr],profile='california',dll_path=manifest['production_dll_path'])
    computed,logs=evaluate_events(arr,meta,fit,manifest['production_dll_path']);forecast=score['forecast']
    names=('point','cell','zone','ground');max_vector=verify_event_vectors(forecast,logs)
    # Archive lacks event IDs: this is a source-order identity derivation, backed
    # by a pointwise production reevaluation, not a historical ID-bearing record.
    identities=[(cat.event_ids[i],float(cat.times[i])) for i in np.flatnonzero(te)]
    identity_digest=hashlib.sha256(json.dumps(identities,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    state=dict(identity=dict(arm_id=arm,logical_arm_window_id=f"{fold['case_id']}__arm_{arm}",actual_procedure_id=fit['procedure_id'],selected_candidate_id=fit['selected']['candidate_id']),event_time=arr['event_time'].tolist(),event_excess=arr['event_excess'].tolist(),beta=float(row['beta']),logs={name:forecast['event_log_'+name+'_intensity'] for name in names},event_identity=identities)
    def integral(s,e):return exposure.evaluate(fit['model'],fit['selected']['pars'],arr['parent_time'],arr['parent_excess'],row['beta'],s,e,16436.,arr['mixture_weights'],arr['mixture_rates'],arr['background_cell_mass'],arr['parent_cell_mass'].ravel())
    full=integral(start,end)
    # Native full-window terms and rebuilt annual integral are separate checks.
    scalar={ 'joint_logscore':-computed[0],'timing_logscore':computed[1],'conditional_zone_logscore':computed[2],'conditional_cell_logscore':computed[3],'within_cell_density_logscore':computed[4],'mark_logscore':computed[5],'integrated_intensity':computed[6],'event_log_ground_intensity_sum':computed[8],'trigger_exposure':computed[9] }
    scalar['conditional_location_logscore']=math.fsum(computed[2:5])
    for k,v in scalar.items():close(v,forecast[k])
    close(full['integrated_intensity'],computed[6]);close(full['trigger_exposure'],computed[9])
    for j,v in enumerate(computed[10:19]):close(v,full['cell_integrated_intensity'][j])
    state['window_state']=dict(**state['identity'],fold_id=f,window_start_day=start,window_end_day=end,T0_days=16436.,beta=float(row['beta']),parameters=fit['selected']['pars'],selected_sigma=fit['sigma'],selected_kde_bandwidth=row['kde_selection']['selected_bandwidth'],source_hash_lineage=manifest['source_pins'],event_identity_evidence='pinned catalogue source order + exact window + pointwise whole-window reevaluation; archive has no event IDs',event_identity_sha256=identity_digest,max_event_vector_abs_discrepancy=max_vector,n_parents=len(arr['parent_time']),n_targets=len(identities))
    return state,integral,full

def pooled_checks(rows,contrast_rows,windows):
    results=[]
    for cid,A,B,primary in CONTRASTS:
        for fold in range(3):
            group=[r for r in contrast_rows if r['contrast_id']==cid and r['fold_id']==fold]
            refA=windows[(fold,A)];refB=windows[(fold,B)]
            for k in COMPONENTS:
                archive_key='event_log_ground_intensity_sum' if k=='event_ground_log' else k
                delta=math.fsum(r[k] for r in group)
                close(delta,refA[archive_key]-refB[archive_key])
        for k in COMPONENTS:
            archive_key='event_log_ground_intensity_sum' if k=='event_ground_log' else k
            delta=math.fsum(r[k] for r in contrast_rows if r['contrast_id']==cid)
            ref=math.fsum(windows[(f,A)][archive_key]-windows[(f,B)][archive_key] for f in range(3))
            discrepancy=close(delta,ref)
            results.append(dict(contrast_id=cid,component=k,archive_abs_discrepancy=discrepancy,pooled_value=delta,pooled_per_target=delta/315))
        expected={'timing_OC_minus_fixedML':37.790339,'location_OC_minus_OL':674.323522,'joint_OC_minus_commonML':21.177884}[cid]
        close(math.fsum(r[primary] for r in contrast_rows if r['contrast_id']==cid),expected)
    close(math.fsum(r['within_cell_density_logscore'] for r in contrast_rows if r['contrast_id']=='location_OC_minus_OL'),653.602228)
    return results

def run(manifest_path,folder,seconds,stop_file,pilot_first_fold=False,lifecycle=None):
    lifecycle={} if lifecycle is None else lifecycle
    lifecycle.update(phase='pre_admission',authority_manifest_sha256=None,evaluated_arm_blocks=0)
    begun=time.monotonic();m,manifest_digest=check_manifest(manifest_path)
    lifecycle.update(phase='admitted_initialization',authority_manifest_sha256=manifest_digest)
    policy=dict(mode='fresh_exclusive_prefix_plus_B',PYTHONPYCACHEPREFIX=sys.pycache_prefix,dont_write_bytecode=True,verified_empty_at_admission=True,exclusive_lifecycle_owner='root_process_supervisor')
    write(folder/'authority_admission_private.json',dict(schema='score_robustness_authority_admission_v1',authority_manifest_sha256=manifest_digest,bytecode_policy=policy,status='authority_admitted'))
    from ..external_replication.catalogue import load_catalogue
    cat=load_catalogue(m['catalogue_path'],m['catalogue_sha256'],profile='california')
    # Audit integer UTC microseconds against the inherited total_seconds() law.
    # Preserve original production times byte-for-byte for frozen decomposition.
    import numpy as np
    rawpath=Path(m['catalogue_path'])
    rawbytes=rawpath.read_bytes()
    if hashlib.sha256(rawbytes).hexdigest()!=m['catalogue_sha256']:raise ValueError('CATALOGUE_CHANGED_AT_READ')
    if rawpath.suffix=='.jsonl':
        rawrows=[json.loads(line) for line in rawbytes.decode('utf-8-sig').splitlines() if line.strip()][1:]
    else:rawrows=json.loads(rawbytes.decode('utf-8-sig'))['events']
    if [r['event_id'] for r in rawrows]!=list(cat.event_ids):raise ValueError('CATALOGUE_ORDER')
    exact=np.asarray([day(r['origin_time_utc']) for r in rawrows],dtype='float64')
    if np.max(np.abs(exact-cat.times),initial=0)>2e-12:raise ValueError('TIME_CONVERSION')
    # Catalogue ingestion validates IDs, chronology, coordinates and preferred law.
    if len(cat.event_ids)!=1272:raise ValueError('CATALOGUE_POPULATION')
    engine=Exposure(m['exposure_dll_path'],m['exposure_dll_sha256'])
    rows=[];cases=[];checks=[];windows={};states=[];stopped=False
    lifecycle.update(phase='scientific_cases',case_statuses=cases,arm_blocks=rows,contrast_blocks=[])
    for fold in sorted(m['folds'],key=lambda x:x['fold_id']):
        f=fold['fold_id'];row=None
        for arm in ARMS:
            planned=[dict(**{k:v for k,v in b.items() if not k.endswith('_day')},arm_id=arm,logical_arm_window_id=f"{fold['case_id']}__arm_{arm}",actual_procedure_id=None,selected_candidate_id=None,status='unresolved',target_count=None,**{k:None for k in COMPONENTS},**{k:None for k in ('immigrant_exposure','trigger_exposure','triggered_integrated_intensity','cell_integrated_intensity','zone_integrated_intensity')}) for b in blocks(f)]
            case=dict(fold_id=f,arm_id=arm,status='planned',attempted=False);cases.append(case)
            if stopped or (pilot_first_fold and f>0):
                case['status']='unresolved';case['failure_code']='PRIOR_STOP';rows.extend(planned);continue
            case['status']='attempted';case['attempted']=True
            try:
                if time.monotonic()-begun>=seconds or (stop_file and Path(stop_file).exists()):raise TimeoutError('SAFE_STOP')
                if row is None:row=read_pinned(fold['training_record_path'],fold['training_record_sha256'])
                record=next(s for s in fold['score_records'] if s['arm_id']==arm);score=read_pinned(record['score_path'],record['score_sha256'])
                state,integral,full=prepare_state(m,fold,row,score,arm,cat,engine);local=[]
                write(folder/f'event_mapping_private_{f}_{arm}.json',dict(schema='score_robustness_private_event_mapping_v1',authority_manifest_sha256=manifest_digest,state=state['window_state'],event_identity=state['event_identity'],event_time=state['event_time'],archived_event_logs=state['logs']))
                for block in blocks(f):
                    if time.monotonic()-begun>=seconds or (stop_file and Path(stop_file).exists()):raise TimeoutError('SAFE_STOP')
                    local.append(reduce_block(state,block,integral(block['start_day'],block['end_day'])))
                    lifecycle['evaluated_arm_blocks']+=1
                    write(folder/f'checkpoint_{f}_{arm}_{len(local)}.json',dict(schema='score_robustness_private_checkpoint_v1',authority_manifest_sha256=manifest_digest,state=state['window_state'],completed_blocks=local,complete_window=False))
                delta=reconcile_window(local,score['forecast'],full)
                checks.append(dict(fold_id=f,arm_id=arm,status='succeeded',max_abs_discrepancy=max(delta.values()),component_discrepancies=delta))
                windows[(f,arm)]=score['forecast'];states.append(state['window_state']);rows.extend(local);case['status']='succeeded'
            except Exception as exc:
                write(folder/f'failure_{f}_{arm}.json',dict(exception_type=type(exc).__name__,private_traceback=traceback.format_exc()))
                case['status']='unresolved' if isinstance(exc,TimeoutError) else 'failed';case['failure_code']='SAFE_STOP' if isinstance(exc,TimeoutError) else 'CASE_FAILED';rows.extend(planned);stopped=True
    lifecycle['phase']='global_reconciliation'
    contrast_rows=contrasts(rows);lifecycle['contrast_blocks']=contrast_rows;complete=all(c['status']=='succeeded' for c in cases)
    pools=[];pooled_failed=False
    if complete:
        try:pools=pooled_checks(rows,contrast_rows,windows)
        except Exception:
            write(folder/'pooled_failure_private.json',dict(private_traceback=traceback.format_exc()))
            pools=[dict(status='failed',failure_code='POOLED_RECONCILIATION_FAILED')];complete=False;pooled_failed=True
    lifecycle['phase']='finalization'
    output=dict(schema='score_robustness_blocks_v1',producer='production',claim_status='numerical_output_requires_independent_acceptance',authority_manifest_sha256=manifest_digest,bytecode_policy=policy,accepted_design_hashes=m['accepted_design_hashes'],source_pins=m['source_pins'],planned_denominators=dict(arm_blocks=60,contrast_blocks=45,arm_component_slots=540,contrast_component_slots=405),case_statuses=cases,arm_blocks=rows,contrast_blocks=contrast_rows,window_checks=checks,pooled_checks=pools,window_states=states,aggregate_release_approved=False,status='succeeded' if complete else 'unresolved',elapsed_seconds=time.monotonic()-begun)
    write(folder/'blocks_private.json',output)
    counts={s:sum(c['status']==s for c in cases) for s in ('planned','attempted','succeeded','failed','unresolved')}
    # Emit no scientific scores, paths, parameters or exception messages.
    pilot_ok=pilot_first_fold and all(c['status']=='succeeded' for c in cases if c['fold_id']==0)
    lifecycle['phase']='terminal'
    return dict(status='pilot_completed' if pilot_ok else output['status'],authority_manifest_sha256=manifest_digest,failure_code='POOLED_RECONCILIATION_FAILED' if pooled_failed else None,planned_arm_cases=12,attempted_arm_cases=sum(c['attempted'] for c in cases),terminal_case_counts=counts,planned_arm_blocks=60,completed_arm_blocks=sum(r['status']=='succeeded' for r in rows),planned_contrast_blocks=45,completed_contrast_blocks=sum(r['status']=='succeeded' for r in contrast_rows),maximum_absolute_component_discrepancy=max((c['max_abs_discrepancy'] for c in checks),default=None),aggregate_release_approved=False)

def main():
    p=argparse.ArgumentParser();p.add_argument('--authority',required=True);p.add_argument('--output',required=True);p.add_argument('--seconds',required=True,type=float);p.add_argument('--stop-file');p.add_argument('--pilot-first-fold',action='store_true');a=p.parse_args()
    # Output must be new and outside authority inputs. No overwrite/reuse.
    folder=Path(a.output).resolve()
    lifecycle=dict(phase='pre_admission',authority_manifest_sha256=None)
    try:
        if not math.isfinite(a.seconds) or a.seconds<=0 or (a.pilot_first_fold and a.seconds>600):raise ValueError('BUDGET')
        folder.mkdir(parents=True,exist_ok=False)
    except Exception:
        _,receipt=failure_accounting(lifecycle);receipt['failure_code']='OUTPUT_OR_BUDGET_INVALID'
        print(json.dumps(receipt,allow_nan=False));return 2
    try:
        write(folder/'planned_ledger_private.json',planned_ledger())
        receipt=run(a.authority,folder,a.seconds,a.stop_file,a.pilot_first_fold,lifecycle)
    except Exception as exc:
        write(folder/'fatal_private.json',dict(exception_type=type(exc).__name__,private_traceback=traceback.format_exc()))
        ledger,receipt=failure_accounting(lifecycle)
        write(folder/'failure_ledger_private.json',ledger)
    write(folder/'receipt_sanitized.json',receipt);print(json.dumps(receipt,allow_nan=False));return 0 if receipt['status'] in ('succeeded','pilot_completed') else 2

if __name__=='__main__':raise SystemExit(main())
