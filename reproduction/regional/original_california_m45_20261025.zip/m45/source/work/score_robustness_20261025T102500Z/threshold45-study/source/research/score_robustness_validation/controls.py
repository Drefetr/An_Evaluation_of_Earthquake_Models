"""Authored handcrafted controls only. Not executed during source preparation."""
from __future__ import annotations
import copy
import hashlib
import math
from pathlib import Path
from .common import (ARMS, ATOMIC, COMPONENTS, DIAGNOSTICS, PLANNED, TARGETS,
                     AuditError, blank_rows, blocks, close, contrast_rows,
                     day, derived, need, pinned)

def rejected(function, code):
    try: function()
    except (AuditError,ValueError,KeyError): return
    raise AuditError(code)

def fixture_output():
    rows=blank_rows()
    for row in rows:
        fold=row['fold_id']; first=next(blocks(fold))[0]['block_id']
        row.update(status='succeeded',actual_procedure_id='fixture_'+row['arm_id'],
                   selected_candidate_id=0,target_count=TARGETS[fold] if row['block_id']==first else 0,
                   immigrant_exposure=1.,trigger_exposure=2.,triggered_integrated_intensity=0.,
                   cell_integrated_intensity=[1/9]*9,zone_integrated_intensity=[1/3]*3)
        row.update({k:0. for k in ATOMIC});row['integrated_intensity']=1.;derived(row)
        row['per_target_mean']=row['joint_logscore']/row['target_count'] if row['target_count'] else None
    return dict(schema='score_robustness_blocks_v1',producer='independent',planned_denominators=PLANNED,
                arm_blocks=rows,contrast_blocks=contrast_rows(rows),
                case_statuses=[dict(fold_id=f,arm_id=a,status='succeeded') for f in range(3) for a in ARMS])

def synthetic_geometry(raw,parent_mask,event_mask):
    import numpy as np
    # Handcrafted unit-area uniform law, sufficient for direct-history fixtures.
    np_,ne=int(parent_mask.sum()),int(event_mask.sum())
    return dict(parent_xy=raw['xy'][parent_mask],event_xy=raw['xy'][event_mask],
                training_xy=np.zeros((1,2)),event_cell=np.zeros(ne,dtype=int),
                area=np.full(9,1/9),density=np.ones(9),parent_cell=np.full((np_,9),1/9),
                parent_normalizer=np.ones(np_),background_cell=np.full(9,1/9),kde_normalizer=np.ones(1))

def run(directory,budget):
    import numpy as np
    from external_replication_validation import oracle as O
    from external_replication_validation import raw_input_v3 as R
    from .authority import check_alias,check_event_identity
    from .compare import validate_output
    from .oracle import background_integral,block_exposure,event_terms,geometry,interval_mass
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False);checks=[]
    mixture=O.mixture()
    def passed(name): checks.append(dict(control=name,status='passed'));budget.checkpoint('handcrafted_control',len(checks))
    raw=dict(times=np.array([1.5]),excess=np.array([0.]),xy=np.zeros((1,2)))
    parent=np.ones(1,dtype=bool);event=parent.copy();g=synthetic_geometry(raw,parent,event)
    values=[]
    for rate in (2.,1.):
        state=dict(parameters=[math.log(rate),0.,0.],beta=1.,T0=10.,temporal='fixedML',spatial='lift',sigma=1.,bandwidth=1.)
        logs=event_terms(raw,state,parent,event,g,budget,mixture)
        timing=[]
        for lo,hi in ((0.,1.),(1.,2.)):
            exposure=block_exposure('fixedML',state['parameters'],raw['times'],raw['excess'],1.,lo,hi,10.,g['parent_cell'],g['background_cell'],budget,mixture)
            timing.append(math.fsum(r['event_ground_log'] for r in logs if lo<=r['time']<hi)-exposure['integrated_intensity'])
        values.append(timing)
    close(values[0][0]-values[1][0],-1.);close(values[0][1]-values[1][1],math.log(2)-1.)
    close(math.fsum(values[0])-math.fsum(values[1]),math.log(2)-2.);passed('constant_rate_empty_first_block_and_exposure_sign')
    pars=[math.log(.5),0.,.25,0.,2.]
    times=np.array([0.,1.,1.5,2.]);q=np.zeros(4);pc=np.full((4,9),1/9);bc=np.full(9,1/9)
    x=block_exposure('Omori',pars,times,q,1.,1.,2.,10.,pc,bc,budget,mixture)
    expected=math.fsum(.3*(1/(1+max(1-t,0))-1/(1+2-t)) for t in times if t<2.)
    close(x['trigger_exposure'],expected, tol=1e-12);close(x['integrated_intensity'],.5+.25*expected,tol=1e-12)
    rejected(lambda:close(x['integrated_intensity'],.5+expected,tol=1e-12),'WRONG_B_PLUS_K_NOT_REJECTED')
    truncated=block_exposure('Omori',pars,times[1:],q[1:],1.,1.,2.,10.,pc[1:],bc,budget,mixture)
    rejected(lambda:close(x['integrated_intensity'],truncated['integrated_intensity'],tol=1e-12),'RESET_HISTORY_NOT_DETECTED')
    passed('before_at_inside_end_parents_n_quarter_and_reset_negative')
    for model,pr in (('fixedML',pars[:3]),('commonML',pars[:3]+[math.log(.1)]),('Omori',pars)):
        full=interval_mass(model,pr,0.,2.,mixture)
        pieces=math.fsum(interval_mass(model,pr,lo,hi,mixture) for lo,hi in ((0.,1e-9),(1e-9,.5),(.5,1.),(1.,2.)))
        close(full,pieces,tol=1e-12)
    for d in (0.,1e-12,.7,-.7):
        close(background_integral(-1.,d,0.,3.,10.),math.fsum(background_integral(-1.,d,a,b,10.) for a,b in ((0.,1.),(1.,2.),(2.,3.))),tol=1e-12)
    close(day('2021-01-01T00:00:00Z')-day('2020-01-01T00:00:00Z'),366.,tol=0.)
    close(day('2020-03-01T00:00:00Z')-day('2020-02-29T00:00:00Z'),1.,tol=0.)
    passed('analytic_interval_additivity_narrow_boundary_and_leap_calendar')
    raw=dict(times=np.array([.2,1.,1.,2.]),excess=np.zeros(4),xy=np.zeros((4,2)))
    parent=raw['times']<2.;event=(raw['times']>=1.)&(raw['times']<2.)
    g=synthetic_geometry(raw,parent,event)
    state=dict(parameters=pars,beta=1.,T0=10.,temporal='Omori',spatial='lift',sigma=1.,bandwidth=1.)
    logs=event_terms(raw,state,parent,event,g,budget,mixture)
    expected_log=math.log(.5+.25*.3/(1+.8)**2)
    need(len(logs)==2,'HALFOPEN_FINAL_END_NOT_EXCLUDED')
    close(logs[0]['event_ground_log'],expected_log,tol=1e-12);close(logs[1]['event_ground_log'],expected_log,tol=1e-12)
    need([r['time'] for r in logs]==[1.,1.],'TIED_EVENT_MAPPING')
    passed('strict_ties_halfopen_targets_and_final_end')
    for temporal,pr in (('fixedML',[-1.,0.,0.]),('Omori',[-1.,0.,0.,math.log(.001),1.01])):
        zero=block_exposure(temporal,pr,np.empty(0),np.empty(0),1.,0.,1.,10.,np.empty((0,9)),bc,budget,mixture)
        close(zero['integrated_intensity'],math.exp(-1.),tol=1e-12)
        with_history=block_exposure(temporal,pr,np.array([0.]),np.array([0.]),1.,0.,1.,10.,np.full((1,9),1/9),bc,budget,mixture)
        close(with_history['integrated_intensity'],zero['integrated_intensity'],tol=1e-12)
    passed('zero_history_empty_queries_and_zero_trigger_inactive_parameters')
    raw['excess']=np.array([0.,.4,.4,0.]);state['beta']=2.
    logs=event_terms(raw,state,parent,event,g,budget,mixture)
    expected_mark=2*(math.log(2)-2*.4)
    close(math.fsum(r['mark_logscore'] for r in logs),expected_mark,tol=1e-12)
    close(math.fsum(r['mark_logscore'] for r in logs)-expected_mark,0.,tol=0.)
    close(math.log(.5)+math.log(.25)+math.log(2.),math.log(.25),tol=1e-12)
    passed('mark_once_and_common_mark_cancellation_zone_cell_within_chain')
    rect=np.array([[j/3,(j+1)/3,i/3,(i+1)/3] for i in range(3) for j in range(3)])
    rg=dict(times=np.array([0.]),excess=np.array([0.]),xy=np.array([[.5,.5]]),rectangles=rect)
    mask=np.ones(1,dtype=bool)
    for spatial in ('continuous','lift'):
        st=dict(training_mask=mask,pi=np.full(9,1/9),sigma=.25,bandwidth=.25,spatial=spatial)
        gg=geometry(rg,st,mask,mask,budget)
        close(math.fsum(gg['parent_cell'][0]),1.,tol=1e-12)
        close(math.fsum(gg['background_cell']),1.,tol=1e-12)
        if spatial=='lift':close(math.fsum(gg['parent_cell'][0]/gg['area']*gg['area']),1.,tol=1e-12)
    passed('independent_continuous_lift_and_background_finite_domain_mass')
    output=fixture_output();validate_output(output,'independent')
    for mutator,name in ((lambda v:v['arm_blocks'].pop(),'missing_block'),
                         (lambda v:v['arm_blocks'].append(copy.deepcopy(v['arm_blocks'][0])),'duplicate_block'),
                         (lambda v:v['arm_blocks'][0].update(integrated_intensity=float('nan')),'nonfinite'),
                         (lambda v:v['contrast_blocks'][0].update(joint_logscore=100.),'wrong_contrast')):
        bad=copy.deepcopy(output);mutator(bad)
        rejected(lambda:validate_output(bad,'independent'),'CORRUPTION_NOT_REJECTED')
    passed('complete_60_45_schema_and_omitted_duplicated_nonfinite_contrast_rejection')
    aliased=copy.deepcopy(output)
    for canonical,alias in (('arm_block_rows','arm_blocks'),('contrast_block_rows','contrast_blocks')):
        aliased['planned_denominators'][alias]=aliased['planned_denominators'].pop(canonical)
    for row in aliased['contrast_blocks']:row['exposure_contribution']=row.pop('exposure_contrast')
    validate_output(aliased,'independent')
    bad=copy.deepcopy(aliased);bad['planned_denominators']['arm_block_rows']=59
    rejected(lambda:validate_output(bad,'independent'),'CONFLICTING_DENOMINATOR_ALIAS_NOT_REJECTED')
    bad=copy.deepcopy(aliased);bad['contrast_blocks'][0]['exposure_contrast']=1.
    rejected(lambda:validate_output(bad,'independent'),'CONFLICTING_EXPOSURE_ALIAS_NOT_REJECTED')
    passed('explicit_60_45_and_exposure_schema_alias_compatibility_and_conflict_rejection')
    model=dict(procedure_id='california_fold_0__selector_fixedML_smooth_cont_sigma5',selected=dict(candidate_id=0))
    alias=dict(source_procedure_id=model['procedure_id'],source_candidate_id=0,sigma=5.,no_additional_fit=True)
    check_alias(alias,model,0,5.)
    for field,value in (('source_candidate_id',1),('sigma',15.),('source_procedure_id','invented_main')):
        bad=dict(alias);bad[field]=value
        rejected(lambda:check_alias(bad,model,0,5.),'ALIAS_CORRUPTION_NOT_REJECTED')
    sample=directory/'hash_fixture.txt';sample.write_bytes(b'handcrafted-before\n');before=hashlib.sha256(sample.read_bytes()).hexdigest()
    sample.write_bytes(b'handcrafted-after\n');rejected(lambda:pinned(sample.resolve(),before),'HASH_CORRUPTION_NOT_REJECTED')
    check_event_identity(['event_A','event_B'],['event_A','event_B'])
    rejected(lambda:check_event_identity(['event_A','event_B'],['event_B','event_A']),'PERMUTED_EVENT_ID_NOT_REJECTED')
    passed('changed_hash_alias_candidate_sigma_and_permuted_ID_rejection')
    sample=directory/'1981.catalog'
    data=b'1981/01/01 00:00:00.000001 eq l 4.0 w 34.5 -117.5 5.0 A* fixture001 10 0\n'
    sample.write_bytes(data);pin=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob_sha1=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
    parsed=R.read_annual_raw([sample],{sample.name:pin})
    need(parsed['row_ids']==['scedc:fixture001'] and len(parsed['times'])==1,'HANDCRAFTED_RAW_BINDING')
    passed('repaired_raw_parser_opaque_quality_microsecond_fixture')
    return dict(schema='score_robustness_independent_controls_v1',status='passed',
                source_preparation_claim=False,controls=checks,passed_controls=len(checks),
                failed_controls=0,empirical_inputs_read=False,aggregate_release_approved=False)
