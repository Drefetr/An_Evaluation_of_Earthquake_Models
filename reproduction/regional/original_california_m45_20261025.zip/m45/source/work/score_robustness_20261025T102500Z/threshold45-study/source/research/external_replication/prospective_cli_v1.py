"""Manual privacy-safe CLI for the admitted operative prospective_v4 API only.

No scheduler, service, automatic capture, caller clock, interim scoring or older
operational API is exposed. Full numeric scores are private artifacts only.
"""
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
import argparse,contextlib,hashlib,json,os,re,sys

class SafeCLIError(ValueError):
    def __init__(self,code):self.code=code;super().__init__(code)

class SafeParser(argparse.ArgumentParser):
    def error(self,message):raise SafeCLIError('INVALID_ARGUMENTS')

def _operative_api():
    try:from . import prospective_v4
    except ImportError:import prospective_v4
    if Path(prospective_v4.__file__).resolve()!=Path(__file__).with_name('prospective_v4.py').resolve():raise SafeCLIError('OPERATIVE_V4_MODULE_ORIGIN')
    return prospective_v4

def _clean(value):
    try:from .workflow import clean
    except ImportError:from workflow import clean
    return clean(value)

def _quiet_call(function,*args,**kwargs):
    # The wrapper owns stdout/stderr even if an admitted Python parser emits
    # accidental diagnostics before raising. Never buffer raw source content.
    with open(os.devnull,'w',encoding='utf-8') as sink:
        with contextlib.redirect_stdout(sink),contextlib.redirect_stderr(sink):return function(*args,**kwargs)

def _actual_now():return datetime.now(timezone.utc)
def _sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _utc(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)',value):raise SafeCLIError('INVALID_UTC_METADATA')
    try:return datetime.fromisoformat(value.replace('Z','+00:00'))
    except Exception:raise SafeCLIError('INVALID_UTC_METADATA') from None

def _day(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):raise SafeCLIError('INVALID_UTC_DAY')
    try:parsed=date.fromisoformat(value)
    except Exception:raise SafeCLIError('INVALID_UTC_DAY') from None
    if parsed.isoformat()!=value:raise SafeCLIError('INVALID_UTC_DAY')
    return value

def _digest(value):
    if not isinstance(value,str) or not re.fullmatch(r'[0-9a-f]{64}',value):raise SafeCLIError('INVALID_SHA256')
    return value

def _absolute(value):
    p=Path(value)
    if not p.is_absolute():raise SafeCLIError('ABSOLUTE_PATH_REQUIRED')
    return p.resolve()

def _ref(value):
    if not isinstance(value,dict):raise SafeCLIError('INVALID_OPERATION_RECEIPT')
    return dict(path=str(_absolute(value['path'])),sha256=_digest(value['sha256']))

def _verified(api,path):
    reg,training=_quiet_call(api.verify_registration,path)
    own=str(Path(__file__).resolve())
    if reg.get('artifact_pins',{}).get(own)!=_sha(own):raise SafeCLIError('CLI_SOURCE_NOT_FROZEN')
    return reg

def _private_score_path(reg,value):
    p=_absolute(value);scores=_absolute(reg['archive_root'])/'scores'
    try:p.relative_to(scores)
    except ValueError:raise SafeCLIError('PRIVATE_SCORE_PATH_OUTSIDE_REGISTERED_SCORES') from None
    if p==scores or p.exists():raise SafeCLIError('PRIVATE_SCORE_OUTPUT_MUST_BE_NEW_FILE')
    return p

def _final_snapshot(reg,path,expected):
    expected=_digest(expected);end=_utc(reg['end_utc']);eligible=end+timedelta(days=90);actual=_actual_now()
    if actual.tzinfo is None or actual.utcoffset()!=timedelta(0):raise SafeCLIError('INVALID_ACTUAL_CLOCK')
    if actual<eligible:raise SafeCLIError('FINAL_ADJUDICATION_NOT_OPEN')
    path=_absolute(path)
    if _sha(path)!=expected:raise SafeCLIError('FINAL_SNAPSHOT_SHA256_MISMATCH')
    with path.open(encoding='utf-8-sig') as f:obj=json.load(f)
    retrieved=_utc(obj['provenance']['retrieved_utc'])
    if retrieved<eligible or retrieved>actual:raise SafeCLIError('FINAL_SNAPSHOT_RETRIEVAL_DATE')
    return path,expected,eligible

def parser():
    ap=SafeParser(description='Manual prospective v4 operations. No automatic monitoring or interim scoring.')
    sub=ap.add_subparsers(dest='command',required=True,parser_class=SafeParser)
    for name in ['verify','capture','issue','missing','score-day']:
        p=sub.add_parser(name)
        p.add_argument('--registration',required=True,help='Absolute path to the actual frozen operational registration.')
        if name in ['capture','score-day']:p.add_argument('--day',required=True,help='UTC calendar day, exactly YYYY-MM-DD.')
        if name=='issue':p.add_argument('--capture-receipt',required=True,help='Absolute path to the actual collector-minted receipt.')
        if name=='score-day':
            p.add_argument('--model',required=True,choices=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift'])
            p.add_argument('--final-snapshot',required=True,help='Absolute path to the one versioned final canonical target snapshot.')
            p.add_argument('--final-snapshot-sha256',required=True)
            p.add_argument('--private-output',required=True,help='New absolute JSON file below registered archive_root/scores.')
    return ap

def run_cli(argv=None):
    args=parser().parse_args(argv);registration=_absolute(args.registration);api=_quiet_call(_operative_api);reg=_verified(api,registration);archive=_absolute(reg['archive_root'])
    if args.command=='verify':return dict(status='verified',path=str(registration),sha256=_sha(registration))
    if args.command=='capture':
        validity_day=_day(args.day);result=_ref(_quiet_call(api.capture_source,registration,validity_day+'T00:00:00Z',archive));return dict(status='capture_complete',day=validity_day,**result)
    if args.command=='issue':
        capture=_absolute(args.capture_receipt);capture_ref=dict(path=str(capture),sha256=_sha(capture));result=_quiet_call(api.issue_day,registration,capture_ref,archive);day_value=_day(result['day'])
        if result.get('status')=='issued':
            packet=_ref(result['packet']);completed=result['archive_completed_utc'];recorded=result['receipt_recorded_utc'];_utc(completed);_utc(recorded)
            return dict(status='issued',day=day_value,**packet,archive_completed_utc=completed,receipt_recorded_utc=recorded,chain_sha256=_digest(result['chain_sha256']))
        if result.get('status')=='unissued':return dict(status='unissued',day=day_value,**_ref(result['attempt']),chain_sha256=_digest(result['chain_sha256']))
        raise SafeCLIError('UNRECOGNIZED_ISSUE_STATUS')
    if args.command=='missing':
        result=_quiet_call(api.finalize_missing_days,registration,archive)
        if result.get('status')!='complete':raise SafeCLIError('MISSING_DAY_FINALIZATION_FAILED')
        return dict(status='missing_days_finalized')
    if args.command=='score-day':
        validity_day=_day(args.day);output=_private_score_path(reg,args.private_output);target,digest,eligible=_final_snapshot(reg,args.final_snapshot,args.final_snapshot_sha256)
        result=_quiet_call(api.evaluate_issued_day,registration,archive,validity_day,args.model,target,digest)
        if result.get('kind')!='operational' or result.get('status')!='issued_score' or result.get('day')!=validity_day or result.get('model')!=args.model or result.get('target_catalogue_sha256')!=digest:raise SafeCLIError('INVALID_OPERATIONAL_SCORE_RESULT')
        # This artifact is intentionally private. No score, model parameter,
        # event log, ID, catalogue row or array is returned on stdout/stderr.
        artifact=dict(schema_version=1,kind='private_final_day_score',registration_path=str(registration),registration_sha256=_sha(registration),final_snapshot_path=str(target),final_snapshot_sha256=digest,adjudication_not_before_utc=eligible.isoformat().replace('+00:00','Z'),result=result)
        output.parent.mkdir(parents=True,exist_ok=True)
        with output.open('x',encoding='utf-8') as f:json.dump(_quiet_call(_clean,artifact),f,indent=2,allow_nan=False)
        return dict(status='private_score_saved',day=validity_day,path=str(output),sha256=_sha(output))
    raise SafeCLIError('INVALID_COMMAND')

SAFE_ERROR_CODES={'OPERATIVE_V4_MODULE_ORIGIN','INVALID_ARGUMENTS','INVALID_UTC_METADATA','INVALID_UTC_DAY','INVALID_SHA256','ABSOLUTE_PATH_REQUIRED','INVALID_OPERATION_RECEIPT','CLI_SOURCE_NOT_FROZEN','PRIVATE_SCORE_PATH_OUTSIDE_REGISTERED_SCORES','PRIVATE_SCORE_OUTPUT_MUST_BE_NEW_FILE','INVALID_ACTUAL_CLOCK','FINAL_ADJUDICATION_NOT_OPEN','FINAL_SNAPSHOT_SHA256_MISMATCH','FINAL_SNAPSHOT_RETRIEVAL_DATE','UNRECOGNIZED_ISSUE_STATUS','MISSING_DAY_FINALIZATION_FAILED','INVALID_OPERATIONAL_SCORE_RESULT','INVALID_COMMAND'}

def main(argv=None):
    try:
        receipt=run_cli(argv);print(json.dumps(receipt,sort_keys=True,allow_nan=False));return 0
    except SystemExit as error:
        if error.code in [None,0]:return 0
        print(json.dumps(dict(status='failed',fixed_error_code='INVALID_ARGUMENTS',error_type='SystemExit')));return 1
    except BaseException as error:
        code=error.code if isinstance(error,SafeCLIError) and error.code in SAFE_ERROR_CODES else 'PROSPECTIVE_CLI_FAILURE';name=type(error).__name__
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}',name):name='Exception'
        print(json.dumps(dict(status='failed',fixed_error_code=code,error_type=name),sort_keys=True));return 1

def run_mock_controls(private_receipt_path):
    """Source-only test entry for a root lease; temporary fixtures, no real API."""
    import contextlib,io,tempfile
    checks=[];sentinel='PRIVATE_FIXTURE_XML_AND_EVENT_SECRET'
    def check(name,value):
        if not value:raise AssertionError(name)
        checks.append(name)
    original_api=_operative_api;original_clock=_actual_now
    allowed={'status','path','sha256','day','archive_completed_utc','receipt_recorded_utc','chain_sha256','fixed_error_code','error_type'}
    with tempfile.TemporaryDirectory(prefix='prospective-cli-mock-only-') as td:
        root=Path(td);archive=root/'operations';regpath=root/'fixture_registration.json';regpath.write_text('{}');capture=root/'capture_receipt.json';capture.write_text('{}');target=root/'final_targets.json';output=archive/'scores'/'private_day.json';calls=[]
        reg=dict(archive_root=str(archive.resolve()),end_utc='2030-01-01T00:00:00Z',artifact_pins={str(Path(__file__).resolve()):_sha(__file__)})
        class MockAPI:
            fail=False
            def verify_registration(self,path):
                if self.fail:raise RuntimeError(sentinel)
                return reg,dict(private_parameters=sentinel)
            def capture_source(self,path,start,store):
                print(sentinel);print(sentinel,file=sys.stderr);calls.append(('capture',start));return dict(path=str(capture),sha256=_sha(capture),raw_events=[sentinel])
            def issue_day(self,path,receipt,store):
                calls.append(('issue',receipt));return dict(status='issued',day='2029-01-02',packet=dict(path=str(root/'mock_candidate.json'),sha256='1'*64),archive_completed_utc='2029-01-01T23:05:00Z',receipt_recorded_utc='2029-01-01T23:05:01Z',chain_sha256='2'*64,parameters=sentinel)
            def finalize_missing_days(self,path,store):return dict(status='complete',missing_days_recorded=3,event_rows=[sentinel])
            def evaluate_issued_day(self,path,store,day,model,source,digest):
                calls.append(('score',day));return dict(kind='operational',status='issued_score',day=day,model=model,target_catalogue_sha256=digest,evaluation=dict(joint_logscore=12.3,gradient=[.1,.2,.3],event_logs=[sentinel]))
        mock=MockAPI();globals()['_operative_api']=lambda:mock;globals()['_actual_now']=lambda:datetime(2030,5,1,tzinfo=timezone.utc)
        def invoke(argv):
            buf=io.StringIO()
            with contextlib.redirect_stdout(buf),contextlib.redirect_stderr(buf):code=main(argv)
            text=buf.getvalue();value=json.loads(text);check('stdout_allowlist_'+str(len(checks)),set(value).issubset(allowed) and sentinel not in text);return code,value
        common=['--registration',str(regpath)]
        score=['score-day',*common,'--day','2029-01-02','--model','fixedML_smooth_cont','--final-snapshot',str(target),'--private-output',str(output)]
        try:
            code,result=invoke(['verify',*common]);check('verify_safe_receipt',code==0 and result['status']=='verified')
            code,result=invoke(['capture',*common,'--day','2029-01-02']);check('canonical_day_passed_as_UTC_midnight',code==0 and calls[-1]==('capture','2029-01-02T00:00:00Z'))
            code,result=invoke(['capture',*common,'--day','2029-1-2']);check('noncanonical_day_rejected',code==1 and result['fixed_error_code']=='INVALID_UTC_DAY')
            code,result=invoke(['capture',*common,'--day','2029-01-02','--now',sentinel]);check('caller_clock_and_argument_leak_rejected',code==1 and result['fixed_error_code']=='INVALID_ARGUMENTS')
            code,result=invoke(['issue',*common,'--capture-receipt',str(capture)]);check('issue_hashes_actual_receipt_file',code==0 and calls[-1][1]==dict(path=str(capture.resolve()),sha256=_sha(capture)))
            code,result=invoke(['missing',*common]);check('missing_counts_and_rows_not_printed',code==0 and result==dict(status='missing_days_finalized'))
            globals()['_actual_now']=lambda:datetime(2030,3,31,tzinfo=timezone.utc)
            code,result=invoke(score+['--final-snapshot-sha256','0'*64]);check('interim_score_blocked_before_snapshot_read_or_API',code==1 and result['fixed_error_code']=='FINAL_ADJUDICATION_NOT_OPEN' and not any(c[0]=='score' for c in calls))
            globals()['_actual_now']=lambda:datetime(2030,5,1,tzinfo=timezone.utc)
            for retrieved,label in [('2030-03-31T00:00:00Z','old'),('2030-06-01T00:00:00Z','future')]:
                target.write_text(json.dumps(dict(provenance=dict(retrieved_utc=retrieved),events=[])));code,result=invoke(score+['--final-snapshot-sha256',_sha(target)]);check(label+'_final_snapshot_retrieval_rejected',code==1 and result['fixed_error_code']=='FINAL_SNAPSHOT_RETRIEVAL_DATE')
            target.write_text(json.dumps(dict(provenance=dict(retrieved_utc='2030-04-02T00:00:00Z'),events=[])))
            code,result=invoke(score+['--final-snapshot-sha256','0'*64]);check('final_snapshot_hash_required_exact',code==1 and result['fixed_error_code']=='FINAL_SNAPSHOT_SHA256_MISMATCH')
            code,result=invoke(score+['--final-snapshot-sha256',_sha(target)]);saved=json.loads(output.read_text());check('full_numeric_result_private_only',code==0 and result['status']=='private_score_saved' and saved['result']['evaluation']['event_logs']==[sentinel])
            code,result=invoke(score+['--final-snapshot-sha256',_sha(target)]);check('private_output_never_overwritten',code==1 and result['fixed_error_code']=='PRIVATE_SCORE_OUTPUT_MUST_BE_NEW_FILE')
            code,result=invoke(['score-day',*common,'--day','2029-01-02','--model','fixedML_smooth_cont','--final-snapshot',str(target),'--final-snapshot-sha256',_sha(target)]);check('explicit_private_output_required',code==1 and result['fixed_error_code']=='INVALID_ARGUMENTS')
            mock.fail=True;code,result=invoke(['verify',*common]);check('raw_exception_message_suppressed',code==1 and result['fixed_error_code']=='PROSPECTIVE_CLI_FAILURE' and result['error_type']=='RuntimeError')
        finally:globals()['_operative_api']=original_api;globals()['_actual_now']=original_clock
    receipt=Path(private_receipt_path)
    with receipt.open('x',encoding='utf-8') as f:json.dump(dict(schema_version=1,kind='source_only_mock_cli_controls',status='passed',checks=checks,check_count=len(checks),real_network_requests=0,real_operational_calls=0,real_scores=0,source_sha256=_sha(__file__)),f,indent=2)

if __name__=='__main__':raise SystemExit(main())
