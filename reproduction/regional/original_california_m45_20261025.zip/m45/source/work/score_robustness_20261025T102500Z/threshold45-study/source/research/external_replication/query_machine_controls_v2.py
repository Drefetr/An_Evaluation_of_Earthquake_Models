"""Handcrafted fixed-parent query witnesses with auditable boundary controls."""
from pathlib import Path
import argparse,json,hashlib,math
import numpy as np
from . import geometry as G
from .typed_query_adapter_v2 import FixedObjectiveV2
from .workflow import verify,source_pins
from .fitting import clean


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);ap.add_argument('--output',required=True);ap.add_argument('--expected-source-sha256',required=True);ap.add_argument('--expected-adapter-sha256',required=True);args=ap.parse_args()
 source_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();adapter=Path(__file__).with_name('typed_query_adapter_v2.py');adapter_sha=hashlib.sha256(adapter.read_bytes()).hexdigest()
 # Check both source identities before protocol verification can lead to objective construction.
 if source_sha!=args.expected_source_sha256:raise ValueError('QUERY_PRODUCER_SOURCE_CHANGED')
 if adapter_sha!=args.expected_adapter_sha256:raise ValueError('QUERY_ADAPTER_SOURCE_CHANGED')
 protocol=json.loads(Path(args.protocol).read_text());verify(protocol,'controls');out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 lat_edges=np.array([-48.5,-43.5,-38.5,-33.5]);lon_edges=np.array([165.,170.,175.,180.]);centers=np.array([[(lat_edges[i]+lat_edges[i+1])/2,(lon_edges[j]+lon_edges[j+1])/2] for i in range(3) for j in range(3)])
 # The final raw row lies exactly on the first window's excluded end boundary.
 ll=np.vstack([np.tile(centers,(12,1)),centers[[0,4,8,3]]+.01,centers[[4]]+.02]);t=np.r_[np.arange(108,dtype=float),[120.,120.25,120.25,120.999999999,121.]];q=np.r_[np.tile(-np.log1p(-np.linspace(.005,.995,18))/2.85,6),[.1,.4,.8,.2,.35]]
 lat=ll[:,0];lon=ll[:,1];cells=G.cell_ids(lat,lon,'new_zealand');tr=(t>=18)&(t<120);pi,_,_=G.cell_proportions(cells,tr);beta,_=G.fit_conditional_beta(q[tr]);xy=G.project(lat[tr],lon[tr],'new_zealand');h=float(G.select_bandwidth(xy,pi,G.SCALES,training_cells=cells[tr],profile='new_zealand')['selected_bandwidth']);records=[];checks=[];fdmax=0.;calls=0;timing={}
 models=[('E_fixed',[-2.,.1,.25]),('E_free',[-2.,.1,.25,math.log(.6)]),('E_omori',[-2.,.1,.25,math.log(.25),1.45])]
 window_witness=dict(start=120.,end=121.,raw_event_time=121.,expected_in_window=False,producer_event_times_exclude_end=True)
 if int(np.count_nonzero(t==121.))!=1:raise ValueError('WINDOW_END_WITNESS_MISSING')
 for family in ['cont','lift']:
  for start,end in [(120.,121.),(130.,131.)]:
   full,_=G.make_geometry(t,q,cells,lat,lon,beta,start,end,pi,family='continuous' if family=='cont' else 'center',sigma=50.,order=16,T0=140.,background='kde',kde_bandwidth=h,background_training_xy=xy,background_training_cells=cells[tr],profile='new_zealand')
   keep=full['parent_time']<start;arrays={k:full[k].copy() for k in ['event_time','event_excess','event_cell','event_x','event_background_density','background_cell_mass','mixture_weights','mixture_rates']}
   for k in ['parent_time','parent_excess','parent_fertility','parent_cell_mass']:arrays[k]=full[k][keep].copy()
   arrays['parent_exposure_lo']=start-arrays['parent_time'];arrays['parent_exposure_hi']=end-arrays['parent_time'];arrays['event_parent_density']=full['event_parent_density'][:,keep].copy()
   metadata=dict(start=start,end=end,T0=140.,beta=beta,profile='new_zealand',history_policy='fixed_preissue')
   with FixedObjectiveV2(arrays,metadata) as obj:
    for model,pars in models:
     v=obj.evaluate(model,pars);calls+=1;timing[family,start,model]=v['timing_logscore']
     row=dict(start=start,end=end,train_start=18.,train_end=120.,T0=140.,beta=beta,beta_policy='training_conditional',sigma=50.,bandwidth=h,spatial=family,model=model,pars=pars,history_policy='fixed_preissue',production=clean(v))
     if start==120.:row['window_excluded_witness']=window_witness
     records.append(row)
     for j in range(len(pars)):
      step=1e-5*(1+abs(pars[j]));plus=list(pars);minus=list(pars);plus[j]+=step;minus[j]-=step;fd=(obj.evaluate(model,plus)['joint_nll']-obj.evaluate(model,minus)['joint_nll'])/(2*step);calls+=2;fdmax=max(fdmax,abs(fd-v['gradient'][j])/(1+abs(v['gradient'][j])))
     if start==130.:
      checks.append(dict(name=f'emptyday_{family}_{model}',passed=len(v['event_log_point_intensity'])==0 and abs(v['joint_logscore']+v['integrated_intensity'])<1e-12 and v['conditional_location_logscore']==0 and v['mark_logscore']==0))
    # Preserve numeric n=0 evaluations in the independent audit bundle.
    for model,basepars in models[1:]:
     n0pars=list(basepars);n0pars[2]=0.;v=obj.evaluate(model,n0pars);calls+=1
     records.append(dict(start=start,end=end,train_start=18.,train_end=120.,T0=140.,beta=beta,beta_policy='training_conditional',sigma=50.,bandwidth=h,spatial=family,model=model,pars=n0pars,history_policy='fixed_preissue',control='n_zero',production=clean(v)))
     checks.append(dict(name=f'n0_{family}_{start}_{model}',passed=bool(np.all(v['gradient'][3:]==0))))
    fixed=obj.evaluate('E_fixed',models[0][1]);nestedpars=models[0][1]+[0.];nested=obj.evaluate('E_free',nestedpars);calls+=2
    records.append(dict(start=start,end=end,train_start=18.,train_end=120.,T0=140.,beta=beta,beta_policy='training_conditional',sigma=50.,bandwidth=h,spatial=family,model='E_fixed',pars=models[0][1],history_policy='fixed_preissue',control='tau_one_nesting_fixed',production=clean(fixed)))
    records.append(dict(start=start,end=end,train_start=18.,train_end=120.,T0=140.,beta=beta,beta_policy='training_conditional',sigma=50.,bandwidth=h,spatial=family,model='E_free',pars=nestedpars,history_policy='fixed_preissue',control='tau_one_nesting_free',production=clean(nested)))
    checks.append(dict(name=f'nesting_{family}_{start}',passed=abs(fixed['joint_nll']-nested['joint_nll'])<=1e-10))
    if start==120.:
     checks.append(dict(name=f'window_end_excluded_{family}',passed=not bool(np.any(full['event_time']==121.))))
 for start in [120.,130.]:
  for model,_ in models:checks.append(dict(name=f'normalized_ground_{start}_{model}',passed=abs(timing['cont',start,model]-timing['lift',start,model])<=1e-10))
 checks.append(dict(name='query_analytic_gradient_fd_scaled',passed=fdmax<=5e-5));checks=[dict(c,passed=bool(c['passed'])) for c in checks]
 pins=source_pins();pins[str(Path(__file__).resolve())]=source_sha;pins[str(adapter.resolve())]=adapter_sha
 bundle=dict(schema_version=1,data_classification='handcrafted_fixture',profile='new_zealand',production_source_pins=pins,raw=dict(times=t.tolist(),excess=q.tolist(),latitude=lat.tolist(),longitude=lon.tolist()),window_excluded_witness=window_witness,records=records)
 bundle_path=out/'query_machine_bundle_v2.json'
 with bundle_path.open('x',encoding='utf-8') as f:json.dump(bundle,f,indent=2,allow_nan=False)
 bundle_sha=hashlib.sha256(bundle_path.read_bytes()).hexdigest()
 result=dict(passed=all(c['passed'] for c in checks),records=len(records),checks=checks,evaluation_calls=calls,maximum_scaled_gradient_error=float(fdmax),bundle_path=str(bundle_path.resolve()),bundle_sha256=bundle_sha,scope='Handcrafted New Zealand fixed-parent query fixture; analytic gradients are independently oracle-audited in saved records; finite-difference check is producer-side; no operational data or fits')
 with (out/'query_machine_controls_v2.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print(json.dumps(dict(passed=result['passed'],records=len(records),checks=len(checks),bundle_sha256=bundle_sha)));return 0 if result['passed'] else 1
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as error:print(json.dumps(dict(passed=False,error_type=type(error).__name__,fixed_error_code='QUERY_MACHINE_FAILURE')));raise SystemExit(1)
