"""Isolated resource epoch checks. No scientific module or shared lease is run."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[4]
STUDY = ROOT / "work" / "competitive_benchmarks_20261025T065609Z" / "study"
MEASURE_PATH = STUDY / "source/research/benchmark_control/measure_v2.py"
BUILDER_PATH = STUDY / "source/research/benchmark_control/make_job_v2.py"
SERIAL_PATH = STUDY / "source/research/benchmark_control/run_serial_v2.py"
ACCOUNTING_PATH = ROOT / "research_runs/competitive_benchmarks_20261025T065609Z/methods/pilot_accounting_v3.py"


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


measure = load(MEASURE_PATH, "isolated_measure_v2")
accounting = load(ACCOUNTING_PATH, "isolated_accounting_v3")


class Info:
    peak_wset = 12_000_000
    peak_pagefile = 14_000_000
    rss = 10_000_000


class Parent:
    pid = 4242

    def create_time(self): return 12345.0
    def memory_info(self): return Info()
    def children(self, recursive): return self.members


class Child:
    pid = 5001

    def __init__(self, exe):
        self.executable = exe
        self.changed = False

    def create_time(self): return 12346.0 if not self.changed else 12347.0
    def name(self): return "conhost.exe"
    def exe(self): return str(self.executable)
    def ppid(self): return 4242
    def memory_info(self): return Info()
    def is_running(self): return True


class ResourceEpochTests(unittest.TestCase):
    def test_verified_console_child_and_accounted_peak(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "conhost.exe"
            exe.write_bytes(b"fixture executable, never run")
            parent = Parent()
            child = Child(exe)
            parent.members = [child]
            with patch.object(measure, "allowed_system_conhost", return_value=True), \
                 patch.object(measure, "file_sha", return_value=measure.EXPECTED_CONHOST_SHA256):
                result = measure.measure_process_tree(parent)
            self.assertEqual(result["remaining_child_count"], 1)
            self.assertEqual(result["peak_own_working_set_bytes"], 12_000_000)
            self.assertEqual(result["peak_accounted_working_set_bytes"], 24_000_000)
            self.assertEqual(result["accounted_children"][0]["created"], 12346.0)

    def test_unexpected_child_access_and_identity_change_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "conhost.exe"
            exe.write_bytes(b"fixture executable, never run")
            child = Child(exe)
            parent = Parent()
            with patch.object(measure, "allowed_system_conhost", return_value=False):
                with self.assertRaisesRegex(measure.ResourceScopeError, "UNEXPECTED_RESOURCE_CHILD"):
                    measure.child_metadata(parent, child)
            with patch.object(measure, "allowed_system_conhost", return_value=True), \
                 patch.object(measure, "file_sha", return_value=measure.EXPECTED_CONHOST_SHA256):
                child.create_time = lambda: (_ for _ in ()).throw(measure.psutil.AccessDenied())
                with self.assertRaisesRegex(measure.ResourceScopeError, "RESOURCE_CHILD_ACCESS_DENIED"):
                    measure.child_metadata(parent, child)
                calls = iter((12346.0, 12347.0))
                child.create_time = lambda: next(calls)
                with self.assertRaisesRegex(measure.ResourceScopeError, "RESOURCE_CHILD_IDENTITY_CHANGED"):
                    measure.child_metadata(parent, child)

    def test_accounting_requires_exact_child_sum_and_pin(self):
        system_root = Path(__import__("os").environ["SystemRoot"])
        conhost = (system_root / "System32/conhost.exe").resolve()
        expected = hashlib.sha256(conhost.read_bytes()).hexdigest()
        self.assertEqual(expected, accounting.EXPECTED_CONHOST_SHA256)
        receipt = {"schema_version": 2, "module": "competitive_benchmarks.workflow",
                   "status": "complete", "exit_status": 0, "wall_seconds": 5.0,
                   "measurement_scope": accounting.RESOURCE_SCOPE,
                   "parent_pid": 4242, "parent_created": 12345.0,
                   "peak_process_working_set_bytes": 100_000_000,
                   "peak_own_working_set_bytes": 100_000_000,
                   "peak_accounted_working_set_bytes": 112_000_000,
                   "remaining_child_count": 1, "accounted_child_count": 1,
                   "accounted_children": [{"pid": 5001, "created": 12346.0, "parent_pid": 4242,
                                           "name": "conhost.exe", "exe_path": str(conhost),
                                           "exe_sha256": expected, "peak_working_set_bytes": 12_000_000}],
                   "system_available_before_bytes": 1_000_000_000,
                   "system_available_after_bytes": 900_000_000,
                   "thread_environment": {name: "1" for name in measure.THREAD_KEYS}}
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "resource.json"
            path.write_text(json.dumps(receipt))
            self.assertEqual(accounting.resource_receipt(path, "competitive_benchmarks.workflow")["peak_bytes"], 112_000_000)
            receipt["peak_accounted_working_set_bytes"] -= 1
            path.write_text(json.dumps(receipt))
            with self.assertRaisesRegex(ValueError, "RESOURCE_PEAK_ACCOUNTING_MISMATCH"):
                accounting.resource_receipt(path, "competitive_benchmarks.workflow")
            receipt["peak_accounted_working_set_bytes"] += 1
            receipt["accounted_children"][0]["name"] = "python.exe"
            path.write_text(json.dumps(receipt))
            with self.assertRaisesRegex(ValueError, "RESOURCE_CHILD_IDENTITY"):
                accounting.resource_receipt(path, "competitive_benchmarks.workflow")

    def test_new_builder_help_and_isolated_serial_help_job(self):
        completed = subprocess.run([sys.executable, str(BUILDER_PATH), "--help"],
                                   capture_output=True, text=True, timeout=10)
        self.assertEqual(completed.returncode, 0)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            executable = Path(sys.executable).resolve()
            pins = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                    for path in (executable, MEASURE_PATH)}
            job = {"job_id": "isolated_resource_help", "argv": [str(executable), "-B", str(MEASURE_PATH), "--help"],
                   "cwd": str(STUDY), "conservative_max_seconds": 5, "pins": pins,
                   "expected_machine": str(root / "machine.sqlite")}
            job_path = root / "job.json"
            job_path.write_text(json.dumps(job))
            result = subprocess.run([sys.executable, str(SERIAL_PATH), "--job", str(job_path),
                                     "--machine", str(root / "machine.sqlite"),
                                     "--output", str(root / "output")],
                                    capture_output=True, text=True, timeout=15)
            summary = json.loads(result.stdout)
            self.assertEqual((result.returncode, summary["status"]), (0, "terminal"))
            self.assertTrue(json.loads((root / "output/receipt.json").read_text())["containment_proved_empty"])
            self.assertFalse((root / "output/resource.json").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
