"""Summarize private local cost-pilot artifacts with accounted Windows peaks.

This reads only allowlisted timing/status fields from local JSON. Its stdout and
optional output contain no fitted parameters, objective values, scores, rows,
or event arrays. It performs no model evaluation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys

FOLDS = ("california_fold_0", "california_fold_2")
ARMS = ("N0", "EP")
MAX_PILOT_SECONDS = 1200.0
ENVELOPE_SECONDS = 14400.0
MIN_AUDIT_RESERVE_SECONDS = 3600.0
FULL_STARTS_PER_ARM = 24
FLOORS = {"N0": 3, "EP": 6}
MAX_SCORE_EVALUATIONS = 153  # 57 candidates + at most 96 solver returns.
MIN_AUDIT_EVALUATIONS = 2 * MAX_SCORE_EVALUATIONS + 3  # train/test, plus three archived O-C.
EXPECTED_CONHOST_SHA256 = "b02ee54fb2ec69673386d41119ee8ed083a6eab3bfca6aa2155d20ce68ef8963"
RESOURCE_SCOPE = ("Windows kernel individual peak working sets: parent plus live verified direct "
                  "system conhost.exe children at final snapshot; sum of individual peaks, "
                  "not simultaneous aggregate; terminated descendants not measured; "
                  "serial Job Object terminal proof required separately")


def read_object(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("JSON_OBJECT_REQUIRED")
    return value


def number(value, name: str, *, zero: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{name}_FINITE_NUMBER_REQUIRED")
    if (value < 0) if zero else (value <= 0):
        raise ValueError(f"{name}_POSITIVE_REQUIRED")
    return float(value)


def receipt_seconds(path: Path) -> float:
    value = read_object(path)
    if value.get("status") != "terminal" or value.get("exit_code") != 0 or value.get("containment_proved_empty") is not True or value.get("timed_out") is True:
        raise ValueError("PROCESS_RECEIPT_NOT_TERMINAL_ZERO")
    return number(value.get("wall_seconds"), "WALL_SECONDS")


def resource_receipt(path: Path, expected_module: str) -> dict:
    value = read_object(path)
    if (value.get("schema_version") != 2 or value.get("module") != expected_module or
            value.get("status") != "complete" or value.get("exit_status") != 0):
        raise ValueError("RESOURCE_RECEIPT_INCOMPLETE")
    children = value.get("accounted_children")
    if (value.get("measurement_scope") != RESOURCE_SCOPE or not isinstance(children, list) or
            type(value.get("remaining_child_count")) is not int or
            type(value.get("accounted_child_count")) is not int or
            value["remaining_child_count"] != len(children) or
            value.get("accounted_child_count") != len(children)):
        raise ValueError("RESOURCE_MEASUREMENT_SCOPE")
    if (type(value.get("peak_process_working_set_bytes")) is not int or
            type(value.get("peak_own_working_set_bytes")) is not int or
            type(value.get("peak_accounted_working_set_bytes")) is not int):
        raise ValueError("RESOURCE_PEAK_INTEGER_BYTES_REQUIRED")
    own_peak = number(value.get("peak_process_working_set_bytes"), "OWN_PEAK_MEMORY_BYTES")
    if number(value.get("peak_own_working_set_bytes"), "OWN_PEAK_MEMORY_BYTES") != own_peak:
        raise ValueError("RESOURCE_OWN_PEAK_MISMATCH")
    parent_pid = value.get("parent_pid")
    parent_created = value.get("parent_created")
    if (type(parent_pid) is not int or parent_pid <= 0 or isinstance(parent_created, bool) or
            not isinstance(parent_created, (int, float)) or not math.isfinite(parent_created) or parent_created <= 0):
        raise ValueError("RESOURCE_PARENT_IDENTITY")
    system_root = Path(os.environ.get("SystemRoot", os.environ.get("WINDIR", "")))
    if not system_root.is_absolute():
        raise ValueError("RESOURCE_SYSTEM_ROOT")
    expected_conhost = (system_root / "System32" / "conhost.exe").resolve(strict=True)
    if hashlib.sha256(expected_conhost.read_bytes()).hexdigest() != EXPECTED_CONHOST_SHA256:
        raise ValueError("RESOURCE_CONHOST_PIN_DRIFT")
    seen = set()
    child_peaks = []
    for child in children:
        if not isinstance(child, dict):
            raise ValueError("RESOURCE_CHILD_SCHEMA")
        pid, created = child.get("pid"), child.get("created")
        if (type(pid) is not int or pid <= 0 or pid in seen or
                isinstance(created, bool) or not isinstance(created, (int, float)) or not math.isfinite(created) or created <= 0 or
                child.get("parent_pid") != parent_pid or
                str(child.get("name", "")).lower() != "conhost.exe" or
                Path(str(child.get("exe_path", ""))).resolve(strict=False) != expected_conhost or
                child.get("exe_sha256") != EXPECTED_CONHOST_SHA256):
            raise ValueError("RESOURCE_CHILD_IDENTITY")
        seen.add(pid)
        if type(child.get("peak_working_set_bytes")) is not int:
            raise ValueError("RESOURCE_CHILD_PEAK_INTEGER_BYTES_REQUIRED")
        child_peaks.append(number(child.get("peak_working_set_bytes"), "CHILD_PEAK_MEMORY_BYTES"))
    accounted = number(value.get("peak_accounted_working_set_bytes"), "ACCOUNTED_PEAK_MEMORY_BYTES")
    if accounted != own_peak + sum(child_peaks):
        raise ValueError("RESOURCE_PEAK_ACCOUNTING_MISMATCH")
    if value.get("thread_environment") != {name: "1" for name in
                                           ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")}:
        raise ValueError("RESOURCE_THREAD_POLICY")
    return {"wall_seconds": number(value.get("wall_seconds"), "RESOURCE_WALL"),
            "peak_bytes": accounted,
            "available_bytes": min(number(value.get("system_available_before_bytes"), "AVAILABLE_MEMORY_BYTES"),
                                   number(value.get("system_available_after_bytes"), "AVAILABLE_MEMORY_BYTES"))}


def pilot_rows(directory: Path) -> dict:
    records = {arm: {"evaluation": [], "pilot_start": []} for arm in ARMS}
    issues: list[str] = []
    case_counts = {}
    for case_id in FOLDS:
        path = directory / case_id / "pilot.json"
        row = read_object(path)
        if row.get("case_id") != case_id or row.get("phase") != "pilot" or not isinstance(row.get("records"), list):
            raise ValueError("PILOT_CASE_SCHEMA")
        case_counts[case_id] = {"evaluation": 0, "pilot_start": 0}
        for entry in row["records"]:
            arm = entry.get("arm")
            kind = entry.get("kind")
            if arm not in ARMS or kind not in ("evaluation", "pilot_start"):
                raise ValueError("PILOT_ENTRY_SCHEMA")
            case_counts[case_id][kind] += 1
            if entry.get("status") != "complete":
                issues.append(f"{case_id}_{arm}_{kind}_INCOMPLETE")
                continue
            wall = number(entry.get("wall_seconds"), "PILOT_ENTRY_WALL")
            if kind == "evaluation":
                if entry.get("finite") is not True:
                    issues.append(f"{case_id}_{arm}_NONFINITE")
                delta = number(entry.get("refinement_delta_nll"), "REFINEMENT_DELTA", zero=True)
                if delta > 1e-4:
                    issues.append(f"{case_id}_{arm}_REFINEMENT_EXCEEDED")
            elif entry.get("success") is not True:
                issues.append(f"{case_id}_{arm}_PILOT_START_FAILED")
            records[arm][kind].append(wall)
        if case_counts[case_id] != {"evaluation": 4, "pilot_start": 2}:
            issues.append(f"{case_id}_PILOT_COUNT")
    for arm in ARMS:
        if len(records[arm]["pilot_start"]) != 2:
            issues.append(f"{arm}_START_COST_MISSING")
        if len(records[arm]["evaluation"]) != (2 if arm == "N0" else 6):
            issues.append(f"{arm}_EVALUATION_COST_MISSING")
    return {"times": records, "case_counts": case_counts, "issues": sorted(set(issues))}


def audit_rows(path: Path) -> dict:
    value = read_object(path)
    records = value.get("records")
    if not isinstance(records, list) or len(records) != 2 or [x.get("case_id") for x in records] != list(FOLDS):
        raise ValueError("AUDIT_PILOT_ROSTER")
    issues = []
    times = {"N0": [], "EP": [], "nuisance": []}
    for row in records:
        if row.get("status") != "complete":
            issues.append(f"{row.get('case_id')}_AUDIT_PILOT_INCOMPLETE")
            continue
        times["N0"].append(number(row.get("n0_seconds"), "AUDIT_N0"))
        times["EP"].append(number(row.get("etas_seconds"), "AUDIT_EP"))
        times["nuisance"].append(number(row.get("nuisance_seconds"), "AUDIT_NUISANCE"))
    if value.get("status") != "complete" or any(len(times[k]) != 2 for k in times):
        issues.append("AUDIT_PILOT_NOT_COMPLETE")
    return {"times": times, "source_seconds": number(value.get("source_verification_seconds"), "SOURCE_VERIFICATION"),
            "issues": sorted(set(issues))}


def boundary_audit_rows(path: Path) -> dict:
    """Separate measured oracle costs at registered interior and two extremes."""
    row = read_object(path)
    records = row.get("records")
    expected = {(fold, vector) for fold in FOLDS
                for vector in ("interior", "short_near", "wide_upper")}
    if row.get("status") != "complete" or not isinstance(records, list) or len(records) != 6:
        raise ValueError("BOUNDARY_AUDIT_COST_INCOMPLETE")
    seen = set()
    walls = []
    for entry in records:
        key = (entry.get("case_id"), entry.get("vector_id"))
        if key not in expected or key in seen or entry.get("status") != "complete" or entry.get("finite") is not True:
            raise ValueError("BOUNDARY_AUDIT_COST_SCHEMA")
        seen.add(key)
        walls.append(number(entry.get("wall_seconds"), "BOUNDARY_AUDIT_WALL"))
    if seen != expected:
        raise ValueError("BOUNDARY_AUDIT_COST_ROSTER")
    return {"max_seconds": max(walls), "count": len(walls)}


def summarize(args) -> dict:
    prepare_wall = receipt_seconds(Path(args.prepare_receipt))
    pilot_wall = receipt_seconds(Path(args.pilot_receipt))
    audit_pilot_wall = receipt_seconds(Path(args.audit_pilot_receipt))
    prepare_resource = resource_receipt(Path(args.prepare_resource), "competitive_benchmarks.workflow")
    pilot_resource = resource_receipt(Path(args.pilot_resource), "competitive_benchmarks.workflow")
    audit_resource = resource_receipt(Path(args.audit_pilot_resource), "research.competitive_benchmarks_validation.audit_cost_pilot_v2")
    for outer, inner in ((prepare_wall, prepare_resource["wall_seconds"]),
                         (pilot_wall, pilot_resource["wall_seconds"]),
                         (audit_pilot_wall, audit_resource["wall_seconds"])):
        if inner > outer + 1:
            raise ValueError("RESOURCE_WALL_EXCEEDS_PROCESS_WALL")
    control_wall = sum(receipt_seconds(Path(p)) for p in args.control_receipt)
    pilot = pilot_rows(Path(args.pilot_directory))
    audit = audit_rows(Path(args.audit_pilot))
    boundary_audit = boundary_audit_rows(Path(args.boundary_audit_cost))
    issues = pilot["issues"] + audit["issues"]
    total_pilot_wall = pilot_wall + audit_pilot_wall
    if total_pilot_wall > MAX_PILOT_SECONDS:
        issues.append("PILOT_1200_SECOND_CAP_EXCEEDED")
    peak_memory = max(x["peak_bytes"] for x in (prepare_resource, pilot_resource, audit_resource))
    available_memory = min(x["available_bytes"] for x in (prepare_resource, pilot_resource, audit_resource))
    if available_memory < 1.3 * peak_memory:
        issues.append("MEMORY_HEADROOM_LT_30_PERCENT")
    audit_evaluations = int(args.audit_evaluations)
    if audit_evaluations < MIN_AUDIT_EVALUATIONS:
        raise ValueError("AUDIT_EVALUATIONS_BELOW_FULL_CANDIDATE_AND_RETURN_COUNT")

    # A missing cost cannot be converted to zero; preserve incomplete status.
    if any(not pilot["times"][a][k] for a in ARMS for k in ("evaluation", "pilot_start")) or any(not audit["times"][a] for a in ARMS):
        issues.append("COST_MEASUREMENT_MISSING")
        return {"status": "not_admitted", "reason_codes": sorted(set(issues)),
                "pilot_wall_seconds": total_pilot_wall, "control_wall_seconds": control_wall,
                "prepare_wall_seconds": prepare_wall, "peak_memory_bytes": int(peak_memory),
                "available_memory_bytes": int(available_memory)}

    start = {a: max(pilot["times"][a]["pilot_start"]) for a in ARMS}
    evaluation = {a: max(pilot["times"][a]["evaluation"]) for a in ARMS}
    audit_eval = max(boundary_audit["max_seconds"], *(max(audit["times"][a]) for a in ARMS))
    audit_nuisance = max(audit["times"]["nuisance"])
    projected = {
        "prior_controls": control_wall,
        "three_fold_prepare": 1.25 * prepare_wall,
        "producer_pilot": pilot_wall,
        "independent_cost_pilot": audit_pilot_wall,
        "N0_24_full_starts": 1.25 * FULL_STARTS_PER_ARM * start["N0"],
        "EP_24_full_starts": 1.5 * FULL_STARTS_PER_ARM * start["EP"],
        "N0_3_floors": 1.25 * FLOORS["N0"] * evaluation["N0"],
        "EP_6_floors": 1.5 * FLOORS["EP"] * evaluation["EP"],
        "all_candidate_and_return_scoring": 1.5 * MAX_SCORE_EVALUATIONS * max(evaluation.values()),
        "independent_audit_reserve": max(MIN_AUDIT_RESERVE_SECONDS,
                                         1.5 * (audit_evaluations * audit_eval +
                                                3 * audit_nuisance + audit["source_seconds"])),
    }
    total = sum(projected.values())
    if total > ENVELOPE_SECONDS:
        issues.append("PROJECTED_WALL_EXCEEDS_ENVELOPE")
    return {
        "status": "admitted" if not issues else "not_admitted",
        "reason_codes": sorted(set(issues)),
        "denominator": {"procedures": 6, "starts": 48, "floors": 9,
                        "full_starts_per_arm": FULL_STARTS_PER_ARM,
                        "max_candidate_and_return_scoring_evaluations": MAX_SCORE_EVALUATIONS,
                        "minimum_full_independent_audit_evaluations": MIN_AUDIT_EVALUATIONS,
                        "audit_evaluations_planned": audit_evaluations},
        "measured": {"prepare_wall_seconds": prepare_wall, "pilot_wall_seconds": pilot_wall,
                     "independent_cost_pilot_wall_seconds": audit_pilot_wall,
                     "total_pilot_wall_seconds": total_pilot_wall,
                     "prior_controls_wall_seconds": control_wall,
                     "maximum_start_seconds": start, "maximum_objective_evaluation_seconds": evaluation,
                     "maximum_independent_audit_evaluation_seconds": audit_eval,
                     "independent_boundary_cost_cases": boundary_audit["count"],
                     "peak_memory_bytes": int(peak_memory),
                     "available_memory_bytes": int(available_memory)},
        "projected_seconds": projected,
        "projected_total_seconds": total,
        "envelope_seconds": ENVELOPE_SECONDS,
        "minimum_audit_reserve_seconds": MIN_AUDIT_RESERVE_SECONDS,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("prepare-receipt", "prepare-resource", "pilot-receipt", "pilot-resource", "pilot-directory", "audit-pilot", "audit-pilot-resource", "boundary-audit-cost",
                 "audit-pilot-receipt",
                 "audit-evaluations", "output"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--control-receipt", action="append", default=[])
    args = parser.parse_args()
    if len(args.control_receipt) != 3:
        parser.error("exactly three --control-receipt values required")
    try:
        result = summarize(args)
        target = Path(args.output)
        if not target.is_absolute():
            raise ValueError("ABSOLUTE_OUTPUT_REQUIRED")
        with target.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False)
        print(json.dumps(result, sort_keys=True, allow_nan=False))
        return 0 if result["status"] == "admitted" else 2
    except Exception as error:
        print(json.dumps({"status": "not_admitted", "error_type": type(error).__name__}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
