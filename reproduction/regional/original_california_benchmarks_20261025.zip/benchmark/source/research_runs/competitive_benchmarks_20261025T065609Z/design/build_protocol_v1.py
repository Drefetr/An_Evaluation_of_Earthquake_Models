"""Build the reviewed benchmark protocol by exclusive create; never run science.

Only absolute paths, hashes, aggregate control statuses, and runtime identities
enter the output. The caller must supply final review/control evidence. This
program does not freeze until that evidence is present and matching.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import sys

ROLES = ("producer", "independent", "cross")
CODE_PACKAGES = (
    "competitive_benchmarks", "competitive_benchmarks_validation",
    "external_replication", "external_replication_validation",
    "benchmark_control",
)
CODE_SUFFIXES = frozenset((".py", ".cpp", ".dll", ".cmd", ".json"))
REVIEW_ROLES = (
    "methods", "component", "normalizer", "serial", "control_release",
)
REQUIRED_DESIGN = (
    "design/methods_protocol_v1.md", "design/component_contracts.json",
    "methods/pilot_protocol_v1.md", "methods/etas_normalizer_derivatives_v1.md",
    "design/source_authorities_v1.json", "control_runtime/serial_launcher_v2_contract.md",
)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def absolute_file(value: str) -> Path:
    path = Path(value)
    if not path.is_absolute() or not path.is_file():
        raise ValueError("ABSOLUTE_EXISTING_FILE_REQUIRED")
    return path.resolve(strict=True)


def absolute_dir(value: str) -> Path:
    path = Path(value)
    if not path.is_absolute() or not path.is_dir():
        raise ValueError("ABSOLUTE_EXISTING_DIRECTORY_REQUIRED")
    return path.resolve(strict=True)


def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("JSON_OBJECT_REQUIRED")
    return value


def role_paths(values: list[str], required: tuple[str, ...]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for value in values:
        if "=" not in value:
            raise ValueError("ROLE_PATH_SYNTAX")
        role, name = value.split("=", 1)
        if not role or role in found or role not in required:
            raise ValueError("ROLE_PATH_ROSTER")
        found[role] = absolute_file(name)
    if set(found) != set(required):
        raise ValueError("ROLE_PATH_INCOMPLETE")
    return found


def pin(pins: dict[str, str], path: Path, expected: str | None = None) -> str:
    path = absolute_file(str(path))
    actual = digest(path)
    if expected is not None and actual != expected.lower():
        raise ValueError("PIN_MISMATCH")
    name = str(path)
    if name in pins and pins[name] != actual:
        raise ValueError("PIN_CONFLICT")
    pins[name] = actual
    return actual


def check_process(result: dict, receipt: dict, job_path: Path, role: str) -> None:
    if receipt.get("status") != "terminal" or receipt.get("exit_code") != 0:
        raise ValueError(f"{role.upper()}_PROCESS_NOT_TERMINAL_ZERO")
    if receipt.get("containment_proved_empty") is not True or receipt.get("timed_out") is True:
        raise ValueError(f"{role.upper()}_PROCESS_CONTAINMENT")
    if receipt.get("job_sha256") != digest(job_path):
        raise ValueError(f"{role.upper()}_JOB_RECEIPT_MISMATCH")
    job = read_json(job_path)
    if receipt.get("job_id") != job.get("job_id"):
        raise ValueError(f"{role.upper()}_JOB_ID_MISMATCH")
    job_pins = job.get("pins")
    if not isinstance(job_pins, dict) or not job_pins:
        raise ValueError(f"{role.upper()}_JOB_PINS_MISSING")
    for name, expected in job_pins.items():
        if digest(absolute_file(name)) != expected:
            raise ValueError(f"{role.upper()}_JOB_PIN_DRIFT")
    if role == "producer":
        checks = result.get("checks")
        if result.get("status") != "complete" or not isinstance(checks, dict) or not checks or not all(v is True for v in checks.values()):
            raise ValueError("PRODUCER_CONTROLS_FAILED")
    elif role != "build":
        if result.get("passed") is not True or result.get("status", "passed") not in ("passed", "complete"):
            raise ValueError(f"{role.upper()}_CONTROLS_FAILED")


def build(args: argparse.Namespace) -> dict:
    run = absolute_dir(args.run)
    study = absolute_dir(args.study)
    source_path = absolute_file(args.source_protocol)
    authorities_path = absolute_file(args.source_authorities)
    sealed = absolute_dir(args.sealed_results)
    build_job = absolute_file(args.build_job)
    build_process = absolute_file(args.build_process)
    acceptance_path = absolute_file(args.acceptance)
    review = role_paths(args.review, REVIEW_ROLES)
    controls = role_paths(args.control_result, ROLES)
    process = role_paths(args.control_process, ROLES)
    jobs = role_paths(args.control_job, ROLES)
    if args.output is None or not Path(args.output).is_absolute():
        raise ValueError("ABSOLUTE_OUTPUT_REQUIRED")
    output = Path(args.output).resolve()
    if output.exists() or output.parent != run / "design":
        raise ValueError("NEW_OUTPUT_IN_RUN_DESIGN_REQUIRED")
    if source_path != absolute_file(str(Path(read_json(authorities_path)["old_protocol"]))):
        raise ValueError("SOURCE_AUTHORITY_PATH")

    source = read_json(source_path)
    authorities = read_json(authorities_path)
    if digest(source_path) != authorities.get("old_protocol_sha256") or source.get("data") != authorities.get("canonical_input"):
        raise ValueError("SOURCE_AUTHORITY_IDENTITY")
    if [x.get("id") for x in source.get("cases", [])] != [f"california_fold_{i}" for i in range(3)]:
        raise ValueError("FOLD_ROSTER")
    if authorities.get("expected_counts", {}).get("test") != [79, 167, 69]:
        raise ValueError("TARGET_ROSTER")
    if len(authorities.get("sealed_OC_cases", [])) != 3:
        raise ValueError("SEALED_CASE_ROSTER")

    pins: dict[str, str] = {}
    pin(pins, source_path, authorities["old_protocol_sha256"])
    pin(pins, authorities_path)
    for item in authorities.get("authority_pins", []):
        pin(pins, absolute_file(item["path"]), item["sha256"])
    for name, expected in authorities.get("inherited_artifact_pins", {}).items():
        pin(pins, absolute_file(name), expected)
    for index, item in enumerate(authorities["sealed_OC_cases"]):
        if item.get("case_id") != f"california_fold_{index}":
            raise ValueError("SEALED_CASE_ORDER")
        old_case = absolute_file(item["private_case_path"])
        if old_case != sealed / item["case_id"] / "case.json":
            raise ValueError("SEALED_ROOT_MISMATCH")
        pin(pins, old_case, item["sha256"])
    pin(pins, absolute_file(authorities["canonical_input"]["catalogue"]), authorities["canonical_input"]["sha256"])

    for relative in REQUIRED_DESIGN:
        pin(pins, absolute_file(str(run / relative)))
    pin(pins, Path(__file__).resolve(strict=True))
    for package in CODE_PACKAGES:
        folder = study / "source" / "research" / package
        if not folder.is_dir():
            raise ValueError("EXECUTED_PACKAGE_MISSING")
        for path in sorted(folder.rglob("*")):
            if path.is_file() and path.suffix.lower() in CODE_SUFFIXES:
                pin(pins, path)
    if not any(Path(name).name == "objective.dll" and "competitive_benchmarks" in name for name in pins):
        raise ValueError("NEW_OBJECTIVE_DLL_MISSING")

    evidence: dict[str, str] = {}
    for role, path in review.items():
        evidence[f"review_{role}"] = pin(pins, path)
    for role in ROLES:
        row = read_json(controls[role])
        receipt = read_json(process[role])
        check_process(row, receipt, jobs[role], role)
        control_job = read_json(jobs[role])
        argv = control_job.get("argv", [])
        if "--output" not in argv or argv.index("--output") + 1 >= len(argv) or Path(argv[argv.index("--output") + 1]).resolve() != controls[role]:
            raise ValueError("CONTROL_RESULT_NOT_JOB_OUTPUT")
        for name, expected in control_job["pins"].items():
            pin(pins, absolute_file(name), expected)
        evidence[f"control_{role}"] = pin(pins, controls[role])
        evidence[f"process_{role}"] = pin(pins, process[role])
        evidence[f"job_{role}"] = pin(pins, jobs[role])
    check_process({}, read_json(build_process), build_job, "build")
    for name, expected in read_json(build_job)["pins"].items():
        pin(pins, absolute_file(name), expected)
    evidence["canonical_build_process"] = pin(pins, build_process)
    evidence["canonical_build_job"] = pin(pins, build_job)

    method_text = review["methods"].read_text(encoding="utf-8")
    for relative in REQUIRED_DESIGN[:4]:
        if pins[str((run / relative).resolve())] not in method_text:
            raise ValueError("METHOD_REVIEW_IDENTITY")
    acceptance = read_json(acceptance_path)
    if acceptance.get("accepted") is not True or acceptance.get("scientific_design_accepted") is not True or acceptance.get("controls_accepted") is not True:
        raise ValueError("ACCEPTANCE_NOT_GRANTED")
    accepted_pins = acceptance.get("evidence_sha256")
    if not isinstance(accepted_pins, dict):
        raise ValueError("ACCEPTANCE_EVIDENCE_SCHEMA")
    for role_map in (review, controls, process, jobs):
        for path in role_map.values():
            if accepted_pins.get(str(path)) != digest(path):
                raise ValueError("ACCEPTANCE_EVIDENCE_MISMATCH")
    for path in (build_job, build_process):
        if accepted_pins.get(str(path)) != digest(path):
            raise ValueError("ACCEPTANCE_EVIDENCE_MISMATCH")
    evidence["acceptance"] = pin(pins, acceptance_path)
    for name in args.extra_pin:
        path = absolute_file(name)
        if accepted_pins.get(str(path)) != digest(path):
            raise ValueError("EXTRA_PIN_NOT_IN_ACCEPTANCE")
        pin(pins, path)

    runtime_modules = ("numpy", "numpy._core._multiarray_umath", "scipy",
                       "scipy.optimize._lbfgsb", "scipy.special._ufuncs",
                       "psutil", "psutil._psutil_windows")
    runtime = {"python_version": sys.version, "platform": platform.platform(),
               "python_executable": str(Path(sys.executable).resolve()),
               "distributions": {key: importlib.metadata.version(key) for key in ("numpy", "scipy", "psutil")}}
    pin(pins, absolute_file(sys.executable))
    runtime["module_files"] = {}
    for name in runtime_modules:
        module_path = absolute_file(importlib.import_module(name).__file__)
        runtime["module_files"][name] = str(module_path)
        pin(pins, module_path)
    python_dll = Path(sys.executable).resolve().with_name(f"python{sys.version_info.major}{sys.version_info.minor}.dll")
    if python_dll.is_file():
        runtime["python_dll"] = str(python_dll)
        pin(pins, python_dll)

    return {
        "schema_version": 1,
        "protocol_id": "california_competitive_benchmarks_v1",
        "status": "frozen",
        "science_gate_passed": True,
        "scope": "Retrospective revised-catalogue O-C versus optimized N0 and adapted inverse-power ETAS; no new holdout or publication claim",
        "source_protocol_sha256": digest(source_path),
        "source_authorities_sha256": digest(authorities_path),
        "sealed_results_path": str(sealed),
        "target_counts": [79, 167, 69],
        "fit_denominator": {"procedures": 6, "starts": 48, "floors": 9},
        "runtime": runtime,
        "evidence_sha256": dict(sorted(evidence.items())),
        "artifact_pins": dict(sorted(pins.items())),
        "postfreeze_gate": "pilot/fit/score require a separate controls gate receipt binding this protocol SHA-256; fit/score also require pilot_admitted true",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("run", "study", "source-protocol", "source-authorities", "sealed-results",
                 "build-job", "build-process", "acceptance", "output"):
        parser.add_argument("--" + name, required=True)
    for name in ("review", "control-result", "control-process", "control-job", "extra-pin"):
        parser.add_argument("--" + name, action="append", default=[])
    args = parser.parse_args()
    try:
        protocol = build(args)
        target = Path(args.output).resolve()
        encoded = (json.dumps(protocol, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
        with target.open("xb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
    except Exception as error:
        print(json.dumps({"status": "not_frozen", "error_type": type(error).__name__}), file=sys.stderr)
        return 1
    print(json.dumps({"status": "frozen", "protocol_path": str(target),
                      "protocol_sha256": hashlib.sha256(encoded).hexdigest(),
                      "artifact_pin_count": len(protocol["artifact_pins"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
