"""Pinned local feature builder for both new benchmark arms."""
import hashlib,json
from pathlib import Path
import numpy as np
from external_replication import geometry as G

FEATURE_NAMES=("parent_time","parent_xy","parent_fertility","parent_exposure_lo","parent_exposure_hi","event_time","event_xy","event_x","event_cell","event_background_density","background_cell_mass","rectangles")
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def _identity(meta):return hashlib.sha256(json.dumps(meta,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def build(cat,case,beta,pi,bandwidth,output,protocol_sha256,*,phase):
    """Create a private NPZ. case has train_start/train_end/test_start/test_end/T0.

    The training KDE and its five percent cell-density floor are frozen for both
    training and test exposures. Targets are exactly the case-window suffix;
    earlier same-time parents are excluded by the compiled likelihood.
    """
    if phase not in ('train','test'):raise ValueError('phase')
    start,end=(case['train_start'],case['train_end']) if phase=='train' else (case['test_start'],case['test_end'])
    t=cat.times;keep=t<end;target=keep&(t>=start);training=(t>=case['train_start'])&(t<case['train_end'])
    if not np.array_equal(np.flatnonzero(target),np.arange(np.count_nonzero(keep)-np.count_nonzero(target),np.count_nonzero(keep))):raise ValueError('target suffix')
    rect,area,_=G.support('california');pi=np.asarray(pi,float)
    if pi.shape!=(9,) or np.any(pi<=0) or abs(pi.sum()-1)>1e-12:raise ValueError('training cell mass')
    parent_xy=G.project(cat.latitude[keep],cat.longitude[keep],'california');event_xy=parent_xy[-int(target.sum()):] if target.any() else np.empty((0,2))
    train_xy=G.project(cat.latitude[training],cat.longitude[training],'california');train_cells=cat.cells[training]
    if not np.array_equal(train_cells,G.point_cells(train_xy,'california')):raise ValueError('training geometry')
    F,Z=G.kde_components(train_xy,bandwidth,profile='california')
    background_mass=.05*pi+.95*np.mean(F/Z[:,None],axis=0)
    ec=cat.cells[target];density=.05*pi[ec]/area[ec]+.95*np.mean(G.kde_density(event_xy,train_xy,bandwidth,Z),axis=1)
    pt=t[keep];q=cat.excess[keep]
    a={"parent_time":pt,"parent_xy":parent_xy,"parent_fertility":.3*np.exp(beta*.7*q),"parent_exposure_lo":np.maximum(start-pt,0.),"parent_exposure_hi":end-pt,
       "event_time":t[target],"event_xy":event_xy,"event_x":2*t[target]/case['T0']-1,"event_cell":ec,"event_background_density":density,
       "background_cell_mass":background_mass,"rectangles":rect}
    a={k:np.ascontiguousarray(v,dtype=np.float64) for k,v in a.items()}
    if any(not np.isfinite(v).all() for v in a.values()) or np.any(density<=0) or abs(background_mass.sum()-1)>1e-12:raise ValueError('nonfinite features')
    meta=dict(version=1,case_id=case['case_id'],phase=phase,start=float(start),end=float(end),T0=float(case['T0']),beta=float(beta),r=.7,marks=float(len(ec)*np.log(beta)-beta*cat.excess[target].sum()),
              catalogue_sha256=cat.source_sha256,protocol_sha256=protocol_sha256,bandwidth_km=float(bandwidth),background_floor=.05,reference_pi=pi.tolist(),n_events=int(target.sum()),n_parents=int(keep.sum()),
              array_sha256={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in a.items()})
    meta['identity_sha256']=_identity(meta);a['metadata_json']=np.asarray(json.dumps(meta,sort_keys=True,allow_nan=False))
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('xb') as f:np.savez_compressed(f,**a)
    return dict(path=str(output.resolve()),sha256=sha(output),metadata_identity=meta['identity_sha256'],n_events=meta['n_events'],n_parents=meta['n_parents'])
