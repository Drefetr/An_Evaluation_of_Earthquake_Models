"""Independent California benchmark procedures; private numerical artifacts stay local."""
