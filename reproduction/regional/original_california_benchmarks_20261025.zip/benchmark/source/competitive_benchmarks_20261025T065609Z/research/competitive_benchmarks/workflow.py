"""Private frozen-protocol driver. Console output contains only fixed status codes."""
import argparse,hashlib,json,math,os,sys,time
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from external_replication import geometry as G
from external_replication.catalogue import load_catalogue,day
from .features import build,sha
from .objective import Objective
from .fitting import fit,clean,OPTIONS_LBFGSB
from .objective import bounds

ARMS=('N0','EP');EXPECTED=(79,167,69)
EP_ROWS=((0,-.2,.2,.0001,1.1,2,1.1),(0,-.2,.6,.001,1.3,5,1.5),(0,.2,.2,.01,1.1,15,2),(0,.2,.6,.1,1.3,50,2.5),(-.5,-.2,.2,1,1.7,150,2),(-.5,-.2,.6,20,2.5,500,1.5),(-.5,.2,.2,.01,2.5,15,3),(-.5,.2,.6,.1,1.01,50,1.05))
N0_D=(-2,-1,-.5,-.2,.2,.5,1,2)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(clean(obj),f,allow_nan=False,indent=2)
def cases(source):
    result=[]
    for i,c in enumerate(source['cases']):
        if c['id']!=f'california_fold_{i}':raise ValueError('fold id')
        result.append(dict(case_id=c['id'],fold_id=c['fold'],T0=source['era']['T0_days'],**{k:day(c[k+'_utc'],'california') for k in ('train_start','train_end','test_start','test_end','history_start')}))
    if len(result)!=3:raise ValueError('fold count')
    return result
def verify_frozen(protocol,source_path,source,sealed_path,phase,gate,authorities_path,authorities):
    if protocol.get('status')!='frozen' or not protocol.get('science_gate_passed'):raise ValueError('protocol gate')
    if protocol.get('source_protocol_sha256')!=sha(source_path):raise ValueError('source protocol identity')
    if protocol.get('source_authorities_sha256')!=sha(authorities_path):raise ValueError('source authorities identity')
    if authorities['old_protocol_sha256']!=sha(source_path) or authorities['canonical_input']!=source['data']:raise ValueError('source authorities mismatch')
    if protocol.get('sealed_results_path')!=str(Path(sealed_path).resolve()):raise ValueError('sealed results identity')
    if protocol.get('target_counts')!=list(EXPECTED) or protocol.get('fit_denominator')!=dict(procedures=6,starts=48,floors=9):raise ValueError('denominator')
    if authorities['expected_counts']['test']!=list(EXPECTED) or len(authorities['sealed_OC_cases'])!=3:raise ValueError('authority denominator')
    for item in authorities['sealed_OC_cases']:
        if sha(item['private_case_path'])!=item['sha256']:raise ValueError('sealed OC identity')
    for path,digest in protocol.get('artifact_pins',{}).items():
        if sha(path)!=digest:raise ValueError('artifact pin')
    for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        if os.environ.get(key)!='1':raise ValueError('single-thread gate')
    if source['models'] is None or source['data']['sha256'] is None:raise ValueError('source protocol')
    if phase in ('pilot','fit','score'):
        if gate is None:raise ValueError('gate receipt missing')
        receipt=read(gate)
        if receipt.get('protocol_sha256')!=sha(protocol['_path']) or receipt.get('controls_passed') is not True:raise ValueError('controls gate')
        if phase in ('fit','score') and receipt.get('pilot_admitted') is not True:raise ValueError('pilot gate')
def sealed_case(folder,case_id):
    path=Path(folder)/case_id/'case.json';row=read(path)
    if row['case']['case_id']!=case_id or row['status']!='complete':raise ValueError('sealed case')
    return path,row
def prepare_case(cat,case,folder,sealed_root,protocol_sha):
    case_id=case['case_id'];old_path,old=sealed_case(sealed_root,case_id)
    if cat.source_sha256!=old['catalogue_sha256']:raise ValueError('catalogue mismatch')
    t=cat.times;training=(t>=case['train_start'])&(t<case['train_end']);testing=(t>=case['test_start'])&(t<case['test_end'])
    if int(testing.sum())!=EXPECTED[int(case_id.rsplit('_',1)[1])] or int(training.sum())!=old['n_train'] or int(testing.sum())!=old['n_test']:raise ValueError('population mismatch')
    pi,counts,_=G.cell_proportions(cat.cells,training);beta,_=G.fit_conditional_beta(cat.excess[training],.5)
    if not np.allclose(pi,old['reference_pi'],rtol=0,atol=1e-14) or abs(beta-old['beta'])>1e-12:raise ValueError('nuisance mismatch')
    xy=G.project(cat.latitude[training],cat.longitude[training],'california')
    kde=G.select_bandwidth(xy,pi,G.SCALES,training_cells=cat.cells[training],profile='california')
    if kde['selected_bandwidth']!=old['kde_selection']['selected_bandwidth'] or any(abs(a['loo_logscore']-b['loo_logscore'])>1e-8 for a,b in zip(kde['candidates'],old['kde_selection']['candidates'])):raise ValueError('bandwidth mismatch')
    feature=build(cat,case,beta,pi,kde['selected_bandwidth'],folder/'train_features.npz',protocol_sha,phase='train')
    summary=dict(case=case,case_id=case_id,catalogue_sha256=cat.source_sha256,sealed_case_path=str(old_path.resolve()),sealed_case_sha256=sha(old_path),n_train=int(training.sum()),n_test=int(testing.sum()),beta=beta,reference_pi=pi,
                 kde_selection=kde,train_feature=feature,status='prepared')
    write(folder/'nuisance.json',summary)
    write(folder/'fit_plan.json',dict(case_id=case_id,procedures=[dict(arm=arm,start_ids=[f'{case_id}__{arm}__start{i}' for i in range(8)],floor_ids=[f'{case_id}__{arm}__floor_constant']+([f'{case_id}__EP__floor_N0'] if arm=='EP' else [])) for arm in ARMS],
                                      planned_procedures=2,planned_starts=16,planned_floors=3,status='planned'))
    return summary
def starts_for(arm,case_id,n_train,duration,n0=None):
    aP=float(np.clip(np.log(n_train/duration),-12,0))
    if arm=='N0':
        starts=[dict(id=f'{case_id}__N0__start{i}',pars=[aP,d]) for i,d in enumerate(N0_D)]
        floors=[dict(id=f'{case_id}__N0__floor_constant',pars=[aP,0.])]
        return starts,floors
    if arm!='EP':raise ValueError('arm')
    a0=float(np.clip(np.log(.6*n_train/duration),-11.5,-.1))
    starts=[dict(id=f'{case_id}__EP__start{i}',pars=[a0+off,d,n,math.log(c),p,math.log(ell),q]) for i,(off,d,n,c,p,ell,q) in enumerate(EP_ROWS)]
    floor=[aP,0.,0.,0.,1.3,math.log(50.),2.]
    if n0 is None:raise ValueError('N0 dependency')
    pars=n0['selected']['pars']
    floors=[dict(id=f'{case_id}__EP__floor_constant',pars=floor),dict(id=f'{case_id}__EP__floor_N0',pars=[pars[0],pars[1],0.,0.,1.3,math.log(50.),2.])]
    return starts,floors
def fit_case(folder):
    nuisance=read(folder/'nuisance.json');case=nuisance['case'];duration=case['train_end']-case['train_start'];n=nuisance['n_train']
    with Objective(nuisance['train_feature']['path']) as obj:
        for arm,model in (('N0','no_trigger'),('EP','independent_etas')):
            prior=read(folder/'fit_N0.json') if arm=='EP' else None
            if prior is not None and not prior['complete']:raise ValueError('N0 fit dependency')
            starts,floors=starts_for(arm,case['case_id'],n,duration,prior)
            out=fit(obj,model,f'{case["case_id"]}__{arm}',starts,floors)
            out.update(case_id=case['case_id'],arm=arm,feature=nuisance['train_feature'],nuisance_path=str((folder/'nuisance.json').resolve()),nuisance_sha256=sha(folder/'nuisance.json'))
            write(folder/f'fit_{arm}.json',out)
            if not out['complete']:raise ValueError('incomplete fit')
def _score(v):
    keys=('joint_logscore','joint_nll','timing_logscore','conditional_location_logscore','mark_logscore','integrated_intensity','event_log_point_intensity_sum','event_log_ground_intensity_sum','timing_event_logscore','timing_exposure_logscore','trigger_exposure',
          'conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','cell_integrated_intensity','cell_point_event_log_intensity_sum','event_log_point_intensity','event_log_cell_intensity','event_log_zone_intensity','event_log_ground_intensity')
    return {k:clean(v[k]) for k in keys}
def score_case(cat,folder,sealed_root,protocol_sha):
    nuisance=read(folder/'nuisance.json');case=nuisance['case'];fits={arm:read(folder/f'fit_{arm}.json') for arm in ARMS}
    if not all(v['complete'] for v in fits.values()):raise ValueError('incomplete training')
    old_path,old=sealed_case(sealed_root,case['case_id'])
    if sha(old_path)!=nuisance['sealed_case_sha256'] or old['beta']!=nuisance['beta'] or old['kde_selection']['selected_bandwidth']!=nuisance['kde_selection']['selected_bandwidth']:raise ValueError('sealed changed')
    feature=build(cat,case,nuisance['beta'],nuisance['reference_pi'],nuisance['kde_selection']['selected_bandwidth'],folder/'test_features.npz',protocol_sha,phase='test')
    if feature['n_events']!=nuisance['n_test']:raise ValueError('test count')
    with Objective(feature['path']) as obj:
        for arm in ARMS:
            fitrow=fits[arm];model=fitrow['model'];candidates=[];returns=[]
            for cand in fitrow['candidates']:
                v=obj.evaluate(model,cand['pars'],detailed=True);fine=obj.evaluate(model,cand['pars'],fine=True)
                candidates.append(dict(candidate_id=cand['candidate_id'],kind=cand['kind'],pars=cand['pars'],training_joint_nll=cand['training_evaluation']['joint_nll'],forecast=_score(v),fine_forecast=_score(fine),quadrature_order_delta_nll=abs(v['joint_nll']-fine['joint_nll'])))
            for slot in fitrow['slots']:
                for attempt in slot.get('attempts',[]):
                    if attempt.get('finite_feasible') and 'pars' in attempt:
                        v=obj.evaluate(model,attempt['pars'],detailed=True);fine=obj.evaluate(model,attempt['pars'],fine=True)
                        returns.append(dict(slot_id=slot['id'],tier=attempt['tier'],accepted=attempt.get('accepted',False),pars=attempt['pars'],forecast=_score(v),fine_forecast=_score(fine),quadrature_order_delta_nll=abs(v['joint_nll']-fine['joint_nll'])))
            chosen=next(x for x in candidates if x['candidate_id']==fitrow['selected_candidate_id']);near=[x for x in candidates if x['candidate_id'] in fitrow['near_optimal_candidate_ids']]
            spread=(max(x['forecast']['joint_logscore'] for x in near)-min(x['forecast']['joint_logscore'] for x in near))/feature['n_events']
            status='provisional_awaiting_independent_audit' if spread<.01 and all(x['quadrature_order_delta_nll']<=1e-4 for x in candidates+returns) else 'unknown_numerical'
            out=dict(case_id=case['case_id'],arm=arm,status=status,fit_path=str((folder/f'fit_{arm}.json').resolve()),fit_sha256=sha(folder/f'fit_{arm}.json'),feature=feature,
                     selected_candidate_id=chosen['candidate_id'],forecast=chosen['forecast'],all_candidate_forecasts=candidates,all_solver_return_forecasts=returns,near_optimal_candidate_ids=fitrow['near_optimal_candidate_ids'],
                     forecast_spread_nats_per_event=spread,sealed_OC_case_path=str(old_path.resolve()),sealed_OC_case_sha256=sha(old_path))
            write(folder/f'score_{arm}.json',out)
    # Archived O-C remains an immutable external procedure, referenced by path/hash.
    oc=old['models']['Omori_smooth_cont']
    write(folder/'sealed_OC_reference.json',dict(case_id=case['case_id'],path=str(old_path.resolve()),sha256=sha(old_path),selected_candidate_id=oc['selected']['candidate_id'],
          selected_training_fit_sha256=oc['training_fit_sha256'],n_test=old['n_test'],beta=old['beta'],bandwidth_km=old['kde_selection']['selected_bandwidth'],
          forecast={k:oc['forecast'][k] for k in ('joint_logscore','timing_logscore','conditional_location_logscore','mark_logscore','integrated_intensity','event_log_point_intensity_sum','event_log_ground_intensity_sum')}))
def pilot_case(folder,output,deadline):
    nuisance=read(folder/'nuisance.json');case=nuisance['case'];n=nuisance['n_train'];duration=case['train_end']-case['train_start'];a0=float(np.clip(np.log(.6*n/duration),-11.5,-.1));records=[]
    with Objective(nuisance['train_feature']['path']) as obj:
        n0,_=starts_for('N0',case['case_id'],n,duration)
        vectors=[('N0',n0[0]['pars']),('EP',[a0,.2,.2,math.log(.01),1.3,math.log(15.),2.]),('EP',[a0,.2,.6,math.log(.0001),1.01,math.log(2.),1.05]),('EP',[a0,.2,.6,math.log(20.),2.5,math.log(500.),3.])]
        for model,p in vectors:
            if time.perf_counter()>=deadline:
                records.append(dict(arm=model,kind='evaluation',status='unknown_timeout'));continue
            name='no_trigger' if model=='N0' else 'independent_etas';t=time.perf_counter();v=obj.evaluate(name,p);fine=obj.evaluate(name,p,fine=True)
            records.append(dict(arm=model,kind='evaluation',status='complete',wall_seconds=time.perf_counter()-t,finite=math.isfinite(v['joint_nll']),refinement_delta_nll=abs(v['joint_nll']-fine['joint_nll'])))
        # Pilot returns are private and never promoted to a main-fit slot.
        for arm,name,start in (('N0','no_trigger',n0[0]['pars']),('EP','independent_etas',starts_for('EP',case['case_id'],n,duration,dict(selected=dict(pars=n0[0]['pars'])))[0][0]['pars'])):
            entry=dict(arm=arm,kind='pilot_start',status='unknown_timeout',start=start);t=time.perf_counter()
            try:
                def target(x):
                    if time.perf_counter()>=deadline:raise TimeoutError('pilot deadline')
                    v=obj.evaluate(name,x);return v['joint_nll'],v['gradient']
                opt=minimize(target,start,method='L-BFGS-B',jac=True,bounds=bounds(name),options=OPTIONS_LBFGSB)
                entry.update(status='complete',success=bool(opt.success),message=str(opt.message),solver_status=int(opt.status),pars=opt.x.tolist(),reported_nll=float(opt.fun),nfev=int(opt.nfev),nit=int(opt.nit))
            except Exception as ex:entry.update(status='unknown_timeout' if isinstance(ex,TimeoutError) else 'failed',error_type=type(ex).__name__)
            entry['wall_seconds']=time.perf_counter()-t;records.append(entry)
    write(output,dict(case_id=case['case_id'],phase='pilot',records=records,contains_private_training_values=True))
def main():
    p=argparse.ArgumentParser();p.add_argument('--protocol',required=True);p.add_argument('--source-protocol',required=True);p.add_argument('--source-authorities',required=True);p.add_argument('--sealed-results',required=True);p.add_argument('--output',required=True);p.add_argument('--phase',choices=('prepare','pilot','fit','score'),required=True);p.add_argument('--gate');args=p.parse_args()
    protocol=read(args.protocol);protocol['_path']=str(Path(args.protocol).resolve());source=read(args.source_protocol);authorities=read(args.source_authorities)
    verify_frozen(protocol,args.source_protocol,source,args.sealed_results,args.phase,args.gate,args.source_authorities,authorities)
    output=Path(args.output).resolve();output.mkdir(parents=True,exist_ok=True);cat=load_catalogue(source['data']['catalogue'],source['data']['sha256'],profile='california')
    roster=cases(source);protocol_sha=sha(args.protocol)
    if args.phase=='prepare':
        for case in roster:prepare_case(cat,case,output/case['case_id'],args.sealed_results,protocol_sha)
    elif args.phase=='pilot':
        deadline=time.perf_counter()+1200
        for case in (roster[0],roster[-1]):pilot_case(output/case['case_id'],output/case['case_id']/'pilot.json',deadline)
    elif args.phase=='fit':
        for case in roster:fit_case(output/case['case_id'])
    else:
        if not all((output/c['case_id']/f'fit_{arm}.json').exists() for c in roster for arm in ARMS):raise ValueError('training not frozen')
        if not all(read(output/c['case_id']/f'fit_{arm}.json').get('complete') is True for c in roster for arm in ARMS):raise ValueError('training incomplete before scoring')
        for case in roster:score_case(cat,output/case['case_id'],args.sealed_results,protocol_sha)
    print(json.dumps(dict(status='complete',phase=args.phase,output=str(output))))
if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps(dict(status='failed',fixed_error_code='BENCHMARK_WORKFLOW_FAILURE',error_type=type(exc).__name__)),file=sys.stderr);sys.exit(1)
