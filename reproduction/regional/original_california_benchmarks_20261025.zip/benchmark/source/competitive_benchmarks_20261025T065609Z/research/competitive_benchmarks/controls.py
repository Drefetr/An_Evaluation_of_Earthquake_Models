"""Handcrafted, data-free numerical controls. Run only under machine lease."""
import argparse,ctypes as ct,json,math,sys
from pathlib import Path
import numpy as np
from scipy.integrate import dblquad,quad
from .objective import library

CONTROL_STAGE='initialization'
def stage(name):
    global CONTROL_STAGE
    CONTROL_STAGE=name

def fixture(lib,parents,events,*,start=1.,end=4.,marks=0.):
    rect=np.array([[x,x+1.,y,y+1.] for y in range(3) for x in range(3)],dtype=np.float64)
    pt=np.array([p[0] for p in parents],dtype=np.float64);pxy=np.array([p[1:3] for p in parents],dtype=np.float64).reshape(-1,2)
    et=np.array([e[0] for e in events],dtype=np.float64);exy=np.array([e[1:3] for e in events],dtype=np.float64).reshape(-1,2)
    cell=np.array([min(2,int(e[1]))+3*min(2,int(e[2])) for e in events],dtype=np.float64)
    kappa=np.full(len(pt),.3);lo=np.maximum(start-pt,0.);hi=end-pt;ex=2*et/10-1;b=np.full(len(et),1/9.);mass=np.full(9,1/9.);meta=np.array([start,end,10.,marks],dtype=np.float64)
    arrays=[pt,pxy,kappa,lo,hi,et,exy,ex,cell,b,mass,rect,meta];pd=ct.POINTER(ct.c_double)
    handle=lib.cb_create(len(et),len(pt),*[a.ctypes.data_as(pd) for a in arrays])
    if not handle:raise RuntimeError(lib.cb_last_error().decode())
    return handle,rect
def evaluate(lib,h,model,p,*,fine=False,detail=True,ne=0):
    pd=ct.POINTER(ct.c_double);p=np.asarray(p,dtype=np.float64);out=np.empty(28);grad=np.empty(len(p));logs=np.empty((ne,4)) if detail else None
    fn=lib.cb_eval_fine if fine else lib.cb_eval
    rc=fn(h,model,p.ctypes.data_as(pd),len(p),out.ctypes.data_as(pd),grad.ctypes.data_as(pd),logs.ctypes.data_as(pd) if detail else None)
    if rc:raise RuntimeError(lib.cb_last_error().decode())
    return out,grad,logs
def rectangle(lib,rect,xy,ell,q):
    pd=ct.POINTER(ct.c_double);r=np.ascontiguousarray(rect,dtype=np.float64);out=np.empty(3)
    if lib.cb_rectangle(r.ctypes.data_as(pd),*xy,ell,q,out.ctypes.data_as(pd)):raise RuntimeError(lib.cb_last_error().decode())
    return out
def invalid_create(lib,*,wrong_exposure=False,gapped_cells=False):
    pd=ct.POINTER(ct.c_double);rect=np.array([[x,x+1.,y,y+1.] for y in range(3) for x in range(3)],dtype=np.float64)
    if gapped_cells:rect[1,0]+=.1
    pt=np.array([0.]);pxy=np.array([[1.5,1.5]]);kappa=np.array([.3]);lo=np.array([1.]);hi=np.array([3. if wrong_exposure else 4.]);
    et=np.array([2.]);exy=np.array([[1.5,1.5]]);ex=np.array([-.6]);cell=np.array([4.]);b=np.array([1/9.]);mass=np.full(9,1/9.);meta=np.array([1.,4.,10.,0.])
    arrays=[pt,pxy,kappa,lo,hi,et,exy,ex,cell,b,mass,rect,meta]
    handle=lib.cb_create(1,1,*[a.ctypes.data_as(pd) for a in arrays])
    if handle:lib.cb_destroy(handle);return False
    return True
def run():
    stage('library')
    lib,_=library();checks={};max_error=0.
    # The same-time event at t=2 is not its own parent or another tied parent's child.
    parents=[(0.,1.5,1.5),(1.5,2.5,1.5),(2.,1.5,2.5),(2.,2.5,2.5)]
    events=[(1.5,2.5,1.5),(2.,1.5,2.5),(2.,2.5,2.5)]
    stage('main_fixture')
    h,rect=fixture(lib,parents,events,marks=3*math.log(2.)-.25)
    try:
        stage('n0_nesting')
        n0=np.array([-1.,.2]);ep=np.array([-1.,.2,0.,math.log(.01),1.3,math.log(2.),2.])
        a,ga,la=evaluate(lib,h,0,n0,ne=3);b,gb,lb=evaluate(lib,h,1,ep,ne=3)
        checks['exact_n0_score']=abs(a[0]-b[0])<1e-10 and abs(a[1]-b[1])<1e-10 and abs(a[2]-b[2])<1e-10
        checks['exact_n0_intensity']=np.max(abs(la-lb))<1e-10
        checks['zero_trigger_coordinate_gradients']=np.max(abs(gb[3:]))<1e-12
        checks['mark_once']=abs(a[5]-(3*math.log(2.)-.25))<1e-12
        checks['full_decomposition']=abs(a[1]+a[2]+a[3]+a[4]+a[5]+a[0])<1e-10
        stage('same_time_fixture')
        reduced,_=fixture(lib,parents[:2],events,marks=3*math.log(2.)-.25)
        try:
            _,_,reduced_logs=evaluate(lib,reduced,1,[-1.,.2,.3,math.log(.01),1.3,math.log(2.),2.],ne=3)
            _,_,full_logs=evaluate(lib,h,1,[-1.,.2,.3,math.log(.01),1.3,math.log(2.),2.],ne=3)
            checks['strict_same_time']=np.max(abs(reduced_logs[1:]-full_logs[1:]))<1e-12
        finally:lib.cb_destroy(reduced)
        stage('interior_gradient')
        p=np.array([-1.,.2,.3,math.log(.01),1.3,math.log(20.),2.]);value,grad,_=evaluate(lib,h,1,p,detail=False)
        errs=[]
        for j in range(7):
            step=1e-5 if j in (3,5) else 1e-6;up=p.copy();down=p.copy();up[j]+=step;down[j]-=step
            vu,_,_=evaluate(lib,h,1,up,detail=False);vd,_,_=evaluate(lib,h,1,down,detail=False);errs.append(abs((vu[0]-vd[0])/(2*step)-grad[j]))
        max_error=max(errs);checks['interior_gradient']=max_error<2e-5
        vf,_,_=evaluate(lib,h,1,p,fine=True,detail=False);checks['refinement']=abs(vf[0]-value[0])<1e-7
        stage('boundary_gradient')
        boundary=np.array([-1.,.2,.3,math.log(.0001),1.01,math.log(2.),1.05]);bv,bg,_=evaluate(lib,h,1,boundary,detail=False)
        one_sided=[]
        for j in (3,4,5,6):
            step=2e-6;up=boundary.copy();up[j]+=step;uv,_,_=evaluate(lib,h,1,up,detail=False)
            one_sided.append(abs((uv[0]-bv[0])/step-bg[j]))
        checks['boundary_gradient']=max(one_sided)<2e-3
        checks['positive_intensity']=np.isfinite(la).all() and np.isfinite(lb).all() and np.isfinite(value[0])
    finally:lib.cb_destroy(h)
    stage('zero_parent_fixture')
    h,_=fixture(lib,[],[],marks=0.)
    try:
        out,grad,_=evaluate(lib,h,0,[-1.,0.],ne=0)
        checks['zero_parents_quiet_exposure']=abs(out[0]-3/math.e)<1e-12 and abs(grad[0]-out[0])<1e-12
    finally:lib.cb_destroy(h)
    stage('spatial_rectangle')
    whole=np.array([0.,3.,0.,3.])
    spatial=[]
    for xy in ((1.5,1.5),(0.,1.5),(0.,0.)):
        for ell,q in ((2.,1.05),(2.,3.),(500.,1.05),(500.,3.)):
            z=rectangle(lib,whole,xy,ell,q)
            oracle=dblquad(lambda y,x:(1+((x-xy[0])**2+(y-xy[1])**2)/ell**2)**(-q),0,3,lambda x:0,lambda x:3,epsabs=1e-10,epsrel=1e-10)[0]
            spatial.append(abs(z[0]-oracle));spatial.append(max(0.,-z[1]));spatial.append(max(0.,z[2]))
    checks['spatial_center_edge_corner']=max(spatial)<1e-7
    stage('distant_cell_mass')
    tiny_cells=np.array([[x,x+1.,y,y+1.] for y in range(3) for x in range(3)],dtype=np.float64)
    whole_mass=rectangle(lib,whole,(0.,0.),2.,3.)[0]
    parts=[rectangle(lib,r,(0.,0.),2.,3.)[0] for r in tiny_cells]
    checks['positive_distant_cells']=min(parts)>0 and abs(sum(parts)-whole_mass)<1e-8
    stage('invalid_api_inputs')
    checks['reject_wrong_exposure']=invalid_create(lib,wrong_exposure=True)
    checks['reject_gapped_cells']=invalid_create(lib,gapped_cells=True)
    pd=ct.POINTER(ct.c_double);bad=np.empty(3);r=np.ascontiguousarray(whole)
    checks['reject_rectangle_parameters']=lib.cb_rectangle(r.ctypes.data_as(pd),1.,1.,1e200,2.,bad.ctypes.data_as(pd))!=0 and lib.cb_rectangle(r.ctypes.data_as(pd),1.,1.,2.,float('nan'),bad.ctypes.data_as(pd))!=0
    stage('temporal_mass')
    for c,p in ((.0001,1.01),(.01,1.3),(20.,2.5)):
        survival=lambda u:(1+u/c)**(1-p)
        density=lambda u:(p-1)/c*(1+u/c)**(-p)
        mass=quad(density,0,20*c,epsabs=1e-12,epsrel=1e-12)[0]
        checks[f'temporal_mass_{c:g}_{p:g}']=abs(survival(0)-1)<1e-14 and abs(mass-(1-survival(20*c)))<1e-10
    stage('complete')
    return dict(status='complete' if all(checks.values()) else 'failed',checks={name:bool(value) for name,value in checks.items()},max_gradient_error=float(max_error),max_spatial_error=float(max(spatial)))
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);args=p.parse_args();result=run();path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps(dict(status=result['status'],output=str(path.resolve()),checks=len(result['checks']))))
    if result['status']!='complete':sys.exit(1)
if __name__=='__main__':
    try:main()
    except Exception as exc:
        print(json.dumps(dict(status='failed',fixed_error_code='CONTROL_FAILURE',control_stage=CONTROL_STAGE,error_type=type(exc).__name__)),file=sys.stderr);sys.exit(1)
