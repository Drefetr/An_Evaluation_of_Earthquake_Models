"""ctypes adapter for independently implemented no-trigger and ETAS DLL."""
import ctypes as ct,hashlib,json
from pathlib import Path
import numpy as np
from .features import FEATURE_NAMES,sha,_identity

MODELS={'no_trigger':(0,2),'independent_etas':(1,7)}
def bounds(model):
    if model=='no_trigger':return [(-12.,0.),(-2.,2.)]
    if model=='independent_etas':return [(-12.,0.),(-2.,2.),(0.,.98),(float(np.log(.0001)),float(np.log(20.))),(1.01,2.5),(float(np.log(2.)),float(np.log(500.))),(1.05,3.)]
    raise ValueError('model')
def library(path=None):
    path=Path(path or Path(__file__).with_name('objective.dll')).resolve();lib=ct.CDLL(str(path));pd=ct.POINTER(ct.c_double)
    lib.cb_create.argtypes=[ct.c_int,ct.c_int]+[pd]*13;lib.cb_create.restype=ct.c_void_p
    lib.cb_eval.argtypes=[ct.c_void_p,ct.c_int,pd,ct.c_int,pd,pd,pd];lib.cb_eval.restype=ct.c_int
    lib.cb_eval_fine.argtypes=lib.cb_eval.argtypes;lib.cb_eval_fine.restype=ct.c_int
    lib.cb_destroy.argtypes=[ct.c_void_p];lib.cb_destroy.restype=None;lib.cb_last_error.restype=ct.c_char_p
    lib.cb_rectangle.argtypes=[pd,ct.c_double,ct.c_double,ct.c_double,ct.c_double,pd];lib.cb_rectangle.restype=ct.c_int
    return lib,path
class Objective:
    def __init__(self,feature_path,dll_path=None):
        self.path=Path(feature_path).resolve();self.handle=None;self.lib,self.dll_path=library(dll_path)
        with np.load(self.path,allow_pickle=False) as saved:
            self.metadata=json.loads(str(saved['metadata_json'].item()))
            self.arrays={k:np.ascontiguousarray(saved[k],dtype=np.float64) for k in FEATURE_NAMES}
        m=self.metadata;a=self.arrays
        ident=dict(m);actual=ident.pop('identity_sha256',None)
        if actual!=_identity(ident) or m['array_sha256']!={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in a.items()}:raise ValueError('feature identity')
        ne=m['n_events'];np_=m['n_parents'];shapes={'parent_time':(np_,),'parent_xy':(np_,2),'parent_fertility':(np_,),'parent_exposure_lo':(np_,),'parent_exposure_hi':(np_,),'event_time':(ne,),'event_xy':(ne,2),'event_x':(ne,),'event_cell':(ne,),'event_background_density':(ne,),'background_cell_mass':(9,),'rectangles':(9,4)}
        if m['version']!=1 or any(a[k].shape!=shape for k,shape in shapes.items()) or any(not v.flags['C_CONTIGUOUS'] or not np.isfinite(v).all() for v in a.values()):raise ValueError('feature shapes')
        if not np.array_equal(a['event_time'],a['parent_time'][-ne:] if ne else a['parent_time'][:0]) or not np.array_equal(a['event_xy'],a['parent_xy'][-ne:] if ne else a['parent_xy'][:0]):raise ValueError('target binding')
        pt=a['parent_time'];start=m['start'];end=m['end']
        if not np.array_equal(a['parent_exposure_lo'],np.maximum(start-pt,0.)) or not np.array_equal(a['parent_exposure_hi'],end-pt):raise ValueError('exposure window binding')
        rect=a['rectangles'].reshape(3,3,4)
        if np.any(rect[:,:,0]>=rect[:,:,1]) or np.any(rect[:,:,2]>=rect[:,:,3]) or not np.array_equal(rect[:,:-1,1],rect[:,1:,0]) or not np.array_equal(rect[:-1,:,3],rect[1:,:,2]) or not np.array_equal(rect[:,:,0],rect[0,:,0][None,:].repeat(3,axis=0)) or not np.array_equal(rect[:,:,1],rect[0,:,1][None,:].repeat(3,axis=0)) or not np.array_equal(rect[:,:,2],rect[:,0,2][:,None].repeat(3,axis=1)) or not np.array_equal(rect[:,:,3],rect[:,0,3][:,None].repeat(3,axis=1)):raise ValueError('rectangle tiling')
        meta=np.array([m['start'],m['end'],m['T0'],m['marks']],dtype=np.float64);self._meta=meta
        pd=ct.POINTER(ct.c_double);self.handle=self.lib.cb_create(ne,np_,*[a[k].ctypes.data_as(pd) for k in FEATURE_NAMES],meta.ctypes.data_as(pd))
        if not self.handle:raise ValueError(self.error())
        self.identity=dict(feature_path=str(self.path),feature_sha256=sha(self.path),dll_path=str(self.dll_path),dll_sha256=sha(self.dll_path),metadata_identity=actual)
    def error(self):return self.lib.cb_last_error().decode(errors='replace')
    def evaluate(self,model,pars,*,detailed=False,fine=False):
        mid,dim=MODELS[model];p=np.ascontiguousarray(pars,dtype=np.float64)
        if p.shape!=(dim,) or not np.isfinite(p).all():raise ValueError('parameter dimension')
        out=np.empty(28);grad=np.empty(dim);logs=np.empty((self.metadata['n_events'],4)) if detailed else None;pd=ct.POINTER(ct.c_double)
        ptr=logs.ctypes.data_as(pd) if detailed else None
        eval_fn=self.lib.cb_eval_fine if fine else self.lib.cb_eval
        if eval_fn(self.handle,mid,p.ctypes.data_as(pd),dim,out.ctypes.data_as(pd),grad.ctypes.data_as(pd),ptr):raise FloatingPointError(self.error())
        result=dict(joint_nll=float(out[0]),joint_logscore=-float(out[0]),gradient=grad.copy(),timing_logscore=float(out[1]),conditional_location_logscore=float(out[2]+out[3]+out[4]),
                    mark_logscore=float(out[5]),integrated_intensity=float(out[6]),event_log_point_intensity_sum=float(out[7]),event_log_ground_intensity_sum=float(out[8]),
                    timing_event_logscore=float(out[8]),timing_exposure_logscore=-float(out[6]),trigger_exposure=float(out[9]))
        if detailed:
            result.update(timing_logscore=float(out[1]),conditional_zone_logscore=float(out[2]),conditional_cell_logscore=float(out[3]),within_cell_density_logscore=float(out[4]),
              conditional_location_logscore=float(out[2]+out[3]+out[4]),mark_logscore=float(out[5]),integrated_intensity=float(out[6]),event_log_point_intensity_sum=float(out[7]),
              event_log_ground_intensity_sum=float(out[8]),timing_event_logscore=float(out[8]),timing_exposure_logscore=-float(out[6]),trigger_exposure=float(out[9]),
              cell_integrated_intensity=out[10:19].copy(),cell_point_event_log_intensity_sum=out[19:28].copy(),event_log_point_intensity=logs[:,0].copy(),event_log_cell_intensity=logs[:,1].copy(),event_log_zone_intensity=logs[:,2].copy(),event_log_ground_intensity=logs[:,3].copy())
            if abs(result['timing_logscore']+result['conditional_location_logscore']+result['mark_logscore']-result['joint_logscore'])>1e-7:raise FloatingPointError('score identity')
        return result
    def close(self):
        if self.handle:self.lib.cb_destroy(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
