"""Prescribed eight-start bounded fits; every return and exact floor is retained."""
import math,time
import numpy as np
from scipy.optimize import minimize
from .objective import bounds

OPTIONS_LBFGSB=dict(maxiter=200,maxfun=20000,maxls=200,ftol=1e-10,gtol=2e-6)
OPTIONS_POWELL=dict(maxiter=400,maxfev=5000,xtol=1e-6,ftol=1e-10)
def clean(v):
    if isinstance(v,np.ndarray):return clean(v.tolist())
    if isinstance(v,np.generic):return clean(v.item())
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    if isinstance(v,float) and not math.isfinite(v):return {'nonfinite':str(v)}
    return v
def feasible(p,b):return len(p)==len(b) and np.isfinite(p).all() and all(lo<=x<=hi for x,(lo,hi) in zip(p,b))
def boundary_flags(pars,b):return [dict(coordinate=i,lower=abs(v-lo)<=1e-7,upper=abs(v-hi)<=1e-7,fixed=lo==hi) for i,(v,(lo,hi)) in enumerate(zip(pars,b))]
def fit(obj,model,procedure_id,starts,floors,*,deadline=None):
    """No wall cap is invented here. A frozen external resource deadline is optional."""
    b=bounds(model);began=time.perf_counter();deadline=float('inf') if deadline is None else float(deadline)
    if len(starts)!=8 or any(not feasible(np.asarray(row['pars'],float),b) for row in starts+floors):raise ValueError('frozen start/floor roster')
    records=[];candidates=[]
    def evaluated(p,candidate_id,kind):
        val=obj.evaluate(model,p);fine=obj.evaluate(model,p,fine=True);delta=abs(val['joint_nll']-fine['joint_nll'])
        if delta>1e-4:raise FloatingPointError('quadrature order disagreement')
        return dict(candidate_id=candidate_id,kind=kind,pars=list(map(float,p)),training_evaluation=clean(val),training_fine_evaluation=clean(fine),quadrature_order_delta_nll=delta,
                    boundary_flags=boundary_flags(p,b),eligible_provisional=True,independent_audit='pending')
    for ordinal,row in enumerate(floors):
        entry=dict(id=row['id'],kind='floor',ordinal=ordinal,pars=list(row['pars']),status='unknown',attempts=[])
        try:
            if time.perf_counter()>=deadline:raise TimeoutError('frozen deadline')
            cand=evaluated(row['pars'],row['id'],'floor');cand['schedule_ordinal']=ordinal;candidates.append(cand)
            entry.update(status='complete',candidate_id=row['id'],training_joint_nll=cand['training_evaluation']['joint_nll'])
        except Exception as ex:entry.update(status='unknown_floor',error_type=type(ex).__name__)
        records.append(entry)
    for ordinal,row in enumerate(starts):
        start=np.asarray(row['pars'],float);entry=dict(id=row['id'],kind='start',ordinal=ordinal+len(floors),pars=list(row['pars']),status='unknown_start',attempts=[])
        try:initial=obj.evaluate(model,start)['joint_nll']
        except Exception as ex:entry.update(error_type=type(ex).__name__);records.append(entry);continue
        for tier,(method,options) in enumerate((('L-BFGS-B',OPTIONS_LBFGSB),('Powell',OPTIONS_POWELL))):
            attempt=dict(tier=tier,method=method,options=options,initial_nll=initial,status='unknown',start=start.tolist());t0=time.perf_counter()
            try:
                if time.perf_counter()>=deadline:raise TimeoutError('frozen deadline')
                def objective(x):
                    if time.perf_counter()>=deadline:raise TimeoutError('frozen deadline')
                    v=obj.evaluate(model,x)
                    return v['joint_nll'],v['gradient']
                opt=minimize((lambda x:objective(x)[0]) if method=='Powell' else objective,start,method=method,jac=method=='L-BFGS-B',bounds=b,options=options)
                attempt.update(status='solver_return',success=bool(opt.success),solver_status=int(opt.status),message=str(opt.message),pars=opt.x.tolist(),reported_nll=float(opt.fun),nfev=int(opt.nfev),nit=int(opt.nit),finite_feasible=bool(feasible(opt.x,b)))
                if attempt['finite_feasible']:
                    reval=obj.evaluate(model,opt.x)
                    attempt['training_evaluation']=clean(reval)
                    attempt['evaluator_delta_nll']=abs(reval['joint_nll']-opt.fun)
                    fine=obj.evaluate(model,opt.x,fine=True)
                    attempt['training_fine_evaluation']=clean(fine)
                    attempt['quadrature_order_delta_nll']=abs(reval['joint_nll']-fine['joint_nll'])
                    good=bool(opt.success and math.isfinite(opt.fun) and attempt['evaluator_delta_nll']<=1e-7 and reval['joint_nll']<=initial+1e-8 and attempt['quadrature_order_delta_nll']<=1e-4)
                    attempt['accepted']=good
                    if good:
                        cand=evaluated(opt.x,row['id']+'_tier'+str(tier),'solver');cand.update(schedule_ordinal=entry['ordinal'],tier=tier,slot_id=row['id'])
                        candidates.append(cand);entry.update(status='complete',candidate_id=cand['candidate_id']);attempt['status']='accepted'
                else:attempt['accepted']=False
            except Exception as ex:attempt.update(status='exception',error_type=type(ex).__name__,accepted=False)
            attempt['wall_seconds']=time.perf_counter()-t0;entry['attempts'].append(clean(attempt))
            if entry['status']=='complete' or time.perf_counter()>=deadline:break
        records.append(entry)
    complete=all(row['status']=='complete' for row in records)
    winner=min(candidates,key=lambda c:(c['training_evaluation']['joint_nll'],c['schedule_ordinal'],c['candidate_id'])) if candidates else None
    near=[] if winner is None else [c['candidate_id'] for c in candidates if c['training_evaluation']['joint_nll']<=winner['training_evaluation']['joint_nll']+4e-4]
    return clean(dict(procedure_id=procedure_id,model=model,status='complete' if complete else 'unknown_incomplete',complete=complete,bounds=b,slots=records,candidates=candidates,
                      selected_candidate_id=None if winner is None else winner['candidate_id'],selected=None if winner is None else winner,near_optimal_candidate_ids=near,selection='minimum eligible training NLL; tie ordinal then ID',
                      independent_quadrature_status='pending_independent_audit',wall_seconds=time.perf_counter()-began))
