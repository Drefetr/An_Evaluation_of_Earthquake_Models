"""Conductor-only serial child launcher; no scientific output is printed."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,sqlite3,subprocess,sys,time,uuid
import psutil

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("x",encoding="utf-8") as f:json.dump(value,f,indent=2,allow_nan=False)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--job",required=True)
    ap.add_argument("--machine",required=True)
    ap.add_argument("--output",required=True)
    a=ap.parse_args()
    job_path=Path(a.job).resolve();job=json.loads(job_path.read_text(encoding="utf-8"))
    out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    for path,want in job["pins"].items():
        if digest(path)!=want:raise ValueError("JOB_INPUT_PIN_MISMATCH")
    argv=job["argv"]
    if not argv or not all(isinstance(v,str) for v in argv):raise ValueError("ARGV_SCHEMA")
    dbpath=Path(a.machine).resolve();dbpath.parent.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(dbpath,timeout=30)
    db.execute("CREATE TABLE IF NOT EXISTS leases(id TEXT PRIMARY KEY,owner TEXT,state TEXT,controller_pid INTEGER,controller_created REAL,started TEXT,finished TEXT,job_sha TEXT,receipt TEXT)")
    db.execute("CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY,start_utc TEXT,end_utc TEXT,owner TEXT,status TEXT)")
    db.commit();lease=str(uuid.uuid4());start=utc();me=psutil.Process()
    db.execute("BEGIN IMMEDIATE")
    busy=db.execute("SELECT id FROM leases WHERE state IN ('running','held')").fetchall()
    if busy:db.rollback();raise RuntimeError("MACHINE_LEASE_BUSY")
    finish_bound=time.time()+float(job["conservative_max_seconds"])
    for begin,end in db.execute("SELECT start_utc,end_utc FROM reservations WHERE status='active'"):
        b=datetime.datetime.fromisoformat(begin).timestamp();e=datetime.datetime.fromisoformat(end).timestamp()
        if time.time()<e and finish_bound>b:db.rollback();raise RuntimeError("OPERATIONAL_WINDOW_RESERVED")
    db.execute("INSERT INTO leases VALUES(?,?,?,?,?,?,?,?,?)",(lease,job["job_id"],"running",os.getpid(),me.create_time(),start,None,digest(job_path),str(out/"receipt.json")))
    db.commit()
    receipt={"schema_version":1,"job_id":job["job_id"],"job_path":str(job_path),"job_sha256":digest(job_path),"machine_lease":lease,"started_utc":start,"status":"running","controller_pid":os.getpid(),"controller_created":me.create_time(),"argv":argv,"cwd":job["cwd"],"tracked_processes":[]}
    save(out/"launch.json",receipt)
    env=os.environ.copy()
    env.update({key:"1" for key in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]})
    env.update(job.get("environment",{}))
    for key in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]:
        if env[key]!="1":raise ValueError("THREAD_POLICY")
    observed={}
    started=time.perf_counter()
    try:
        with (out/"stdout_private.log").open("wb") as stdout,(out/"stderr_private.log").open("wb") as stderr:
            child=subprocess.Popen(argv,cwd=job["cwd"],env=env,stdout=stdout,stderr=stderr)
            receipt["child_pid"]=child.pid
            childproc=psutil.Process(child.pid)
            observed[child.pid]=childproc.create_time()
            while child.poll() is None:
                try:
                    for proc in childproc.children(recursive=True):observed[proc.pid]=proc.create_time()
                except (psutil.NoSuchProcess,psutil.AccessDenied):pass
                time.sleep(.25)
            rc=child.wait()
        alive=[]
        for pid,created in observed.items():
            try:
                proc=psutil.Process(pid)
                if proc.create_time()==created and proc.is_running() and proc.status()!=psutil.STATUS_ZOMBIE:alive.append(pid)
            except psutil.NoSuchProcess:pass
        receipt.update(status="held" if alive else "terminal",exit_code=rc,finished_utc=utc(),wall_seconds=time.perf_counter()-started,live_tracked_descendants=alive,tracked_processes=[{"pid":pid,"created":created} for pid,created in observed.items()],stdout_sha256=digest(out/"stdout_private.log"),stderr_sha256=digest(out/"stderr_private.log"),liveness_limit="Synchronous reviewed children; process tree sampled every .25s. No unattended child launches permitted.")
        state="held" if alive else "terminal"
        save(out/"receipt.json",receipt)
        db.execute("UPDATE leases SET state=?,finished=? WHERE id=?",(state,receipt["finished_utc"],lease));db.commit()
        print(json.dumps({"status":state,"job_id":job["job_id"],"exit_code":rc,"wall_seconds":receipt["wall_seconds"],"receipt":str(out/"receipt.json"),"receipt_sha256":digest(out/"receipt.json")}))
        return 2 if alive else rc
    except BaseException as error:
        db.execute("UPDATE leases SET state='held' WHERE id=?",(lease,));db.commit()
        save(out/"interruption.json",{"status":"held","fixed_error_type":type(error).__name__,"utc":utc(),"machine_lease":lease,"tracked_processes":[{"pid":pid,"created":created} for pid,created in observed.items()]})
        print(json.dumps({"status":"held","fixed_error_type":type(error).__name__,"receipt":str(out/"interruption.json")}))
        return 3
    finally:db.close()
if __name__=="__main__":
    try:sys.exit(main())
    except Exception as e:
        print(json.dumps({"status":"not_launched","fixed_error_type":type(e).__name__}))
        sys.exit(4)

