"""Isolated process-control tests; no scientific jobs or source data are used."""

import hashlib
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest

import psutil


SCRIPT = Path(__file__).with_name("run_serial_v2.py")


@unittest.skipUnless(sys.platform == "win32", "Windows Job Objects only")
class SerialControllerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.machine = self.root / "machine.sqlite"
        self.counter = 0

    def job(self, code, budget=4, **changes):
        self.counter += 1
        executable = Path(sys.executable).resolve()
        job = {
            "job_id": f"test-{self.counter}",
            "expected_machine": str(self.machine.resolve()),
            "argv": [str(executable), "-c", code],
            "cwd": str(self.root.resolve()),
            "conservative_max_seconds": budget,
            "pins": {str(executable): hashlib.sha256(executable.read_bytes()).hexdigest()},
            "environment": {},
        }
        job.update(changes)
        path = self.root / f"job-{self.counter}.json"
        path.write_text(json.dumps(job), encoding="utf-8")
        return path

    def invoke(self, job):
        output = self.root / f"output-{self.counter}"
        completed = subprocess.run([sys.executable, str(SCRIPT), "--job", str(job),
                                    "--machine", str(self.machine), "--output", str(output)],
                                   capture_output=True, text=True, timeout=15)
        self.assertFalse(completed.stderr, completed.stderr)
        return completed, json.loads(completed.stdout), output

    def lease(self):
        with closing(sqlite3.connect(self.machine)) as db:
            return db.execute("SELECT state FROM leases ORDER BY rowid DESC LIMIT 1").fetchone()[0]

    def test_fast_and_nonzero(self):
        good = self.job("print('private output')")
        done, summary, output = self.invoke(good)
        self.assertEqual((done.returncode, summary["status"], self.lease()), (0, "terminal", "terminal"))
        self.assertEqual((output / "stdout_private.log").read_text().strip(), "private output")
        self.assertNotIn("private output", done.stdout)
        self.assertTrue(json.loads((output / "receipt.json").read_text())["containment_proved_empty"])
        bad = self.job("import sys; sys.exit(7)")
        done, summary, _ = self.invoke(bad)
        self.assertEqual((done.returncode, summary["status"], summary["exit_code"]), (7, "terminal", 7))

    def test_invalid_environment_and_pin_before_lease(self):
        bad_env = self.job("pass", environment={"SECRET": "do-not-inherit"})
        done, summary, _ = self.invoke(bad_env)
        self.assertEqual((done.returncode, summary["status"], summary["phase"]), (4, "aborted", "not_launched"))
        self.assertFalse(self.machine.exists())
        bad_pin = self.job("pass", pins={str(Path(sys.executable).resolve()): "0" * 64})
        done, summary, _ = self.invoke(bad_pin)
        self.assertEqual((done.returncode, summary["status"]), (4, "aborted"))
        self.assertFalse(self.machine.exists())

    def test_busy_and_reservation(self):
        job = self.job("pass")
        with closing(sqlite3.connect(self.machine)) as db:
            db.execute("CREATE TABLE leases(id TEXT PRIMARY KEY,owner TEXT,state TEXT,controller_pid INTEGER,controller_created REAL,started TEXT,finished TEXT,job_sha TEXT,receipt TEXT)")
            db.execute("INSERT INTO leases(id,state) VALUES('held', 'held')")
            db.commit()
        done, summary, _ = self.invoke(job)
        self.assertEqual((done.returncode, summary["fixed_error_type"]), (4, "RuntimeError"))
        with closing(sqlite3.connect(self.machine)) as db:
            db.execute("DELETE FROM leases")
            db.execute("CREATE TABLE reservations(id TEXT PRIMARY KEY,start_utc TEXT,end_utc TEXT,owner TEXT,status TEXT)")
            db.execute("INSERT INTO reservations VALUES('one',datetime('now','-1 minute')||'+00:00',datetime('now','+1 minute')||'+00:00','test','active')")
            db.commit()
        job = self.job("pass")
        done, summary, _ = self.invoke(job)
        self.assertEqual((done.returncode, summary["fixed_error_type"]), (4, "RuntimeError"))
        with closing(sqlite3.connect(self.machine)) as db:
            self.assertIsNone(db.execute("SELECT id FROM leases").fetchone())
            db.execute("UPDATE reservations SET start_utc=datetime('now','-1 minute'), end_utc=datetime('now','+1 minute')")
            db.commit()
        job = self.job("pass")
        done, summary, _ = self.invoke(job)
        self.assertEqual((done.returncode, summary["fixed_error_type"]), (4, "ValueError"))

    def test_timeout_kills_child(self):
        marker = self.root / "started"
        code = f"from pathlib import Path; Path({str(marker)!r}).write_text('started'); import time; time.sleep(30)"
        job = self.job(code, budget=1)
        done, summary, output = self.invoke(job)
        self.assertEqual((done.returncode, summary["status"], self.lease()), (2, "terminal", "terminal"))
        self.assertTrue(marker.exists())
        receipt = json.loads((output / "receipt.json").read_text())
        self.assertTrue(receipt["timed_out"] and receipt["termination_attempted"] and receipt["containment_proved_empty"])
        self.assertFalse(psutil.pid_exists(receipt["child_pid"]))

    def test_descendant_contained_after_parent_exit(self):
        pidfile = self.root / "descendant.pid"
        code = ("import subprocess,sys,pathlib; "
                "p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)']); "
                f"pathlib.Path({str(pidfile)!r}).write_text(str(p.pid))")
        job = self.job(code)
        done, summary, output = self.invoke(job)
        self.assertEqual((done.returncode, summary["status"], self.lease()), (0, "terminal", "terminal"))
        self.assertTrue(pidfile.exists())
        self.assertTrue(json.loads((output / "receipt.json").read_text())["termination_attempted"])
        pid = int(pidfile.read_text())
        for _ in range(20):
            if not psutil.pid_exists(pid):
                break
            time.sleep(.05)
        self.assertFalse(psutil.pid_exists(pid))

    def test_timeout_kills_spawned_descendant(self):
        pidfile = self.root / "timeout-descendant.pid"
        code = ("import subprocess,sys,pathlib,time; "
                "p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)']); "
                f"pathlib.Path({str(pidfile)!r}).write_text(str(p.pid)); "
                "time.sleep(30)")
        job = self.job(code, budget=1)
        done, summary, output = self.invoke(job)
        self.assertEqual((done.returncode, summary["status"], self.lease()), (2, "terminal", "terminal"))
        pid = int(pidfile.read_text())
        receipt = json.loads((output / "receipt.json").read_text())
        self.assertTrue(receipt["timed_out"] and receipt["containment_proved_empty"])
        self.assertFalse(psutil.pid_exists(pid))


if __name__ == "__main__":
    unittest.main()
