"""Synchronous, conductor-only Windows launcher with one SQLite machine lease.

The caller must use the same canonical --machine database for every job on a
machine. Running/held leases are never reclaimed automatically. Child output
stays in the local output directory and is never printed by this controller.
"""

from __future__ import annotations

import argparse
import ctypes
from ctypes import wintypes
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math
import msvcrt
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import time
import uuid

import psutil


THREAD_KEYS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")
ENV_KEYS = frozenset({
    "PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "COMSPEC",
    "USERPROFILE", "APPDATA", "LOCALAPPDATA", "PROGRAMDATA", "PYTHONPATH",
    "PYTHONHOME", "VIRTUAL_ENV", "INCLUDE", "LIB", "LIBPATH", "VSINSTALLDIR",
    "VCINSTALLDIR", "VCTOOLSINSTALLDIR", "WINDOWSSDKDIR", "WINDOWSSDKVERSION",
    "UNIVERSALCRTSDKDIR", "UCRTVERSION", "VSCMD_ARG_TGT_ARCH",
    "VSCMD_ARG_HOST_ARCH", "PROCESSOR_ARCHITECTURE", "NUMBER_OF_PROCESSORS",
})


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def write_json(path: Path, value: dict) -> None:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)


def checked_utc(value: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError("RESERVATION_TIME_SCHEMA")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None or parsed.utcoffset() != timedelta(0):
        raise ValueError("RESERVATION_NOT_UTC")
    return parsed.astimezone(timezone.utc)


def checked_job(job_path: Path, machine: Path) -> tuple[dict, str, list[str], Path, dict[str, str], float, dict[Path, str]]:
    raw = job_path.read_bytes()
    job = json.loads(raw.decode("utf-8"))
    if not isinstance(job, dict) or not isinstance(job.get("job_id"), str) or not job["job_id"]:
        raise ValueError("JOB_SCHEMA")
    budget = job.get("conservative_max_seconds")
    if isinstance(budget, bool) or not isinstance(budget, (int, float)) or not math.isfinite(budget) or budget <= 0:
        raise ValueError("BUDGET_SCHEMA")
    argv = job.get("argv")
    if not isinstance(argv, list) or not argv or not all(isinstance(x, str) and x and "\x00" not in x for x in argv):
        raise ValueError("ARGV_SCHEMA")
    executable = Path(argv[0])
    if not executable.is_absolute() or not executable.is_file():
        raise ValueError("EXECUTABLE_NOT_ABSOLUTE_FILE")
    executable = executable.resolve(strict=True)
    cwd = Path(job.get("cwd", ""))
    if not cwd.is_absolute() or not cwd.is_dir():
        raise ValueError("CWD_SCHEMA")
    cwd = cwd.resolve(strict=True)
    expected_machine = job.get("expected_machine")
    if expected_machine is not None and (not isinstance(expected_machine, str) or Path(expected_machine).resolve() != machine):
        raise ValueError("MACHINE_PATH_MISMATCH")
    pins = job.get("pins")
    if not isinstance(pins, dict) or not pins:
        raise ValueError("PINS_SCHEMA")
    verified = {}
    for name, expected in pins.items():
        if not isinstance(name, str) or not isinstance(expected, str) or len(expected) != 64:
            raise ValueError("PINS_SCHEMA")
        path = Path(name)
        if not path.is_absolute() or not path.is_file() or any(c not in "0123456789abcdef" for c in expected.lower()):
            raise ValueError("PINS_SCHEMA")
        path = path.resolve(strict=True)
        if sha_file(path) != expected.lower():
            raise ValueError("JOB_INPUT_PIN_MISMATCH")
        verified[path] = expected.lower()
    if executable not in verified:
        raise ValueError("EXECUTABLE_NOT_PINNED")
    argv = [str(executable), *argv[1:]]
    overrides = job.get("environment", {})
    if not isinstance(overrides, dict):
        raise ValueError("ENV_SCHEMA")
    if not all(isinstance(k, str) and isinstance(v, str) and "\x00" not in k + v and "=" not in k for k, v in overrides.items()):
        raise ValueError("ENV_SCHEMA")
    if any(k.upper() not in ENV_KEYS and k.upper() not in THREAD_KEYS for k in overrides):
        raise ValueError("ENV_NOT_ALLOWED")
    if len({k.upper() for k in overrides}) != len(overrides):
        raise ValueError("ENV_DUPLICATE_KEY")
    if any(k.upper() in THREAD_KEYS and v != "1" for k, v in overrides.items()):
        raise ValueError("THREAD_POLICY")
    env = {k.upper(): v for k, v in os.environ.items() if k.upper() in ENV_KEYS}
    env.update({k.upper(): v for k, v in overrides.items()})
    env.update({k: "1" for k in THREAD_KEYS})
    return job, sha_bytes(raw), argv, cwd, env, float(budget), verified


if os.name == "nt":
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    HANDLE = wintypes.HANDLE
    SIZE_T = ctypes.c_size_t
    ULONG_PTR = ctypes.c_size_t

    class STARTUPINFO(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("lpReserved", wintypes.LPWSTR),
                    ("lpDesktop", wintypes.LPWSTR), ("lpTitle", wintypes.LPWSTR),
                    ("dwX", wintypes.DWORD), ("dwY", wintypes.DWORD),
                    ("dwXSize", wintypes.DWORD), ("dwYSize", wintypes.DWORD),
                    ("dwXCountChars", wintypes.DWORD), ("dwYCountChars", wintypes.DWORD),
                    ("dwFillAttribute", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("wShowWindow", wintypes.WORD), ("cbReserved2", wintypes.WORD),
                    ("lpReserved2", ctypes.c_void_p), ("hStdInput", HANDLE),
                    ("hStdOutput", HANDLE), ("hStdError", HANDLE)]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [("hProcess", HANDLE), ("hThread", HANDLE),
                    ("dwProcessId", wintypes.DWORD), ("dwThreadId", wintypes.DWORD)]

    class BASIC_LIMIT(ctypes.Structure):
        _fields_ = [("PerProcessUserTimeLimit", ctypes.c_longlong),
                    ("PerJobUserTimeLimit", ctypes.c_longlong), ("LimitFlags", wintypes.DWORD),
                    ("MinimumWorkingSetSize", SIZE_T), ("MaximumWorkingSetSize", SIZE_T),
                    ("ActiveProcessLimit", wintypes.DWORD), ("Affinity", ULONG_PTR),
                    ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

    class IO_COUNTERS(ctypes.Structure):
        _fields_ = [(name, ctypes.c_ulonglong) for name in (
            "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
            "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

    class EXTENDED_LIMIT(ctypes.Structure):
        _fields_ = [("BasicLimitInformation", BASIC_LIMIT), ("IoInfo", IO_COUNTERS),
                    ("ProcessMemoryLimit", SIZE_T), ("JobMemoryLimit", SIZE_T),
                    ("PeakProcessMemoryUsed", SIZE_T), ("PeakJobMemoryUsed", SIZE_T)]

    class BASIC_ACCOUNTING(ctypes.Structure):
        _fields_ = [(name, ctypes.c_longlong) for name in (
            "TotalUserTime", "TotalKernelTime", "ThisPeriodTotalUserTime", "ThisPeriodTotalKernelTime")]
        _fields_ += [(name, wintypes.DWORD) for name in (
            "TotalPageFaultCount", "TotalProcesses", "ActiveProcesses", "TotalTerminatedProcesses")]

    kernel.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
    kernel.CreateJobObjectW.restype = HANDLE
    kernel.SetInformationJobObject.argtypes = [HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.SetInformationJobObject.restype = wintypes.BOOL
    kernel.QueryInformationJobObject.argtypes = [HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p]
    kernel.QueryInformationJobObject.restype = wintypes.BOOL
    kernel.AssignProcessToJobObject.argtypes = [HANDLE, HANDLE]
    kernel.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel.TerminateJobObject.argtypes = [HANDLE, wintypes.UINT]
    kernel.TerminateJobObject.restype = wintypes.BOOL
    kernel.CreateProcessW.argtypes = [wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p,
                                       ctypes.c_void_p, wintypes.BOOL, wintypes.DWORD,
                                       ctypes.c_void_p, wintypes.LPCWSTR,
                                       ctypes.POINTER(STARTUPINFO), ctypes.POINTER(PROCESS_INFORMATION)]
    kernel.CreateProcessW.restype = wintypes.BOOL
    kernel.ResumeThread.argtypes = [HANDLE]
    kernel.ResumeThread.restype = wintypes.DWORD
    kernel.WaitForSingleObject.argtypes = [HANDLE, wintypes.DWORD]
    kernel.WaitForSingleObject.restype = wintypes.DWORD
    kernel.GetExitCodeProcess.argtypes = [HANDLE, ctypes.POINTER(wintypes.DWORD)]
    kernel.GetExitCodeProcess.restype = wintypes.BOOL
    kernel.TerminateProcess.argtypes = [HANDLE, wintypes.UINT]
    kernel.TerminateProcess.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL


def wincheck(value, label: str):
    if not value:
        raise OSError(ctypes.get_last_error(), label)
    return value


def active_count(job_handle) -> int:
    info = BASIC_ACCOUNTING()
    wincheck(kernel.QueryInformationJobObject(job_handle, 1, ctypes.byref(info), ctypes.sizeof(info), None), "QueryInformationJobObject")
    return info.ActiveProcesses


def wait_empty(job_handle, seconds: float) -> bool:
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if active_count(job_handle) == 0:
            return True
        time.sleep(.05)
    return active_count(job_handle) == 0


def exit_code(process_handle) -> int:
    code = wintypes.DWORD()
    wincheck(kernel.GetExitCodeProcess(process_handle, ctypes.byref(code)), "GetExitCodeProcess")
    return ctypes.c_int32(code.value).value


def acquire(db: sqlite3.Connection, job_id: str, job_sha: str, receipt: Path, budget: float, controller_created: float) -> tuple[str, str, float]:
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute("CREATE TABLE IF NOT EXISTS leases(id TEXT PRIMARY KEY,owner TEXT,state TEXT,controller_pid INTEGER,controller_created REAL,started TEXT,finished TEXT,job_sha TEXT,receipt TEXT)")
        db.execute("CREATE TABLE IF NOT EXISTS reservations(id TEXT PRIMARY KEY,start_utc TEXT,end_utc TEXT,owner TEXT,status TEXT)")
        if db.execute("SELECT 1 FROM leases WHERE state IN ('running','held') LIMIT 1").fetchone():
            raise RuntimeError("MACHINE_LEASE_BUSY")
        begun = now_utc()
        ended = begun + timedelta(seconds=budget)
        for start_s, end_s in db.execute("SELECT start_utc,end_utc FROM reservations WHERE status='active'"):
            start, end = checked_utc(start_s), checked_utc(end_s)
            if end <= start:
                raise ValueError("RESERVATION_ORDER")
            if begun < end and start < ended:
                raise RuntimeError("OPERATIONAL_WINDOW_RESERVED")
        lease = str(uuid.uuid4())
        db.execute("INSERT INTO leases VALUES(?,?,?,?,?,?,?,?,?)", (
            lease, job_id, "running", os.getpid(), controller_created,
            begun.isoformat(), None, job_sha, str(receipt)))
        db.commit()
        return lease, begun.isoformat(), time.monotonic()
    except BaseException:
        db.rollback()
        raise


def run(args) -> int:
    phase = "not_launched"
    lease = None
    db = None
    job_handle = None
    process = PROCESS_INFORMATION() if os.name == "nt" else None
    output = None
    stdout = stderr = stdin = None
    result = {}
    started_clock = None
    termination_attempted = False
    containment_proved_empty = False
    try:
        if os.name != "nt":
            raise RuntimeError("WINDOWS_ONLY")
        job_path = Path(args.job).resolve(strict=True)
        machine = Path(args.machine).resolve()
        job, job_sha, argv, cwd, env, budget, pins = checked_job(job_path, machine)
        controller_created = psutil.Process().create_time()
        output = Path(args.output).resolve()
        output.mkdir(parents=True, exist_ok=False)
        machine.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(machine, timeout=30)
        lease, started_utc, started_clock = acquire(db, job["job_id"], job_sha, output / "receipt.json", budget, controller_created)
        phase = "reserved"
        result = {"schema_version": 2, "job_id": job["job_id"], "job_sha256": job_sha,
                  "machine": str(machine), "machine_lease": lease, "started_utc": started_utc,
                  "controller_pid": os.getpid(), "controller_created": controller_created,
                  "phase": phase, "status": "running", "argv_count": len(argv),
                  "executable_sha256": pins[Path(argv[0])], "cwd": str(cwd)}
        write_json(output / "launch.json", result)
        # Recheck the exact parsed bytes and all pinned artifacts immediately before process creation.
        if sha_file(job_path) != job_sha or any(sha_file(p) != expected for p, expected in pins.items()):
            raise ValueError("PRELAUNCH_PIN_DRIFT")
        stdout = (output / "stdout_private.log").open("wb")
        stderr = (output / "stderr_private.log").open("wb")
        stdin = open(os.devnull, "rb")
        for handle in (stdin, stdout, stderr):
            os.set_handle_inheritable(msvcrt.get_osfhandle(handle.fileno()), True)
        job_handle = wincheck(kernel.CreateJobObjectW(None, None), "CreateJobObjectW")
        limit = EXTENDED_LIMIT()
        limit.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        wincheck(kernel.SetInformationJobObject(job_handle, 9, ctypes.byref(limit), ctypes.sizeof(limit)), "SetInformationJobObject")
        startup = STARTUPINFO()
        startup.cb = ctypes.sizeof(startup)
        startup.dwFlags = 0x100  # STARTF_USESTDHANDLES
        startup.hStdInput = msvcrt.get_osfhandle(stdin.fileno())
        startup.hStdOutput = msvcrt.get_osfhandle(stdout.fileno())
        startup.hStdError = msvcrt.get_osfhandle(stderr.fileno())
        env_block = ctypes.create_unicode_buffer("".join(f"{k}={v}\0" for k, v in sorted(env.items(), key=lambda x: x[0].upper())) + "\0")
        command = ctypes.create_unicode_buffer(subprocess.list2cmdline(argv))
        wincheck(kernel.CreateProcessW(argv[0], command, None, None, True,
                                        0x4 | 0x400 | 0x8000000, env_block, str(cwd),
                                        ctypes.byref(startup), ctypes.byref(process)), "CreateProcessW")
        phase = "created_suspended"
        result.update(phase=phase, child_pid=process.dwProcessId)
        wincheck(kernel.AssignProcessToJobObject(job_handle, process.hProcess), "AssignProcessToJobObject")
        if kernel.ResumeThread(process.hThread) == 0xFFFFFFFF:
            raise OSError(ctypes.get_last_error(), "ResumeThread")
        phase = "launched"
        result["phase"] = phase
        deadline = started_clock + budget
        timed_out = False
        while True:
            if kernel.WaitForSingleObject(process.hProcess, 50) == 0:
                break
            if time.monotonic() >= deadline:
                timed_out = True
                break
        if timed_out or active_count(job_handle) != 0:
            termination_attempted = True
            wincheck(kernel.TerminateJobObject(job_handle, 1), "TerminateJobObject")
        containment_proved_empty = wait_empty(job_handle, 5)
        if containment_proved_empty:
            kernel.WaitForSingleObject(process.hProcess, 5000)
        result.update(status="terminal" if containment_proved_empty else "held",
                      phase="launched", timed_out=timed_out,
                      termination_attempted=termination_attempted,
                      containment_proved_empty=containment_proved_empty,
                      exit_code=exit_code(process.hProcess) if containment_proved_empty else None)
    except BaseException as error:
        result.update(status="aborted" if phase in ("not_launched", "reserved", "created_suspended") else "held",
                      phase=phase, fixed_error_type=type(error).__name__)
        if process is not None and process.hProcess:
            termination_attempted = True
            try:
                if job_handle and phase == "launched":
                    kernel.TerminateJobObject(job_handle, 1)
                    containment_proved_empty = wait_empty(job_handle, 5)
                else:
                    kernel.TerminateProcess(process.hProcess, 1)
                    containment_proved_empty = kernel.WaitForSingleObject(process.hProcess, 5000) == 0
            except BaseException:
                containment_proved_empty = False
            if phase == "created_suspended" and not containment_proved_empty:
                result["status"] = "held"
        result.update(termination_attempted=termination_attempted,
                      containment_proved_empty=containment_proved_empty)
    finally:
        if lease and not result:
            result = {"schema_version": 2, "status": "aborted", "phase": phase,
                      "machine_lease": lease, "fixed_error_type": "PostReserveFailure"}
        if result:
            result["finished_utc"] = now_utc().isoformat()
            if started_clock is not None:
                result["wall_seconds"] = time.monotonic() - started_clock
            for stream in (stdin, stdout, stderr):
                if stream:
                    try: stream.close()
                    except OSError: pass
            if output and output.exists():
                for name in ("stdout_private.log", "stderr_private.log"):
                    path = output / name
                    if path.exists():
                        try: result[name.replace("_private.log", "_sha256")] = sha_file(path)
                        except OSError: pass
                try: write_json(output / "receipt.json", result)
                except OSError: result["status"] = "held" if phase == "launched" else result["status"]
            if lease and db:
                try:
                    db.execute("UPDATE leases SET state=?,finished=? WHERE id=?", (
                        result["status"], result["finished_utc"], lease))
                    db.commit()
                except BaseException:
                    result["status"] = "held"
            # A surviving job is killed by close. A held lease remains until manual review.
            if process is not None:
                for handle in (process.hThread, process.hProcess):
                    if handle: kernel.CloseHandle(handle)
            if job_handle: kernel.CloseHandle(job_handle)
        if db:
            try: db.close()
            except BaseException: pass
    if result:
        summary = {k: result.get(k) for k in ("status", "phase", "job_id", "exit_code", "timed_out", "machine_lease", "fixed_error_type") if k in result}
        if output and (output / "receipt.json").exists():
            summary["receipt"] = str(output / "receipt.json")
            summary["receipt_sha256"] = sha_file(output / "receipt.json")
        print(json.dumps(summary))
        if result["status"] == "terminal":
            return 2 if result.get("timed_out") else (result.get("exit_code") or 0)
        return 3 if result["status"] == "held" else 4
    print(json.dumps({"status": "not_launched", "phase": phase}))
    return 4


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    parser.add_argument("--machine", required=True)
    parser.add_argument("--output", required=True)
    return run(parser.parse_args())


if __name__ == "__main__":
    sys.exit(main())
