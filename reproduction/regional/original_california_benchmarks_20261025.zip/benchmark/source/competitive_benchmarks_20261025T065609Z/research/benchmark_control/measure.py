"""Resource-only wrapper; numerical modules still require the conductor lease."""
import argparse, json, os, runpy, sys, time
from pathlib import Path
import psutil

ALLOWED = {
    "competitive_benchmarks.workflow",
    "research.competitive_benchmarks_validation.audit_cost_pilot_v2",
    "research.competitive_benchmarks_validation.audit_saved",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--resource-output", required=True)
    parser.add_argument("--module", choices=sorted(ALLOWED), required=True)
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    destination = Path(args.resource_output).resolve()
    if destination.exists():
        raise FileExistsError("Resource receipt already exists")
    destination.parent.mkdir(parents=True, exist_ok=True)
    process = psutil.Process()
    before = psutil.virtual_memory()
    started = time.perf_counter()
    error_type = None
    exit_status = 0
    try:
        forwarded = args.arguments[1:] if args.arguments[:1] == ["--"] else args.arguments
        sys.argv = [args.module] + forwarded
        runpy.run_module(args.module, run_name="__main__")
    except SystemExit as error:
        exit_status = error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
        raise
    except BaseException as error:
        error_type = type(error).__name__
        exit_status = 1
        raise
    finally:
        memory = process.memory_info()
        after = psutil.virtual_memory()
        receipt = {
            "schema_version": 1, "module": args.module,
            "status": "complete" if exit_status == 0 else "failed",
            "exit_status": exit_status, "fixed_error_type": error_type,
            "wall_seconds": time.perf_counter() - started,
            "peak_process_working_set_bytes": getattr(memory, "peak_wset", None),
            "peak_process_pagefile_bytes": getattr(memory, "peak_pagefile", None),
            "working_set_at_exit_bytes": memory.rss,
            "system_total_bytes": before.total,
            "system_available_before_bytes": before.available,
            "system_available_after_bytes": after.available,
            "logical_cpus": os.cpu_count(),
            "remaining_child_count": len(process.children(recursive=True)),
            "measurement_scope": "Windows kernel-maintained peaks for this single numerical process; no child aggregate",
            "thread_environment": {name: os.environ.get(name) for name in
                ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")},
        }
        with destination.open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, indent=2, allow_nan=False)

if __name__ == "__main__":
    main()
