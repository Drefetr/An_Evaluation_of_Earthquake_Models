"""Versioned resource-only wrapper; numerical work still requires the serial lease.

The accounted working-set bound is the sum of kernel-maintained individual
peaks for this Python process and live, verified Windows console hosts at the
final snapshot. It is not a simultaneous aggregate or a system-wide peak.
The serial launcher must separately prove its Job Object empty at exit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import psutil
import runpy
import sys
import time


ALLOWED = {
    "competitive_benchmarks.workflow",
    "research.competitive_benchmarks_validation.audit_cost_pilot_v2",
    "research.competitive_benchmarks_validation.audit_saved",
}
THREAD_KEYS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS")
EXPECTED_CONHOST_SHA256 = "b02ee54fb2ec69673386d41119ee8ed083a6eab3bfca6aa2155d20ce68ef8963"
SCOPE = ("Windows kernel individual peak working sets: parent plus live verified direct "
         "system conhost.exe children at final snapshot; sum of individual peaks, "
         "not simultaneous aggregate; terminated descendants not measured; "
         "serial Job Object terminal proof required separately")


class ResourceScopeError(RuntimeError):
    pass


def file_sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def positive_peak(info, name: str) -> int:
    value = getattr(info, "peak_wset", None)
    if type(value) is not int or value <= 0:
        raise ResourceScopeError(name + "_KERNEL_PEAK_UNAVAILABLE")
    return value


def allowed_system_conhost(exe: Path) -> bool:
    system_root = Path(os.environ.get("SystemRoot", os.environ.get("WINDIR", "")))
    if not system_root.is_absolute():
        raise ResourceScopeError("WINDOWS_SYSTEM_ROOT_UNAVAILABLE")
    root = system_root.resolve(strict=True)
    return exe == (root / "System32" / "conhost.exe").resolve(strict=False)


def child_metadata(parent: psutil.Process, child: psutil.Process) -> dict:
    """Check one still-live identity before and after kernel memory sampling."""
    try:
        pid = child.pid
        created = child.create_time()
        name = child.name()
        exe = Path(child.exe()).resolve(strict=True)
        ppid = child.ppid()
        if (ppid != parent.pid or name.lower() != "conhost.exe" or
                exe.name.lower() != "conhost.exe" or not allowed_system_conhost(exe)):
            raise ResourceScopeError("UNEXPECTED_RESOURCE_CHILD")
        digest = file_sha(exe)
        if digest != EXPECTED_CONHOST_SHA256:
            raise ResourceScopeError("CONHOST_BINARY_PIN_MISMATCH")
        peak = positive_peak(child.memory_info(), "CHILD")
        rss = child.memory_info().rss
        if (not child.is_running() or child.pid != pid or child.create_time() != created or
                child.ppid() != ppid or Path(child.exe()).resolve(strict=True) != exe):
            raise ResourceScopeError("RESOURCE_CHILD_IDENTITY_CHANGED")
        return {"pid": pid, "created": created, "parent_pid": ppid,
                "name": name, "exe_path": str(exe), "exe_sha256": digest,
                "peak_working_set_bytes": peak, "working_set_at_snapshot_bytes": rss}
    except psutil.AccessDenied:
        raise ResourceScopeError("RESOURCE_CHILD_ACCESS_DENIED") from None
    except psutil.NoSuchProcess:
        raise ResourceScopeError("RESOURCE_CHILD_IDENTITY_CHANGED") from None
    except OSError:
        raise ResourceScopeError("RESOURCE_CHILD_EXECUTABLE_UNREADABLE") from None


def measure_process_tree(parent: psutil.Process) -> dict:
    if os.name != "nt":
        raise ResourceScopeError("WINDOWS_KERNEL_PEAK_REQUIRED")
    try:
        identity = parent.create_time()
        parent_info = parent.memory_info()
        own_peak = positive_peak(parent_info, "PARENT")
        children = parent.children(recursive=True)
        metadata = [child_metadata(parent, child) for child in children]
        if parent.create_time() != identity:
            raise ResourceScopeError("RESOURCE_PARENT_IDENTITY_CHANGED")
        return {"peak_process_working_set_bytes": own_peak,
                "peak_own_working_set_bytes": own_peak,
                "peak_process_pagefile_bytes": getattr(parent_info, "peak_pagefile", None),
                "working_set_at_exit_bytes": parent_info.rss,
                "parent_pid": parent.pid, "parent_created": identity,
                "remaining_child_count": len(children),
                "accounted_child_count": len(metadata),
                "accounted_children": metadata,
                "peak_accounted_working_set_bytes": own_peak + sum(row["peak_working_set_bytes"] for row in metadata),
                "measurement_scope": SCOPE}
    except psutil.AccessDenied:
        raise ResourceScopeError("RESOURCE_TREE_ACCESS_DENIED") from None
    except psutil.NoSuchProcess:
        raise ResourceScopeError("RESOURCE_TREE_IDENTITY_CHANGED") from None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resource-output", required=True)
    parser.add_argument("--module", choices=sorted(ALLOWED), required=True)
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    destination = Path(args.resource_output).resolve()
    if destination.exists():
        raise FileExistsError("Resource receipt already exists")
    destination.parent.mkdir(parents=True, exist_ok=True)
    process = psutil.Process()
    before = psutil.virtual_memory()
    started = time.perf_counter()
    error_type = None
    exit_status = 0
    fatal = None
    try:
        forwarded = args.arguments[1:] if args.arguments[:1] == ["--"] else args.arguments
        sys.argv = [args.module] + forwarded
        runpy.run_module(args.module, run_name="__main__")
    except SystemExit as error:
        exit_status = error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
        fatal = error
    except BaseException as error:
        error_type = type(error).__name__
        exit_status = 1
        fatal = error
    try:
        measurement = measure_process_tree(process)
    except BaseException as error:
        measurement = {"measurement_scope": SCOPE, "measurement_error_type": type(error).__name__,
                       "measurement_error_code": str(error) if isinstance(error, ResourceScopeError) else "RESOURCE_MEASUREMENT_FAILED"}
        error_type = type(error).__name__
        exit_status = 1
        fatal = error
    after = psutil.virtual_memory()
    receipt = {"schema_version": 2, "module": args.module,
               "status": "complete" if exit_status == 0 else "failed",
               "exit_status": exit_status, "fixed_error_type": error_type,
               "wall_seconds": time.perf_counter() - started,
               "system_total_bytes": before.total,
               "system_available_before_bytes": before.available,
               "system_available_after_bytes": after.available,
               "logical_cpus": os.cpu_count(),
               "thread_environment": {name: os.environ.get(name) for name in THREAD_KEYS},
               **measurement}
    with destination.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
    if fatal is not None:
        if isinstance(fatal, SystemExit):
            raise fatal
        raise fatal
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
