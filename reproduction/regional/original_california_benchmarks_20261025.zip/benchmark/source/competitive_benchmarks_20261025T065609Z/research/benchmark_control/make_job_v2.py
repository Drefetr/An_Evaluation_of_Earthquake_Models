"""Build a pinned numerical job using resource measurement v2; do not launch it."""
import argparse, hashlib, json, math, sys
from pathlib import Path

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)

def main():
    parser=argparse.ArgumentParser()
    for name in ("run","study","root","protocol","observed-root","job-id"):
        parser.add_argument("--"+name,required=True)
    parser.add_argument("--phase",choices=("prepare","pilot","fit","score","independent_pilot","audit"),required=True)
    parser.add_argument("--budget",type=float,required=True)
    parser.add_argument("--gate")
    args=parser.parse_args()
    run,study,root,protocol,observed=map(lambda s:Path(s).resolve(),(args.run,args.study,args.root,args.protocol,args.observed_root))
    frozen=json.loads(protocol.read_text(encoding="utf-8"))
    authorities_path=run/"design/source_authorities_v1.json"
    authorities=json.loads(authorities_path.read_text(encoding="utf-8"))
    if frozen.get("status")!="frozen" or not math.isfinite(args.budget) or args.budget<=0:
        raise ValueError("Frozen protocol and positive budget required")
    if not args.job_id or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789_" for c in args.job_id):
        raise ValueError("Invalid job identifier")
    resource=run/"resources"/(args.job_id+".json")
    report=run/"reviews"/(args.job_id+".json")
    module="competitive_benchmarks.workflow"
    if args.phase in ("prepare","pilot","fit","score"):
        forwarded=["--protocol",str(protocol),"--source-protocol",authorities["old_protocol"],
            "--source-authorities",str(authorities_path),"--sealed-results",frozen["sealed_results_path"],
            "--output",str(observed),"--phase",args.phase]
        if args.gate:
            forwarded+=["--gate",str(Path(args.gate).resolve())]
        elif args.phase!="prepare":
            raise ValueError("Gate receipt required")
    else:
        module="research.competitive_benchmarks_validation."+("audit_cost_pilot_v2" if args.phase=="independent_pilot" else "audit_saved")
        forwarded=["--source-authorities",str(authorities_path),"--source-authorities-sha256",sha(authorities_path),"--output",str(report)]
        if args.phase=="independent_pilot":
            forwarded+=["--folds","0,2","--max-seconds","1200"]
        else:
            forwarded+=["--observed-root",str(observed)]
    wrapper=study/"source/research/benchmark_control/measure_v2.py"
    controller=study/"source/research/benchmark_control/run_serial_v2.py"
    argv=[str(Path(sys.executable).resolve()),"-B",str(wrapper),"--resource-output",str(resource),"--module",module,"--"]+forwarded
    pins=dict(frozen["artifact_pins"])
    extra=[protocol,authorities_path,wrapper,controller,Path(__file__).resolve(),Path(sys.executable).resolve()]
    if args.gate:extra.append(Path(args.gate).resolve())
    if observed.exists():
        extra.extend(path for path in observed.rglob("*") if path.is_file() and path.suffix in (".json",".npz"))
    for path in extra:pins[str(path.resolve())]=sha(path)
    for path,expected in pins.items():
        if sha(path)!=expected:raise ValueError("Pin drift")
    job=dict(job_id=args.job_id,argv=argv,cwd=str(study),conservative_max_seconds=args.budget,
        pins=pins,environment={"PYTHONPATH":str(study/"source")+";"+str(study/"source/research")},
        expected_machine=str(root/"research_runs/active_machine_numerical_lease.sqlite3"),
        scope="Registered benchmark "+args.phase,protocol_sha256=sha(protocol))
    assignment=dict(task_id=args.job_id,parent_id=None,kind="numerical",owner="conductor",objective=job["scope"],
        allowed_paths=[str(run/"jobs"),str(run/"processes"),str(run/"resources"),str(run/"reviews"),str(observed)],
        depends_on=[],expected_outputs=["Contained terminal receipt and local phase artifacts"],
        acceptance=["Pin identity and terminal machine lease","Independent scientific review before claims"],
        reviewer="benchmark_audit",stopping_rule="Return at completion or recorded bounded failure")
    job_path=run/"jobs"/(args.job_id+".json")
    assignment_path=run/"assignments"/(args.job_id+".json")
    write(job_path,job);write(assignment_path,assignment)
    print(json.dumps({"job":str(job_path),"assignment":str(assignment_path),"pins":len(pins),"phase":args.phase}))

if __name__=="__main__":main()
