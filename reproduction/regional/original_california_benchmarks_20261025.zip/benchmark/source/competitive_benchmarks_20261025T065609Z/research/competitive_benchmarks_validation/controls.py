"""Handcrafted independent controls; run only under the machine numerical lease."""
from __future__ import annotations
import json
import math
from pathlib import Path
import numpy as np
from scipy.integrate import dblquad,quad
from ..external_replication_validation import oracle as old
from . import oracle as O


def direct_2d_mass(bounds,parent,scale,tail):
    xl,xh,yl,yh=map(float,bounds);px,py=map(float,parent)
    f=lambda y,x:(1+((x-px)**2+(y-py)**2)/scale**2)**(-tail)
    return dblquad(f,xl,xh,lambda x:yl,lambda x:yh,
                   epsabs=2e-8,epsrel=2e-9)[0]


def direct_2d_derivatives(bounds,parent,scale,tail):
    xl,xh,yl,yh=map(float,bounds);px,py=map(float,parent)
    def integrate(kind):
        def f(y,x):
            u=((x-px)**2+(y-py)**2)/scale**2
            d=(1+u)**(-tail)
            return d*(2*tail*u/(1+u) if kind=='logell' else -math.log1p(u))
        return dblquad(f,xl,xh,lambda x:yl,lambda x:yh,
                       epsabs=2e-8,epsrel=2e-9)[0]
    return integrate('logell'),integrate('tail')


def handcrafted_raw():
    lat_edges=[32,32+5/3,32+10/3,37]
    lon_edges=[-121,-121+7/3,-121+14/3,-114]
    lat=[(lat_edges[i]+lat_edges[i+1])/2 for i in range(3)]
    lon=[(lon_edges[j]+lon_edges[j+1])/2 for j in range(3)]
    la=np.array([lat[i] for i in range(3) for j in range(3)]+[lat[1],lat[1],lat[2]])
    lo=np.array([lon[j] for i in range(3) for j in range(3)]+[lon[1],lon[1],lon[2]])
    xy=old.project(la,lo,34.5,-117.5)
    rect=old.rectangles(lat_edges,lon_edges,34.5,-117.5)
    times=np.array([10.,20.,30.,40.,50.,60.,70.,80.,90.,
                    100.,100.,120.])
    return dict(times=times,excess=np.array([.1,.2,.3,.4,.5,.6,.7,.8,.9,
                                              .2,.5,.1]),xy=xy,
                rectangles=rect,cells=old.labels(xy,rect))


def finite_difference(function, point, lower, upper, relstep=2e-5):
    """Coordinate-aware one/two-sided derivative without crossing bounds."""
    point=np.asarray(point,float);lower=np.asarray(lower,float);upper=np.asarray(upper,float)
    O.require(point.shape==lower.shape==upper.shape and np.all(lower<=point)
              and np.all(point<=upper),"GRADIENT_POINT_BOUNDS")
    f0=float(function(point));out=np.empty(len(point));kind=[]
    for j,x in enumerate(point):
        h=min(relstep*max(1.,abs(x)),.125*(upper[j]-lower[j]))
        O.require(h>0,"GRADIENT_STEP_DOMAIN")
        plus=x+h<=upper[j];minus=x-h>=lower[j]
        v=point.copy()
        if plus and minus:
            v[j]=x+h;fp=float(function(v));v[j]=x-h;fm=float(function(v))
            out[j]=(fp-fm)/(2*h);kind.append('central')
        elif plus:
            v[j]=x+h;f1=float(function(v));v[j]=x+2*h;f2=float(function(v))
            out[j]=(-3*f0+4*f1-f2)/(2*h);kind.append('forward')
        else:
            v[j]=x-h;f1=float(function(v));v[j]=x-2*h;f2=float(function(v))
            out[j]=(3*f0-4*f1+f2)/(2*h);kind.append('backward')
    return out,kind


def run_controls():
    raw=handcrafted_raw();t=raw['times'];train=t<100
    event=(t>=100)&(t<130);empty=t<0
    beta=1.8;h=15.;T0=16436.
    mass_errors=[]
    derivative_errors=[]
    for idx,scale,tail,position in [(0,2.,1.05,'center'),
                                    (4,20.,2.,'edge'),
                                    (8,500.,3.,'corner')]:
        b=raw['rectangles'][idx]
        p={'center':((b[0]+b[1])/2,(b[2]+b[3])/2),
           'edge':(b[0],(b[2]+b[3])/2),
           'corner':(b[0],b[2])}[position]
        m=O.rectangle_mass(b,p,scale,tail)
        independent=direct_2d_mass(b,p,scale,tail)
        mass_errors.append(abs(m-independent))
        O.require(abs(m-independent)<=3e-6,"ETAS_2D_MASS_CROSSCHECK")
        whole=(min(raw['rectangles'][:,0]),max(raw['rectangles'][:,1]),
               min(raw['rectangles'][:,2]),max(raw['rectangles'][:,3]))
        cell_sum=math.fsum(O.rectangle_mass(cell,p,scale,tail)
                          for cell in raw['rectangles'])
        whole_mass=O.rectangle_mass(whole,p,scale,tail)
        O.require(abs(cell_sum-whole_mass)<=2e-7*max(1,whole_mass),
                  "NINE_CELL_ETAS_MASS_CONSERVATION")
        O.require(0<whole_mass<math.pi*scale**2/(tail-1),
                  "FINITE_DOMAIN_ETAS_MASS_BOUND")
        if position=='edge':
            hstep=2e-5
            ds,dq=direct_2d_derivatives(b,p,scale,tail)
            fd_s=(O.rectangle_mass(b,p,scale*math.exp(hstep),tail)
                  -O.rectangle_mass(b,p,scale*math.exp(-hstep),tail))/(2*hstep)
            fd_q=(O.rectangle_mass(b,p,scale,tail+hstep)
                  -O.rectangle_mass(b,p,scale,tail-hstep))/(2*hstep)
            derivative_errors.extend([abs(fd_s-ds),abs(fd_q-dq)])
            O.require(ds>0 and dq<0 and max(derivative_errors)<=2e-5,
                      "ETAS_MASS_DERIVATIVE_CROSSCHECK")
    c=.2;p=1.3
    temporal_mass=quad(lambda u:(p-1)/c*(1+u/c)**(-p),0,np.inf,
                       epsabs=1e-9,epsrel=2e-10)[0]
    O.require(abs(temporal_mass-1)<=2e-8,"INFINITE_OMORI_MASS")
    p0=[-4.2,.2]
    et=[*p0,0.,math.log(.2),1.3,math.log(20.),1.6]
    no=O.evaluate_n0(p0,raw,train,event,beta,h,100.,130.,T0)
    nested=O.evaluate_etas(et,raw,train,event,beta,h,100.,130.,T0)
    nesting=max(abs(float(no[k])-float(nested[k])) for k in
                ['joint_nll','timing_logscore','conditional_zone_logscore',
                 'conditional_cell_logscore','within_cell_density_logscore',
                 'integrated_intensity','mark_logscore'])
    O.require(nesting<=1e-10,"ETAS_N0_NESTING")
    active=O.evaluate_etas([*p0,.3,math.log(.2),1.3,math.log(20.),1.6],
                           raw,train,event,beta,h,100.,130.,T0)
    O.require(math.isfinite(active['joint_nll']) and active['trigger_exposure']>0,
              "ACTIVE_ETAS_POSITIVITY")
    identity=(active['timing_logscore']+active['conditional_zone_logscore']
              +active['conditional_cell_logscore']
              +active['within_cell_density_logscore']
              +active['mark_logscore'])
    O.require(abs(identity-active['joint_logscore'])<=1e-10,
              "MARK_ONCE_AND_SCORE_DECOMPOSITION")
    quiet=O.evaluate_n0(p0,raw,train,empty,beta,h,100.,130.,T0)
    O.require(quiet['joint_logscore']==-quiet['integrated_intensity']
              and quiet['mark_logscore']==0,"QUIET_EXPOSURE")
    # Strict ties: the two events at day 100 cannot trigger one another.
    tied=(t>=100)&(t<101)
    twin=O.evaluate_etas([*p0,.3,math.log(.2),1.3,math.log(20.),1.6],
                         raw,train,tied,beta,h,100.,101.,T0)
    keep=np.arange(len(t))!=10
    single={key:(value[keep] if key in ('times','excess','xy','cells') else value)
            for key,value in raw.items()}
    single_event=(single['times']>=100)&(single['times']<101)
    single_train=single['times']<100
    one=O.evaluate_etas([*p0,.3,math.log(.2),1.3,math.log(20.),1.6],
                        single,single_train,single_event,beta,h,100.,101.,T0)
    tie_error=abs(twin['event_log_point_intensity'][0]-one['event_log_point_intensity'][0])
    O.require(tie_error<=1e-12,"SAME_TIME_EXCLUSION")
    early=O.evaluate_etas([*p0,.3,math.log(.2),1.3,math.log(20.),1.6],
                          raw,train,empty,beta,h,0.,5.,T0)
    O.require(early['trigger_exposure']==0 and
              early['joint_logscore']==-early['integrated_intensity'],
              "ZERO_PARENT_CONTROL")
    return dict(passed=True,fixtures=11,max_mass_absolute_error=max(mass_errors),
                max_mass_derivative_absolute_error=max(derivative_errors),
                infinite_temporal_mass_absolute_error=abs(temporal_mass-1),
                n0_nesting_max_absolute_error=nesting,
                positive_active_intensity=True,quiet_exposure=True,
                same_time_exclusion_max_absolute_error=tie_error,
                zero_parent_control=True)


def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    args=parser.parse_args()
    try: result=run_controls()
    except Exception as error:
        result=dict(passed=False,fixed_error_code='BENCHMARK_CONTROLS_FAILED',
                    error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
