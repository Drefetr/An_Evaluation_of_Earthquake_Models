"""Fail-closed local reconstruction of every saved benchmark fit/score record.

The enclosing driver must verify original-source and artifact hashes before
calling these functions. Raw rows, parameters and component arrays stay inside
the local process; only scalar discrepancy/count receipts are returned upward.
"""
from __future__ import annotations
import math
import hashlib
from pathlib import Path
import numpy as np
from ..external_replication_validation import nuisance_oracle as N
from ..external_replication_validation import oracle as old
from ..external_replication_validation.raw_input import fit_beta
from . import oracle as O
from .controls import finite_difference

BOUNDS={
    'no_trigger':[(-12.,0.),(-2.,2.)],
    'independent_etas':[(-12.,0.),(-2.,2.),(0.,.98),
        (math.log(.0001),math.log(20.)),(1.01,2.5),
        (math.log(2.),math.log(500.)),(1.05,3.)],
}
SCORE_KEYS=(
    'joint_nll','joint_logscore','timing_logscore',
    'conditional_zone_logscore','conditional_cell_logscore',
    'within_cell_density_logscore','conditional_location_logscore',
    'mark_logscore','integrated_intensity','trigger_exposure',
    'cell_integrated_intensity','event_log_point_intensity_sum',
    'event_log_ground_intensity_sum','event_log_point_intensity',
    'event_log_cell_intensity','event_log_zone_intensity',
    'event_log_ground_intensity',
)


def _equal(a,b,code,tol=1e-12):
    aa,bb=np.asarray(a),np.asarray(b)
    O.require(aa.shape==bb.shape and np.isfinite(aa).all()
              and np.isfinite(bb).all() and
              np.max(abs(aa-bb),initial=0)<=tol,code)


def _check_parameters(pars,model):
    bounds=BOUNDS[model]
    O.require(isinstance(pars,list) and len(pars)==len(bounds)
              and np.isfinite(pars).all()
              and all(lo<=v<=hi for v,(lo,hi) in zip(pars,bounds)),
              'CANDIDATE_PARAMETER_BOUNDS')


def _expected_starts(model,ntrain,days):
    ap=float(np.clip(math.log(ntrain/days),-12,0))
    if model=='no_trigger':
        starts=[[ap,d] for d in [-2,-1,-.5,-.2,.2,.5,1,2]]
        return starts,[[ap,0.]]
    a0=float(np.clip(math.log(.6*ntrain/days),-11.5,-.1))
    rows=[(0,-.2,.2,.0001,1.1,2,1.1),
          (0,-.2,.6,.001,1.3,5,1.5),
          (0,.2,.2,.01,1.1,15,2),
          (0,.2,.6,.1,1.3,50,2.5),
          (-.5,-.2,.2,1,1.7,150,2),
          (-.5,-.2,.6,20,2.5,500,1.5),
          (-.5,.2,.2,.01,2.5,15,3),
          (-.5,.2,.6,.1,1.01,50,1.05)]
    starts=[[a0+off,d,n,math.log(c),p,math.log(ell),q]
            for off,d,n,c,p,ell,q in rows]
    return starts,[[ap,0.,0.,0.,1.3,math.log(50.),2.]]


def _evaluate(model,pars,raw,train,event,beta,h,start,end,T0):
    if model=='no_trigger':
        result=O.evaluate_n0(pars,raw,train,event,beta,h,start,end,T0)
    else:
        result=O.evaluate_etas(pars,raw,train,event,beta,h,start,end,T0)
    return O.score_record(result,np.asarray(raw['cells'])[event])


def compare_saved(saved,expected,*,scalar_only=False):
    """Compare all declared terms; reject absent required score components."""
    required=('joint_nll',) if scalar_only else SCORE_KEYS
    O.require(isinstance(saved,dict) and all(key in saved for key in required),
              'SAVED_SCORE_COMPONENT_MISSING')
    maximum=0.;checked=0
    for key in required:
        a=np.asarray(saved[key],float);e=np.asarray(expected[key],float)
        O.require(a.shape==e.shape and np.isfinite(a).all(),
                  'SAVED_SCORE_SHAPE_OR_NONFINITE')
        err=float(np.max(abs(a-e),initial=0.))
        O.require(err<=1e-4,'INDEPENDENT_SCORE_DISCREPANCY')
        maximum=max(maximum,err);checked+=1
    # Every extra numeric production term must be a known derived field and
    # agree as well; unknown fields are provenance/status only, never accepted
    # as numerical score substitutions.
    for key in set(saved)&set(expected)-set(required):
        a=np.asarray(saved[key],float);e=np.asarray(expected[key],float)
        if a.shape!=e.shape:continue
        O.require(np.isfinite(a).all(), 'EXTRA_SCORE_NONFINITE')
        err=float(np.max(abs(a-e),initial=0.))
        O.require(err<=1e-4,'EXTRA_SCORE_DISCREPANCY')
        maximum=max(maximum,err);checked+=1
    return maximum,checked


def audit_nuisance(raw,case,reported_beta,reported_h,reported_loo):
    t=np.asarray(raw['times'],float)
    train=(t>=case['train_start'])&(t<case['train_end'])
    O.require(int(train.sum())==case['n_train'] and
              np.all(np.bincount(np.asarray(raw['cells'])[train]//3,minlength=3)>=30),
              'RAW_TRAINING_DENOMINATOR')
    beta=fit_beta(np.asarray(raw['excess'])[train])
    O.require(abs(beta-reported_beta)<=1e-10,'RAW_BETA_IDENTITY')
    loo=N.select_bandwidth(np.asarray(raw['xy'])[train],raw['rectangles'])
    O.require(loo['selected_bandwidth']==reported_h and
              len(loo['candidates'])==len(reported_loo)==6,
              'RAW_BANDWIDTH_SELECTION')
    maximum=0.
    for expected,actual in zip(loo['candidates'],reported_loo):
        O.require(expected['bandwidth']==actual['bandwidth']
                  and expected['n_loo']==actual['n_loo'],
                  'RAW_BANDWIDTH_CANDIDATE_IDENTITY')
        err=abs(expected['loo_logscore']-actual['loo_logscore'])
        O.require(err<=1e-4,'RAW_BANDWIDTH_LOO_DISCREPANCY')
        maximum=max(maximum,err)
    return train,beta,reported_h,maximum


def audit_fit(fit,raw,case,beta,h,*,nested_n0=None):
    """Reconstruct all accepted candidates, finite solver returns and floors."""
    model=fit['model'];O.require(model in BOUNDS,'FIT_MODEL_ROSTER')
    O.require(fit['procedure_id']==case['case_id']+'__'+
              ('N0' if model=='no_trigger' else 'EP'),
              'FIT_PROCEDURE_ID')
    O.require(fit['status']=='complete' and fit['complete'] is True,
              'FIT_INCOMPLETE')
    _equal(fit['bounds'],BOUNDS[model],'FIT_BOUNDS',0)
    t=np.asarray(raw['times'],float)
    start,end,T0=[float(case[k]) for k in ('train_start','train_end','T0')]
    train=(t>=start)&(t<end);event=train
    expected_starts,expected_floors=_expected_starts(model,int(train.sum()),end-start)
    if model=='independent_etas':
        O.require(nested_n0 is not None,'NESTED_N0_REQUIRED')
        _check_parameters(nested_n0,'no_trigger')
        expected_floors.append([*nested_n0,0.,0.,1.3,math.log(50.),2.])
    slots=fit['slots'];candidates=fit['candidates']
    nf=len(expected_floors)
    O.require(len(slots)==nf+8 and len(candidates)==nf+8,
              'FIT_SLOT_CANDIDATE_DENOMINATOR')
    O.require([s['kind'] for s in slots]==['floor']*nf+['start']*8,
              'FIT_SLOT_ORDER')
    cache={};maximum=0.;checks=0;returns=0
    def evaluate(pars):
        key=tuple(pars)
        if key not in cache:
            cache[key]=_evaluate(model,pars,raw,train,event,beta,h,start,end,T0)
        return cache[key]
    for i,(slot,expected) in enumerate(zip(slots,expected_floors+expected_starts)):
        _check_parameters(slot['pars'],model)
        _equal(slot['pars'],expected,'PRESCRIBED_START_OR_FLOOR',2e-12)
        arm='N0' if model=='no_trigger' else 'EP'
        suffix=('floor_constant' if i==0 else 'floor_N0') if i<nf else f'start{i-nf}'
        O.require(slot['id']==f"{case['case_id']}__{arm}__{suffix}",
                  'PRESCRIBED_SLOT_ID')
        O.require(slot['ordinal']==i and slot['status']=='complete',
                  'START_OR_FLOOR_STATUS')
        if i<nf:
            O.require(slot['attempts']==[],'FLOOR_HAS_SOLVER_ATTEMPT')
        else:
            attempts=slot['attempts']
            O.require(len(attempts) in (1,2),'SOLVER_ATTEMPT_DENOMINATOR')
            O.require(sum(bool(a.get('accepted')) for a in attempts)==1,
                      'ONE_ACCEPTED_RETURN_PER_START')
            for tier,attempt in enumerate(attempts):
                O.require(attempt['tier']==tier and
                          attempt['method']==('L-BFGS-B' if tier==0 else 'Powell'),
                          'SOLVER_TIER_IDENTITY')
                options=({'maxiter':200,'maxfun':20000,'maxls':200,
                          'ftol':1e-10,'gtol':2e-6} if tier==0 else
                         {'maxiter':400,'maxfev':5000,'xtol':1e-6,'ftol':1e-10})
                O.require(attempt['options']==options,
                          'FROZEN_SOLVER_OPTIONS')
                _equal(attempt['start'],expected,'SOLVER_ORIGINAL_START',2e-12)
                initial=evaluate(expected)['joint_nll']
                O.require(abs(attempt['initial_nll']-initial)<=1e-4,
                          'ORIGINAL_START_NLL')
                if tier:
                    O.require(attempts[0].get('accepted') is False,
                              'RECOVERY_ONLY_ON_FAILURE')
                if attempt.get('finite_feasible'):
                    _check_parameters(attempt['pars'],model)
                    score=evaluate(attempt['pars'])
                    err,count=compare_saved(attempt['training_evaluation'],score,scalar_only=True)
                    fine_err,fine_count=compare_saved(attempt['training_fine_evaluation'],score,scalar_only=True)
                    maximum=max(maximum,err);checks+=count;returns+=1
                    maximum=max(maximum,fine_err);checks+=fine_count
                    O.require(attempt['quadrature_order_delta_nll']<=1e-4,
                              'SOLVER_RETURN_QUADRATURE_ORDER')
                    O.require(abs(attempt['reported_nll']-score['joint_nll'])<=1e-7
                              if attempt.get('accepted') else True,
                              'ACCEPTED_SOLVER_RETURN_NLL')
    seen=set()
    for candidate in candidates:
        identity=candidate['candidate_id']
        O.require(identity not in seen,'DUPLICATE_CANDIDATE_ID');seen.add(identity)
        _check_parameters(candidate['pars'],model)
        expected=evaluate(candidate['pars'])
        err,count=compare_saved(candidate['training_evaluation'],expected,scalar_only=True)
        fine_err,fine_count=compare_saved(candidate['training_fine_evaluation'],expected,scalar_only=True)
        maximum=max(maximum,err,fine_err);checks+=count+fine_count
        O.require(candidate['quadrature_order_delta_nll']<=1e-4,
                  'CANDIDATE_QUADRATURE_ORDER')
        O.require(candidate['eligible_provisional'] is True and
                  candidate['schedule_ordinal'] in range(len(slots)),
                  'CANDIDATE_SELECTION_ELIGIBILITY')
        slot=slots[candidate['schedule_ordinal']]
        O.require(candidate['candidate_id']==slot['candidate_id']
                  and candidate['kind']==('floor' if slot['kind']=='floor' else 'solver'),
                  'CANDIDATE_SLOT_LINEAGE')
        if slot['kind']=='floor':
            _equal(candidate['pars'],slot['pars'],'FLOOR_CANDIDATE_PARAMETERS',0)
        else:
            accepted=[a for a in slot['attempts'] if a.get('accepted')]
            O.require(len(accepted)==1 and candidate['tier']==accepted[0]['tier']
                      and candidate['slot_id']==slot['id'],
                      'ACCEPTED_RETURN_CANDIDATE_IDENTITY')
            _equal(candidate['pars'],accepted[0]['pars'],
                   'ACCEPTED_RETURN_CANDIDATE_PARAMETERS',0)
        expected_flags=[dict(coordinate=j,lower=abs(v-lo)<=1e-7,
                             upper=abs(v-hi)<=1e-7,fixed=lo==hi)
                        for j,(v,(lo,hi)) in enumerate(zip(candidate['pars'],BOUNDS[model]))]
        O.require(candidate['boundary_flags']==expected_flags,
                  'CANDIDATE_BOUNDARY_FLAGS')
    O.require({s['candidate_id'] for s in slots}==seen,
              'CANDIDATE_SLOT_BINDING')
    winner=min(candidates,key=lambda c:(c['training_evaluation']['joint_nll'],
                                         c['schedule_ordinal'],c['candidate_id']))
    O.require(fit['selected_candidate_id']==winner['candidate_id']
              and fit['selected']==winner,'TRAINING_ONLY_MINIMUM_SELECTION')
    near=[c['candidate_id'] for c in candidates
          if c['training_evaluation']['joint_nll']<=
             winner['training_evaluation']['joint_nll']+4e-4]
    O.require(fit['near_optimal_candidate_ids']==near,
              'FULL_NEAR_OPTIMAL_CANDIDATES')
    independent_min=min(cache[tuple(c['pars'])]['joint_nll'] for c in candidates)
    O.require(cache[tuple(winner['pars'])]['joint_nll']<=independent_min+2e-4,
              'INDEPENDENT_TRAINING_SELECTION_DISCREPANCY')
    return dict(passed=True,procedure_id=fit['procedure_id'],
                starts=8,floors=nf,candidates=len(candidates),
                finite_solver_returns=returns,score_component_checks=checks,
                maximum_absolute_score_error=maximum,
                near_optimal_count=len(near))


def audit_gradient(record,raw,case,beta,h,*,phase):
    """Separate gradient check at registered representative coordinates."""
    model=record['model'];pars=np.asarray(record['pars'],float)
    bounds=np.asarray(BOUNDS[model],float)
    t=np.asarray(raw['times'],float)
    train=(t>=case['train_start'])&(t<case['train_end'])
    start,end=(case['train_start'],case['train_end']) if phase=='train' else (case['test_start'],case['test_end'])
    event=(t>=start)&(t<end)
    function=lambda x:_evaluate(model,x,raw,train,event,beta,h,start,end,case['T0'])['joint_nll']
    grad0,kinds=finite_difference(function,pars,bounds[:,0],bounds[:,1],2e-5)
    grad1,_=finite_difference(function,pars,bounds[:,0],bounds[:,1],1e-5)
    analytic=np.asarray(record['gradient'],float)
    O.require(analytic.shape==grad0.shape and np.isfinite(analytic).all(),
              'ANALYTIC_GRADIENT_SHAPE')
    scale=1+np.abs(grad1)
    tolerance=np.array([1e-3 if kind!='central' else 2e-4 for kind in kinds])*scale
    stabilization=np.abs(grad0-grad1)
    O.require(np.all(stabilization<=tolerance),
              'FINITE_DIFFERENCE_UNSTABLE')
    error=np.abs(analytic-grad1)
    O.require(np.all(error<=tolerance),'INDEPENDENT_GRADIENT_DISCREPANCY')
    return dict(passed=True,coordinates=len(pars),
                maximum_gradient_criterion_ratio=float(np.max(error/tolerance)),
                maximum_stabilization_ratio=float(np.max(stabilization/tolerance)),
                boundary_coordinates=sum(kind!='central' for kind in kinds))


def _sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def audit_forecast(score,fit,fit_path,raw,case,beta,h):
    """Audit every held-out candidate and finite solver return in one fold."""
    O.require(score['case_id']==case['case_id'] and
              score['fit_path']==str(Path(fit_path).resolve()) and
              score['fit_sha256']==_sha(fit_path) and
              score['selected_candidate_id']==fit['selected_candidate_id'] and
              score['near_optimal_candidate_ids']==fit['near_optimal_candidate_ids'],
              'FORECAST_FROZEN_TRAINING_BINDING')
    model=fit['model'];arm='N0' if model=='no_trigger' else 'EP'
    O.require(score['arm']==arm and
              score['status']=='provisional_awaiting_independent_audit',
              'FORECAST_STATUS')
    t=np.asarray(raw['times'],float)
    train=(t>=case['train_start'])&(t<case['train_end'])
    event=(t>=case['test_start'])&(t<case['test_end'])
    nt=int(event.sum())
    O.require(nt==case['n_test'] and score['feature']['n_events']==nt,
              'FORECAST_TARGET_DENOMINATOR')
    cache={};maximum=0.;checks=0
    def evaluate(pars):
        key=tuple(pars)
        if key not in cache:
            cache[key]=_evaluate(model,pars,raw,train,event,beta,h,
                case['test_start'],case['test_end'],case['T0'])
        return cache[key]
    saved_candidates=score['all_candidate_forecasts']
    O.require(len(saved_candidates)==len(fit['candidates']) and
              [r['candidate_id'] for r in saved_candidates]==
              [r['candidate_id'] for r in fit['candidates']],
              'ALL_FORECAST_CANDIDATES')
    for saved,candidate in zip(saved_candidates,fit['candidates']):
        O.require(saved['pars']==candidate['pars'] and
                  saved['training_joint_nll']==candidate['training_evaluation']['joint_nll']
                  and saved['kind']==candidate['kind'],
                  'FORECAST_CANDIDATE_LINEAGE')
        expected=evaluate(saved['pars'])
        for key in ('forecast','fine_forecast'):
            err,count=compare_saved(saved[key],expected)
            maximum=max(maximum,err);checks+=count
        O.require(saved['quadrature_order_delta_nll']<=1e-4 and
                  abs(saved['quadrature_order_delta_nll']-
                      abs(saved['forecast']['joint_nll']-
                          saved['fine_forecast']['joint_nll']))<=1e-12,
                  'FORECAST_QUADRATURE_ORDER')
    returns=[(slot,attempt) for slot in fit['slots']
             for attempt in slot['attempts'] if attempt.get('finite_feasible')]
    saved_returns=score['all_solver_return_forecasts']
    O.require(len(saved_returns)==len(returns),
              'ALL_SOLVER_RETURN_FORECASTS')
    for saved,(slot,attempt) in zip(saved_returns,returns):
        O.require(saved['slot_id']==slot['id'] and saved['tier']==attempt['tier']
                  and saved['accepted']==attempt['accepted']
                  and saved['pars']==attempt['pars'],
                  'SOLVER_RETURN_FORECAST_LINEAGE')
        expected=evaluate(saved['pars'])
        for key in ('forecast','fine_forecast'):
            err,count=compare_saved(saved[key],expected)
            maximum=max(maximum,err);checks+=count
        O.require(saved['quadrature_order_delta_nll']<=1e-4,
                  'SOLVER_RETURN_FORECAST_QUADRATURE')
    selected=next(r for r in saved_candidates
                  if r['candidate_id']==fit['selected_candidate_id'])
    O.require(score['forecast']==selected['forecast'],
              'SELECTED_FORECAST_BINDING')
    near=[r for r in saved_candidates
          if r['candidate_id'] in fit['near_optimal_candidate_ids']]
    O.require(len(near)>0,'EMPTY_NEAR_OPTIMAL_POOL')
    spread=(max(r['forecast']['joint_logscore'] for r in near)
            -min(r['forecast']['joint_logscore'] for r in near))/nt
    independent_spread=(max(evaluate(r['pars'])['joint_logscore'] for r in near)
                        -min(evaluate(r['pars'])['joint_logscore'] for r in near))/nt
    O.require(spread<.01 and abs(score['forecast_spread_nats_per_event']-spread)<=1e-12
              and abs(independent_spread-spread)<=2e-4/nt,
              'NEAR_OPTIMAL_FORECAST_SENSITIVITY')
    return dict(passed=True,case_id=case['case_id'],arm=arm,
                target_events=nt,candidate_forecasts=len(saved_candidates),
                solver_return_forecasts=len(saved_returns),
                near_optimal_forecasts=len(near),
                score_component_checks=checks,
                maximum_absolute_score_error=maximum,
                near_optimal_spread_nats_per_event=spread)


def audit_sealed_oc(old_case,oc_reference,raw,case,beta,h):
    """Reconstruct the archived O-C selected forecast without fitting it."""
    O.require(old_case['case']['case_id']==case['case_id']
              and old_case['status']=='complete'
              and old_case['n_train']==case['n_train']
              and old_case['n_test']==case['n_test']
              and abs(old_case['beta']-beta)<=1e-10
              and old_case['kde_selection']['selected_bandwidth']==h,
              'SEALED_OC_NUISANCE_AND_POPULATION')
    model=old_case['models']['Omori_smooth_cont']
    pars=model['selected']['pars']
    O.require(len(pars)==5 and np.isfinite(pars).all(),
              'SEALED_OC_SELECTED_PARAMETERS')
    O.require(oc_reference['case_id']==case['case_id']
              and oc_reference['selected_candidate_id']==model['selected']['candidate_id']
              and oc_reference['selected_training_fit_sha256']==model['training_fit_sha256']
              and oc_reference['n_test']==case['n_test']
              and abs(oc_reference['beta']-beta)<=1e-10
              and oc_reference['bandwidth_km']==h,
              'SEALED_OC_REFERENCE_BINDING')
    t=np.asarray(raw['times'],float);q=np.asarray(raw['excess'],float)
    train=(t>=case['train_start'])&(t<case['train_end'])
    event=(t>=case['test_start'])&(t<case['test_end'])
    parent=t<case['test_end']
    pi=old.reference_mass(raw['cells'],train)
    _equal(old_case['reference_pi'],pi,'SEALED_OC_REFERENCE_MASS',1e-12)
    sigma=float(old_case['selected_sigma'])
    geometry=old.geometry(np.asarray(raw['xy'])[parent],
                          np.asarray(raw['xy'])[event],
                          np.asarray(raw['xy'])[train],
                          np.asarray(raw['rectangles']),pi,sigma,h,'continuous')
    expected=O.score_record(old.evaluate('Omori',pars,t[parent],q[parent],
                        t[event],q[event],beta,case['test_start'],
                        case['test_end'],case['T0'],geometry),
                        np.asarray(raw['cells'])[event])
    saved=dict(model['forecast'])
    saved['joint_nll']=-saved['joint_logscore']
    maximum,checks=compare_saved(saved,expected)
    for key,value in oc_reference['forecast'].items():
        O.require(key in saved and np.asarray(value).shape==np.asarray(saved[key]).shape
                  and np.max(abs(np.asarray(value)-np.asarray(saved[key])),initial=0)==0,
                  'SEALED_OC_REFERENCE_SCORE')
    return dict(passed=True,case_id=case['case_id'],
                score_component_checks=checks,
                maximum_absolute_score_error=maximum,
                target_events=case['n_test'])
