"""Direct-history oracle for California n=0 and conventional ETAS benchmarks.

Private event arrays are returned only to local audit programs. This module never
loads a production binary, feature cache, fit artifact, or catalogue parser.
The earlier independently authored external_replication_validation oracle is
used solely for projection, p=2 background quadrature, and archived O-C replay.
"""
from __future__ import annotations

from functools import lru_cache
import math
import numpy as np
from scipy.integrate import quad
from scipy.special import beta as beta_function, betainc
from ..external_replication_validation import oracle as old


def require(condition, code):
    if not bool(condition):
        raise ValueError(code)


def _primitive_y(x, y, scale, tail):
    """Integral from zero to y of (1+(x²+v²)/scale²)^(-tail)."""
    if y == 0:
        return 0.0
    a = 1.0 + (x / scale) ** 2
    u = abs(y) / (scale * math.sqrt(a))
    z = 1.0 - 1.0 / (1.0 + u * u)
    return math.copysign(
        0.5 * scale * a ** (0.5 - tail)
        * beta_function(0.5, tail - 0.5)
        * betainc(0.5, tail - 0.5, z), y)


def _inner_mass(x, bottom, top, scale, tail):
    """Stable positive y interval, including far same-side rectangles."""
    if top <= 0:
        return _inner_mass(x,-top,-bottom,scale,tail)
    if bottom >= 0:
        a=1.0+(x/scale)**2
        if bottom >= scale*math.sqrt(a):
            def surviving(y):
                u=y/(scale*math.sqrt(a))
                z=1.0/(1.0+u*u)
                return (.5*scale*a**(0.5-tail)
                        *beta_function(.5,tail-.5)
                        *betainc(tail-.5,.5,z))
            value=surviving(bottom)-surviving(top)
        else:
            value=_primitive_y(x,top,scale,tail)-_primitive_y(x,bottom,scale,tail)
    else:
        value=_primitive_y(x,top,scale,tail)-_primitive_y(x,bottom,scale,tail)
    if value <= 0:
        value=quad(lambda y:(1+(x*x+y*y)/scale**2)**(-tail),
                   bottom,top,epsabs=1e-12,epsrel=2e-11,limit=80)[0]
    return value


@lru_cache(maxsize=300000)
def _rectangle_mass(bounds, parent, scale, tail):
    """Positive finite-rectangle D mass by independent 1D quadrature.

    The inner antiderivative uses the regularized incomplete beta function;
    the outer x integral is split at the parent and local scale transitions.
    """
    xl, xh, yl, yh = bounds
    px, py = parent
    require(xh > xl and yh > yl and scale > 0 and tail > 1,
            "INVALID_ETAS_RECTANGLE_OR_KERNEL")
    lo, hi, bottom, top = xl-px, xh-px, yl-py, yh-py
    cuts = {lo, hi}
    for c in (0., -scale, scale, -4*scale, 4*scale,
              -16*scale, 16*scale):
        if lo < c < hi:
            cuts.add(c)
    edges = sorted(cuts)
    def cross(x):
        return _inner_mass(x, bottom, top, scale, tail)
    value = math.fsum(quad(cross, a, b, epsabs=2e-9/max(1,len(edges)-1),
                           epsrel=2e-11, limit=120)[0]
                      for a,b in zip(edges[:-1], edges[1:]))
    require(value > 0 and math.isfinite(value), "INVALID_ETAS_RECTANGLE_MASS")
    return value


def rectangle_mass(bounds, parent, scale, tail):
    return _rectangle_mass(tuple(map(float,bounds)), tuple(map(float,parent)),
                           float(scale), float(tail))


def etas_geometry(raw, train_mask, parent_mask, event_mask, bandwidth, scale, tail):
    """Reconstruct the normalized spatial law and smooth background from rows."""
    xy = np.asarray(raw['xy'], float)
    rect = np.asarray(raw['rectangles'], float)
    parent = xy[parent_mask]
    events = xy[event_mask]
    train = xy[train_mask]
    labels = np.asarray(raw['cells'], int)
    pi = old.reference_mass(labels, train_mask)
    area = (rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2])
    kde_mass = np.array([[old.rectangle_mass(b,p,bandwidth)[0] for b in rect]
                         for p in train])
    kde_z = kde_mass.sum(axis=1)
    bg_cell = .05*pi + .95*np.mean(kde_mass/kde_z[:,None], axis=0)
    offspring_mass = np.array([[rectangle_mass(b,p,scale,tail) for b in rect]
                               for p in parent]).reshape(len(parent),len(rect))
    offspring_z = offspring_mass.sum(axis=1)
    offspring_cell = offspring_mass/offspring_z[:,None]
    require(np.all(kde_z > 0) and np.all(offspring_z > 0)
            and abs(bg_cell.sum()-1) < 2e-12
            and np.max(abs(offspring_cell.sum(axis=1)-1),initial=0) < 2e-12,
            "SPATIAL_NORMALIZATION_FAILURE")
    return dict(parent_xy=parent, event_xy=events, training_xy=train, rect=rect,
                event_cell=labels[event_mask], pi=pi, area=area,
                bg_cell=bg_cell, kde_z=kde_z, offspring_z=offspring_z,
                offspring_cell=offspring_cell, bandwidth=bandwidth,
                scale=scale, tail=tail)


def _background(points, cells, geometry):
    density = geometry['pi']/geometry['area']
    kde = old.kernel(points, geometry['training_xy'], geometry['bandwidth'])
    return .05*density[cells] + .95*np.mean(
        kde/geometry['kde_z'][None,:], axis=1)


def _finish(log_point, log_ground, log_cell, log_zone, cell_comp,
            immigrant, trigger_base, branching, beta, event_excess):
    lp,lg,lc,lz = [np.asarray(x,float) for x in
                   (log_point,log_ground,log_cell,log_zone)]
    exposure = immigrant+branching*trigger_base
    mark = len(event_excess)*math.log(beta)-beta*math.fsum(event_excess)
    cell_comp = np.asarray(cell_comp,float)
    require(abs(math.fsum(cell_comp)-exposure) <= 2e-10*max(1.,exposure),
            "COMPENSATOR_MASS_FAILURE")
    return dict(joint_nll=exposure-math.fsum(lp)-mark,
                joint_logscore=math.fsum(lp)-exposure+mark,
                timing_logscore=math.fsum(lg)-exposure,
                conditional_zone_logscore=math.fsum(lz-lg),
                conditional_cell_logscore=math.fsum(lc-lz),
                within_cell_density_logscore=math.fsum(lp-lc),
                mark_logscore=mark, integrated_intensity=exposure,
                immigrant_exposure=immigrant, trigger_exposure=trigger_base,
                cell_integrated_intensity=cell_comp,
                event_log_point_intensity=lp,
                event_log_ground_intensity=lg,
                event_log_cell_intensity=lc,
                event_log_zone_intensity=lz)


def evaluate_n0(parameters, raw, train_mask, event_mask, beta, bandwidth,
                start, end, T0):
    """Exact n=0 joint and decomposed proper score from raw chronology."""
    a,d = map(float, parameters)
    require(math.isfinite(a) and math.isfinite(d) and beta>0,
            "N0_PARAMETER_DOMAIN")
    t = np.asarray(raw['times'],float)
    q = np.asarray(raw['excess'],float)
    te = t[event_mask]
    rect = np.asarray(raw['rectangles'],float)
    pi = old.reference_mass(raw['cells'],train_mask)
    area = (rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2])
    train = np.asarray(raw['xy'])[train_mask]
    F = np.array([[old.rectangle_mass(b,p,bandwidth)[0] for b in rect]
                  for p in train])
    Z = F.sum(axis=1)
    require(np.all(Z>0),"N0_BACKGROUND_MASS")
    cell_bg = .05*pi+.95*np.mean(F/Z[:,None],axis=0)
    cells = np.asarray(raw['cells'])[event_mask]
    point_bg = .05*(pi/area)[cells]+.95*np.mean(
        old.kernel(np.asarray(raw['xy'])[event_mask],train,bandwidth)/Z[None,:],axis=1)
    mu = np.exp(a+d*(2*te/T0-1))
    exposure,_ = old.immigrant_integral(a,d,start,end,T0)
    require(np.all(mu>0) and np.all(point_bg>0) and np.all(cell_bg>0),
            "N0_POSITIVE_INTENSITY")
    zone_bg = cell_bg.reshape(3,3).sum(axis=1)
    return _finish(np.log(mu*point_bg),np.log(mu),np.log(mu*cell_bg[cells]),
                   np.log(mu*zone_bg[cells//3]),exposure*cell_bg,
                   exposure,0.,0.,beta,q[event_mask])


def evaluate_etas(parameters, raw, train_mask, event_mask, beta, bandwidth,
                  start, end, T0, chunk=64):
    """Raw direct-history ETAS score, with Omori mass on [0,infinity)."""
    a,d,n,logc,p,logell,tail = map(float,parameters)
    c,ell = math.exp(logc),math.exp(logell)
    require(np.isfinite(parameters).all() and n>=0 and c>0 and p>1
            and ell>0 and tail>1 and beta>0,"ETAS_PARAMETER_DOMAIN")
    t=np.asarray(raw['times'],float);q=np.asarray(raw['excess'],float)
    parent=t<end;tp=t[parent];qp=q[parent]
    te=t[event_mask];qe=q[event_mask]
    require(np.all(np.diff(t)>=0) and np.all(te>=start) and np.all(te<end)
            and np.all(tp<end),"ETAS_CHRONOLOGY")
    geo=etas_geometry(raw,train_mask,parent,event_mask,bandwidth,ell,tail)
    fert=.3*np.exp(.7*beta*qp)
    lower=np.maximum(start-tp,0.)
    upper=end-tp
    def survival(v): return np.exp((1-p)*np.log1p(v/c))
    J=survival(lower)*(-np.expm1((1-p)*np.log1p((upper-lower)/(c+lower))))
    trigger_base=float(fert@J)
    immigrant,_=old.immigrant_integral(a,d,start,end,T0)
    cell_comp=immigrant*geo['bg_cell']+n*((fert*J)@geo['offspring_cell'])
    lp=np.empty(len(te));lg=np.empty(len(te));lc=np.empty(len(te));lz=np.empty(len(te))
    zone_mass=geo['offspring_cell'].reshape(len(tp),3,3).sum(axis=2)
    bg_zone=geo['bg_cell'].reshape(3,3).sum(axis=1)
    for begin in range(0,len(te),chunk):
        stop=min(begin+chunk,len(te));rows=np.arange(begin,stop)
        lag=te[rows,None]-tp[None,:]
        temporal=np.zeros_like(lag)
        valid=lag>0
        temporal[valid]=(p-1)/c*np.exp(-p*np.log1p(lag[valid]/c))
        weighted=temporal*fert[None,:]
        dr2=np.sum((geo['event_xy'][rows,None,:]-geo['parent_xy'][None,:,:])**2,axis=2)
        spatial=(1+dr2/ell**2)**(-tail)/geo['offspring_z'][None,:]
        cells=geo['event_cell'][rows]
        mu=np.exp(a+d*(2*te[rows]/T0-1))
        point=mu*_background(geo['event_xy'][rows],cells,geo)+n*np.sum(weighted*spatial,axis=1)
        ground=mu+n*np.sum(weighted,axis=1)
        cell=mu*geo['bg_cell'][cells]+n*np.sum(weighted*geo['offspring_cell'][:,cells].T,axis=1)
        zone=mu*bg_zone[cells//3]+n*np.sum(weighted*zone_mass[:,cells//3].T,axis=1)
        require(np.all(point>0) and np.all(ground>0) and np.all(cell>0)
                and np.all(zone>0),"ETAS_POSITIVE_INTENSITY")
        lp[rows]=np.log(point);lg[rows]=np.log(ground)
        lc[rows]=np.log(cell);lz[rows]=np.log(zone)
    return _finish(lp,lg,lc,lz,cell_comp,immigrant,trigger_base,n,beta,qe)


def score_record(result, cells):
    """Expand independent core terms to saved production score vocabulary."""
    v=dict(result)
    v['conditional_location_logscore']=(v['conditional_zone_logscore']
        +v['conditional_cell_logscore']+v['within_cell_density_logscore'])
    v['timing_event_logscore']=math.fsum(v['event_log_ground_intensity'])
    v['timing_exposure_logscore']=-v['integrated_intensity']
    v['event_log_point_intensity_sum']=math.fsum(v['event_log_point_intensity'])
    v['event_log_ground_intensity_sum']=v['timing_event_logscore']
    v['event_log_intensity_sum']=v['event_log_point_intensity_sum']
    v['zone_integrated_intensity']=v['cell_integrated_intensity'].reshape(3,3).sum(axis=1)
    v['cell_point_event_log_intensity_sum']=np.bincount(cells,weights=v['event_log_point_intensity'],minlength=9)
    v['cell_point_logscore']=v['cell_point_event_log_intensity_sum']-v['cell_integrated_intensity']
    return v
