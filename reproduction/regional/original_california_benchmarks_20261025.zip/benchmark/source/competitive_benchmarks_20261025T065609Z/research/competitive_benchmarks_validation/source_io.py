"""Local-only California source binding through the prior independent parser.

The source-authorities manifest contains paths and hashes only. This program
parses original annual bytes and checks canonical rows inside the local
process. Callers must never print or serialize its raw return value.
"""
from __future__ import annotations
from datetime import datetime,timezone
import hashlib,json
from pathlib import Path
import numpy as np
from ..external_replication_validation import empirical_io_v2 as E


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _days(stamp):
    epoch=datetime(1981,1,1,tzinfo=timezone.utc)
    value=datetime.fromisoformat(stamp.replace('Z','+00:00'))
    if value.tzinfo is None or value.utcoffset().total_seconds()!=0:
        raise ValueError('SOURCE_NONUTC_CASE')
    return (value-epoch).total_seconds()/86400.


def load_verified(authorities_path,expected_manifest_sha256):
    """Return private raw arrays, fixed cases and opaque source metadata."""
    path=Path(authorities_path)
    if sha(path)!=expected_manifest_sha256:raise ValueError('SOURCE_AUTHORITY_MANIFEST_HASH')
    manifest=json.loads(path.read_text(encoding='utf-8'))
    if manifest['schema_version']!=1 or len(manifest['cases'])!=3:
        raise ValueError('SOURCE_AUTHORITY_SCHEMA')
    for entry in manifest['authority_pins']:
        if sha(entry['path'])!=entry['sha256']:
            raise ValueError('SOURCE_AUTHORITY_PIN_CHANGED')
    for original,digest in manifest['inherited_artifact_pins'].items():
        if sha(original)!=digest:
            raise ValueError('INHERITED_SOURCE_PIN_CHANGED')
    if sha(manifest['old_protocol'])!=manifest['old_protocol_sha256']:
        raise ValueError('SEALED_OBSERVED_PROTOCOL_CHANGED')
    canonical=manifest['canonical_input']
    if canonical['legacy_csv'] is not False or sha(canonical['catalogue'])!=canonical['sha256']:
        raise ValueError('CANONICAL_INPUT_CHANGED')
    oldrun=Path(manifest['sealed_run'])
    train=E.load_ca_lane(oldrun,'train')
    protected=E.load_ca_lane(oldrun,'protected')
    source=E.merge_ca(train,protected)
    raw=source['raw'];t=np.asarray(raw['times'])
    cases=[]
    for ordinal,spec in enumerate(manifest['cases']):
        case=dict(case_id=spec['id'],fold=ordinal,T0=float(manifest['era']['T0_days']))
        for part in ('train_start','train_end','test_start','test_end','history_start'):
            case[part]=_days(spec[part+'_utc'])
        case['n_train']=int(np.count_nonzero((t>=case['train_start'])&(t<case['train_end'])))
        case['n_test']=int(np.count_nonzero((t>=case['test_start'])&(t<case['test_end'])))
        if case['case_id']!=f'california_fold_{ordinal}' or case['history_start']!=0 \
           or case['n_train']!=manifest['expected_counts']['train'][ordinal] \
           or case['n_test']!=manifest['expected_counts']['test'][ordinal]:
            raise ValueError('RAW_FIXED_CASE_DENOMINATOR')
        cases.append(case)
    if len(t)!=manifest['expected_counts']['catalogue'] or \
       int(np.count_nonzero(t<cases[0]['train_start']))!=manifest['expected_counts']['warmup'] or \
       sum(case['n_test'] for case in cases)!=manifest['expected_counts']['total_test']:
        raise ValueError('RAW_POPULATION_DENOMINATOR')
    for sealed,case in zip(manifest['sealed_OC_cases'],cases):
        if sealed['case_id']!=case['case_id'] or sha(sealed['private_case_path'])!=sealed['sha256']:
            raise ValueError('SEALED_OC_CASE_BINDING')
    safe=dict(source_authorities_sha256=expected_manifest_sha256,
              canonical_input_sha256=canonical['sha256'],
              old_protocol_sha256=manifest['old_protocol_sha256'],
              train_counts=[case['n_train'] for case in cases],
              test_counts=[case['n_test'] for case in cases],
              model_population=len(t),
              authority_pin_count=len(manifest['authority_pins'])+
                  len(manifest['inherited_artifact_pins']))
    return raw,cases,manifest,safe
