"""Independent local benchmark validation. No production engine imports."""
