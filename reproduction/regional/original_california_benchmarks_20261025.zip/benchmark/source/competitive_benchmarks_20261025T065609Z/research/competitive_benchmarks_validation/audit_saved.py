"""Root-leased full saved benchmark audit; stdout is a safe scalar receipt.

This program independently parses pinned original SCEDC annual bytes and
reconstructs all six new fits, their held-out candidate/return scores, and
the three sealed O-C selections. It never loads a production DLL or features.
"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
import numpy as np
from . import oracle as O
from . import audit_records as A
from .source_io import load_verified,sha


def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))


def _bind(path):
    path=Path(path).resolve()
    return dict(path=str(path),sha256=sha(path))


def _plan(plan,case):
    cid=case['case_id']
    expected=dict(case_id=cid,
        procedures=[dict(arm=arm,
            start_ids=[f'{cid}__{arm}__start{i}' for i in range(8)],
            floor_ids=[f'{cid}__{arm}__floor_constant']+
                ([f'{cid}__EP__floor_N0'] if arm=='EP' else []))
            for arm in ('N0','EP')],
        planned_procedures=2,planned_starts=16,planned_floors=3,status='planned')
    O.require(plan==expected,'PREFIT_PLAN_IDENTITY')


def audit(authorities_path,expected_sha,observed_root):
    raw,cases,manifest,source_receipt=load_verified(authorities_path,expected_sha)
    root=Path(observed_root).resolve();results=[];bindings=[]
    bindings.append(_bind(authorities_path))
    for case,sealed in zip(cases,manifest['sealed_OC_cases']):
        folder=root/case['case_id']
        filenames=['nuisance.json','fit_plan.json','fit_N0.json','fit_EP.json',
                   'score_N0.json','score_EP.json','sealed_OC_reference.json']
        paths={name:folder/name for name in filenames}
        for path in paths.values():bindings.append(_bind(path))
        nuisance=read(paths['nuisance.json'])
        saved_case=nuisance['case']
        O.require(saved_case['case_id']==case['case_id'] and
            all(saved_case[key]==case[key] for key in
                ('train_start','train_end','test_start','test_end',
                 'history_start','T0')) and
            nuisance['case_id']==case['case_id'] and
            nuisance['n_train']==case['n_train'] and
            nuisance['n_test']==case['n_test'] and
            nuisance['catalogue_sha256']==manifest['canonical_input']['sha256'] and
            nuisance['sealed_case_path']==str(Path(sealed['private_case_path']).resolve())
            and nuisance['sealed_case_sha256']==sealed['sha256'] and
            nuisance['status']=='prepared',
            'PREPARED_NUISANCE_SOURCE_BINDING')
        train,beta,h,loo_error=A.audit_nuisance(raw,case,nuisance['beta'],
            nuisance['kde_selection']['selected_bandwidth'],
            nuisance['kde_selection']['candidates'])
        pi=A.old.reference_mass(raw['cells'],train)
        A._equal(nuisance['reference_pi'],pi,'PREPARED_REFERENCE_MASS',1e-12)
        _plan(read(paths['fit_plan.json']),case)
        n0=read(paths['fit_N0.json']);ep=read(paths['fit_EP.json'])
        for fit,arm in ((n0,'N0'),(ep,'EP')):
            O.require(fit['case_id']==case['case_id'] and fit['arm']==arm
                      and fit['nuisance_path']==str(paths['nuisance.json'].resolve())
                      and fit['nuisance_sha256']==sha(paths['nuisance.json'])
                      and fit['feature']==nuisance['train_feature'],
                      'FIT_PREPARED_NUISANCE_BINDING')
        fit_n0=A.audit_fit(n0,raw,case,beta,h)
        fit_ep=A.audit_fit(ep,raw,case,beta,h,
                           nested_n0=n0['selected']['pars'])
        score_n0=read(paths['score_N0.json']);score_ep=read(paths['score_EP.json'])
        score_reports=[]
        for score,fit,name in ((score_n0,n0,'fit_N0.json'),
                               (score_ep,ep,'fit_EP.json')):
            score_reports.append(A.audit_forecast(score,fit,paths[name],raw,case,beta,h))
            O.require(score['sealed_OC_case_path']==
                      str(Path(sealed['private_case_path']).resolve())
                      and score['sealed_OC_case_sha256']==sealed['sha256'],
                      'FORECAST_SEALED_REFERENCE_BINDING')
        oc_ref=read(paths['sealed_OC_reference.json'])
        O.require(oc_ref['path']==str(Path(sealed['private_case_path']).resolve())
                  and oc_ref['sha256']==sealed['sha256'],
                  'SEALED_OC_REFERENCE_HASH')
        old_case=read(sealed['private_case_path'])
        oc=A.audit_sealed_oc(old_case,oc_ref,raw,case,beta,h)
        results.append(dict(case_id=case['case_id'],target_events=case['n_test'],
            nuisance_maximum_absolute_loo_error=loo_error,
            fits=[fit_n0,fit_ep],forecasts=score_reports,sealed_OC=oc))
    O.require(len(results)==3 and sum(r['target_events'] for r in results)==315,
              'COMPLETE_THREE_WINDOW_AUDIT')
    max_error=max([r['nuisance_maximum_absolute_loo_error'] for r in results]
        +[v['maximum_absolute_score_error'] for r in results
            for group in ('fits','forecasts') for v in r[group]]
        +[r['sealed_OC']['maximum_absolute_score_error'] for r in results])
    O.require(max_error<=1e-4,'FULL_AUDIT_SCORE_TOLERANCE')
    return dict(status='passed',passed=True,independent=True,
        scope='Original raw-row reconstruction; all new starts, floors, finite returns, candidates and forecasts; sealed O-C replay',
        source=source_receipt,denominator=dict(folds=3,new_procedures=6,
            starts=48,floors=9,candidates=sum(v['candidates'] for r in results for v in r['fits']),
            finite_solver_returns=sum(v['finite_solver_returns'] for r in results for v in r['fits']),
            candidate_forecasts=sum(v['candidate_forecasts'] for r in results for v in r['forecasts']),
            solver_return_forecasts=sum(v['solver_return_forecasts'] for r in results for v in r['forecasts']),
            sealed_OC_replays=3,target_events=315),
        maximum_absolute_score_error=max_error,cases=results,bindings=bindings)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-authorities',required=True)
    p.add_argument('--source-authorities-sha256',required=True)
    p.add_argument('--observed-root',required=True)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    try:
        result=audit(args.source_authorities,args.source_authorities_sha256,
                     args.observed_root)
    except Exception as error:
        result=dict(status='failed',passed=False,independent=True,
            fixed_error_code='BENCHMARK_SAVED_AUDIT_FAILED',
            error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({key:result[key] for key in
        ('status','passed','denominator','maximum_absolute_score_error',
         'fixed_error_code','error_type') if key in result},allow_nan=False))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
