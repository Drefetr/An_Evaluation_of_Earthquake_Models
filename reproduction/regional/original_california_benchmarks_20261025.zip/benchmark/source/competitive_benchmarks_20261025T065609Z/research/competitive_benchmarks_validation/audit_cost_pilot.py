"""Training-only timing probe for the independent full-history oracle.

Run under the root's machine numerical lease. The output has timings and
counts only; no private objective values, parameters or event arrays.
"""
from __future__ import annotations
import argparse,json,math,time
from pathlib import Path
import numpy as np
from .source_io import load_verified
from . import oracle as O
from ..external_replication_validation import nuisance_oracle as N
from ..external_replication_validation.raw_input import fit_beta


def run(authorities,expected_sha,folds,max_seconds):
    t0=time.perf_counter()
    raw,cases,_,safe=load_verified(authorities,expected_sha)
    source_seconds=time.perf_counter()-t0
    records=[]
    for index in folds:
        O.require(index in (0,2),"PILOT_FOLD_ROSTER")
        if time.perf_counter()-t0>max_seconds:
            records.append(dict(case_id=cases[index]['case_id'],status='not_reached_timeout'))
            continue
        case=cases[index];t=np.asarray(raw['times'],float)
        train=(t>=case['train_start'])&(t<case['train_end'])
        start,end=case['train_start'],case['train_end']
        p=time.perf_counter()
        beta=fit_beta(np.asarray(raw['excess'])[train])
        h=N.select_bandwidth(np.asarray(raw['xy'])[train],raw['rectangles'])['selected_bandwidth']
        nuisance_seconds=time.perf_counter()-p
        ap=float(np.clip(math.log(int(train.sum())/(end-start)),-12,0))
        a0=float(np.clip(math.log(.6*int(train.sum())/(end-start)),-11.5,-.1))
        p=time.perf_counter()
        n0=O.evaluate_n0([ap,.2],raw,train,train,beta,h,start,end,case['T0'])
        n0_seconds=time.perf_counter()-p
        O.require(math.isfinite(n0['joint_nll']),"PILOT_N0_FINITE")
        if time.perf_counter()-t0>max_seconds:
            records.append(dict(case_id=case['case_id'],status='etas_not_reached_timeout',
                training_targets=int(train.sum()),nuisance_seconds=nuisance_seconds,
                n0_seconds=n0_seconds))
            continue
        p=time.perf_counter()
        et=O.evaluate_etas([a0,.2,.2,math.log(.01),1.3,math.log(15.),2.],
            raw,train,train,beta,h,start,end,case['T0'])
        etas_seconds=time.perf_counter()-p
        O.require(math.isfinite(et['joint_nll']),"PILOT_ETAS_FINITE")
        records.append(dict(case_id=case['case_id'],status='complete',
            training_targets=int(train.sum()),nuisance_seconds=nuisance_seconds,
            n0_seconds=n0_seconds,etas_seconds=etas_seconds))
    return dict(status='complete' if all(r['status']=='complete' for r in records)
                else 'partial_cost_measurement',source_verification_seconds=source_seconds,
                records=records,total_wall_seconds=time.perf_counter()-t0,
                source_authorities_sha256=safe['source_authorities_sha256'])


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-authorities',required=True)
    p.add_argument('--source-authorities-sha256',required=True)
    p.add_argument('--folds',default='0,2')
    p.add_argument('--max-seconds',type=float,default=1200)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    try:
        folds=[int(v) for v in args.folds.split(',')]
        result=run(args.source_authorities,args.source_authorities_sha256,
                   folds,args.max_seconds)
    except Exception as error:
        result=dict(status='failed',fixed_error_code='INDEPENDENT_AUDIT_COST_PILOT_FAILED',
                    error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False))
    return 0 if result['status']!='failed' else 1


if __name__=='__main__':raise SystemExit(main())
