"""Training-only, six-vector cost probe for the independent history oracle.

Run only under the conductor's serial numerical lease. Saved outputs contain
timings, finite flags, statuses, counts, and source hashes; no objective values,
parameters, event arrays, or exception messages.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np

from .source_io import load_verified
from . import oracle as O
from ..external_replication_validation import nuisance_oracle as N
from ..external_replication_validation.raw_input import fit_beta


FOLDS = (0, 2)
VECTORS = (
    ("interior", .2, .01, 1.3, 15., 2.),
    ("short_near", .6, .0001, 1.01, 2., 1.05),
    ("wide_upper", .6, 20., 2.5, 500., 3.),
)
MAX_SECONDS = 1200.0


def _case_id(index: int) -> str:
    return f"california_fold_{index}"


def _empty_records() -> tuple[list[dict], list[dict]]:
    folds = [dict(case_id=_case_id(index), status="unknown_unreached")
             for index in FOLDS]
    vectors = [dict(case_id=_case_id(index), vector_id=vector[0],
                    status="unknown_unreached", finite=False)
               for index in FOLDS for vector in VECTORS]
    return folds, vectors


def _elapsed(started: float) -> float:
    return time.perf_counter() - started


def run(authorities: str, expected_sha: str, folds: list[int], max_seconds: float) -> tuple[dict, dict]:
    if folds != list(FOLDS):
        raise ValueError("PILOT_FOLD_ROSTER")
    if not math.isfinite(max_seconds) or max_seconds <= 0:
        raise ValueError("PILOT_BUDGET")
    budget = min(max_seconds, MAX_SECONDS)
    started = time.perf_counter()
    fold_records, vector_records = _empty_records()
    main = dict(status="partial_cost_measurement", records=fold_records,
                source_verification_seconds=None, total_wall_seconds=None,
                source_authorities_sha256=None)
    vectors = dict(status="partial_cost_measurement", records=vector_records)

    try:
        raw, cases, _, safe = load_verified(authorities, expected_sha)
    except Exception as error:
        main["status"] = "failed"
        main["fixed_error_code"] = "SOURCE_VERIFICATION_FAILED"
        main["error_type"] = type(error).__name__
        main["total_wall_seconds"] = _elapsed(started)
        return main, vectors
    main["source_verification_seconds"] = _elapsed(started)
    main["source_authorities_sha256"] = safe["source_authorities_sha256"]

    for fold_number, index in enumerate(FOLDS):
        row = fold_records[fold_number]
        corresponding = vector_records[3 * fold_number:3 * fold_number + 3]
        if _elapsed(started) >= budget:
            row["status"] = "not_reached_timeout"
            continue
        case = cases[index]
        if case["case_id"] != row["case_id"]:
            row["status"] = "case_identity_failed"
            continue
        t = np.asarray(raw["times"], float)
        train = (t >= case["train_start"]) & (t < case["train_end"])
        start, end = case["train_start"], case["train_end"]
        row["training_targets"] = int(train.sum())

        clock = time.perf_counter()
        try:
            beta = fit_beta(np.asarray(raw["excess"])[train])
            h = N.select_bandwidth(np.asarray(raw["xy"])[train],
                                   raw["rectangles"])["selected_bandwidth"]
        except Exception as error:
            row.update(status="nuisance_failed", error_type=type(error).__name__,
                       nuisance_seconds=time.perf_counter() - clock)
            continue
        row["nuisance_seconds"] = time.perf_counter() - clock
        if _elapsed(started) >= budget:
            row["status"] = "nuisance_deadline_exceeded"
            continue

        count = row["training_targets"]
        ap = float(np.clip(math.log(count / (end - start)), -12, 0))
        a0 = float(np.clip(math.log(.6 * count / (end - start)), -11.5, -.1))
        clock = time.perf_counter()
        try:
            n0 = O.evaluate_n0([ap, .2], raw, train, train, beta, h,
                               start, end, case["T0"])
            n0_finite = math.isfinite(n0["joint_nll"])
        except Exception as error:
            row.update(status="n0_failed", error_type=type(error).__name__,
                       n0_seconds=time.perf_counter() - clock)
            continue
        row["n0_seconds"] = time.perf_counter() - clock
        if not n0_finite:
            row["status"] = "n0_nonfinite"
            continue
        if _elapsed(started) >= budget:
            row["status"] = "n0_deadline_exceeded"
            continue

        for vector, record in zip(VECTORS, corresponding):
            if _elapsed(started) >= budget:
                record["status"] = "not_reached_timeout"
                continue
            _, n, c, p, ell, q = vector
            clock = time.perf_counter()
            try:
                value = O.evaluate_etas(
                    [a0, .2, n, math.log(c), p, math.log(ell), q],
                    raw, train, train, beta, h, start, end, case["T0"])
                finite = math.isfinite(value["joint_nll"])
            except Exception as error:
                record.update(status="failed", finite=False,
                              error_type=type(error).__name__,
                              wall_seconds=time.perf_counter() - clock)
                continue
            record["wall_seconds"] = time.perf_counter() - clock
            record["finite"] = bool(finite)
            record["status"] = ("deadline_exceeded" if _elapsed(started) >= budget
                                else "complete" if finite else "nonfinite")
            if record["vector_id"] == "interior" and record["status"] == "complete":
                row["etas_seconds"] = record["wall_seconds"]
        row["status"] = ("complete" if all(r["status"] == "complete" for r in corresponding)
                         else "partial_cost_measurement")

    vectors["status"] = ("complete" if all(r["status"] == "complete" for r in vector_records)
                         else "partial_cost_measurement")
    main["status"] = ("complete" if vectors["status"] == "complete" and
                      all(r["status"] == "complete" for r in fold_records)
                      else "partial_cost_measurement")
    main["total_wall_seconds"] = _elapsed(started)
    return main, vectors


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-authorities", required=True)
    parser.add_argument("--source-authorities-sha256", required=True)
    parser.add_argument("--folds", default="0,2")
    parser.add_argument("--max-seconds", type=float, default=MAX_SECONDS)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output = Path(args.output)
    vector_output = output.with_name(output.stem + "_vectors.json")
    if output.exists() or vector_output.exists():
        raise FileExistsError("Cost receipt already exists")
    try:
        folds = [int(value) for value in args.folds.split(",")]
        main_result, vector_result = run(args.source_authorities,
                                         args.source_authorities_sha256,
                                         folds, args.max_seconds)
    except Exception as error:
        fold_records, vector_records = _empty_records()
        main_result = dict(status="failed", fixed_error_code="INDEPENDENT_AUDIT_COST_PILOT_FAILED",
                           error_type=type(error).__name__, records=fold_records)
        vector_result = dict(status="partial_cost_measurement", records=vector_records)
    with vector_output.open("x", encoding="utf-8") as stream:
        json.dump(vector_result, stream, indent=2, allow_nan=False)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(main_result, stream, indent=2, allow_nan=False)
    print(json.dumps(main_result, allow_nan=False))
    return 1 if main_result["status"] == "failed" else 0


if __name__ == "__main__":
    raise SystemExit(main())
