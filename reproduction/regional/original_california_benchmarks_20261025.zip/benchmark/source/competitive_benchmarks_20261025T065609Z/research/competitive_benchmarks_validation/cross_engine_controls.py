"""Handcrafted C++ versus independent direct-history benchmark comparison.

Only this comparison harness imports the production library adapter. The
independent oracle and empirical auditor remain entirely production-free.
No catalogue data, fitted parameter or saved feature cache enters this test.
"""
from __future__ import annotations
import argparse,ctypes as ct,json,math
from pathlib import Path
import numpy as np
from ..external_replication_validation import oracle as old
from . import oracle as O
from .controls import finite_difference


def fixture_arrays(parents,events,marks,start=1.,end=4.,T0=10.):
    rect=np.array([[x,x+1.,y,y+1.] for y in range(3) for x in range(3)],float)
    pt=np.array([r[0] for r in parents],float)
    pxy=np.array([r[1:] for r in parents],float).reshape(-1,2)
    et=np.array([r[0] for r in events],float)
    exy=np.array([r[1:] for r in events],float).reshape(-1,2)
    cell=np.array([min(2,int(r[2]))*3+min(2,int(r[1])) for r in events],float)
    arrays=[pt,pxy,np.full(len(pt),.3),np.maximum(start-pt,0.),end-pt,
            et,exy,2*et/T0-1,cell,np.full(len(et),1/9.),
            np.full(9,1/9.),rect,np.array([start,end,T0,marks])]
    return [np.ascontiguousarray(v,dtype=np.float64) for v in arrays]


def independent(parents,events,marks,model,pars,start=1.,end=4.,T0=10.):
    a,d=map(float,pars[:2]);n=0. if model==0 else float(pars[2])
    c,p,ell,tail=(1.,2.,1.,2.) if model==0 else \
        (math.exp(pars[3]),pars[4],math.exp(pars[5]),pars[6])
    rect=np.array([[x,x+1.,y,y+1.] for y in range(3) for x in range(3)],float)
    whole=np.array([0.,3.,0.,3.])
    pt=np.array([r[0] for r in parents],float)
    pxy=np.array([r[1:] for r in parents],float).reshape(-1,2)
    et=np.array([r[0] for r in events],float)
    exy=np.array([r[1:] for r in events],float).reshape(-1,2)
    cells=np.array([min(2,int(r[2]))*3+min(2,int(r[1])) for r in events],int)
    B,_=old.immigrant_integral(a,d,start,end,T0)
    kappa=np.full(len(pt),.3)
    if model:
        z=np.array([O.rectangle_mass(whole,v,ell,tail) for v in pxy])
        cellmass=np.array([[O.rectangle_mass(r,v,ell,tail)/zj for r in rect]
                           for v,zj in zip(pxy,z)]).reshape(len(pt),9)
        lower=np.maximum(start-pt,0.);upper=end-pt
        survival=lambda x:np.exp((1-p)*np.log1p(x/c))
        J=survival(lower)*(-np.expm1((1-p)*np.log1p((upper-lower)/(c+lower))))
        K=float(kappa@J)
    else:
        z=np.empty(0);cellmass=np.zeros((len(pt),9));J=np.zeros(len(pt));K=0.
    cellcomp=np.full(9,B/9.)+n*((kappa*J)@cellmass)
    lp=[];lg=[];lc=[];lz=[]
    for time,xy,cell in zip(et,exy,cells):
        mu=math.exp(a+d*(2*time/T0-1));valid=time>pt
        if model:
            lag=time-pt[valid]
            temporal=(p-1)/c*np.exp(-p*np.log1p(lag/c))
            weight=kappa[valid]*temporal
            dr2=np.sum((pxy[valid]-xy)**2,axis=1)
            spatial=(1+dr2/ell**2)**(-tail)/z[valid]
            point=mu/9.+n*float(weight@spatial)
            ground=mu+n*float(weight.sum())
            cm=np.full(9,mu/9.)+n*(weight@cellmass[valid])
        else:
            point=mu/9.;ground=mu;cm=np.full(9,mu/9.)
        lp.append(math.log(point));lg.append(math.log(ground))
        lc.append(math.log(cm[cell]));lz.append(math.log(cm.reshape(3,3).sum(axis=1)[cell//3]))
    lp,lg,lc,lz=map(lambda v:np.asarray(v,float),(lp,lg,lc,lz))
    exposure=B+n*K
    return dict(joint_nll=exposure-math.fsum(lp)-marks,
        timing_logscore=math.fsum(lg)-exposure,
        conditional_zone_logscore=math.fsum(lz-lg),
        conditional_cell_logscore=math.fsum(lc-lz),
        within_cell_density_logscore=math.fsum(lp-lc),
        mark_logscore=marks,integrated_intensity=exposure,
        event_log_point_intensity_sum=math.fsum(lp),
        event_log_ground_intensity_sum=math.fsum(lg),
        trigger_exposure=K,cell_integrated_intensity=cellcomp,
        cell_point_event_log_intensity_sum=np.bincount(cells,weights=lp,minlength=9),
        event_logs=np.column_stack((lp,lc,lz,lg)))


def compare(lib,parents,events,marks,model,pars,gradient=False):
    arrays=fixture_arrays(parents,events,marks)
    pd=ct.POINTER(ct.c_double)
    handle=lib.cb_create(len(events),len(parents),
                         *[a.ctypes.data_as(pd) for a in arrays])
    O.require(bool(handle),'CROSS_ENGINE_CREATE')
    try:
        p=np.ascontiguousarray(pars,dtype=np.float64)
        out=np.empty(28);grad=np.empty(len(p));logs=np.empty((len(events),4))
        rc=lib.cb_eval(handle,model,p.ctypes.data_as(pd),len(p),
                       out.ctypes.data_as(pd),grad.ctypes.data_as(pd),
                       logs.ctypes.data_as(pd))
        O.require(rc==0,'CROSS_ENGINE_EVALUATE')
    finally:lib.cb_destroy(handle)
    expected=independent(parents,events,marks,model,pars)
    fields=[(out[0],expected['joint_nll']),
        (out[1],expected['timing_logscore']),
        (out[2],expected['conditional_zone_logscore']),
        (out[3],expected['conditional_cell_logscore']),
        (out[4],expected['within_cell_density_logscore']),
        (out[5],expected['mark_logscore']),
        (out[6],expected['integrated_intensity']),
        (out[7],expected['event_log_point_intensity_sum']),
        (out[8],expected['event_log_ground_intensity_sum']),
        (out[9],expected['trigger_exposure'])]
    errors=[abs(a-b) for a,b in fields]
    errors.extend(abs(out[10:19]-expected['cell_integrated_intensity']))
    errors.extend(abs(out[19:28]-expected['cell_point_event_log_intensity_sum']))
    errors.extend(abs(logs-expected['event_logs']).ravel())
    maximum=max(errors,default=0.)
    O.require(maximum<=1e-7,'CROSS_ENGINE_SCORE_DISCREPANCY')
    gradient_report=None
    if gradient:
        bounds=np.array([[-12.,0.],[-2.,2.]] if model==0 else
            [[-12.,0.],[-2.,2.],[0.,.98],[math.log(.0001),math.log(20.)],
             [1.01,2.5],[math.log(2.),math.log(500.)],[1.05,3.]])
        fun=lambda x:independent(parents,events,marks,model,x)['joint_nll']
        g0,kinds=finite_difference(fun,p,bounds[:,0],bounds[:,1],2e-5)
        g1,_=finite_difference(fun,p,bounds[:,0],bounds[:,1],1e-5)
        tolerance=np.array([1e-3 if k!='central' else 2e-4 for k in kinds])*(1+abs(g1))
        stabilization=np.max(abs(g0-g1)/tolerance)
        ratio=np.max(abs(grad-g1)/tolerance)
        O.require(stabilization<=1 and ratio<=1,'CROSS_ENGINE_GRADIENT_DISCREPANCY')
        gradient_report=dict(maximum_criterion_ratio=float(ratio),
                             maximum_stabilization_ratio=float(stabilization),
                             boundary_coordinates=sum(k!='central' for k in kinds))
    return dict(maximum_score_absolute_error=float(maximum),
                component_checks=len(errors),gradient=gradient_report)


def run():
    # This is the exact simple fixture used by the compiled control, rebuilt
    # here without loading its fixture arrays, cache, or score artifacts.
    from ..competitive_benchmarks.objective import library
    lib,_=library()
    parents=[(0.,1.5,1.5),(1.5,2.5,1.5),(2.,1.5,2.5),(2.,2.5,2.5)]
    events=[(1.5,2.5,1.5),(2.,1.5,2.5),(2.,2.5,2.5)]
    marks=3*math.log(2.)-.25
    cases=[('n0',parents,events,0,[-1.,.2],True),
           ('nested_etas',parents,events,1,[-1.,.2,0.,math.log(.01),1.3,math.log(2.),2.],False),
           ('interior_etas',parents,events,1,[-1.,.2,.3,math.log(.01),1.3,math.log(2.),2.],True),
           ('boundary_etas',parents,events,1,[-1.,.2,.3,math.log(.0001),1.01,math.log(2.),1.05],True),
           ('edge_parent',[(0.,0.,1.5),(1.5,0.,0.)],[(2.,.5,.5)],1,
            [-1.,.2,.3,math.log(.01),1.3,math.log(2.),2.],False),
           ('zero_parent_quiet',[],[],0,[-1.,0.],True)]
    reports=[]
    for name,parents,events,model,pars,gradient in cases:
        report=compare(lib,parents,events,marks if events else 0.,
                       model,pars,gradient)
        reports.append(dict(case=name,**report))
    return dict(status='passed',passed=True,cases=len(reports),
        component_checks=sum(r['component_checks'] for r in reports),
        maximum_score_absolute_error=max(r['maximum_score_absolute_error'] for r in reports),
        maximum_gradient_criterion_ratio=max(
            (r['gradient']['maximum_criterion_ratio'] for r in reports
             if r['gradient']),default=0.),reports=reports)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True)
    args=p.parse_args()
    try: result=run()
    except Exception as error:
        result=dict(status='failed',passed=False,
                    fixed_error_code='CROSS_ENGINE_HANDCRAFTED_CONTROL_FAILED',
                    error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:
        json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
