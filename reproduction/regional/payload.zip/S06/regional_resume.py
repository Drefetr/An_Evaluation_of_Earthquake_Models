"""Private Stage2 CA causal episodes and JMA stationary-background ablation."""
from pathlib import Path
import argparse,json,math,time,sys,os,hashlib,datetime as dt
from concurrent.futures import ProcessPoolExecutor
import numpy as np
HERE=Path('archive:\\research_runs\\scientific_stage2_resume_20261031T205913Z\\regional_v2');ROOT=Path('archive:');sys.path.insert(0,'archive:\\research_runs\\scientific_stage2_resume_20261031T205913Z\\regional_v2\\source')
from s06 import engine as E,runner as R
sys.path.insert(0,str(ROOT/'work/conditional_calibration_20261025T085151Z/study/source/research'))
from external_replication import geometry as G
CA=ROOT/'research_runs/california_schema_repair_20261025T044000Z/inputs/california/canonical_merged_v1.json'
JROOT=ROOT/'work/third_region_transfer_20261026T001254Z/study/private_inputs/jma/fitting/static_20261027T051211Z/forecast_run_v1'
JPTR=ROOT/'research_runs/third_region_transfer_20261026T001254Z/orchestration/JMA_PROCESSED_LOCAL_INPUTS_v1.json'
DEFAULT={k:np.array(getattr(E,k),copy=True) for k in ('XEDGE','YEDGE','RECT','AREA','CENTERS')};ORIG_BOUNDS=E.bounds

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert read(p)==R.clean(v),'IMMUTABLE_ARTIFACT_DRIFT'
 else:p.write_text(json.dumps(R.clean(v),indent=2,allow_nan=False)+'\n')
def day(x):return (dt.datetime.fromisoformat(x.replace('Z','+00:00'))-dt.datetime(1981,1,1,tzinfo=dt.timezone.utc)).total_seconds()/86400

def load_ca():
 obj=read(CA);events=obj['events'];t=np.array([day(v['origin_time_utc']) for v in events]);q=np.array([float(v['magnitude'])-4 for v in events]);lat=np.array([float(v['latitude']) for v in events]);lon=np.array([float(v['longitude']) for v in events]);cells=G.cell_ids(lat,lon,'california');xy=G.project(lat,lon,'california')
 assert np.isfinite(t).all() and np.all(t[1:]>=t[:-1]) and np.all(q>=0)
 return dict(t_days=t,K=q/.1,Q=q,xy_km=xy,cell_id=cells),q

def configure(region,d0=False):
 for k,v in DEFAULT.items():setattr(E,k,v.copy())
 if region=='CA':
  rect,area,centers=G.support('california');E.RECT=rect;E.AREA=area;E.CENTERS=centers;E.XEDGE=np.r_[rect[:3,0],rect[2,1]];E.YEDGE=np.r_[rect[::3,2],rect[6,3]]
 def bounds(arm):
  b=ORIG_BOUNDS(arm)
  if d0:b[1]=(0.,0.)
  return b
 E.bounds=bounds

def ca_nuisance(cat,start,end):
 train=(cat['t_days']>=start)&(cat['t_days']<end);q=cat['Q'][train];cells=cat['cell_id'][train];counts=np.bincount(cells,minlength=9)
 assert len(q)>=180 and np.all(counts.reshape(3,3).sum(axis=1)>=30),'TRAINING_ADEQUACY'
 beta,_=G.fit_conditional_beta(q,.5);pi=E.pi_from_counts(counts);xy=cat['xy_km'][train];d2=E.distance2(xy,xy);N=len(q);loo=np.empty(N)
 for i,c in enumerate(cells):cc=counts.copy();cc[c]-=1;loo[i]=E.pi_from_counts(cc)[c]/E.AREA[c]
 records=[]
 for h in E.SCALES:
  F=E.rectangle_integrals(xy,h);Z=F.sum(axis=1);density=(1+d2/h**2)**-2/Z[None,:];np.fill_diagonal(density,0);records.append(dict(bandwidth_km=h,loo_logscore=float(np.log(.05*loo+.95*density.sum(axis=1)/(N-1)).sum())))
 win=min(records,key=lambda x:(-x['loo_logscore'],x['bandwidth_km']))
 return dict(training_start=start,training_end=end,N=N,beta=beta,kappa_prefactor=.3,reference_pi=pi.tolist(),h_km=win['bandwidth_km'],h_candidates=records,T0=16436.,mark_measure='continuous')

def plan():
 cat,q=load_ca();t=cat['t_days'];anchors=t[q>=2];episodes=[]
 for anchor in anchors:
  if episodes and anchor<=episodes[-1]['end']:episodes[-1]['end']=max(episodes[-1]['end'],float(anchor+30));episodes[-1]['anchors']+=1
  else:episodes.append(dict(origin=float(anchor),end=float(anchor+30),anchors=1))
 trainstart=day('1986-01-01T00:00:00Z');coverage_end=day('2026-01-01T00:00:00Z');eligible=[]
 for ordinal,e in enumerate(episodes):
  e['episode_id']=f'CA_episode_{ordinal:02d}';e['eligible']=e['origin']-trainstart>=5*365.25 and e['origin']<coverage_end;e['reason']=None if e['eligible'] else 'under_five_year_preceding_training_or_outside_coverage'
  tr=(t>=trainstart)&(t<e['origin']);counts=np.bincount(cat['cell_id'][tr],minlength=9)
  if e['eligible'] and (tr.sum()<180 or np.any(counts.reshape(3,3).sum(axis=1)<30)):
   e['eligible']=False;e['reason']='training_count_or_zone_adequacy'
  if e['eligible']:eligible.append(e)
 for i,e in enumerate(eligible):e['test_end']=min(e['origin']+365.25,eligible[i+1]['origin'] if i+1<len(eligible) else coverage_end,coverage_end);e['train_start']=trainstart;e['train_end']=e['origin'];e['warmup_start']=0.
 write(HERE/'s06_plan/private_CA_episodes.json',dict(episodes=episodes,eligible=eligible,source_sha256=E.sha(CA)))
 aggregate=dict(anchors=len(anchors),episodes=len(episodes),eligible_episodes=len(eligible),required=4,training='expanding 1986 start,1981 warmup; >=5yrs',windows='origin to min(nexteligibleorigin,origin+365.25,2026cutoff); disjoint active30day unions and complements')
 write(HERE/'s06_plan/eligibility.json',aggregate);assert len(eligible)>=4,'FEWER_THAN_FOUR_ELIGIBLE_EPISODES'
 jobs=[dict(region='CA',case=e['episode_id'],**e) for e in eligible]+[dict(region='JMA',case=f'JMA_fold_{i}',fold=i) for i in range(3)]
 write(HERE/'s06_plan/jobs.json',jobs);print(json.dumps(dict(status='planned',CA_episodes=len(eligible),JMA_folds=3)))

def cache(folder,name,cat,nuis,start,end,sigma,family):
 identity=dict(nuisance=nuis,start=float(start),end=float(end),sigma=float(sigma),family=family)
 key=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()[:24]
 return R.ensure_cache(folder/'caches'/('features_'+key+'.npz'),cat,nuis,start,end,float(sigma),family)

def fit_arm(folder,name,cat,nuis,arm,sigma,start,end,prereq,d0,deadline):
 fam='competitive' if arm in ('EP','N0') else 'continuous';cp=cache(folder,name+'_train',cat,nuis,start,end,sigma,fam)
 starts=R.starts(arm,nuis['N'],end-start,prereq);floors=R.floors(arm,nuis['N'],end-start,prereq)
 if d0:
  for p in starts:p[1]=0.
  for _,p in floors:p[1]=0.
 with E.Objective(cp) as obj:res=R.fit(folder/'fits'/(name+'.json'),obj,arm,name,starts,floors,deadline)
 assert res['status']=='complete','INCOMPLETE_FIT_'+name
 return res

def near_diagnostic(folder,label,fit,cat,nuis,arm,sigma,start,end):
 values=[];all_returns=[]
 for slot in fit['slots']:
  for j,cand in enumerate(slot.get('attempts',[])):
   if 'x' not in cand or not np.isfinite(cand['x']).all():continue
   if not all(lo<=v<=hi for v,(lo,hi) in zip(cand['x'],E.bounds(arm))):continue
   sc=score_arm(folder,label+f'_return{len(all_returns)}',cat,nuis,arm,cand['x'],sigma,start,end)
   row=dict(candidate_id=cand['candidate_id'],near_optimal=cand['candidate_id'] in fit.get('near_optimal_ids',[]),training_nll=cand.get('evaluator_nll'),accepted=cand.get('accepted',False),score=compact_score(sc));all_returns.append(row)
   if row['near_optimal']:values.append(row['score']['joint_logscore'])
 count=all_returns[0]['score']['n_events'] if all_returns else 0
 spread=(max(values)-min(values))/count if values and count else 0.
 write(folder/'diagnostics'/(label+'.json'),dict(all_finite_returns=all_returns,forecast_spread_nats_per_event=spread,threshold=.01,stable=spread<.01,selection='training_only_never_changed_by_this_diagnostic'))
 return spread

def score_arm(folder,name,cat,nuis,arm,pars,sigma,start,end):
 fam='competitive' if arm in ('EP','N0') else 'continuous';cp=cache(folder,name+'_test',cat,nuis,start,end,sigma,fam)
 return R.score(folder/'scores'/(name+'.json'),cp,arm,pars)

def run_case(job):
 folder=HERE/'s06_results'/job['case'];folder.mkdir(parents=True,exist_ok=True);write(folder/'case_config.json',job)
 if (folder/'receipt.json').exists():
  saved=read(folder/'receipt.json');assert saved['status']=='complete';return dict(case=job['case'],status='complete',wall_seconds=saved['wall_seconds'])
 begin=time.perf_counter();deadline=time.time()+14400;rows=[]
 try:
  region=job['region'];configure(region)
  if region=='CA':
   cat,_=load_ca();nuis=ca_nuisance(cat,job['train_start'],job['train_end']);write(folder/'nuisance.json',nuis);prior={};selectors=[]
   for i,sigma in enumerate(E.SCALES):
    fit=fit_arm(folder,f'FC_sigma{i}',cat,dict(nuis,background_type='cell'),'FC',sigma,job['train_start'],job['train_end'],{},False,deadline);selectors.append(dict(sigma=sigma,fit=fit))
   selected=min(selectors,key=lambda x:(x['fit']['selected']['evaluator_nll'],x['sigma']));sigma=selected['sigma'];fits={};write(folder/'sigma_selection.json',dict(sigma=sigma,selection='training_nll_only',candidates=[dict(sigma=x['sigma'],nll=x['fit']['selected']['evaluator_nll']) for x in selectors]))
   gridnear=[];gridbest=selected['fit']['selected']['evaluator_nll']
   for ordinal,item in enumerate(selectors):
    label=f'FCcell_sigma{ordinal}_near';near_diagnostic(folder,label,item['fit'],cat,dict(nuis,background_type='cell'),'FC',item['sigma'],job['origin'],job['test_end'])
    detail=read(folder/'diagnostics'/(label+'.json'))
    gridnear.extend(v['score']['joint_logscore'] for v in detail['all_finite_returns'] if v['accepted'] and v['training_nll']<=gridbest+4e-4)
   ntest=np.count_nonzero((cat['t_days']>=job['origin'])&(cat['t_days']<job['test_end']));gridspread=(max(gridnear)-min(gridnear))/ntest if gridnear and ntest else 0.
   write(folder/'diagnostics/FCcell_cross_grid.json',dict(forecast_spread_nats_per_event=gridspread,stable=gridspread<.01,threshold=.01,selection='training_only_no_heldout_reselection'))
   for arm in ('FC','MC','OC','N0','EP'):
    fits[arm]=fit_arm(folder,arm,cat,nuis,arm,sigma,job['train_start'],job['train_end'],prior,False,deadline);prior[arm]=fits[arm]['selected']['x']
   # Every partition covers the whole scored block; activity is a temporal
   # episode union, not causal attribution of individual aftershocks.
   ep=read(HERE/'s06_plan/private_CA_episodes.json')['episodes'];cuts={job['origin'],job['test_end']}
   for e in ep:
    for x in (e['origin'],e['end']):
     if job['origin']<x<job['test_end']:cuts.add(x)
   cuts=sorted(cuts)
   for arm in ('FC','MC','OC','EP'):
    selected=fits[arm]['selected']['x'];near_diagnostic(folder,arm+'_near',fits[arm],cat,nuis,arm,sigma,job['origin'],job['test_end']);whole=score_arm(folder,arm+'_full',cat,nuis,arm,selected,sigma,job['origin'],job['test_end'])
    rows.append(dict(region=region,case=job['case'],arm=arm,partition='full',**compact_score(whole)))
    for i,(lo,hi) in enumerate(zip(cuts,cuts[1:])):
     active=any(e['origin']<=lo<e['end'] for e in ep);sc=score_arm(folder,arm+f'_partition{i}',cat,nuis,arm,selected,sigma,lo,hi);rows.append(dict(region=region,case=job['case'],arm=arm,partition='active' if active else 'complement',**compact_score(sc)))
  else:
   cat,_=R.load(JPTR);fold=job['fold'];nuis=read(JROOT/'nuisance'/f'f{fold}.json');sigma=read(JROOT/'nuisance'/f'f{fold}_sigma.json')['winner']['sigma'];old=read(JROOT/'selected'/f'f{fold}.json');write(folder/'nuisance.json',nuis)
   for d0 in (False,True):
    configure('JMA',d0);prior={};label='d0' if d0 else 'dfree'
    for arm in ('FC','OC','N0','EP'):
     if d0:
      fit=fit_arm(folder,label+'_'+arm,cat,nuis,arm,sigma,1826.,E.ORIGINS[fold],prior,True,deadline);pars=fit['selected']['x']
     else:pars=old[arm]['selected']['x']
     prior[arm]=pars
     if d0 and arm!='N0':near_diagnostic(folder,label+'_'+arm+'_near',fit,cat,nuis,arm,sigma,E.ORIGINS[fold],E.ENDS[fold])
     if arm=='N0':continue
     sc=score_arm(folder,label+'_'+arm,cat,nuis,arm,pars,sigma,E.ORIGINS[fold],E.ENDS[fold]);rows.append(dict(region='JMA',case=job['case'],arm=arm,trend=label,partition='full',**compact_score(sc)))
  receipt=dict(status='complete',case=job['case'],rows=rows,wall_seconds=time.perf_counter()-begin);write(folder/'receipt.json',receipt)
  return dict(case=job['case'],status='complete',wall_seconds=receipt['wall_seconds'])
 except Exception as exc:
  receipt=dict(status='failed',case=job['case'],error_type=type(exc).__name__,reason=str(exc),wall_seconds=time.perf_counter()-begin);write(folder/('error_'+str(time.time_ns())+'.json'),receipt);return receipt

def compact_score(sc):
 e=sc['evaluation'];return {k:e[k] for k in ('n_events','joint_logscore','timing_logscore','conditional_location_logscore','mark_logscore','integrated_intensity','P','G')}

def run(workers,limit=None):
 jobs=read(HERE/'s06_plan/jobs.json');jobs=jobs if limit is None else jobs[:limit]
 with ProcessPoolExecutor(max_workers=workers) as pool:results=list(pool.map(run_case,jobs))
 report=dict(status='complete' if all(x['status']=='complete' for x in results) else 'incomplete',planned=len(jobs),complete=sum(x['status']=='complete' for x in results),cases=results);write(HERE/('s06_pilot_receipt.json' if limit else 's06_production_receipt.json'),report);print(json.dumps({k:report[k] for k in ('status','planned','complete')}))

if __name__=='__main__':
 frozen=read(HERE/'S06_PILOT_PROTOCOL_v2.json')
 for name,digest in frozen['source_pins'].items():assert E.sha(name)==digest,'PROTOCOL_PIN_DRIFT'
 p=argparse.ArgumentParser();p.add_argument('phase',choices=('plan','pilot','production'));p.add_argument('--workers',type=int,default=6);a=p.parse_args()
 if a.phase=='plan':plan()
 else:run(a.workers,1 if a.phase=='pilot' else None)
