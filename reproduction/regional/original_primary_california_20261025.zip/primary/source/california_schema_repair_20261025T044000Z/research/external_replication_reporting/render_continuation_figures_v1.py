"""Aggregate-only reporting renderer. Source scaffold; author has not executed it.

No catalogue, event rows, fit/case/cache, audit path or worker-log access. Only the
explicit SHA-pinned public summary and its SHA-pinned release approval are read.
Matplotlib is imported only when a root-authorized rendering command runs.
"""
import argparse
import contextlib
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys

DEPENDENCY_FILENAMES=("render_continuation_figures_v1.py",)
SUMMARY_PRODUCER_SHA256="df3b55d26d15b8fa676e51635ef4c85dadc80d74ed57458f0184c4a564a2e4bc"
MODELS=("fixedML_smooth_lift","fixedML_smooth_cont","commonML_smooth_cont","Omori_smooth_cont","Omori_smooth_lift")
COMPONENTS=("joint_logscore","timing_logscore","conditional_location_logscore","conditional_zone_logscore","conditional_cell_logscore","within_cell_density_logscore","mark_logscore","timing_event_logscore","timing_exposure_logscore","integrated_intensity")
COMPARISONS=(
    ("primary_timing","Omori_smooth_cont","fixedML_smooth_cont","timing_logscore","Primary timing\nOmori continuous vs fixed-scale ML continuous"),
    ("primary_location","Omori_smooth_cont","Omori_smooth_lift","conditional_location_logscore","Primary location\nOmori continuous vs Omori lifted"),
    ("context_freeML","Omori_smooth_cont","commonML_smooth_cont","joint_logscore","Context: free scale\nOmori continuous vs free-scale ML continuous"),
    ("context_fixedML_spatial","fixedML_smooth_cont","fixedML_smooth_lift","conditional_location_logscore","Context: fixed-scale spatial\nFixed-scale ML continuous vs lifted"),
    ("complete_procedure","Omori_smooth_cont","fixedML_smooth_lift","joint_logscore","Complete procedure\nOmori continuous vs fixed-scale ML lifted"))
WINDOWS=("2011-2016","2016-2021","2021-2026")
FORMATS=("png","pdf","svg")
COLORS=("#2166AC","#762A83","#59656F","#59656F","#1B6C50")
CODES={"RENDERER_PIN_MISMATCH","INPUT_PIN_MISMATCH","RELEASE_NOT_APPROVED","SUMMARY_SCHEMA_INVALID","SUMMARY_IDENTITY_INVALID","OUTPUT_ALREADY_EXISTS","INVALID_ARGUMENT","REPORTING_RENDER_FAILURE"}

class ReportingError(Exception):
    def __init__(self,code):
        self.code=code if code in CODES else "REPORTING_RENDER_FAILURE"
        super().__init__(self.code)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda:stream.read(65536),b""):digest.update(part)
    return digest.hexdigest()

def valid_hash(value):
    return type(value) is str and re.fullmatch(r"[0-9a-f]{64}",value) is not None

def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ReportingError("SUMMARY_SCHEMA_INVALID")
        result[key]=value
    return result

def read_pinned(path,expected,cap):
    if not valid_hash(expected):raise ReportingError("INPUT_PIN_MISMATCH")
    # Read one bounded immutable byte view: the parsed bytes must be those hashed.
    with Path(path).open("rb") as stream:raw=stream.read(cap+1)
    if len(raw)>cap:raise ReportingError("SUMMARY_SCHEMA_INVALID")
    if hashlib.sha256(raw).hexdigest()!=expected:raise ReportingError("INPUT_PIN_MISMATCH")
    def bad_constant(unused):raise ReportingError("SUMMARY_SCHEMA_INVALID")
    try:return json.loads(raw.decode("utf-8-sig"),object_pairs_hook=_pairs,parse_constant=bad_constant)
    except ReportingError:raise
    except Exception:raise ReportingError("SUMMARY_SCHEMA_INVALID") from None

def number(value):
    if type(value) not in (float,int) or not math.isfinite(value):raise ReportingError("SUMMARY_SCHEMA_INVALID")
    return float(value)

def count(value):
    if type(value) is not int or value<0:raise ReportingError("SUMMARY_SCHEMA_INVALID")
    return value

def close(left,right):
    return abs(number(left)-number(right))<=1e-7

def checked_comparison(entry,spec):
    ident,candidate,reference,component,_=spec
    if (type(entry) is not dict or tuple(entry.get(k) for k in ("id","candidate","reference","primary_component"))!=(ident,candidate,reference,component)
            or entry.get("status") not in ("complete","unknown_incomplete")):
        raise ReportingError("SUMMARY_SCHEMA_INVALID")
    if entry["status"]=="unknown_incomplete":
        if any(k in entry for k in ("primary_delta_nats","primary_delta_nats_per_event","delta")):
            raise ReportingError("SUMMARY_SCHEMA_INVALID")
        return None
    n=count(entry.get("n_test"))
    delta=entry.get("delta")
    if n==0 or type(delta) is not dict or set(delta)!=set(COMPONENTS):raise ReportingError("SUMMARY_SCHEMA_INVALID")
    delta={k:number(delta[k]) for k in COMPONENTS}
    if (not close(delta["joint_logscore"],delta["timing_logscore"]+delta["conditional_location_logscore"]+delta["mark_logscore"])
            or not close(delta["timing_logscore"],delta["timing_event_logscore"]+delta["timing_exposure_logscore"])
            or not close(entry.get("primary_delta_nats"),delta[component])
            or not close(entry.get("primary_delta_nats_per_event"),delta[component]/n)):
        raise ReportingError("SUMMARY_IDENTITY_INVALID")
    return {"n":n,"total":delta[component],"per_target":delta[component]/n,"delta":delta}

def approved_projection(summary,approval,summary_sha):
    """Read only scalar aggregate fields; never follow any referenced path."""
    if (type(approval) is not dict or approval.get("status")!="accepted" or approval.get("approved_for_public_reporting") is not True
            or approval.get("summary_sha256")!=summary_sha or approval.get("summary_producer_sha256")!=SUMMARY_PRODUCER_SHA256):
        raise ReportingError("RELEASE_NOT_APPROVED")
    if (type(summary) is not dict or type(summary.get("schema_version")) is not int or summary["schema_version"]!=2
            or summary.get("source_sha256")!=SUMMARY_PRODUCER_SHA256 or summary.get("status") not in ("complete","unknown_incomplete")):
        raise ReportingError("SUMMARY_SCHEMA_INVALID")
    audit=summary.get("independent_audit",{})
    if (type(audit) is not dict or audit.get("status")!="passed" or audit.get("passed") is not True
            or audit.get("independent") is not True or audit.get("mode")!="full" or not valid_hash(audit.get("sha256"))
            or approval.get("independent_audit_sha256")!=audit["sha256"]):raise ReportingError("RELEASE_NOT_APPROVED")
    denominators=summary.get("denominators",{})
    expected={"planned_windows":3,"procedures":30,"starts":240,"floors":33}
    if type(denominators) is not dict or any(type(denominators.get(k)) is not int or denominators[k]!=v for k,v in expected.items()):raise ReportingError("SUMMARY_SCHEMA_INVALID")
    cases=summary.get("cases")
    if type(cases) is not list or len(cases)!=3:raise ReportingError("SUMMARY_SCHEMA_INVALID")
    projected=[]
    for ordinal,case in enumerate(cases):
        if (type(case) is not dict or case.get("case_id")!="california_fold_"+str(ordinal)
                or case.get("status") not in ("complete","unknown_incomplete") or type(case.get("models")) is not dict or set(case["models"])!=set(MODELS)):
            raise ReportingError("SUMMARY_SCHEMA_INVALID")
        ntrain,ntest=count(case.get("n_train")),count(case.get("n_test"))
        for name,total in (("training_cell_counts",ntrain),("test_cell_counts",ntest)):
            cells=case.get(name)
            if type(cells) is not list or len(cells)!=9 or sum(count(n) for n in cells)!=total:raise ReportingError("SUMMARY_SCHEMA_INVALID")
        comparisons=case.get("comparisons")
        if type(comparisons) is not list or len(comparisons)!=5:raise ReportingError("SUMMARY_SCHEMA_INVALID")
        views=[checked_comparison(entry,spec) for entry,spec in zip(comparisons,COMPARISONS)]
        if any((view is not None)!=(case["status"]=="complete") for view in views):raise ReportingError("SUMMARY_SCHEMA_INVALID")
        if any(view is not None and view["n"]!=ntest for view in views):raise ReportingError("SUMMARY_IDENTITY_INVALID")
        projected.append({"status":case["status"],"n_train":ntrain,"n_test":ntest,"comparisons":views})
    if count(denominators.get("all_test_targets"))!=sum(c["n_test"] for c in projected):raise ReportingError("SUMMARY_IDENTITY_INVALID")
    if (summary["status"]=="complete")!=all(c["status"]=="complete" for c in projected):raise ReportingError("SUMMARY_SCHEMA_INVALID")
    aggregate=summary.get("comparisons")
    if type(aggregate) is not list or len(aggregate)!=5:raise ReportingError("SUMMARY_SCHEMA_INVALID")
    pooled=[]
    for index,(entry,spec) in enumerate(zip(aggregate,COMPARISONS)):
        view=checked_comparison(entry,spec)
        parts=[c["comparisons"][index] for c in projected]
        complete=sum(part is not None for part in parts)
        if (type(entry.get("planned_windows")) is not int or entry["planned_windows"]!=3
                or type(entry.get("complete_windows")) is not int or entry["complete_windows"]!=complete
                or (view is not None)!=(complete==3)):raise ReportingError("SUMMARY_SCHEMA_INVALID")
        if view is not None:
            n=sum(part["n"] for part in parts)
            if view["n"]!=n or not close(view["total"],math.fsum(part["total"] for part in parts)):raise ReportingError("SUMMARY_IDENTITY_INVALID")
            if any(not close(view["delta"][k],math.fsum(part["delta"][k] for part in parts)) for k in COMPONENTS):raise ReportingError("SUMMARY_IDENTITY_INVALID")
            window_deltas=entry.get("window_deltas_nats")
            if (type(window_deltas) is not list or len(window_deltas)!=3 or any(not close(a,b["total"]) for a,b in zip(window_deltas,parts))
                    or type(entry.get("positive_windows")) is not int or entry["positive_windows"]!=sum(p["total"]>0 for p in parts)):
                raise ReportingError("SUMMARY_IDENTITY_INVALID")
        pooled.append({"view":view,"complete_windows":complete})
    return {"status":summary["status"],"cases":projected,"pooled":pooled,"all_test_targets":sum(c["n_test"] for c in projected)}

def _save(fig,name,out,plt):
    for suffix in FORMATS:
        fig.savefig(out/(name+"."+suffix),format=suffix,dpi=300,facecolor="white",bbox_inches="tight")
    plt.close(fig)

def _foot(fig,text):
    fig.text(0.02,0.015,text,fontsize=9,color="#404040",ha="left",va="bottom")

def diagrams(out,plt,patches):
    fig,ax=plt.subplots(figsize=(12,3.7))
    ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
    cards=[(.02,"TRAIN","Choose settings from earlier data.\nSelection uses training objective only.","#DBEAF6"),(.35,"FREEZE","Freeze parameters and rules\nat the declared forecast origin.","#E7E1F1"),(.68,"EVALUATE","Use the next fixed window.\nKeep failures and unknowns.","#F8E5C7")]
    for x,title,body,color in cards:
        ax.add_patch(patches.FancyBboxPatch((x,.35),.29,.43,boxstyle="round,pad=0.015",facecolor=color,edgecolor="#59656F"))
        ax.text(x+.145,.66,title,ha="center",fontsize=14,weight="bold")
        ax.text(x+.145,.48,body,ha="center",va="center",fontsize=10)
    for x in (.315,.645):ax.annotate("",xy=(x+.035,.56),xytext=(x,.56),arrowprops={"arrowstyle":"->","lw":1.7})
    ax.text(.5,.16,"Earlier observations may enter history under the frozen rule; later outcomes cannot retune that window.",ha="center",fontsize=10)
    fig.suptitle("Learn first, freeze the rules, then evaluate",fontsize=16)
    _foot(fig,"Conceptual protocol diagram. No observed events or result values. Historical California evaluation uses a revised catalogue.")
    _save(fig,"forecast_workflow",out,plt)
    fig,ax=plt.subplots(figsize=(12,4.4))
    for index,(origin,end) in enumerate(((2011,2016),(2016,2021),(2021,2026))):
        y=2-index
        ax.barh(y,5,left=1981,height=.45,color="#C6C6C6")
        ax.barh(y,origin-1986,left=1986,height=.45,color="#73A9D2")
        ax.barh(y,end-origin,left=origin,height=.45,color="#E5B96F")
        ax.plot([origin,origin],[y-.32,y+.32],color="#4C286D",lw=2)
        ax.text(origin,y+.36,"freeze",ha="center",fontsize=9,color="#4C286D")
    ax.set_yticks([2,1,0],labels=["Fold 1: 2011-2016","Fold 2: 2016-2021","Fold 3: 2021-2026"])
    ax.set_xticks([1981,1986,1991,1996,2001,2006,2011,2016,2021,2026]);ax.set_xlim(1980,2027)
    ax.set_xlabel("Calendar year (half-open UTC windows)")
    for side in ("top","right","left"):ax.spines[side].set_visible(False)
    ax.tick_params(axis="y",length=0)
    handles=[patches.Patch(color="#C6C6C6",label="Warmup: parent history only"),patches.Patch(color="#73A9D2",label="Scored training"),patches.Patch(color="#E5B96F",label="Fixed test window")]
    ax.legend(handles=handles,loc="upper left",bbox_to_anchor=(0,1.17),ncol=3,frameon=False,fontsize=9)
    fig.suptitle("Three fixed windows, with expanding training",fontsize=16,y=1.02)
    fig.subplots_adjust(bottom=.22,top=.82,left=.21)
    _foot(fig,"Design dates only; no target counts shown. Warmup never enters training targets or nuisance counts. Parameters stay fixed within each test window.")
    _save(fig,"protocol_timeline",out,plt)
    fig,ax=plt.subplots(figsize=(12,4.6));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
    cards=[(.02,"WHEN / HOW MANY?","Event log ground rate\nminus full predicted exposure\n(including quiet periods)","#DBEAF6"),(.35,"WHERE, GIVEN AN EVENT?","Conditional location density\non the declared spatial support\nwith the declared area measure","#E7E1F1"),(.68,"MAGNITUDE","The common declared\nmagnitude mark score\nunder the frozen protocol","#E1EEE7")]
    for x,title,body,color in cards:
        ax.add_patch(patches.FancyBboxPatch((x,.36),.29,.43,boxstyle="round,pad=.015",facecolor=color,edgecolor="#59656F"))
        ax.text(x+.145,.68,title,ha="center",fontsize=11,weight="bold")
        ax.text(x+.145,.50,body,ha="center",va="center",fontsize=10)
    ax.text(.333,.56,"+",fontsize=18,ha="center");ax.text(.663,.56,"+",fontsize=18,ha="center")
    ax.text(.5,.17,"JOINT PROPER SCORE = TIMING + CONDITIONAL LOCATION + MAGNITUDE",ha="center",fontsize=12,weight="bold")
    fig.suptitle("Timing and location answer different questions",fontsize=16)
    _foot(fig,"Conceptual score identity, not a result. Timing is a point-process ground score; it is not a density normalized over the observed event times.")
    _save(fig,"score_components",out,plt)


def summary_status_figure(view,out,plt,patches):
    """Display only statuses and counts projected from the pinned approved summary."""
    fig,ax=plt.subplots(figsize=(12,4.4));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis("off")
    overall=view["status"]
    color="#DDEFE4" if overall=="complete" else "#F8E5C7"
    ax.add_patch(patches.FancyBboxPatch((.04,.77),.92,.15,boxstyle="round,pad=.012",facecolor=color,edgecolor="#59656F"))
    ax.text(.07,.845,"Approved summary status: "+overall.replace("_"," "),fontsize=12,weight="bold",va="center")
    ax.text(.93,.845,"All-window targets: "+format(view["all_test_targets"],","),fontsize=11,ha="right",va="center")
    for ordinal,case in enumerate(view["cases"]):
        y=.54-ordinal*.25
        color="#DDEFE4" if case["status"]=="complete" else "#F8E5C7"
        ax.add_patch(patches.FancyBboxPatch((.04,y),.92,.18,boxstyle="round,pad=.01",facecolor=color,edgecolor="#59656F"))
        ax.text(.07,y+.12,WINDOWS[ordinal]+" | "+case["status"].replace("_"," "),fontsize=11,weight="bold",va="center")
        ax.text(.07,y+.05,"Training targets: "+format(case["n_train"],",")+"    Test targets: "+format(case["n_test"],","),fontsize=10,va="center")
    fig.suptitle("Window status and target counts from the approved aggregate",fontsize=15)
    _foot(fig,"Statuses and counts are read from the SHA-pinned public summary after release-approval checks. Unknown windows remain visible; no score is imputed.")
    _save(fig,"summary_status",out,plt)

def _axis(ax,values):
    if values:
        extent=max(abs(v) for v in values)
        extent=extent*1.35 if extent else .01
        ax.set_xlim(-extent,extent);ax.axvline(0,color="#333333",lw=1,ls="--")
        ax.set_xlabel("Candidate minus reference (nats per target)")
        ax.grid(axis="x",color="#E7E7E7",lw=.7);ax.set_axisbelow(True)
    else:
        ax.set_xlim(-1,1);ax.set_xticks([]);ax.set_xlabel("No numerical estimate plotted")
    for side in ("top","right","left"):ax.spines[side].set_visible(False)
    ax.tick_params(axis="y",length=0)

def comparison_figures(view,out,plt):
    fig,ax=plt.subplots(figsize=(13,6.6))
    values=[p["view"]["per_target"] for p in view["pooled"] if p["view"] is not None]
    _axis(ax,values)
    for index,(pooled,spec) in enumerate(zip(view["pooled"],COMPARISONS)):
        y=4-index
        item=pooled["view"]
        if item is None:
            ax.text(.03,y,"Unknown/incomplete ? "+str(pooled["complete_windows"])+"/3 complete windows",transform=ax.get_yaxis_transform(),va="center",fontsize=10)
        else:
            ax.scatter(item["per_target"],y,s=65,color=COLORS[index],marker="o" if index<2 else "D",zorder=3)
            ax.annotate(format(item["per_target"],".3g")+"; N="+str(item["n"]),(item["per_target"],y),xytext=(0,11),textcoords="offset points",ha="center",fontsize=9)
    ax.set_yticks(range(4,-1,-1),labels=[spec[4] for spec in COMPARISONS],fontsize=9)
    ax.set_ylim(-.6,4.6)
    ax.set_title("Approved California aggregate comparisons",fontsize=16,pad=18)
    fig.subplots_adjust(left=.40,bottom=.22,right=.97,top=.87)
    _foot(fig,"Positive favors the named candidate for that row's component. Pooling = summed differences / summed targets across all three windows.\nDots are estimates, not confidence intervals; no event-iid inference. Revised-catalogue hindsight; conditional regional history.")
    _save(fig,"comparison_overview",out,plt)
    fig,axes=plt.subplots(1,2,figsize=(13,4.8),sharey=True)
    for index,ax in enumerate(axes):
        values=[c["comparisons"][index]["per_target"] for c in view["cases"] if c["comparisons"][index] is not None]
        _axis(ax,values)
        for ordinal,case in enumerate(view["cases"]):
            item=case["comparisons"][index];y=2-ordinal
            if item is None:ax.text(.03,y,"Unknown/incomplete | N_test="+format(case["n_test"],","),transform=ax.get_yaxis_transform(),va="center",fontsize=9)
            else:
                ax.scatter(item["per_target"],y,color=COLORS[index],s=60,zorder=3)
                ax.annotate(format(item["per_target"],".3g")+"; N="+str(item["n"]),(item["per_target"],y),xytext=(0,11),textcoords="offset points",ha="center",fontsize=9)
        ax.set_title("Primary timing" if index==0 else "Primary location",fontsize=13)
        ax.set_ylim(-.5,2.5)
    axes[0].set_yticks([2,1,0],labels=WINDOWS)
    fig.suptitle("All three predeclared windows remain visible",fontsize=16)
    fig.subplots_adjust(left=.13,right=.97,bottom=.25,top=.80,wspace=.23)
    _foot(fig,"Panels use separate symmetric horizontal scales. Window dots are not independent event samples or confidence intervals.\nUnknown windows are never treated as zero or omitted from the planned denominator; no pooled estimate unless every window is complete.")
    _save(fig,"primary_windows",out,plt)

def render(args):
    if not valid_hash(args.expected_renderer_sha256) or sha(__file__)!=args.expected_renderer_sha256:raise ReportingError("RENDERER_PIN_MISMATCH")
    if not args.output.is_absolute():raise ReportingError("INVALID_ARGUMENT")
    empirical=(args.summary,args.expected_summary_sha256,args.approval,args.expected_approval_sha256)
    if args.diagrams_only:
        if any(v is not None for v in empirical):raise ReportingError("INVALID_ARGUMENT")
        view=None
    else:
        if any(v is None for v in empirical):raise ReportingError("INVALID_ARGUMENT")
        approval=read_pinned(args.approval,args.expected_approval_sha256,256*1024)
        if (type(approval) is not dict or approval.get("status")!="accepted" or approval.get("approved_for_public_reporting") is not True
                or approval.get("summary_sha256")!=args.expected_summary_sha256 or approval.get("summary_producer_sha256")!=SUMMARY_PRODUCER_SHA256):
            raise ReportingError("RELEASE_NOT_APPROVED")
        summary=read_pinned(args.summary,args.expected_summary_sha256,8*1024*1024)
        view=approved_projection(summary,approval,args.expected_summary_sha256)
    # Inputs fully gated before output creation; never overwrite an existing output.
    try:args.output.mkdir(parents=True,exist_ok=False)
    except FileExistsError:raise ReportingError("OUTPUT_ALREADY_EXISTS") from None
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import patches
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"pdf.fonttype":42,"svg.fonttype":"none","axes.unicode_minus":True})
    diagrams(args.output,plt,patches)
    if view is not None:
        summary_status_figure(view,args.output,plt,patches)
        comparison_figures(view,args.output,plt)
    artifacts={p.name:sha(p) for p in sorted(args.output.iterdir()) if p.suffix in (".png",".pdf",".svg")}
    expected_families=3 if view is None else 6
    if len(artifacts)!=expected_families*3:raise ReportingError("REPORTING_RENDER_FAILURE")
    receipt={"schema_version":1,"status":"rendered_pending_visual_QA_and_delivery_review","mode":"conceptual_diagrams_only" if view is None else "approved_aggregate_figures",
        "renderer_sha256":args.expected_renderer_sha256,"summary_producer_sha256":SUMMARY_PRODUCER_SHA256,
        "summary_sha256":None if view is None else args.expected_summary_sha256,"release_approval_sha256":None if view is None else args.expected_approval_sha256,
        "summary_status":None if view is None else view["status"],"matplotlib_version":matplotlib.__version__,"artifacts_sha256":artifacts,
        "event_data_read":False,"private_references_followed":False,"confidence_intervals_or_p_values_generated":False,
        "actual_results_claimed_by_conceptual_diagrams":False,"publication_authorized_by_rendering":False}
    with (args.output/"render_receipt.json").open("x",encoding="utf-8") as stream:json.dump(receipt,stream,indent=2,allow_nan=False)
    return {"status":receipt["status"],"figure_families":expected_families,"artifact_count":len(artifacts),"render_receipt_sha256":sha(args.output/"render_receipt.json")}

def main(argv=None):
    cli=argparse.ArgumentParser(description="Proposed aggregate-only renderer; root authorization/lease and later visual QA required")
    cli.add_argument("--expected-renderer-sha256",required=True)
    cli.add_argument("--output",type=Path,required=True)
    cli.add_argument("--diagrams-only",action="store_true")
    cli.add_argument("--summary",type=Path);cli.add_argument("--expected-summary-sha256")
    cli.add_argument("--approval",type=Path);cli.add_argument("--expected-approval-sha256")
    args=cli.parse_args(argv)
    try:
        # Suppress backend diagnostics and sourceful exception messages from stdout/stderr.
        with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):result=render(args)
    except BaseException as error:
        result={"status":"failed","fixed_error_code":error.code if isinstance(error,ReportingError) else "REPORTING_RENDER_FAILURE"}
    print(json.dumps(result,sort_keys=True,allow_nan=False))
    return 0 if result["status"]!="failed" else 1

if __name__=="__main__":sys.exit(main())
