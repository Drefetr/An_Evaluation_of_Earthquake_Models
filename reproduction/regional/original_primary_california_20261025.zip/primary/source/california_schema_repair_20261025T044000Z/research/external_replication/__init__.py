"""External retrospective and prospective forecasting implementation."""
