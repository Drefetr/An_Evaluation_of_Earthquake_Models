"""Private canonical and pinned legacy catalogue ingestion; never formats event values."""
from dataclasses import dataclass
from datetime import datetime,timezone,timedelta
from pathlib import Path
import csv,json,hashlib,re
import numpy as np
try:
    from .geometry import PROFILES,cell_ids
except ImportError:
    from geometry import PROFILES,cell_ids

@dataclass(frozen=True)
class Catalogue:
    times: np.ndarray
    excess: np.ndarray
    latitude: np.ndarray
    longitude: np.ndarray
    cells: np.ndarray
    event_ids: tuple
    source_sha256: str
    provenance: dict

def utc(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)',value):raise ValueError('UTC_SCHEMA')
    try:return datetime.fromisoformat(value.replace('Z','+00:00'))
    except Exception:raise ValueError('UTC_SCHEMA') from None

def day(value,profile):return (utc(value)-utc(PROFILES[profile]['epoch'])).total_seconds()/86400

def load_catalogue(path,expected_sha256,*,profile='california',legacy_csv=False):
    path=Path(path);raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    if not expected_sha256 or digest!=expected_sha256:raise ValueError('CATALOGUE_IDENTITY')
    if legacy_csv:
        if profile!='new_zealand':raise ValueError('LEGACY_PROFILE')
        rows=list(csv.DictReader(raw.decode('utf-8-sig').splitlines()));provenance={'source_snapshot':'pinned_legacy_NZ','raw_manifest_sha256':digest,'retrieved_utc':None}
    else:
        try:
            if path.suffix=='.jsonl':
                items=[json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
                header=items[0];rows=items[1:]
                if header.get('record_type')!='catalogue_header':raise ValueError('CANONICAL_HEADER')
                obj=dict(header,events=rows)
            else:obj=json.loads(raw.decode('utf-8-sig'));rows=obj['events']
            if obj['schema_version']!=1 or not isinstance(obj['catalogue_id'],str):raise ValueError('CANONICAL_SCHEMA')
            provenance=obj['provenance']
            if not all(k in provenance for k in ['source_snapshot','raw_manifest_sha256','retrieved_utc']):raise ValueError('CANONICAL_PROVENANCE')
        except Exception:raise ValueError('CANONICAL_SCHEMA') from None
    ids=[];times=[];q=[];lat=[];lon=[];previous=None
    for r in rows:
        try:
            eid=r['event_id'];a=float(r['latitude']);b=float(r['longitude']);m=float(r['magnitude'])
            if not isinstance(eid,str) or not eid:raise ValueError()
            if legacy_csv:
                t=float(r['t_days']);excess=float(r['excess'])
                if abs(m-5-excess)>2e-12:raise ValueError()
            else:
                required=['depth_km','magnitude_type','event_type','source_year','source_line_1based']
                if not all(k in r for k in required):raise ValueError()
                t=day(r['origin_time_utc'],profile);excess=m-PROFILES[profile]['minimum_magnitude']
                if profile=='california':
                    if r['event_type']!='eq' or r['magnitude_type'] not in ['e','w','b','s','l','lr','c','h','d'] or not -5<=float(r['depth_km'])<=40:raise ValueError()
                if 'origin_time_us' in r:
                    exact=int((utc(r['origin_time_utc'])-datetime(1970,1,1,tzinfo=timezone.utc))//timedelta(microseconds=1))
                    if isinstance(r['origin_time_us'],bool) or r['origin_time_us']!=exact:raise ValueError()
            if not np.isfinite([a,b,m,t,excess]).all() or excess<0 or t<0:raise ValueError()
            key=(t,eid)
            if previous is not None and key<previous:raise ValueError()
            previous=key;ids.append(eid);times.append(t);q.append(excess);lat.append(a);lon.append(b)
        except Exception:raise ValueError('CANONICAL_ROW_INVALID') from None
    if len(set(ids))!=len(ids):raise ValueError('CANONICAL_DUPLICATE_ID')
    lat=np.asarray(lat,float);lon=np.asarray(lon,float)
    return Catalogue(np.asarray(times,float),np.asarray(q,float),lat,lon,cell_ids(lat,lon,profile),tuple(ids),digest,provenance)
