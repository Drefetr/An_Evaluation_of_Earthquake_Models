﻿"""Manual prospective daily issue archive and fixed-parent compiled query evaluator."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
import ctypes as ct,json,hashlib
import numpy as np
try:
    from . import geometry as G
    from .catalogue import load_catalogue,utc,day
    from .compiled_objective import Objective,library,MODELS
    from .workflow import read,write,sha,MODELS as MODEL_IDS,SOURCE_FILES,HERE,score
except ImportError:
    import geometry as G
    from catalogue import load_catalogue,utc,day
    from compiled_objective import Objective,library,MODELS
    from workflow import read,write,sha,MODELS as MODEL_IDS,SOURCE_FILES,HERE,score

class FixedObjective(Objective):
    """Same score/gradient API with arbitrary target queries and issued-only parents."""
    def __init__(self,arrays,metadata,dll_path=None):
        self.handle=None;self.lib,self.dll_path=library(dll_path);a={k:np.ascontiguousarray(v,dtype=np.float64) for k,v in arrays.items()};self.arrays=a;self.metadata=metadata;self.ne=len(a['event_time']);self.np=len(a['parent_time'])
        if any(not np.isfinite(v).all() for v in a.values()) or np.any(np.diff(a['parent_time'])<0) or np.any(a['parent_time']>=metadata['start']) or np.any(np.diff(a['event_time'])<0) or np.any(a['event_time']<metadata['start']) or np.any(a['event_time']>=metadata['end']):raise ValueError('fixed history/query chronology')
        pd=ct.POINTER(ct.c_double);self.lib.ts_create_query.argtypes=[ct.c_int]*3+[pd]*14;self.lib.ts_create_query.restype=ct.c_void_p
        names=['parent_time','event_time','event_x','event_cell','event_background_density','background_cell_mass','event_parent_density','parent_cell_mass','parent_fertility','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates']
        meta=np.array([metadata['start'],metadata['end'],metadata['T0'],self.ne*np.log(metadata['beta'])-metadata['beta']*a['event_excess'].sum()])
        self.handle=self.lib.ts_create_query(self.ne,self.np,195,*[a[n].ctypes.data_as(pd) for n in names],meta.ctypes.data_as(pd))
        if not self.handle:raise ValueError('fixed objective create')

def verify_registration(reg):
    if reg.get('status')!='frozen' or reg.get('initialization_audit_passed') is not True:raise ValueError('prospective registration not frozen')
    pins=reg.get('artifact_pins',{})
    for path in [HERE/n for n in SOURCE_FILES]:
        if pins.get(str(path.resolve()))!=sha(path):raise ValueError('prospective source pin')
    for path,digest in pins.items():
        if sha(path)!=digest:raise ValueError('prospective artifact changed')
    freeze=utc(reg['freeze_utc']);start=utc(reg['start_utc']);end=utc(reg['end_utc']);first=(freeze+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
    if start!=first or end!=start.replace(year=start.year+10):raise ValueError('registration horizon')

def archive_issue(registration_path,training_case_path,source_path,source_sha256,received_utc,validity_start_utc,folder,*,now=None,fixture=False):
    """Late/missing days cannot be created retrospectively; no network collection here."""
    reg=read(registration_path);verify_registration(reg);start=utc(validity_start_utc);end=start+timedelta(days=1);received=utc(received_utc);actual=datetime.now(timezone.utc) if now is None else utc(now)
    if now is not None and not fixture:raise ValueError('synthetic clock requires fixture mode')
    if start.hour or start.minute or start.second or start.microsecond:raise ValueError('daily UTC boundary')
    if not utc(reg['start_utc'])<=start<end<=utc(reg['end_utc']):raise ValueError('outside registered horizon')
    if received>start-timedelta(hours=1) or received>actual or actual>=start or actual<utc(reg['freeze_utc']):raise ValueError('late/missing source or issue')
    training_case_path=Path(training_case_path).resolve()
    if reg['artifact_pins'].get(str(training_case_path))!=sha(training_case_path):raise ValueError('initialization pin')
    training=read(training_case_path)
    if training['profile']!='new_zealand' or training['status']!='complete' or set(training['models'])!=set(MODEL_IDS) or training['case']['train_end']!=24394.:raise ValueError('initialization receipt')
    source=load_catalogue(source_path,source_sha256,profile='new_zealand')
    if np.any(source.times>=day(validity_start_utc,'new_zealand')):raise ValueError('source has future-origin parent')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=False);target=folder/'issued_parent_snapshot.json'
    with target.open('xb') as f:f.write(Path(source_path).read_bytes())
    models={}
    for mid in MODEL_IDS:
        r=training['models'][mid]
        if not r['complete']:raise ValueError('incomplete frozen model')
        path=Path(r['cache_paths']['train16']).resolve()
        if reg['artifact_pins'].get(str(path))!=sha(path):raise ValueError('frozen nuisance cache pin')
        models[mid]=dict(model=r['model'],pars=r['selected']['pars'],spatial=r['spatial'],sigma=r['sigma'],nuisance_cache=str(path),nuisance_cache_sha256=sha(path))
    packet=dict(schema_version=1,status='fixture' if fixture else 'issued',registration_path=str(Path(registration_path).resolve()),registration_sha256=sha(registration_path),training_case_path=str(training_case_path),training_case_sha256=sha(training_case_path),validity_start_utc=validity_start_utc,validity_end_utc=end.isoformat().replace('+00:00','Z'),actual_issue_utc=actual.isoformat(),source_received_utc=received_utc,source_snapshot_path=str(target.resolve()),source_snapshot_sha256=source_sha256,models=models,beta=training['beta'],T0=24394.,history_policy='fixed issued parents; no within-day updating',backfill=False)
    write(folder/'issued_packet.json',packet);return dict(status=packet['status'],packet_path=str((folder/'issued_packet.json').resolve()),packet_sha256=sha(folder/'issued_packet.json'))

def fixed_arrays(packet,mid,event_times,event_excess,event_lat,event_lon):
    """Targets enter query arrays only; archived parent bytes are revalidated every use."""
    if packet['status'] not in ['issued','fixture']:raise ValueError('unissued day')
    p=packet['models'][mid];parent=load_catalogue(packet['source_snapshot_path'],packet['source_snapshot_sha256'],profile='new_zealand');start=day(packet['validity_start_utc'],'new_zealand');end=day(packet['validity_end_utc'],'new_zealand')
    if sha(p['nuisance_cache'])!=p['nuisance_cache_sha256']:raise ValueError('changed nuisance cache')
    with np.load(p['nuisance_cache'],allow_pickle=False) as saved:
        pi=saved['reference_pi'].copy();kxy=saved['kde_training_xy'].copy();kZ=saved['kde_normalizers'].copy();meta=json.loads(str(saved['metadata_json'].item()));bgmass=saved['background_cell_mass'].copy()
    if np.any(parent.times>=start):raise ValueError('issued parent chronology')
    et=np.asarray(event_times,float);eq=np.asarray(event_excess,float);xy=G.project(event_lat,event_lon,'new_zealand');cells=G.cell_ids(event_lat,event_lon,'new_zealand');pxy=G.project(parent.latitude,parent.longitude,'new_zealand');rect,area,centers=G.support('new_zealand');b=pi/area
    if eq.shape!=et.shape or xy.shape!=(len(et),2) or np.any(eq<0):raise ValueError('query shape')
    if p['spatial']=='cont':
        F=G.rectangle_integrals(pxy,p['sigma'],profile='new_zealand');Z=F@b;W=F*b[None,:]/Z[:,None];density=b[cells,None]*(1+np.sum((xy[:,None,:]-pxy[None,:,:])**2,axis=2)/p['sigma']**2)**-2/Z[None,:]
    else:
        raw=pi[None,:]*(1+np.sum((pxy[:,None,:]-centers[None,:,:])**2,axis=2)/p['sigma']**2)**-2;W=raw/raw.sum(axis=1)[:,None];density=W[:,cells].T/area[cells,None]
    eventb=.05*b[cells]+.95*G.kde_density(xy,kxy,meta['kde_bandwidth'],kZ).mean(axis=1);w,r=G.mixture()
    arrays=dict(parent_time=parent.times,parent_fertility=.3*np.exp(.7*packet['beta']*parent.excess),parent_exposure_lo=start-parent.times,parent_exposure_hi=end-parent.times,parent_cell_mass=W,event_time=et,event_excess=eq,event_cell=cells,event_x=2*et/24394.-1,event_background_density=eventb,background_cell_mass=bgmass,event_parent_density=density,mixture_weights=w,mixture_rates=r)
    return arrays,dict(start=start,end=end,T0=24394.,beta=packet['beta'])

def evaluate_day(packet_path,mid,event_times,event_excess,event_lat,event_lon):
    packet=read(packet_path);a,m=fixed_arrays(packet,mid,event_times,event_excess,event_lat,event_lon)
    with FixedObjective(a,m) as obj:return obj.evaluate(packet['models'][mid]['model'],packet['models'][mid]['pars'])
