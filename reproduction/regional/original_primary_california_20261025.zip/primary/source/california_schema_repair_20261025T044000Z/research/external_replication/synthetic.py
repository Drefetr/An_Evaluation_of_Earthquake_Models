"""Fixed-seed cluster histories with a known normalized smooth background.

The nuisance background truth is known, so this tests implementation and
bandwidth selection mechanics, not recovery of a uniquely identifiable KDE h.
There are no retries, redraws, or replacement histories after a failure.
"""
import heapq,math,time
import numpy as np
try:
    from .geometry import mixture,point_cells,inverse,support
except ImportError:
    from geometry import mixture,point_cells,inverse,support
def require(value,message):
    if not value:raise ValueError(message)

SCENARIOS=(dict(name='TS_commonML_uniform',seed=89113,mark_seed=73113,location_seed=59113,
                kernel='ml',background='uniform',tau=.6,c=.25,p=1.45,n=.25),
           dict(name='TS_Omori_smooth',seed=89119,mark_seed=73119,location_seed=59119,
                kernel='omori',background='smooth',tau=.6,c=.25,p=1.45,n=.25))


class GenerationFailure(RuntimeError):
    def __init__(self,message,partial):
        super().__init__(message);self.partial=partial


def generate(rectangles,scenario,rate=.35,horizon=420.,sigma=50.,background_h=150.,
             beta=2.85,floor=.05,event_cap=1500,spatial_proposal_cap=300000,
             seconds=90.,profile="california"):
    if isinstance(scenario,str):
        found=[s for s in SCENARIOS if s['name']==scenario]
        require(len(found)==1,'Frozen synthetic scenario identity');scenario=found[0]
    rect=np.asarray(rectangles,float);area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2])
    outer=[rect[:,0].min(),rect[:,1].max(),rect[:,2].min(),rect[:,3].max()]
    require(abs(area.sum()-(outer[1]-outer[0])*(outer[3]-outer[2]))<1e-6,'Tiled rectangle')
    require(0<=scenario['n']<1,'Subcritical branching law')
    clock=np.random.Generator(np.random.PCG64(scenario['seed']))
    marks=np.random.Generator(np.random.PCG64(scenario['mark_seed']))
    loc=np.random.Generator(np.random.PCG64(scenario['location_seed']))
    centers=np.array([[outer[0]+.32*(outer[1]-outer[0]),outer[2]+.28*(outer[3]-outer[2])],
                      [outer[0]+.68*(outer[1]-outer[0]),outer[2]+.73*(outer[3]-outer[2])]])
    weights,rates=mixture();began=time.monotonic();draws=0;pending=[];counter=0
    out=[];offspring_counts=[];immigrants=[]
    def open_u(rng):
        value=float(rng.random());require(0<value<1,'Open uniform; no resampling');return value
    def bounded():
        require(time.monotonic()-began<seconds,'Synthetic wall cap')
        require(len(out)<event_cap,'Synthetic event cap')
        require(len(pending)+len(out)<=event_cap,'Synthetic pending-plus-retained cap')
    def radial(center,h):
        nonlocal draws
        while True:
            bounded();require(draws<spatial_proposal_cap,'Spatial proposal cap');draws+=1
            u=open_u(loc);r=h*math.sqrt(u/(1-u));a=2*math.pi*open_u(loc)
            xy=center+r*np.array([math.cos(a),math.sin(a)])
            if outer[0]<=xy[0]<=outer[1] and outer[2]<=xy[1]<=outer[3]:return xy
    def bgdraw():
        if scenario['background']=='uniform' or open_u(loc)<floor:
            return np.array([outer[0]+open_u(loc)*(outer[1]-outer[0]),outer[2]+open_u(loc)*(outer[3]-outer[2])])
        return radial(centers[int(loc.integers(0,2))],background_h)
    try:
        t=0.
        while True:
            bounded();t+=-math.log(open_u(clock))/rate
            if t>=horizon:break
            require(len(pending)+len(out)<event_cap,'Immigrant pending insertion cap')
            heapq.heappush(pending,(t,counter,-1,bgdraw()));counter+=1;immigrants.append(t)
        while pending:
            bounded();t,identity,parent,xy=heapq.heappop(pending)
            q=-math.log(open_u(marks))/beta;fert=.3*math.exp(.7*beta*q)
            index=len(out);out.append((t,q,xy,parent,identity))
            number=int(clock.poisson(scenario['n']*fert));offspring_counts.append(number)
            require(number<=spatial_proposal_cap,'Per-parent offspring proposal cap')
            for _ in range(number):
                bounded()
                if scenario['kernel']=='ml':
                    component=int(clock.choice(len(weights),p=weights))
                    lag=-math.log(open_u(clock))*scenario['tau']/rates[component]
                else:
                    exponent=-math.log(open_u(clock))/(scenario['p']-1)
                    # A delay beyond the finite observation horizon need not be
                    # represented as a finite binary64 number.
                    if exponent>=math.log1p((horizon-t)/scenario['c']):continue
                    lag=scenario['c']*math.expm1(exponent)
                child=t+lag
                require(child>t,'Strict positive child delay')
                if child<horizon:
                    require(len(pending)+len(out)<event_cap,'Pending-plus-retained insertion cap')
                    heapq.heappush(pending,(child,counter,index,radial(xy,sigma)));counter+=1
    except Exception as error:
        raise GenerationFailure(str(error),dict(complete=False,scenario=scenario,retained_events=len(out),
                event_rows=out,offspring_counts=offspring_counts,immigrant_times=immigrants,
                wall_seconds=time.monotonic()-began,no_redraw=True)) from error
    times=np.array([row[0] for row in out]);q=np.array([row[1] for row in out]);xy=np.array([row[2] for row in out]).reshape(-1,2)
    require(np.all(np.diff(times)>0),'Strict generated chronology');lat,lon=inverse(xy,profile);latlon=np.column_stack([lat,lon])
    return dict(complete=True,times=times,excess=q,xy=xy,latitude=latlon[:,0],longitude=latlon[:,1],
                parent_index=np.array([row[3] for row in out]),event_identity=np.array([row[4] for row in out]),
                cells=point_cells(xy,profile),offspring_counts=np.array(offspring_counts),
                immigrant_times=np.array(immigrants),reference_pi=area/area.sum(),
                background_centers=centers,scenario=scenario,
                profile=profile,parameters=dict(rate=rate,horizon=horizon,T0=horizon,beta=beta,sigma=sigma,
                                background_h=background_h,floor=floor),
                diagnostics=dict(retained_events=len(out),immigrants=len(immigrants),
                                 spatial_proposals=draws,wall_seconds=time.monotonic()-began,
                                 no_redraw=True,history_law='Poisson cluster process from empty history at t=0'),
                rng_consumption=dict(clock='openU exponential immigrant intervals; Poisson offspring count; ML mode categorical then openU delay or Omori openU delay per offspring',
                    mark='one openU exponential mark per retained event',
                    location='background mixture and center choices then radial rejection pairs; child radial rejection only if within horizon'))


def run_controls(protocol,protocol_sha,output,deadline,seconds):
    # Geography changed explicitly; seeds/laws/epoch/horizon remain declared.
    try:
        from .workflow import write,train_case,score_case,read
        from .catalogue import Catalogue
        from . import geometry as G
    except ImportError:
        from workflow import write,train_case,score_case,read
        from catalogue import Catalogue
        import geometry as G
    import hashlib,json
    cfg=protocol['synthetic'];profile=cfg['profile']
    if profile not in ['california','new_zealand'] or cfg['train_start']!=0. or cfg['train_end']!=294. or cfg['test_start']!=294. or cfg['test_end']!=420. or cfg['T0']!=420.:raise ValueError('synthetic predeclared chronology')
    write(output/'all_procedure_plan.json',dict(histories=2,procedures=10,mandatory_starts=80,exact_floor_slots=12,profile=profile,epoch='synthetic t=0; not civil observed epoch',seeds_and_laws=SCENARIOS,no_redraw=True))
    rows=[]
    for scenario in SCENARIOS:
        folder=output/scenario['name'];folder.mkdir(parents=True,exist_ok=True)
        try:gen=generate(G.support(profile)[0],scenario,profile=profile)
        except Exception as error:
            write(folder/'generation_failure.json',dict(error_type=type(error).__name__,partial=getattr(error,'partial',None),no_redraw=True));raise
        write(folder/'generation.json',gen)
        config_digest=hashlib.sha256(json.dumps(dict(scenario=scenario,profile=profile,law=gen['parameters']),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        identities=tuple('synthetic:'+str(i) for i in range(len(gen['times'])))
        raw_identity=dict(times=gen['times'].tolist(),excess=gen['excess'].tolist(),latitude=gen['latitude'].tolist(),longitude=gen['longitude'].tolist(),event_ids=list(identities))
        digest=hashlib.sha256(json.dumps(raw_identity,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
        generation_digest=hashlib.sha256((folder/'generation.json').read_bytes()).hexdigest()
        provenance=dict(synthetic=True,scenario=scenario,raw_rows_sha256=digest,generating_configuration_sha256=config_digest,generation_file_sha256=generation_digest)
        cat=Catalogue(gen['times'],gen['excess'],gen['latitude'],gen['longitude'],gen['cells'],identities,digest,provenance)
        tr=(cat.times>=cfg['train_start'])&(cat.times<cfg['train_end']);te=(cat.times>=cfg['test_start'])&(cat.times<cfg['test_end'])
        if tr.sum()<50 or te.sum()<20:raise ValueError('fixed seed history inadequate; no redraw')
        case=dict(case_id=scenario['name'],**{k:cfg[k] for k in ['train_start','train_end','test_start','test_end','T0']})
        known=dict(pi=gen['reference_pi'],beta=gen['parameters']['beta'],background=scenario['background'])
        row=train_case(case,cat,folder,protocol,protocol_sha,deadline,seconds,profile=profile,known=known)
        row=score_case(row,cat,folder,protocol,known=known)
        row['generation_provenance']=provenance
        row['truth']=dict(scenario=scenario,parameters=gen['parameters'],reference_pi=gen['reference_pi'])
        temporal='commonML' if scenario['kernel']=='ml' else 'Omori';mid=temporal+'_smooth_cont';r=row['models'][mid];truthpars=[math.log(.35),0.,scenario['n']]+([math.log(scenario['tau'])] if temporal=='commonML' else [math.log(scenario['c']),scenario['p']])
        try:
            from .compiled_objective import Objective
        except ImportError:
            from compiled_objective import Objective
        with Objective(r['cache_paths']['train16']) as obj:witness=obj.evaluate(r['model'],truthpars)
        row['truth_evaluation']=dict(model=mid,pars=truthpars,evaluation=witness,optimizer_dominates_truth=bool(r.get('selected') and r['selected']['evaluation']['joint_nll']<=witness['joint_nll']+1e-4),nonfit_truth_not_candidate=True)
        if not row['truth_evaluation']['optimizer_dominates_truth']:row['status']='unknown_incomplete'
        write(folder/'synthetic_training_case.json',row);rows.append(row)
    write(output/'summary_private.json',dict(status='complete' if all(r['status']=='complete' for r in rows) else 'unknown_incomplete',mode='controls',cases=rows,procedures=10,mandatory_starts=80,exact_floor_slots=12,no_redraw=True))
