"""Local-only, profile-parameterized equal-area geometry and training nuisance laws."""
from pathlib import Path
import ctypes as ct,json,hashlib,math
import numpy as np
from scipy.optimize import brentq
R=6371.0088
SCALES=[5.,15.,50.,150.,500.,1500.]
PROFILES={"california":dict(latitude_edges=[32.,32.+5/3,32.+10/3,37.],longitude_edges=[-121.,-121.+7/3,-121.+14/3,-114.],phi0=34.5,lambda0=-117.5,epoch="1981-01-01T00:00:00Z",T0=16436.,minimum_magnitude=4.),"new_zealand":dict(latitude_edges=[-48.5,-43.5,-38.5,-33.5],longitude_edges=[165.,170.,175.,180.],phi0=-41.,lambda0=172.5,epoch="1960-01-01T00:00:00Z",T0=24394.,minimum_magnitude=5.)}

def sha256(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def project(latitude,longitude,profile="california"):
    cfg=PROFILES[profile];lat=np.radians(np.asarray(latitude,float));lon=np.radians(np.asarray(longitude,float));phi=np.radians(cfg['phi0']);lam=np.radians(cfg['lambda0'])
    if lat.shape!=lon.shape or not np.isfinite(lat).all() or not np.isfinite(lon).all():raise ValueError('coordinate arrays')
    return np.column_stack([R*np.cos(phi)*(lon-lam),R*(np.sin(lat)-np.sin(phi))/np.cos(phi)])
def inverse(xy,profile="california"):
    cfg=PROFILES[profile];xy=np.asarray(xy,float);phi=np.radians(cfg['phi0']);lam=np.radians(cfg['lambda0']);s=xy[:,1]*np.cos(phi)/R+np.sin(phi)
    if not np.isfinite(xy).all() or np.any(abs(s)>1+1e-14):raise ValueError('inverse projection range')
    return np.degrees(np.arcsin(np.clip(s,-1,1))),np.degrees(xy[:,0]/(R*np.cos(phi))+lam)
def support(profile="california"):
    cfg=PROFILES[profile];x=project(np.repeat(cfg['phi0'],4),cfg['longitude_edges'],profile)[:,0];y=project(cfg['latitude_edges'],np.repeat(cfg['lambda0'],4),profile)[:,1]
    rect=np.array([[x[j],x[j+1],y[i],y[i+1]] for i in range(3) for j in range(3)]);area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]);centers=np.column_stack([(rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2]);return rect,area,centers
def cell_ids(latitude,longitude,profile="california"):
    cfg=PROFILES[profile];result=[]
    for a,e in [(np.asarray(latitude,float),np.asarray(cfg['latitude_edges'])),(np.asarray(longitude,float),np.asarray(cfg['longitude_edges']))]:
        if not np.isfinite(a).all() or np.any(a<e[0]) or np.any(a>e[-1]):raise ValueError('outside closed spatial support')
        result.append(np.minimum(np.searchsorted(e,a,side='right')-1,2))
    return (3*result[0]+result[1]).astype(int)
def mixture():
    alpha=.5;step=.4;bound=1e-8;c=4*math.sin(math.pi*alpha)/(math.pi*alpha)
    m=math.ceil(max(math.log(4)/alpha,math.log(c/bound)/alpha)/step);v=np.arange(-m,m+1)*step
    mass=step*math.sin(math.pi*alpha)/(2*math.pi*(np.cosh(alpha*v)+math.cos(math.pi*alpha)));mass[[0,-1]]*=.5
    return mass/mass.sum(),np.exp(v)
def fit_conditional_beta(q,cutoff=.5):
    q=np.asarray(q,float)
    if q.ndim!=1 or not np.isfinite(q).all() or np.any(q<0) or cutoff<=0:raise ValueError('training marks')
    high=q>=cutoff;nh=int(high.sum());nl=len(q)-nh
    if not nh or not nl:raise ValueError('both mark bins required')
    residual=math.fsum(q[~high])+math.fsum(q[high]-cutoff)
    if residual<=0:raise ValueError('within bin residual')
    def score(b):
        x=b*cutoff;low=cutoff*(.5-x/12+x**3/720) if x<1e-5 else 1/b-cutoff/math.expm1(x) if x<700 else 1/b
        return nh/b+nl*low-residual
    lower=min(1e-6/cutoff,len(q)/residual*1e-6);upper=max(1/cutoff,2*len(q)/residual)
    for _ in range(80):
        if score(lower)>0:break
        lower*=.1
    else:raise ValueError('lower beta bracket')
    for _ in range(80):
        if score(upper)<0:break
        upper*=2
    else:raise ValueError('upper beta bracket')
    beta=float(brentq(score,lower,upper,xtol=1e-12,rtol=1e-12,maxiter=200))
    return beta,dict(policy='common_training_conditional_bin_MLE',cutoff=cutoff,n_train=len(q),n_low=nl,n_high=nh,score_at_solution=score(beta))

def cell_proportions(cell,train):
    counts=np.bincount(np.asarray(cell)[train],minlength=9);zone=counts.reshape(3,3).sum(axis=1)
    if np.any(zone<30):raise ValueError("zone eligibility")
    piz=zone/zone.sum();q=(counts.reshape(3,3)+.5)/(zone[:,None]+1.5);return (piz[:,None]*q).ravel(),counts,piz

def rectangle_integrals(parent_xy,sigma,dll_path=None,*,profile="california",rectangles=None):
    RECTANGLES,AREAS,CENTERS_XY=support(profile)
    if rectangles is not None:
        RECTANGLES=np.asarray(rectangles,float);AREAS=(RECTANGLES[:,1]-RECTANGLES[:,0])*(RECTANGLES[:,3]-RECTANGLES[:,2])
    xy=np.ascontiguousarray(parent_xy,dtype=np.float64);rect=np.ascontiguousarray(RECTANGLES);out=np.empty((len(xy),9));path=Path(dll_path or Path(__file__).with_name("objective.dll"));lib=ct.CDLL(str(path.resolve()));pd=ct.POINTER(ct.c_double)
    lib.cl_rectangles.argtypes=[ct.c_int,ct.c_int,pd,pd,ct.c_double,pd];lib.cl_rectangles.restype=ct.c_int;lib.cl_last_error.restype=ct.c_char_p
    if lib.cl_rectangles(len(xy),9,xy.ctypes.data_as(pd),rect.ctypes.data_as(pd),float(sigma),out.ctypes.data_as(pd)):raise FloatingPointError(lib.cl_last_error().decode(errors="replace"))
    if not np.isfinite(out).all() or np.any(out<=0) or np.any(out>AREAS[None,:]*(1+1e-10)):raise FloatingPointError("rectangle mass range")
    whole=np.array([[RECTANGLES[:,0].min(),RECTANGLES[:,1].max(),RECTANGLES[:,2].min(),RECTANGLES[:,3].max()]]*9,float)
    check=np.empty((len(xy),9))
    if lib.cl_rectangles(len(xy),9,xy.ctypes.data_as(pd),whole.ctypes.data_as(pd),float(sigma),check.ctypes.data_as(pd)):raise FloatingPointError("whole rectangle integral")
    if not np.allclose(out.sum(axis=1),check[:,0],rtol=2e-11,atol=1e-10) or np.any(out.sum(axis=1)>=np.pi*float(sigma)**2):raise FloatingPointError("domain rectangle normalization")
    return out

def point_cells(xy,profile="california"):
    RECTANGLES,AREAS,CENTERS_XY=support(profile)
    xy=np.asarray(xy,float);result=[]
    for x,y in xy:
        candidates=np.flatnonzero((RECTANGLES[:,0]<=x)&(x<=RECTANGLES[:,1])&(RECTANGLES[:,2]<=y)&(y<=RECTANGLES[:,3]))
        if not len(candidates):raise ValueError('outside projected support')
        result.append(candidates[-1])
    return np.asarray(result,int)

def hierarchical_pi(cells):
    counts=np.bincount(np.asarray(cells,int),minlength=9).reshape(3,3);zone=counts.sum(axis=1)
    if counts.sum()<=0 or np.any(zone<=0):raise ValueError('positive training counts in each zone required')
    return ((zone/zone.sum())[:,None]*(counts+.5)/(zone[:,None]+1.5)).ravel()

def kde_components(training_xy,bandwidth,dll_path=None,*,profile="california"):
    xy=np.asarray(training_xy,float)
    if xy.ndim!=2 or xy.shape[1]!=2 or len(xy)<2 or not np.isfinite(xy).all():raise ValueError('KDE training history')
    F=rectangle_integrals(xy,bandwidth,dll_path,profile=profile);Z=F.sum(axis=1)
    return F,Z

def kde_density(query_xy,training_xy,bandwidth,normalizers):
    distance2=np.sum((np.asarray(query_xy)[:,None,:]-np.asarray(training_xy)[None,:,:])**2,axis=2)
    return (1+distance2/float(bandwidth)**2)**-2/np.asarray(normalizers)[None,:]

def select_bandwidth(training_xy,reference_pi=None,candidates=SCALES,*,floor=.05,dll_path=None,training_cells=None,profile="california"):
    RECTANGLES,AREAS,CENTERS_XY=support(profile)
    xy=np.asarray(training_xy,float);cells=point_cells(xy,profile) if training_cells is None else np.asarray(training_cells,int)
    candidates=[float(h) for h in candidates]
    if len(set(candidates))!=len(candidates) or not candidates or any(not np.isfinite(h) or h<=0 for h in candidates):raise ValueError('bandwidth candidates')
    if not np.array_equal(cells,point_cells(xy,profile)) or len(xy)<2 or not 0<floor<1:raise ValueError('LOO inputs')
    fullpi=hierarchical_pi(cells)
    if reference_pi is not None and np.max(abs(np.asarray(reference_pi)-fullpi))>1e-12:raise ValueError('LOO full training reference differs')
    floor_loo=np.array([hierarchical_pi(np.delete(cells,i))[cells[i]]/AREAS[cells[i]] for i in range(len(xy))])
    records=[]
    for h in candidates:
        F,Z=kde_components(xy,h,dll_path,profile=profile);density=kde_density(xy,xy,h,Z);np.fill_diagonal(density,0.)
        b=floor*floor_loo+(1-floor)*density.sum(axis=1)/(len(xy)-1)
        if np.any(b<=0):raise FloatingPointError('LOO positive density')
        records.append(dict(bandwidth=float(h),loo_logscore=float(np.log(b).sum()),n_loo=len(xy)))
    winner=max(range(len(records)),key=lambda i:(records[i]['loo_logscore'],-records[i]['bandwidth']))
    return dict(selected_bandwidth=records[winner]['bandwidth'],selected_index=winner,candidates=records,floor=float(floor),floor_policy='hierarchical cell proportions refit leaving each row out',selection='training spatial LOO only; subsequent likelihood proper full training KDE')

def make_base(times,q,cells,beta,start,end,*,order=16,T0=16436.):
    t=np.asarray(times,float);q=np.asarray(q,float);cells=np.asarray(cells)
    if t.ndim!=1 or q.shape!=t.shape or cells.shape!=t.shape or not np.isfinite(t).all() or not np.isfinite(q).all() or np.any(np.diff(t)<0) or np.any(q<0) or not np.isin(cells,np.arange(9)).all():raise ValueError('raw history')
    if not 0<=start<end or not np.isfinite(beta) or beta<=0 or T0<=0:raise ValueError('window nuisance')
    w,r=mixture();keep=t<end;t=t[keep];q=q[keep];cells=cells[keep];event=t>=start
    # Production compensators are analytic; order is retained as an independent-cache check tag.
    return dict(parent_time=t,parent_excess=q,parent_cell=cells,event_time=t[event],event_excess=q[event],event_cell=cells[event],event_x=2*t[event]/T0-1,event_parent_lag=t[event,None]-t[None,:],parent_exposure_lo=np.maximum(start-t,0.),parent_exposure_hi=end-t,mixture_weights=w,mixture_rates=r,quad_time=np.empty(0),quad_x=np.empty(0),quad_w=np.empty(0),start=float(start),end=float(end),T0=float(T0),beta=float(beta),order=order,quadrature_zero_width_panels_removed=int(np.count_nonzero(np.diff(t)==0)))

def make_geometry(times,q,cells,latitude,longitude,beta,start,end,reference_pi,*,family='continuous',sigma=150.,order=16,T0=16436.,background='cell',kde_bandwidth=None,background_training_xy=None,background_training_cells=None,base=None,metadata=None,dll_path=None,known_background=None,profile="california"):
    RECTANGLES,AREAS,CENTERS_XY=support(profile)
    cells=np.asarray(cells);pi=np.asarray(reference_pi,float)
    if not np.array_equal(cells,cell_ids(latitude,longitude,profile)):raise ValueError('actual coordinate/cell mismatch')
    if pi.shape!=(9,) or np.any(pi<=0) or abs(pi.sum()-1)>1e-12:raise ValueError('positive reference pi')
    base=base or make_base(times,q,cells,beta,start,end,order=order,T0=T0)
    if any(base[k]!=v for k,v in [('start',start),('end',end),('T0',T0),('order',order),('beta',beta)]):raise ValueError('stale temporal base')
    keep=np.asarray(times)<end
    if not np.array_equal(base['parent_time'],np.asarray(times)[keep]) or not np.array_equal(base['parent_excess'],np.asarray(q)[keep]) or not np.array_equal(base['parent_cell'],cells[keep]):raise ValueError('stale raw temporal base')
    keep=np.asarray(times)<end;lat=np.asarray(latitude)[keep];lon=np.asarray(longitude)[keep];xy=project(lat,lon,profile);exy=xy[base['parent_time']>=start];ec=base['event_cell'].astype(int);b=pi/AREAS
    F=np.empty((len(xy),0));Z=np.ones(len(xy))
    if family=='continuous':
        F=rectangle_integrals(xy,sigma,dll_path,profile=profile);Z=F@b;W=F*b[None,:]/Z[:,None]
        point=b[ec,None]*(1+np.sum((exy[:,None,:]-xy[None,:,:])**2,axis=2)/sigma**2)**-2/Z[None,:]
    elif family=='center':
        raw=pi[None,:]*(1+np.sum((xy[:,None,:]-CENTERS_XY[None,:,:])**2,axis=2)/sigma**2)**-2;Z=raw.sum(axis=1);W=raw/Z[:,None];point=W[:,ec].T/AREAS[ec,None]
    else:raise ValueError('spatial family')
    bgmass=pi.copy();eventb=b[ec];kxy=np.empty((0,2));kcells=np.empty(0);kF=np.empty((0,9));kZ=np.empty(0)
    if background=='kde':
        kxy=np.asarray(background_training_xy,float);kcells=point_cells(kxy,profile) if background_training_cells is None else np.asarray(background_training_cells,int)
        if not np.array_equal(kcells,point_cells(kxy,profile)):raise ValueError('KDE coordinate binding')
        if kde_bandwidth is None:raise ValueError('frozen KDE bandwidth required')
        kF,kZ=kde_components(kxy,kde_bandwidth,dll_path,profile=profile);bgmass=.05*pi+.95*np.mean(kF/kZ[:,None],axis=0);eventb=.05*b[ec]+.95*np.mean(kde_density(exy,kxy,kde_bandwidth,kZ),axis=1)
    elif background!='cell':raise ValueError('background family')
    if known_background is not None:
        eventb=np.asarray(known_background['event_density'],float);bgmass=np.asarray(known_background['cell_mass'],float)
        if eventb.shape!=(len(exy),) or bgmass.shape!=(9,):raise ValueError('known background shape')
    if np.max(abs(W.sum(axis=1)-1),initial=0)>1e-12 or abs(bgmass.sum()-1)>1e-12 or np.any(eventb<=0) or np.any(bgmass<=0):raise FloatingPointError('proper spatial mass/density')
    names=['parent_time','parent_excess','parent_cell','event_time','event_excess','event_cell','event_x','event_parent_lag','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates','quad_time','quad_x','quad_w']
    arr={k:base[k] for k in names};arr.update(parent_latitude=lat,parent_longitude=lon,parent_xy=xy,event_xy=exy,event_parent_density=point,parent_cell_mass=W,parent_rectangle_integrals=F,parent_normalizer=Z,parent_fertility=.3*np.exp(beta*.7*base['parent_excess']),event_background_density=eventb,background_cell_mass=bgmass,reference_pi=pi,cell_pi=pi,cell_areas=AREAS,rectangles=RECTANGLES,cell_centers_xy=CENTERS_XY,kde_training_xy=kxy,kde_training_cells=kcells,kde_rectangle_integrals=kF,kde_normalizers=kZ)
    arr={k:np.ascontiguousarray(v,dtype=np.float64) for k,v in arr.items()}
    if any(not np.isfinite(v).all() for v in arr.values()):raise FloatingPointError('nonfinite cache')
    meta=dict(metadata or {},geometry_version=2,profile=profile,start=float(start),end=float(end),T0=float(T0),beta=float(beta),order=int(order),n_events=len(exy),n_parents=len(xy),family=family,sigma=float(sigma),background=background,kde_bandwidth=None if kde_bandwidth is None else float(kde_bandwidth),kde_floor=.05,known_background_override=known_background is not None,reference_pi=pi.tolist(),pi=pi.tolist(),r=.7,modes=len(base['mixture_weights']),strict_left_limit=True,spatial_measure='km^-2 equal-area projected rectangle',quadrature_zero_width_panels_removed=base['quadrature_zero_width_panels_removed'],temporal_compensator='exact analytic finite-window',background_compensator='exact analytic exponential trend')
    meta['array_sha256']={k:hashlib.sha256(v.tobytes(order='C')).hexdigest() for k,v in arr.items()}
    meta['cache_identity_sha256']=hashlib.sha256(json.dumps(meta,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest()
    arr['metadata_json']=np.array(json.dumps(meta,sort_keys=True,allow_nan=False));return arr,meta

def save_geometry(path,arrays):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:np.savez_compressed(f,**arrays)
    return sha256(path)

