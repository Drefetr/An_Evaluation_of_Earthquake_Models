"""Bounded eight-start optimizer with strict complete lineage and exact caller floors."""
import time,math
import numpy as np
from scipy.optimize import minimize
try:
    from .compiled_objective import model_bounds
except ImportError:
    from compiled_objective import model_bounds
def clean(v):
    if isinstance(v,np.ndarray):return clean(v.tolist())
    if isinstance(v,np.generic):return clean(v.item())
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    if isinstance(v,float) and not math.isfinite(v):return {"nonfinite":str(v)}
    return v
def fit_procedure(coarse,fine,model,start_points,floor_points,*,fixed_d=None,seconds=80.,deadline=None):
    began=time.perf_counter();deadline=min(deadline or float("inf"),began+seconds);bounds=model_bounds(model,fixed_d=fixed_d);candidates=[];slots=[]
    if len(start_points)!=8:raise ValueError("exactly eight prescribed starts required")
    def feasible(p):return len(p)==len(bounds) and np.isfinite(p).all() and all(lo<=v<=hi for v,(lo,hi) in zip(p,bounds))
    def evaluate(p,origin):
        v=coarse.evaluate(model,p);f=fine.evaluate(model,p)
        return dict(candidate_id=len(candidates),pars=list(p),origin=origin,evaluation=clean(v),fine_evaluation=clean(f),quadrature_error=abs(v["joint_nll"]-f["joint_nll"]))
    for p,origin in floor_points:
        try:
            if time.perf_counter()>=deadline:raise TimeoutError("deadline before floor")
            if not feasible(p):raise ValueError("exact floor infeasible; no clipping")
            c=evaluate(p,origin)
            if c["quadrature_error"]>1e-4:raise FloatingPointError("floor quadrature disagreement")
            candidates.append(c)
            slots.append(dict(kind='floor',origin=origin,pars=list(p),status='complete',candidate_id=c['candidate_id']))
        except Exception as error:slots.append(dict(kind="floor",origin=origin,pars=list(p),status="unknown_floor",error_type=type(error).__name__))
    for slot,p in enumerate(start_points):
        start=np.asarray(p,dtype=float)
        if len(start)!=len(bounds):raise ValueError("prescribed start dimension")
        if not feasible(start):raise ValueError('prescribed start infeasible; no clipping')
        attempts=[];accepted=False
        def target(x):
            if time.perf_counter()>=deadline:raise TimeoutError("procedure deadline")
            v=coarse.evaluate(model,x);return v["joint_nll"],v["gradient"]
        for tier,(method,options) in enumerate([("L-BFGS-B",dict(maxiter=200,maxfun=20000,maxls=200,ftol=1e-10,gtol=2e-6)),("Powell",dict(maxiter=400,maxfev=5000,xtol=1e-6,ftol=1e-10))]):
            record=dict(tier=tier,method=method,options=options,start=start.tolist(),accepted=False);t=time.perf_counter()
            try:
                initial=target(start)[0];record["initial_nll"]=initial
                opt=minimize((lambda x:target(x)[0]) if method=="Powell" else target,start,method=method,jac=None if method=="Powell" else True,bounds=bounds,options=options)
                record.update(pars=opt.x.tolist(),success=bool(opt.success),message=str(opt.message),solver_status=int(opt.status),reported_nll=float(opt.fun),nfev=int(opt.nfev),nit=int(opt.nit),finite_feasible=bool(feasible(opt.x)))
                if record["finite_feasible"]:
                    candidate=evaluate(opt.x,"solver");record.update(evaluation=candidate["evaluation"],fine_evaluation=candidate["fine_evaluation"])
                    good=bool(opt.success and math.isfinite(opt.fun) and candidate["quadrature_error"]<=1e-4 and abs(candidate["evaluation"]["joint_nll"]-opt.fun)<=1e-7 and candidate["evaluation"]["joint_nll"]<=initial+1e-8)
                    if time.perf_counter()>=deadline:raise TimeoutError("deadline before acceptance")
                    if good:candidate.update(slot=slot,tier=tier);candidates.append(candidate);accepted=True;record["accepted"]=True
            except Exception as error:record["error_type"]=type(error).__name__
            record["wall_seconds"]=time.perf_counter()-t;attempts.append(clean(record))
            if accepted or time.perf_counter()>=deadline:break
        slots.append(dict(kind="start",slot=slot,requested_start=list(p),start=start.tolist(),status="complete" if accepted else "unknown_start",attempts=attempts))
    complete=sum(s.get("kind")=="start" and s["status"]=="complete" for s in slots)==8 and not any(s["status"]=="unknown_floor" for s in slots);selected=min(candidates,key=lambda c:(c["evaluation"]["joint_nll"],c["candidate_id"])) if candidates else None
    if selected is not None:selected["boundary_flags"]=[dict(coordinate=i,fixed=lo==hi,lower=abs(v-lo)<=1e-7,upper=abs(v-hi)<=1e-7) for i,(v,(lo,hi)) in enumerate(zip(selected["pars"],bounds))]
    solver=[c for c in candidates if c["origin"]=="solver"]
    return clean(dict(model=model,status="complete" if complete else "unknown_incomplete",complete=complete,selected=selected,raw_solver_selected=min(solver,key=lambda c:c["evaluation"]["joint_nll"]) if solver else None,accepted_candidates=candidates,slots=slots,bounds=bounds,wall_seconds=time.perf_counter()-began))
