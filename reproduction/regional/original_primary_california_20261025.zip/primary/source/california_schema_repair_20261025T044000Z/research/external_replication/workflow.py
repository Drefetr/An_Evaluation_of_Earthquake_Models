"""Frozen, conductor-leased training and scoring. All detailed outputs stay private."""
from pathlib import Path
import argparse,datetime,hashlib,json,math,os,sys,time
import numpy as np
try:
    from . import geometry as G
    from .compiled_objective import Objective
    from .fitting import fit_procedure,clean
    from .catalogue import load_catalogue,day
except ImportError:
    import geometry as G
    from compiled_objective import Objective
    from fitting import fit_procedure,clean
    from catalogue import load_catalogue,day
HERE=Path(__file__).resolve().parent
TEMPORAL={'fixedML':'E_fixed','commonML':'E_free','Omori':'E_omori'}
MODELS=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
SOURCE_FILES=['__init__.py','objective.cpp','objective.dll','compiled_objective.py','geometry.py','fitting.py','catalogue.py','workflow.py','prospective.py','synthetic.py','build_objective.cmd']
SCORE_KEYS=['joint_logscore','timing_logscore','conditional_location_logscore','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore','timing_event_logscore','timing_exposure_logscore','event_log_point_intensity_sum','event_log_ground_intensity_sum','event_log_intensity_sum','integrated_intensity','trigger_exposure','cell_integrated_intensity','zone_integrated_intensity','cell_point_event_log_intensity_sum','cell_point_logscore','event_log_point_intensity','event_log_cell_intensity','event_log_zone_intensity','event_log_ground_intensity']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f:json.dump(clean(v),f,indent=2,allow_nan=False)
def source_pins():return {str((HERE/n).resolve()):sha(HERE/n) for n in SOURCE_FILES}

def score(v):
    r={k:clean(v[k]) for k in SCORE_KEYS}
    if abs(r['timing_logscore']+r['conditional_location_logscore']+r['mark_logscore']-r['joint_logscore'])>1e-8:raise FloatingPointError('score identity')
    return r

def schedule(case_id):
    rows=[dict(id=f'{case_id}__selector_fixedML_smooth_cont_sigma{s:g}',case=case_id,phase='primary_selector',temporal='fixedML',background='smooth',spatial='cont',sigma_km=s,starts=8) for s in G.SCALES]
    for mid in ['fixedML_smooth_lift','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']:
        t,b,s=mid.split('_');rows.append(dict(id=f'{case_id}__main_{mid}',case=case_id,phase='primary_main',temporal=t,background=b,spatial=s,sigma_km='selected_baseline_sigma',starts=8))
    return rows

def verify(protocol,mode):
    if protocol.get('status') not in ['frozen','controls_frozen']:raise ValueError('protocol not frozen')
    if mode!='controls' and protocol.get('status')!='frozen':raise ValueError('production protocol not frozen')
    if mode!='controls' and protocol.get('science_gate_passed') is not True:raise ValueError('independent science gate not passed')
    if mode=='california' and protocol.get('protected_release_authorized') is not True:raise ValueError('protected release not authorized')
    pins=protocol.get('artifact_pins',{})
    for p in [HERE/n for n in SOURCE_FILES]+[Path(sys.executable)]:
        if pins.get(str(p.resolve()))!=sha(p):raise ValueError('production pin missing or changed')
    for path,digest in pins.items():
        if sha(path)!=digest:raise ValueError('frozen artifact changed')
    for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
        if os.environ.get(name)!='1':raise ValueError('single thread required')
    if protocol['models']!=MODELS or protocol['fit_policy']['starts_per_procedure']!=8 or protocol['primary_selection']['sigma_km']!=G.SCALES or protocol['background']['bandwidth_km']!=G.SCALES:raise ValueError('model or candidate roster')
    if protocol['fit_policy']['optimizer']!=dict(method='L-BFGS-B',maxiter=200,maxfun=20000,maxls=200,ftol=1e-10,gtol=2e-6):raise ValueError('optimizer contract')
    if mode.startswith('california') and protocol['schedule']!=sum([schedule(f'california_fold_{i}') for i in range(3)],[]):raise ValueError('schedule differs')
    if protocol['fit_policy']['fixedML_starts']!=[dict(a_offset=a,d=d,n=n) for a in [0.,-.5] for d in [-.2,.2] for n in [.2,.6]]:raise ValueError('fixed starts differ')
    if protocol['fit_policy']['commonML_tau_starts_days']!=[.001,.005,.02,.1,.5,1.,5.,20.] or protocol['fit_policy']['Omori_cp_starts']!=[[.0001,1.1],[.001,1.3],[.01,1.1],[.1,1.3],[1.,1.7],[20.,2.5],[.01,2.5],[.1,1.01]]:raise ValueError('start roster differs')

def fit_saved(folder,spec,cache,starts,floors,deadline,seconds,dependency=True):
    if dependency:
        with Objective(cache['train16']) as c,Objective(cache['train32']) as f:r=fit_procedure(c,f,TEMPORAL[spec['temporal']],starts,floors,deadline=deadline,seconds=seconds)
    else:
        r=dict(model=TEMPORAL[spec['temporal']],status='unknown_dependency',complete=False,selected=None,accepted_candidates=[],slots=[dict(kind='floor',origin=x,status='unknown_dependency') for x in (['poisson_floor','fixedML_tau1_floor'] if spec['temporal']=='commonML' else ['poisson_floor'])]+[dict(kind='start',slot=i,status='unknown_dependency',attempts=[]) for i in range(8)])
    r.update(procedure_id=spec['id'],case_id=spec['case'],temporal=spec['temporal'],background='smooth',spatial=spec['spatial'],sigma=float(spec['sigma_km']),role=spec['phase'],cache_paths=cache,selection='training joint NLL only')
    path=Path(folder)/f"fit_{spec['id']}.json";write(path,r)
    write(Path(folder)/f"registry_{spec['id']}.json",dict(procedure_id=spec['id'],path=str(path.resolve()),sha256=sha(path),model=r['model'],cache_paths=cache))
    return r,str(path.resolve())

def train_case(case,cat,folder,protocol,protocol_sha,deadline,seconds,*,profile='california',known=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);t=cat.times;q=cat.excess;cells=cat.cells;lat=cat.latitude;lon=cat.longitude
    tr=(t>=case['train_start'])&(t<case['train_end']);ntr=int(tr.sum());counts=np.bincount(cells[tr],minlength=9)
    if known is None:
        if ntr<(180 if profile=='california' else 90) or np.any(counts.reshape(3,3).sum(axis=1)<30):raise ValueError('training eligibility')
        pi,counts,_=G.cell_proportions(cells,tr);beta,beta_policy=G.fit_conditional_beta(q[tr],.5)
    else:pi=np.asarray(known['pi']);beta=known['beta'];beta_policy={'policy':'known_synthetic'}
    trainxy=G.project(lat[tr],lon[tr],profile);kde=G.select_bandwidth(trainxy,None if known else pi,G.SCALES,training_cells=cells[tr],profile=profile)
    duration=case['train_end']-case['train_start'];a0=float(np.clip(np.log(.6*ntr/duration),-11.5,-.1));ap=float(np.clip(np.log(ntr/duration),-12,0))
    plan=schedule(case['case_id'])
    if known is not None:plan=[plan[2]]+plan[6:]
    write(folder/'procedure_plan.json',dict(case=case,schedule=plan,procedures=len(plan),mandatory_starts=8*len(plan),exact_floor_slots=len(plan)+1))
    row=dict(case=case,profile=profile,catalogue_sha256=cat.source_sha256,beta=beta,beta_policy=beta_policy,reference_pi=pi,pi=pi,kde_selection=kde,n_train=ntr,training_cell_counts=counts,protocol_sha256=protocol_sha,models={},model_aliases={},procedures=[],cache_paths={},selected_sigma=None,status='unknown_pending')
    cache_sets={}
    def caches(spatial,sigma):
        key=f'{spatial}_smooth_sigma{sigma:g}'
        if key not in cache_sets:
            paths={}
            for order in [16,32]:
                knownbg=None
                if known is not None:knownbg=known_background(G.project(lat[(t>=case['train_start'])&(t<case['train_end'])],lon[(t>=case['train_start'])&(t<case['train_end'])],profile),known['background'],profile)
                arr,meta=G.make_geometry(t,q,cells,lat,lon,beta,case['train_start'],case['train_end'],pi,family='continuous' if spatial=='cont' else 'center',sigma=sigma,order=order,T0=case['T0'],background='kde',kde_bandwidth=kde['selected_bandwidth'],background_training_xy=trainxy,background_training_cells=cells[tr],profile=profile,known_background=knownbg,metadata=dict(production_source_pins=source_pins(),case_id=case['case_id'],protocol_sha256=protocol_sha,catalogue_sha256=cat.source_sha256,training_start=case['train_start'],training_end=case['train_end'],cache_key=key,nuisance_policy='training_only' if known is None else 'known_synthetic'))
                path=folder/f'cache_{key}_train{order}.npz';G.save_geometry(path,arr);paths[f'train{order}']=str(path.resolve())
            cache_sets[key]=paths;row['cache_paths'][key]=paths
        return cache_sets[key]
    def run(spec,sigma,dependency=True):
        spec=dict(spec,sigma_km=sigma);temp=spec['temporal'];mid=f"fixedML_smooth_{spec['spatial']}";fixed=row['models'].get(mid);point=fixed['selected']['pars'] if fixed and fixed.get('complete') else None
        if temp=='fixedML':
            starts=[[a0+s['a_offset'],s['d'],s['n']] for s in protocol['fit_policy']['fixedML_starts']];floors=[([ap,0.,0.],'poisson_floor')]
        elif temp=='commonML':
            starts=[point+[float(np.log(tau))] for tau in protocol['fit_policy']['commonML_tau_starts_days']] if point else [];floors=[([ap,0.,0.,0.],'poisson_floor'),(point+[0.],'fixedML_tau1_floor')] if point else [];dependency=dependency and point is not None
        else:
            starts=[point+[float(np.log(c)),float(p)] for c,p in protocol['fit_policy']['Omori_cp_starts']] if point else [];floors=[([ap,0.,0.,0.,1.3],'poisson_floor')] if point else [];dependency=dependency and point is not None
        r,path=fit_saved(folder,spec,caches(spec['spatial'],sigma) if dependency else {},starts,floors,deadline,seconds,dependency);row['procedures'].append(path);return r,path
    selectors=[]
    for spec in [x for x in plan if x['phase']=='primary_selector']:selectors.append((spec,*run(spec,float(spec['sigma_km']))))
    row['selector_complete']=all(r.get('complete') for _,r,_ in selectors)
    if row['selector_complete']:
        win=min(enumerate(selectors),key=lambda item:(item[1][1]['selected']['evaluation']['joint_nll'],item[0],item[1][1]['selected']['candidate_id']))[1];spec,r,path=win;row['selected_sigma']=float(spec['sigma_km']);row['models']['fixedML_smooth_cont']=r
        alias=dict(source_procedure_id=spec['id'],source_path=path,source_sha256=sha(path),source_candidate_id=r['selected']['candidate_id'],sigma=row['selected_sigma'],no_additional_fit=True);row['model_aliases']['fixedML_smooth_cont']=alias;write(folder/'alias_fixedML_smooth_cont.json',alias)
    for spec in [x for x in plan if x['phase']=='primary_main']:
        r,path=run(spec,row['selected_sigma'] or 50.,row['selected_sigma'] is not None);row['models'][f"{spec['temporal']}_smooth_{spec['spatial']}"]=r
    row['status']='complete' if len(row['procedures'])==len(plan) and row['selector_complete'] and all(r.get('complete') for r in row['models'].values()) else 'unknown_incomplete'
    row['accounting']=dict(procedures=len(row['procedures']),mandatory_starts=8*len(plan),exact_floor_slots=len(plan)+1,completed_starts=sum(sum(s['kind']=='start' and s['status']=='complete' for s in read(p)['slots']) for p in row['procedures']),completed_floors=sum(sum(s['kind']=='floor' and s['status']=='complete' for s in read(p)['slots']) for p in row['procedures']))
    write(folder/'training_case.json',row);return row

def known_background(xy,background,profile):
    rect,area,_=G.support(profile);pi=area/area.sum()
    if background=='uniform':return dict(event_density=np.full(len(xy),1/area.sum()),cell_mass=pi)
    left=rect[:,0].min();right=rect[:,1].max();bottom=rect[:,2].min();top=rect[:,3].max();centers=np.array([[left+.32*(right-left),bottom+.28*(top-bottom)],[left+.68*(right-left),bottom+.73*(top-bottom)]])
    F=G.rectangle_integrals(centers,150.,profile=profile);Z=F.sum(axis=1)
    return dict(event_density=.05/area.sum()+.95*G.kde_density(xy,centers,150.,Z).mean(axis=1),cell_mass=.05*pi+.95*(F/Z[:,None]).mean(axis=0))

def score_case(row,cat,folder,protocol,*,known=None):
    # Invoked only after all prescribed training choices have been archived.
    folder=Path(folder);case=row['case'];profile=row['profile'];tr=(cat.times>=case['train_start'])&(cat.times<case['train_end']);te=(cat.times>=case['test_start'])&(cat.times<case['test_end']);nt=int(te.sum());cache_sets={};all_scores={}
    def caches(r):
        key=f"{r['spatial']}_smooth_sigma{r['sigma']:g}"
        if key not in cache_sets:
            paths={}
            for order in [16,32]:
                query=G.project(cat.latitude[te],cat.longitude[te],profile)
                knownbg=None if known is None else known_background(query,known['background'],profile)
                arr,_=G.make_geometry(cat.times,cat.excess,cat.cells,cat.latitude,cat.longitude,row['beta'],case['test_start'],case['test_end'],row['reference_pi'],family='continuous' if r['spatial']=='cont' else 'center',sigma=r['sigma'],order=order,T0=case['T0'],background='kde',kde_bandwidth=row['kde_selection']['selected_bandwidth'],background_training_xy=G.project(cat.latitude[tr],cat.longitude[tr],profile),background_training_cells=cat.cells[tr],profile=profile,known_background=knownbg,metadata=dict(production_source_pins=source_pins(),case_id=case['case_id'],catalogue_sha256=cat.source_sha256,protocol_sha256=row['protocol_sha256'],training_start=case['train_start'],training_end=case['train_end'],nuisance_policy='frozen_training_only'))
                path=folder/f'cache_{key}_test{order}.npz';G.save_geometry(path,arr);paths[f'test{order}']=str(path.resolve())
            cache_sets[key]=paths
        return cache_sets[key]
    for path in row['procedures']:
        r=read(path);out=dict(procedure_id=r['procedure_id'],training_fit_path=path,training_fit_sha256=sha(path),status='unknown_incomplete',all_candidate_forecasts=[],near_optimal_forecasts=[])
        if r.get('selected'):
            paths=caches(r);out['forecast_cache_paths']=paths
            with Objective(paths['test16']) as c,Objective(paths['test32']) as fine:
                best=r['selected']['evaluation']['joint_nll']
                out['all_solver_return_forecasts']=[]
                for slot in r['slots']:
                    for attempt in slot.get('attempts',[]):
                        if attempt.get('finite_feasible') and 'pars' in attempt:
                            v=c.evaluate(r['model'],attempt['pars']);f=fine.evaluate(r['model'],attempt['pars']);out['all_solver_return_forecasts'].append(dict(slot=slot['slot'],tier=attempt['tier'],accepted=attempt['accepted'],pars=attempt['pars'],forecast=score(v),fine_forecast=score(f),forecast_quadrature_error=abs(v['joint_nll']-f['joint_nll'])))
                for cand in r['accepted_candidates']:
                    v=c.evaluate(r['model'],cand['pars']);f=fine.evaluate(r['model'],cand['pars']);err=abs(v['joint_nll']-f['joint_nll'])
                    item=dict(candidate_id=cand['candidate_id'],pars=cand['pars'],training_joint_nll=cand['evaluation']['joint_nll'],forecast=score(v),fine_forecast=score(f),forecast_quadrature_error=err);out['all_candidate_forecasts'].append(item)
                    if cand['evaluation']['joint_nll']<=best+4e-4:out['near_optimal_forecasts'].append(item)
                selected=next(x for x in out['all_candidate_forecasts'] if x['candidate_id']==r['selected']['candidate_id']);out['forecast']=selected['forecast']
                near=out['near_optimal_forecasts'];spread=(max(x['forecast']['joint_logscore'] for x in near)-min(x['forecast']['joint_logscore'] for x in near))/nt if nt else None
                out.update(forecast_spread_nats_per_event=spread,forecast_stable=spread is not None and spread<.01)
                out['status']='complete' if r['complete'] and out['forecast_stable'] and all(x['forecast_quadrature_error']<=1e-4 for x in out['all_candidate_forecasts']) else 'unknown_incomplete'
        write(folder/f"score_{r['procedure_id']}.json",out);all_scores[r['procedure_id']]=out
    row['n_test']=nt;row['test_cell_counts']=np.bincount(cat.cells[te],minlength=9);row['scores']=all_scores
    for mid,r in row['models'].items():r.update(all_scores[r['procedure_id']])
    row['cross_grid_forecast_stable']=False
    if row['selector_complete']:
        selector=[read(p) for p in row['procedures'] if read(p)['role']=='primary_selector'];best=min(r['selected']['evaluation']['joint_nll'] for r in selector)
        pool=[dict(procedure_id=r['procedure_id'],sigma=r['sigma'],**x) for r in selector for x in all_scores[r['procedure_id']]['all_candidate_forecasts'] if x['training_joint_nll']<=best+4e-4]
        spread=(max(x['forecast']['joint_logscore'] for x in pool)-min(x['forecast']['joint_logscore'] for x in pool))/nt if nt else None
        row.update(cross_grid_near_optimal_forecasts=pool,cross_grid_forecast_spread_nats_per_event=spread,cross_grid_forecast_stable=spread is not None and spread<.01)
    row['status']='complete' if row['status']=='complete' and all(s['status']=='complete' for s in all_scores.values()) and row['cross_grid_forecast_stable'] else 'unknown_incomplete';write(folder/'case.json',row);return row

def main():
    p=argparse.ArgumentParser();p.add_argument('--protocol',required=True);p.add_argument('--output',required=True);p.add_argument('--mode',choices=['california-train','california','nz-initialize','controls'],required=True);p.add_argument('--seconds-per-procedure',type=float,default=70.);p.add_argument('--stage-seconds',type=float,default=4500.);a=p.parse_args();protocol=read(a.protocol);verify(protocol,a.mode);output=Path(a.output);output.mkdir(parents=True,exist_ok=True);deadline=time.perf_counter()+a.stage_seconds
    if 'deadline_utc' in protocol.get('resources',{}):deadline=min(deadline,time.perf_counter()+(datetime.datetime.fromisoformat(protocol['resources']['deadline_utc'].replace('Z','+00:00'))-datetime.datetime.now(datetime.timezone.utc)).total_seconds())
    if a.mode=='controls':
        try:from . import synthetic
        except ImportError:import synthetic
        synthetic.run_controls(protocol,sha(a.protocol),output,deadline,a.seconds_per_procedure);return
    profile='new_zealand' if a.mode=='nz-initialize' else 'california';data=protocol['data'];cat=load_catalogue(data['catalogue'],data['sha256'],profile=profile,legacy_csv=data.get('legacy_csv',False));rows=[]
    if profile=='new_zealand':
        if cat.source_sha256!='feacccb7581d1c4c33f88874cd6b198c41639da6930a7fc35e46f910a594fb3e' or len(cat.times)!=913:raise ValueError('NZ training identity')
        cases=[dict(case_id='nz_full_training',train_start=0.,train_end=24394.,T0=24394.)]
    else:
        cases=[dict(case_id=c['id'],fold_id=c['fold'],T0=protocol['era']['T0_days'],**{name:day(c[name+'_utc'],profile) for name in ['train_start','train_end','test_start','test_end','history_start']}) for c in protocol['cases']]
        if a.mode=='california-train':
            cases=cases[:1]
            if np.any(cat.times>=cases[0]['train_end']):raise ValueError('training input includes protected rows')
    write(output/'all_procedure_plan.json',dict(schedule=sum([schedule(c['case_id']) for c in cases],[]),procedures=10*len(cases),mandatory_starts=80*len(cases),exact_floor_slots=11*len(cases)))
    for case in cases:
        folder=output/case['case_id'];row=train_case(case,cat,folder,protocol,sha(a.protocol),deadline,a.seconds_per_procedure,profile=profile)
        if a.mode=='california':row=score_case(row,cat,folder,protocol)
        rows.append(row)
    write(output/'summary_private.json',dict(status='complete' if all(r['status']=='complete' for r in rows) else 'unknown_incomplete',mode=a.mode,cases=rows,procedures=sum(r['accounting']['procedures'] for r in rows),mandatory_starts=80*len(rows),exact_floor_slots=11*len(rows)))

if __name__=='__main__':
    try:main()
    except Exception as error:
        # Deliberately suppress data-bearing exception strings and tracebacks.
        print(json.dumps(dict(status='failed',fixed_error_code='WORKFLOW_FAILURE',error_type=type(error).__name__)),file=sys.stderr);sys.exit(1)
