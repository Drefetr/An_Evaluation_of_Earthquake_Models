"""Validated local geometry adapter for independent temporal/spatial/background DLL."""
from pathlib import Path
import ctypes as ct,json,hashlib
import numpy as np
MODELS={"E_fixed":(0,3),"E_free":(1,4),"E_omori":(2,5)}
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def model_bounds(model,*,fixed_d=None):
    b=[(-12.,0.),(-2.,2.),(0.,.98)]
    if model=="E_free":b += [(float(np.log(.001)),float(np.log(20.)))]
    elif model=="E_omori":b += [(float(np.log(.0001)),float(np.log(20.))),(1.01,2.5)]
    elif model!="E_fixed":raise ValueError("model")
    if fixed_d is not None:b[1]=(float(fixed_d),float(fixed_d))
    return b
def library(path=None):
    path=Path(path or Path(__file__).with_name("objective.dll")).resolve();lib=ct.CDLL(str(path));pd=ct.POINTER(ct.c_double)
    lib.ts_create.argtypes=[ct.c_int]*3+[pd]*13;lib.ts_create.restype=ct.c_void_p
    lib.ts_eval.argtypes=[ct.c_void_p,ct.c_int,pd,ct.c_int,pd,pd,pd];lib.ts_eval.restype=ct.c_int
    lib.ts_destroy.argtypes=[ct.c_void_p];lib.ts_destroy.restype=None;lib.ts_last_error.restype=ct.c_char_p
    return lib,path
class Objective:
    def __init__(self,path,dll_path=None):
        self.path=Path(path).resolve();self.handle=None;self.lib,self.dll_path=library(dll_path)
        with np.load(self.path,allow_pickle=False) as saved:
            self.metadata=json.loads(str(saved["metadata_json"].item()));self.arrays={}
            for name in saved.files:
                if name=="metadata_json":continue
                v=saved[name]
                if v.dtype!=np.dtype("float64") or not np.isfinite(v).all():raise ValueError("invalid cache "+name)
                self.arrays[name]=np.ascontiguousarray(v)
        a=self.arrays;m=self.metadata
        if 'protocol_sha256' in m:
            if not m.get('catalogue_sha256') or not m.get('production_source_pins'):raise ValueError('unbound production cache')
            for path,expected in m['production_source_pins'].items():
                if digest(path)!=expected:raise ValueError('production cache source changed')
        self.ne=len(a["event_time"]);self.np=len(a["parent_time"])
        identity=dict(m);identity.pop('cache_identity_sha256',None)
        if m.get('cache_identity_sha256')!=hashlib.sha256(json.dumps(identity,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest():raise ValueError('stale cache metadata identity')
        if m.get('array_sha256')!={k:hashlib.sha256(v.tobytes(order='C')).hexdigest() for k,v in a.items()}:raise ValueError('stale cache array digest')
        shapes={n:(self.ne,) for n in ["event_time","event_excess","event_cell","event_x","event_background_density"]};shapes.update({n:(self.np,) for n in ["parent_time","parent_excess","parent_cell","parent_fertility","parent_exposure_lo","parent_exposure_hi","parent_normalizer"]});shapes.update(event_xy=(self.ne,2),parent_xy=(self.np,2),event_parent_density=(self.ne,self.np),event_parent_lag=(self.ne,self.np),parent_cell_mass=(self.np,9),reference_pi=(9,),background_cell_mass=(9,),cell_areas=(9,),rectangles=(9,4),mixture_weights=(195,),mixture_rates=(195,))
        if m["geometry_version"]!=2 or m["n_events"]!=self.ne or m["n_parents"]!=self.np:raise ValueError("cache dimensions")
        for key,expected in shapes.items():
            if a[key].shape!=expected:raise ValueError("cache shape "+key)
        t=a["parent_time"];event=t>=m["start"]
        if np.any(np.diff(t)<0) or np.any(t>=m["end"]) or not np.array_equal(a["event_time"],t[event]):raise ValueError("raw chronology")
        if not np.array_equal(a["event_excess"],a["parent_excess"][event]) or not np.array_equal(a["event_cell"],a["parent_cell"][event]) or not np.array_equal(a["event_xy"],a["parent_xy"][event]):raise ValueError("event-parent binding")
        cell=a["event_cell"]
        if np.any(cell!=np.floor(cell)) or np.any(cell<0) or np.any(cell>=9):raise ValueError("event cell")
        if not np.array_equal(a["event_parent_lag"],a["event_time"][:,None]-t[None,:]) or not np.array_equal(a["parent_exposure_lo"],np.maximum(m["start"]-t,0.)) or not np.array_equal(a["parent_exposure_hi"],m["end"]-t):raise ValueError("stale temporal features")
        if not np.array_equal(a["event_x"],2*a["event_time"]/m["T0"]-1) or np.max(abs(a["parent_fertility"]-.3*np.exp(m["beta"]*.7*a["parent_excess"])),initial=0)>1e-12:raise ValueError("stale nuisance features")
        area=(a["rectangles"][:,1]-a["rectangles"][:,0])*(a["rectangles"][:,3]-a["rectangles"][:,2])
        if not np.array_equal(area,a["cell_areas"]) or np.max(abs(a["reference_pi"]-m["reference_pi"]),initial=0)>1e-14 or abs(a["reference_pi"].sum()-1)>1e-12 or np.any(a["reference_pi"]<=0) or np.max(abs(a["parent_cell_mass"].sum(axis=1)-1),initial=0)>1e-12 or np.any(a["event_parent_density"]<=0):raise ValueError("spatial unit mass")
        if m["background"]=="cell" and not m["known_background_override"]:
            if np.max(abs(a["event_background_density"]-a["reference_pi"][cell.astype(int)]/area[cell.astype(int)]),initial=0)>1e-18 or not np.array_equal(a["background_cell_mass"],a["reference_pi"]):raise ValueError("cell background binding")
        meta=np.array([m["start"],m["end"],m["T0"],self.ne*np.log(m["beta"])-m["beta"]*a["event_excess"].sum()],dtype=np.float64);pd=ct.POINTER(ct.c_double)
        names=["parent_time","event_x","event_cell","event_background_density","background_cell_mass","event_parent_density","parent_cell_mass","parent_fertility","parent_exposure_lo","parent_exposure_hi","mixture_weights","mixture_rates"]
        self.handle=self.lib.ts_create(self.ne,self.np,195,*[a[n].ctypes.data_as(pd) for n in names],meta.ctypes.data_as(pd))
        if not self.handle:raise ValueError(self.last_error())
        self.identity=dict(feature_path=str(self.path),feature_sha256=digest(self.path),dll_path=str(self.dll_path),dll_sha256=digest(self.dll_path),metadata=m)
    def last_error(self):return self.lib.ts_last_error().decode(errors="replace")
    def evaluate(self,model,pars):
        if self.handle is None:raise RuntimeError("closed objective")
        mid,dim=MODELS[model];p=np.ascontiguousarray(pars,dtype=np.float64)
        if p.shape!=(dim,) or not np.isfinite(p).all():raise ValueError("parameter dimension")
        out=np.empty(28);grad=np.empty(dim);logs=np.empty((self.ne,4));pd=ct.POINTER(ct.c_double)
        if self.lib.ts_eval(self.handle,mid,p.ctypes.data_as(pd),dim,out.ctypes.data_as(pd),grad.ctypes.data_as(pd),logs.ctypes.data_as(pd)):raise FloatingPointError(self.last_error())
        cellC=out[10:19].copy();cellE=out[19:28].copy();zoneC=cellC.reshape(3,3).sum(axis=1)
        return dict(conditional_location_logscore=float(out[2]+out[3]+out[4]),timing_event_logscore=float(out[8]),timing_exposure_logscore=-float(out[6]),joint_nll=float(out[0]),joint_logscore=-float(out[0]),timing_logscore=float(out[1]),conditional_zone_logscore=float(out[2]),conditional_cell_logscore=float(out[3]),within_cell_density_logscore=float(out[4]),mark_logscore=float(out[5]),integrated_intensity=float(out[6]),event_log_point_intensity_sum=float(out[7]),event_log_ground_intensity_sum=float(out[8]),event_log_intensity_sum=float(out[7]),trigger_exposure=float(out[9]),cell_integrated_intensity=cellC,zone_integrated_intensity=zoneC,cell_point_event_log_intensity_sum=cellE,cell_point_logscore=cellE-cellC,event_log_point_intensity=logs[:,0].copy(),event_log_cell_intensity=logs[:,1].copy(),event_log_zone_intensity=logs[:,2].copy(),event_log_ground_intensity=logs[:,3].copy(),gradient=grad.copy())
    def close(self):
        if self.handle:self.lib.ts_destroy(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
