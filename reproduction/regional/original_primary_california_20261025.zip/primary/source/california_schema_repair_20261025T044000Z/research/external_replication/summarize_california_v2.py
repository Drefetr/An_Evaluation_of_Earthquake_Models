"""Audited aggregate-only summary of fixed-roster California saved outputs."""
from pathlib import Path
import argparse,hashlib,json,math

MODELS=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
COMPARISONS=[('primary_timing','Omori_smooth_cont','fixedML_smooth_cont','timing_logscore'),('primary_location','Omori_smooth_cont','Omori_smooth_lift','conditional_location_logscore'),('context_freeML','Omori_smooth_cont','commonML_smooth_cont','joint_logscore'),('context_fixedML_spatial','fixedML_smooth_cont','fixedML_smooth_lift','conditional_location_logscore'),('complete_procedure','Omori_smooth_cont','fixedML_smooth_lift','joint_logscore')]
COMPONENTS=['joint_logscore','timing_logscore','conditional_location_logscore','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore','timing_event_logscore','timing_exposure_logscore','integrated_intensity']
SCALES=[5.,15.,50.,150.,500.,1500.]
MAIN_MODELS=['fixedML_smooth_lift','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def number(value):
 if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):raise ValueError('NONFINITE_SUMMARY_COMPONENT')
 return float(value)
def same(a,b):return a==b
def expected_ids(case_id):
 return [f'{case_id}__selector_fixedML_smooth_cont_sigma{s:g}' for s in SCALES]+[f'{case_id}__main_{mid}' for mid in MAIN_MODELS]
def expected_plan(case_id,case):
 rows=[dict(id=f'{case_id}__selector_fixedML_smooth_cont_sigma{s:g}',case=case_id,phase='primary_selector',temporal='fixedML',background='smooth',spatial='cont',sigma_km=s,starts=8) for s in SCALES]
 for mid in MAIN_MODELS:
  temporal,background,spatial=mid.split('_');rows.append(dict(id=f'{case_id}__main_{mid}',case=case_id,phase='primary_main',temporal=temporal,background=background,spatial=spatial,sigma_km='selected_baseline_sigma',starts=8))
 return rows
def bind(path,bindings):
 path=Path(path).resolve();bindings[str(path)]=sha(path);return path

def score_view(value):
 result={k:number(value[k]) for k in COMPONENTS}
 if abs(result['joint_logscore']-result['timing_logscore']-result['conditional_location_logscore']-result['mark_logscore'])>1e-7:raise ValueError('SUMMARY_PROPER_SCORE_IDENTITY')
 if abs(result['timing_logscore']-result['timing_event_logscore']-result['timing_exposure_logscore'])>1e-7:raise ValueError('SUMMARY_EVENT_EXPOSURE_IDENTITY')
 return result

def summarize(source,audit_path,expected_audit_sha256):
 source=Path(source).resolve();audit_path=Path(audit_path).resolve()
 if sha(audit_path)!=expected_audit_sha256:raise ValueError('INDEPENDENT_AUDIT_CHANGED')
 raw=read(source);audit=read(audit_path)
 if raw.get('mode')!='california' or len(raw.get('cases',[]))!=3 or [c.get('case',{}).get('case_id') for c in raw['cases']]!=[f'california_fold_{i}' for i in range(3)]:raise ValueError('SUMMARY_CASE_ROSTER')
 if (raw.get('procedures'),raw.get('mandatory_starts'),raw.get('exact_floor_slots'))!=(30,240,33):raise ValueError('SUMMARY_DENOMINATORS')
 if audit.get('status')!='passed' or audit.get('passed') is not True or audit.get('independent') is not True or audit.get('mode')!='full':raise ValueError('INDEPENDENT_AUDIT_NOT_ACCEPTED')
 denominators=audit.get('denominators',{})
 if any(denominators.get(k)!=v for k,v in [('procedures',30),('starts',240),('floors',33)]):raise ValueError('INDEPENDENT_AUDIT_DENOMINATORS')
 rows=[];bindings={};bind(source,bindings);expected_case_status=[]
 for ordinal,summary_case in enumerate(raw['cases']):
  case_id=f'california_fold_{ordinal}';case_dir=source.parent/case_id
  training_path=bind(case_dir/'training_case.json',bindings);case_path=bind(case_dir/'case.json',bindings);plan_path=bind(case_dir/'procedure_plan.json',bindings);alias_path=bind(case_dir/'alias_fixedML_smooth_cont.json',bindings)
  training=read(training_path);case_file=read(case_path);plan=read(plan_path);alias=read(alias_path)
  if summary_case!=case_file:raise ValueError('SUMMARY_CASE_FILE_MISMATCH')
  if training.get('case',{}).get('case_id')!=case_id or training.get('profile')!='california' or case_file.get('case',{}).get('case_id')!=case_id:raise ValueError('SUMMARY_CASE_IDENTITY')
  if training.get('procedures')!=case_file.get('procedures') or not same(training.get('case'),case_file.get('case')):raise ValueError('SUMMARY_TRAINING_CASE_BINDING')
  ids=expected_ids(case_id)
  if plan.get('schedule')!=expected_plan(case_id,training['case']) or plan.get('case')!=training['case'] or (plan.get('procedures'),plan.get('mandatory_starts'),plan.get('exact_floor_slots'))!=(10,80,11):raise ValueError('SUMMARY_PLAN_BINDING')
  fit_paths=[(case_dir/f'fit_{pid}.json').resolve() for pid in ids]
  recorded_paths=[str(Path(p).resolve()) for p in case_file.get('procedures',[])]
  if recorded_paths!=[str(p) for p in fit_paths] or [str(Path(p).resolve()) for p in training.get('procedures',[])]!=recorded_paths:raise ValueError('SUMMARY_ORDERED_FIT_ROSTER')
  if len(training.get('models',{}))!=5 or set(training['models'])!=set(MODELS) or set(case_file.get('models',{}))!=set(MODELS):raise ValueError('SUMMARY_MODEL_ROSTER')
  if (case_file.get('accounting',{}).get('procedures'),case_file.get('accounting',{}).get('mandatory_starts'),case_file.get('accounting',{}).get('exact_floor_slots'))!=(10,80,11):raise ValueError('SUMMARY_CASE_DENOMINATORS')
  fit_rows=[];score_rows=[];registry_rows=[];selector_rows=[]
  for index,(pid,fit_path) in enumerate(zip(ids,fit_paths)):
   fit_path=bind(fit_path,bindings);fit=read(fit_path);registry_path=bind(case_dir/f'registry_{pid}.json',bindings);registry=read(registry_path);score_path=bind(case_dir/f'score_{pid}.json',bindings);score=read(score_path)
   if fit.get('procedure_id')!=pid or fit.get('case_id')!=case_id or fit.get('selection')!='training joint NLL only':raise ValueError('SUMMARY_FIT_IDENTITY')
   if registry.get('procedure_id')!=pid or str(Path(registry.get('path','')).resolve())!=str(fit_path) or registry.get('sha256')!=sha(fit_path) or registry.get('model')!=fit.get('model') or registry.get('cache_paths')!=fit.get('cache_paths'):raise ValueError('SUMMARY_REGISTRY_BINDING')
   if score.get('procedure_id')!=pid or str(Path(score.get('training_fit_path','')).resolve())!=str(fit_path) or score.get('training_fit_sha256')!=sha(fit_path):raise ValueError('SUMMARY_SCORE_FIT_BINDING')
   if index<6:
    if fit.get('role')!='primary_selector' or fit.get('sigma')!=SCALES[index] or fit.get('temporal')!='fixedML' or fit.get('spatial')!='cont':raise ValueError('SUMMARY_SELECTOR_LINEAGE')
    selector_rows.append(fit)
   else:
    mid=MAIN_MODELS[index-6];temporal,background,spatial=mid.split('_')
    if fit.get('role')!='primary_main' or fit.get('temporal')!=temporal or fit.get('background')!=background or fit.get('spatial')!=spatial:raise ValueError('SUMMARY_MAIN_LINEAGE')
   fit_starts=[s for s in fit.get('slots',[]) if s.get('kind')=='start'];fit_floors=[s for s in fit.get('slots',[]) if s.get('kind')=='floor']
   if len(fit_starts)!=8 or len(fit_floors)!=(2 if fit.get('temporal')=='commonML' else 1):raise ValueError('SUMMARY_START_OR_FLOOR_DENOMINATOR')
   fit_rows.append(fit);registry_rows.append(registry);score_rows.append(score)
  floor_count=sum(sum(s.get('kind')=='floor' for s in f.get('slots',[])) for f in fit_rows)
  if floor_count!=11:raise ValueError('SUMMARY_FLOOR_DENOMINATOR')
  expected_scores={pid:s for pid,s in zip(ids,score_rows)}
  if case_file.get('scores')!=expected_scores:raise ValueError('SUMMARY_SCORE_FILE_BINDING')
  for mid in MODELS:
   model=training['models'][mid];case_model=case_file['models'][mid]
   proc_id=model.get('procedure_id')
   if mid=='fixedML_smooth_cont':
    winners=[(float(f['selected']['evaluation']['joint_nll']),i,f['selected']['candidate_id'],f) for i,f in enumerate(selector_rows) if f.get('selected') is not None]
    if len(winners)!=6:raise ValueError('SUMMARY_SELECTOR_INCOMPLETE')
    winner=min(winners,key=lambda z:(z[0],z[1],z[2]))[3];proc_id=winner['procedure_id'];selected_sigma=winner['sigma'];selected_candidate=winner['selected']['candidate_id']
    expected_alias=dict(source_procedure_id=proc_id,source_path=str(fit_paths[ids.index(proc_id)]),source_sha256=sha(fit_paths[ids.index(proc_id)]),source_candidate_id=selected_candidate,sigma=selected_sigma,no_additional_fit=True)
    if alias!=expected_alias or training.get('model_aliases',{}).get(mid)!=alias or training.get('selected_sigma')!=selected_sigma:raise ValueError('SUMMARY_SELECTOR_ALIAS')
   else:
    expected_proc=f'{case_id}__main_{mid}'
    if proc_id!=expected_proc:raise ValueError('SUMMARY_MODEL_FIT_BINDING')
   fit=next(f for f in fit_rows if f['procedure_id']==proc_id)
   for key in ['model','spatial','sigma','complete','selected','procedure_id']:
    if model.get(key)!=fit.get(key) or case_model.get(key)!=model.get(key):raise ValueError('SUMMARY_MODEL_FIT_CONTENT')
   score=expected_scores[proc_id]
   if case_model.get('status')!=score.get('status') or case_model.get('forecast')!=score.get('forecast') or case_model.get('forecast_stable')!=score.get('forecast_stable') or case_model.get('forecast_spread_nats_per_event')!=score.get('forecast_spread_nats_per_event'):raise ValueError('SUMMARY_MODEL_SCORE_CONTENT')
   if score.get('forecast') is not None:score_view(score['forecast'])
   if score.get('status')=='complete':
    if model.get('complete') is not True or fit.get('complete') is not True or score.get('forecast_stable') is not True or not score.get('near_optimal_forecasts') or score.get('forecast_spread_nats_per_event') is None or score['forecast_spread_nats_per_event']>=.01:raise ValueError('SUMMARY_COMPLETE_MODEL_GATES')
    if any(number(x['forecast_quadrature_error'])>1e-4 for x in score.get('all_candidate_forecasts',[])):raise ValueError('SUMMARY_QUADRATURE_GATE')
   if case_model.get('scores') is not None and score.get('forecast') is not None and case_model['scores']!=score_view(score['forecast']):raise ValueError('SUMMARY_MODEL_SCORE_VIEW')
  case_status=case_file.get('status')
  if case_status not in ['complete','unknown_incomplete'] or case_file.get('status')!=training.get('status') and case_status=='complete':raise ValueError('SUMMARY_CASE_STATUS')
  if training.get('status') not in ['complete','unknown_incomplete'] or case_file.get('n_train')!=training.get('n_train') or sum(case_file.get('training_cell_counts',[]))!=case_file.get('n_train'):raise ValueError('SUMMARY_TRAINING_DENOMINATOR')
  accounting=case_file['accounting']
  if accounting.get('completed_starts',0)>80 or accounting.get('completed_floors',0)>11:raise ValueError('SUMMARY_COMPLETED_DENOMINATORS')
  if case_status=='complete':
   if training.get('status')!='complete' or accounting.get('completed_starts')!=80 or accounting.get('completed_floors')!=11 or not all(f.get('complete') is True for f in fit_rows):raise ValueError('SUMMARY_COMPLETE_FIT_GATES')
   for fit in fit_rows:
    slots=fit.get('slots',[]);starts=[s for s in slots if s.get('kind')=='start'];floors=[s for s in slots if s.get('kind')=='floor'];accepted=fit.get('accepted_candidates',[])
    if fit.get('selected') is None or any(s.get('status')!='complete' for s in starts+floors) or len(accepted)!=8+len(floors) or fit['selected'].get('candidate_id') not in {c.get('candidate_id') for c in accepted}:raise ValueError('SUMMARY_COMPLETE_CANDIDATE_GATES')
   if not all(score.get('status')=='complete' for score in score_rows):raise ValueError('SUMMARY_COMPLETE_SCORE_GATES')
   if case_file.get('selector_complete') is not True or case_file.get('cross_grid_forecast_stable') is not True or case_file.get('cross_grid_forecast_spread_nats_per_event') is None or case_file['cross_grid_forecast_spread_nats_per_event']>=.01:raise ValueError('SUMMARY_CROSS_GRID_GATES')
  expected_case_status.append(case_status)
  ntest=case_file.get('n_test');number_ntest=number(ntest)
  if int(number_ntest)!=number_ntest or number_ntest<0 or sum(case_file.get('test_cell_counts',[]))!=int(number_ntest):raise ValueError('SUMMARY_TEST_DENOMINATOR')
  row=dict(case_id=case_id,status=case_status,n_train=case_file['n_train'],n_test=int(number_ntest),training_cell_counts=case_file['training_cell_counts'],test_cell_counts=case_file['test_cell_counts'],accounting=accounting,beta=case_file['beta'],selected_bandwidth_km=case_file['kde_selection']['selected_bandwidth'],selected_sigma_km=case_file['selected_sigma'],models={},comparisons=[])
  for mid in MODELS:
   model=case_file['models'][mid];entry=dict(status=model['status'],complete=model['complete'],procedure_id=model['procedure_id'])
   if model.get('selected'):
    entry['parameters']=model['selected']['pars'];entry['training_joint_nll']=number(model['selected']['evaluation']['joint_nll'])
   score_file=expected_scores[model['procedure_id']]
   if score_file.get('forecast'):
    entry['scores']=score_view(score_file['forecast']);entry['forecast_spread_nats_per_event']=score_file.get('forecast_spread_nats_per_event');entry['forecast_stable']=score_file.get('forecast_stable')
   row['models'][mid]=entry
  for ident,candidate,reference,component in COMPARISONS:
   c=row['models'][candidate];reference_model=row['models'][reference];item=dict(id=ident,candidate=candidate,reference=reference,primary_component=component,status='unknown_incomplete')
   if case_status=='complete' and 'scores' in c and 'scores' in reference_model:
    delta={k:c['scores'][k]-reference_model['scores'][k] for k in COMPONENTS};n=row['n_test']
    if n<=0:raise ValueError('SUMMARY_EMPTY_TEST_WINDOW')
    if abs(delta['joint_logscore']-delta['timing_logscore']-delta['conditional_location_logscore']-delta['mark_logscore'])>1e-7 or abs(delta['timing_logscore']-delta['timing_event_logscore']-delta['timing_exposure_logscore'])>1e-7:raise ValueError('SUMMARY_DELTA_IDENTITY')
    item.update(status='complete',n_test=n,delta=delta,primary_delta_nats=delta[component],primary_delta_nats_per_event=delta[component]/n,timing_decomposition=dict(event=delta['timing_event_logscore'],compensator=delta['timing_exposure_logscore'],total=delta['timing_logscore']))
   row['comparisons'].append(item)
  rows.append(row)
 if audit.get('bindings')!=bindings:raise ValueError('INDEPENDENT_AUDIT_BINDINGS')
 aggregates=[]
 for index,(ident,candidate,reference,component) in enumerate(COMPARISONS):
  parts=[r['comparisons'][index] for r in rows];entry=dict(id=ident,candidate=candidate,reference=reference,primary_component=component,status='unknown_incomplete',planned_windows=3,complete_windows=sum(p['status']=='complete' for p in parts))
  if all(p['status']=='complete' for p in parts):
   n=sum(p['n_test'] for p in parts);delta={k:math.fsum(p['delta'][k] for p in parts) for k in COMPONENTS}
   if n<=0 or abs(delta['joint_logscore']-delta['timing_logscore']-delta['conditional_location_logscore']-delta['mark_logscore'])>1e-7 or abs(delta['timing_logscore']-delta['timing_event_logscore']-delta['timing_exposure_logscore'])>1e-7:raise ValueError('SUMMARY_AGGREGATE_IDENTITY')
   entry.update(status='complete',n_test=n,delta=delta,primary_delta_nats=delta[component],primary_delta_nats_per_event=delta[component]/n,positive_windows=sum(p['primary_delta_nats']>0 for p in parts),window_deltas_nats=[p['primary_delta_nats'] for p in parts])
  aggregates.append(entry)
 status='complete' if all(s=='complete' for s in expected_case_status) else 'unknown_incomplete'
 if raw.get('status')!=status:raise ValueError('SUMMARY_TOP_STATUS')
 return dict(schema_version=2,status=status,scope='Revised-catalogue hindsight external retrospective replication; conditional regional history; not historical as-issued forecasting or causal evidence.',denominators=dict(planned_windows=3,procedures=30,starts=240,floors=33,all_test_targets=sum(r['n_test'] for r in rows)),cases=rows,comparisons=aggregates,input_bindings=bindings,independent_audit=dict(path=str(audit_path),sha256=expected_audit_sha256,status=audit['status'],passed=audit['passed'],independent=audit['independent'],mode=audit['mode'],denominators=audit['denominators']),source_sha256=sha(__file__),claim_limits=['Event-weighted differences over fixed windows; no event-iid confidence intervals or p-values.','Unknown/incomplete windows remain in the fixed three-window denominator and cannot be silently omitted.','No test-score retuning or additional optimization is performed by this postprocessor.'])

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--expected-source-sha256',required=True);p.add_argument('--independent-audit',required=True);p.add_argument('--expected-audit-sha256',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 if sha(__file__)!=a.expected_source_sha256:raise ValueError('SUMMARY_SOURCE_CHANGED')
 result=summarize(a.source,a.independent_audit,a.expected_audit_sha256)
 out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
 print(json.dumps(dict(status=result['status'],planned_windows=3,summary_sha256=sha(out))))

if __name__=='__main__':
 try:main()
 except Exception as error:print(json.dumps(dict(status='failed',fixed_error_code='CALIFORNIA_SUMMARY_FAILURE',error_type=type(error).__name__)));raise SystemExit(1)
