"""Handcrafted production machine witnesses; no empirical input or fitting."""
from pathlib import Path
import argparse,json,hashlib,math
import numpy as np
from . import geometry as G
from .compiled_objective import Objective
from .workflow import source_pins,verify
from .fitting import clean

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--protocol',required=True);ap.add_argument('--output',required=True);args=ap.parse_args();protocol=json.loads(Path(args.protocol).read_text());verify(protocol,'controls');out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 # Exactly declared synthetic scaffold: 108 parents, last90 scoredtraining,
 # plus3 futuretargets including a simultaneous pair; no empirical rows.
 lat_edges=np.array([32,32+5/3,32+10/3,37]);lon_edges=np.array([-121,-121+7/3,-121+14/3,-114]);centers=np.array([[(lat_edges[i]+lat_edges[i+1])/2,(lon_edges[j]+lon_edges[j+1])/2] for i in range(3) for j in range(3)])
 ll=np.vstack([np.tile(centers,(12,1)),centers[[0,4,8]]+np.array([.01,.01])]);t=np.r_[np.arange(108,dtype=float),[121.,125.,125.]];q=np.r_[np.tile(-np.log1p(-np.linspace(.005,.995,18))/2.85,6),[.1,.4,.8]];lat=ll[:,0];lon=ll[:,1];cells=G.cell_ids(lat,lon,'california');tr=(t>=18)&(t<120);pi,_,_=G.cell_proportions(cells,tr);beta,_=G.fit_conditional_beta(q[tr]);xy=G.project(lat[tr],lon[tr],'california');kde=G.select_bandwidth(xy,pi,G.SCALES,training_cells=cells[tr],profile='california');h=float(kde['selected_bandwidth']);records=[];checks=[];fdmax=0.;ordermax=0.;timing={};calls=0
 models=[('E_fixed',[-2.,.1,.25]),('E_free',[-2.,.1,.25,math.log(.6)]),('E_omori',[-2.,.1,.25,math.log(.25),1.45])]
 endpoints=[('E_free',[-2.,.1,.25,math.log(tau)]) for tau in [.001,20.]]+[('E_omori',[-2.,.1,.25,math.log(c),power]) for c,power in [(.0001,1.01),(.0001,2.5),(20.,1.01),(20.,2.5)]]
 for family in ['cont','lift']:
  for start,end in [(18.,120.),(120.,130.)]:
   paths={}
   for order in [16,32]:
    a,m=G.make_geometry(t,q,cells,lat,lon,beta,start,end,pi,family='continuous' if family=='cont' else 'center',sigma=50.,order=order,T0=140.,background='kde',kde_bandwidth=h,background_training_xy=xy,background_training_cells=cells[tr],profile='california')
    path=out/f'fixture_{family}_{int(start)}_{order}.npz';G.save_geometry(path,a);paths[order]=path
   with Objective(paths[16]) as obj,Objective(paths[32]) as fine:
    for index,(model,pars) in enumerate(models+endpoints):
     v=obj.evaluate(model,pars);f=fine.evaluate(model,pars);calls+=2;ordermax=max(ordermax,abs(v['joint_nll']-f['joint_nll']))
     records.append(dict(start=start,end=end,train_start=18.,train_end=120.,T0=140.,beta=beta,beta_policy='training_conditional',sigma=50.,bandwidth=h,spatial=family,model=model,pars=pars,history_policy='continuous',production=clean(v)))
     if index<3:
      timing[family,start,model]=v['timing_logscore']
      for j in range(len(pars)):
       step=1e-5*(1+abs(pars[j]));plus=list(pars);minus=list(pars);plus[j]+=step;minus[j]-=step
       fd=(obj.evaluate(model,plus)['joint_nll']-obj.evaluate(model,minus)['joint_nll'])/(2*step);calls+=2;fdmax=max(fdmax,abs(fd-v['gradient'][j])/(1+abs(v['gradient'][j])))
    fixed=obj.evaluate('E_fixed',models[0][1]);nested=obj.evaluate('E_free',models[0][1]+[0.]);calls+=2
    checks.append(dict(name=f'nesting_{family}_{start}',passed=abs(fixed['joint_nll']-nested['joint_nll'])<=1e-10 and np.max(abs(fixed['gradient']-nested['gradient'][:3]))<=1e-10))
    for model,pars in models[1:]:
     pars=list(pars);pars[2]=0.;v=obj.evaluate(model,pars);calls+=1;checks.append(dict(name=f'n0_{family}_{start}_{model}',passed=bool(np.all(v['gradient'][3:]==0))))
 for start in [18.,120.]:
  for model,_ in models:checks.append(dict(name=f'ground_normalization_{start}_{model}',passed=abs(timing['cont',start,model]-timing['lift',start,model])<=1e-10))
 checks.extend([dict(name='analytic_gradient_fd_scaled',passed=fdmax<=5e-5),dict(name='order16_32_consistency',passed=ordermax<=1e-4)])
 checks=[dict(c,passed=bool(c['passed'])) for c in checks];pins=source_pins();pins[str(Path(__file__).resolve())]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 bundle=dict(schema_version=1,data_classification='handcrafted_fixture',profile='california',production_source_pins=pins,raw=dict(times=t.tolist(),excess=q.tolist(),latitude=lat.tolist(),longitude=lon.tolist()),records=records,nuisance_controls=[dict(train_start=18.,train_end=120.,production_kde_selection=clean(kde))])
 with (out/'machine_bundle.json').open('x',encoding='utf-8') as f:json.dump(bundle,f,indent=2,allow_nan=False)
 result=dict(passed=all(c['passed'] for c in checks),records=len(records),checks=checks,evaluation_calls=calls,maximum_scaled_gradient_error=float(fdmax),maximum_16_32_nll_error=float(ordermax),quadrature_scope='Production compensators analytic; identical16/32 is consistency only. Independent positive-integrand geometry/oracle audit separately required.',bundle_sha256=hashlib.sha256((out/'machine_bundle.json').read_bytes()).hexdigest())
 with (out/'machine_controls.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print(json.dumps(dict(passed=result['passed'],records=len(records),checks=len(checks))))
 return 0 if result['passed'] else 1
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as error:print(json.dumps(dict(passed=False,error_type=type(error).__name__,fixed_error_code='MACHINE_CONTROL_FAILURE')));raise SystemExit(1)
