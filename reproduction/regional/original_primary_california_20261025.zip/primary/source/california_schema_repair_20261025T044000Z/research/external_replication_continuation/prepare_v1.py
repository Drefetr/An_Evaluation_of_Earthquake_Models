"""Source-only-governed IO authorization and final California protocol freezing."""
from datetime import datetime,timedelta,timezone
from pathlib import Path
import argparse,copy,importlib,json,sys
try:from .closure_v1 import *
except ImportError:from closure_v1 import *
QUALITY_SHA='415cc953e92250b4f5091c6b4ea3dd1e0c681cc9a53ea5a93cd29fc81adf3d38'

def schema_admission(config,pins):
    reference=config['schema_admission'];path=checked(reference);value=read(path);amendment=config['schema_amendment']
    if value.get('status')!='accepted' or value.get('passed') is not True or value.get('independent_review') is not True or value.get('controls_passed') is not True or value.get('quality_schema_amendment_sha256')!=amendment['sha256']:raise ValueError('QUALITY_SCHEMA_SOURCE_NOT_ACCEPTED')
    sources=value.get('source_files_sha256')
    if type(sources) is not dict or set(sources)!={'catalogue_v4.py','parse_v3.py'}:raise ValueError('QUALITY_SOURCE_CLOSURE')
    directory=Path(config['study']).resolve()/'source/research/external_replication_catalogue'
    for name,digest in sources.items():target=checked(dict(path=str(directory/name),sha256=digest));pins[str(target)]=digest
    control=value['fixture_control_receipt'];controlpath=Path(control['path']);controlpath=controlpath if controlpath.is_absolute() else Path(config['run'])/controlpath;controlref=dict(path=str(controlpath.resolve()),sha256=control['sha256']);target=checked(controlref);checks=read(target)
    if checks.get('passed') is False or checks.get('status')=='failed' or (checks.get('passed') is not True and checks.get('status')!='passed'):raise ValueError('QUALITY_FIXTURES_NOT_PASSED')
    pins[str(target)]=controlref['sha256'];pins[str(path)]=reference['sha256']
    if 'source_review' not in value:raise ValueError('QUALITY_INDEPENDENT_SOURCE_REVIEW_REQUIRED')
    review=value['source_review'];reviewpath=checked(review);pins[str(reviewpath)]=review['sha256']
    for target,digest in checks.get('source_pins',{}).items():
        source=Path(target);source=source if source.is_absolute() else directory/source;source=source.resolve();checked(dict(path=str(source),sha256=digest));pins[str(source)]=digest
    return value

def pin_current_source_inputs(config,pins):
    """Hash currentR2 custody files; parse manifests only, never event arrays."""
    run=Path(config['run']).resolve()
    metadata=['design/catalogue_source_metadata.json','design/acquisition_protocol_v2.json','design/acquisition_freeze_v1.json','design/boundary_contract_v1.json','design/time_schema_amendment_v1.json','design/quality_schema_amendment_v1.json','design/repair_input_authorization_v1.json','inputs/cached_raw_custody_v1.json']
    for relative in metadata:
        path=run/relative;pins[str(path)]=sha(path)
    total_files=0
    for lane,relative in [('training','inputs/california/train'),('protected','protected/california')]:
        root=run/relative
        for name in ['raw_manifest.json','raw_id_index.json','canonical_model.json','canonical_diagnostic.json','retrieval_receipt.json']:
            path=root/name;pins[str(path)]=sha(path)
        manifest=read(root/'raw_manifest.json')
        if manifest.get('quality_schema_amendment_sha256')!=QUALITY_SHA:raise ValueError('CURRENT_MANIFEST_SCHEMA_AMENDMENT_BINDING')
        files=manifest.get('files')
        if type(files) is not list or len(files)!=(30 if lane=='training' else 15):raise ValueError('FIXED_ANNUAL_SOURCE_FILE_ACCOUNTING')
        for entry in files:
            path=(root/'raw'/Path(entry['path']).name).resolve();target=checked(dict(path=str(path),sha256=entry['sha256']));pins[str(target)]=entry['sha256'];total_files+=1
        key='training_catalogue' if lane=='training' else 'protected_catalogue';actual=ref(root/'canonical_model.json')
        if key in config and config[key]!=actual:raise ValueError('CURRENT_CANONICAL_REFERENCE_MISMATCH')
        config[key]=actual
    if total_files!=45:raise ValueError('FIXED_RAW_BLOB_COUNT')

def base(config_path,*,require_source_admission=True):
    config=read(config_path);study=Path(config['study']).resolve();run=Path(config['run']).resolve();pins=verify_core(study);methods=checked(config['methods_protocol'])
    if config['methods_protocol']['sha256']!=METHODS_SHA or config['schema_amendment']['sha256']!=QUALITY_SHA:raise ValueError('FROZEN_SCIENCE_OR_SCHEMA_IDENTITY')
    pins.update(verify_nz(config['nz_registration'],config['nz_acceptance']));authority=read(checked(config['input_authorization']))
    if authority.get('status')!='frozen_pre_fit_user_authorized_repair' or authority.get('old_NZ_registration')!=config['nz_registration'] or authority.get('old_NZ_registration_acceptance')!=config['nz_acceptance']:raise ValueError('ROOT_REPAIR_INPUT_AUTHORIZATION')
    for reference in [config['methods_protocol'],config['schema_amendment'],config['input_authorization'],*config.get('source_inputs',[]),*config.get('auditor_sources',[]),*config.get('extra_pins',[])]:target=checked(reference);pins[str(target)]=reference['sha256']
    if not config.get('auditor_sources'):raise ValueError('INDEPENDENT_AUDITOR_SOURCE_PINS_REQUIRED')
    pins.update(local_source_pins());pins[str(Path(sys.executable).resolve())]=sha(sys.executable);pins[str(Path(config_path).resolve())]=sha(config_path)
    if require_source_admission:schema_admission(config,pins)
    pin_current_source_inputs(config,pins)
    # There must be exactly one mathematical core at the NEW study paths. Never
    # expand the historical old49/112 registration artifact map into CA pins.
    expected={str(study/'source/research/external_replication'/name) for name in CORE}
    actual={path for path in pins if Path(path).parent.name=='external_replication' and Path(path).name in CORE}
    if actual!=expected:raise ValueError('DUPLICATED_OR_RELOCATED_MATHEMATICAL_CORE_PINS')
    return config,read(methods),pins

def authorize_preflight(config_path,output):
    config,methods,pins=base(config_path);authorization=copy.deepcopy(methods);authorization.update(schema_version=1,kind='independent_source_reconstruction_and_preflight_only',status='frozen',protected_release_authorized=True,fit_authorized=False,forecast_outcome_inspection_authorized=False,artifact_pins=pins,methods_protocol=config['methods_protocol'],schema_amendment=config['schema_amendment'],input_authorization=config['input_authorization'],training_catalogue=config['training_catalogue'],protected_catalogue=config['protected_catalogue'],nz_registration=config['nz_registration'],nz_acceptance=config['nz_acceptance'],scope='Read local source/canonical/diagnostics to reconstruct schema and frozen M2/target admission; no model fits, forecast scores or outcome-driven changes.',created_utc=datetime.now(timezone.utc).isoformat())
    write(output,authorization);return dict(status='preflight_io_authorized',path=str(Path(output).resolve()),sha256=sha(output))

def freeze(config_path,output,receipt_path,plan_path):
    config,methods,pins=base(config_path);required=[config['training_catalogue'],config['protected_catalogue'],config['schema_amendment']];preflight,added=gate(config['preflight_admission'],bindings_required=required,classification='local_verified_empirical_rows');pins.update(added)
    if preflight.get('schema_reconstruction_passed') is not True or preflight.get('training_admission_passed') is not True or preflight.get('target_adequacy',{}).get('admitted') is not True:raise ValueError('RAW_CANONICAL_M2_PREFLIGHT_REQUIRED')
    replay=read(checked(config['core_replay_receipt']))
    if replay.get('passed') is not True or replay.get('unchanged_core_11') is not True or replay.get('optimizer_fits')!=0 or replay.get('records')!=36:raise ValueError('UNCHANGED_CORE_REPLAY_REQUIRED')
    core_gate,added=gate(config['core_replay_admission'],bindings_required=[config['core_replay_receipt']]);pins.update(added)
    merge_path=checked(config['merge_receipt']);merge=read(merge_path);combined=checked(config['merged_catalogue'])
    if merge.get('kind')!='lossless_canonical_merge' or merge.get('passed') is not True or merge.get('all_input_rows_preserved') is not True or merge.get('event_fields_unchanged') is not True or merge.get('output')!=config['merged_catalogue'] or merge.get('input_refs')!=[config['training_catalogue'],config['protected_catalogue']]:raise ValueError('LOSSLESS_FULL_CATALOGUE_MERGE_REQUIRED')
    resource,added=gate(config['resource_admission'],bindings_required=[config['merge_receipt'],config['merged_catalogue']]);pins.update(added)
    if resource.get('all_rows_retained') is not True or resource.get('no_row_exclusions') is not True or (resource.get('estimated_within_cap') is not True and resource.get('equivalent_engineering_admitted') is not True):raise ValueError('FULL_POPULATION_RESOURCE_ADMISSION')
    if resource.get('remaining_compute_seconds',0)<6500+6000+900:raise ValueError('FIT_PLUS_AUDIT_REPORT_COMPUTE_RESERVE')
    for reference in [config['core_replay_receipt'],config['merge_receipt'],config['merged_catalogue'],config['training_catalogue'],config['protected_catalogue']]:target=checked(reference);pins[str(target)]=reference['sha256']
    for path,digest in merge.get('bindings',{}).items():target=checked(dict(path=path,sha256=digest));pins[str(target)]=digest
    study=Path(config['study']).resolve();expected={str(study/'source/research/external_replication'/name) for name in CORE};actual={path for path in pins if Path(path).parent.name=='external_replication' and Path(path).name in CORE}
    if actual!=expected:raise ValueError('FINAL_CORE_PINS_MUST_BE_EXACTLY_NEW_11')
    now=datetime.now(timezone.utc);wall_end=utc(config['run_started_utc'])+timedelta(seconds=28800);fit_deadline=wall_end-timedelta(seconds=6000+900)
    if now+timedelta(seconds=6500)>fit_deadline:raise ValueError('FIT_PLUS_AUDIT_REPORT_WALL_RESERVE')
    protocol=copy.deepcopy(methods);protocol.update(status='frozen',science_gate_passed=True,protected_release_authorized=True,artifact_pins=pins,data=dict(catalogue=str(combined),sha256=config['merged_catalogue']['sha256'],legacy_csv=False),resources=dict(deadline_utc=fit_deadline.isoformat(),compute_budget_seconds=21600,wall_budget_seconds=28800,fit_stage_seconds=6500,seconds_per_procedure=2000,audit_reserve_seconds=6000,report_reserve_seconds=900,memory_budget_bytes=8700000000,working_cap_bytes=6700000000,all_rows_retained=True,event_count_cutoff=None),continuation=dict(baseline_commit=BASELINE_COMMIT,methods_protocol=config['methods_protocol'],schema_amendment=config['schema_amendment'],input_authorization=config['input_authorization'],preflight_admission=config['preflight_admission'],core_replay_receipt=config['core_replay_receipt'],core_replay_admission=config['core_replay_admission'],merge_receipt=config['merge_receipt'],resource_admission=config['resource_admission'],nz_registration=config['nz_registration'],nz_acceptance=config['nz_acceptance'],old_NZ_112_closure_not_duplicated=True),frozen_utc=now.isoformat())
    sys.path.insert(0,str(study));W=importlib.import_module('source.research.external_replication.workflow')
    if Path(W.__file__).resolve()!=study/'source/research/external_replication/workflow.py':raise ValueError('WORKFLOW_MODULE_ORIGIN')
    W.verify(protocol,'california');write(output,protocol)
    plan=dict(schema_version=1,status='frozen_commands_for_root_serial_lease_only',protocol=ref(output),thread_environment={name:'1' for name in THREAD_NAMES},fit=dict(argv=[sys.executable,'-B',str(study/'source/research/external_replication/workflow.py'),'--protocol',str(Path(output).resolve()),'--output',str(Path(config['fit_output']).resolve()),'--mode','california','--seconds-per-procedure','2000','--stage-seconds','6500'],procedures=30,starts=240,floors=33),reserved_after_fit=dict(independent_audit_seconds=6000,report_seconds=900),no_job_started_by_builder=True);write(plan_path,plan)
    receipt=dict(schema_version=1,status='frozen',passed=True,kind='California_continuation_protocol_freeze',protocol=ref(output),execution_plan=ref(plan_path),denominators=dict(procedures=30,starts=240,floors=33),independent_gates=[config['preflight_admission'],config['core_replay_admission'],config['resource_admission']],immutable_old_NZ_registration=config['nz_registration'],old_NZ_acceptance=config['nz_acceptance'],core_names=list(CORE),core_path_policy='Exactly newW2 core11; no old49/112 artifact map copied',all_rows_retained=True,no_forecast_outcomes_used=True,no_fit_started=True,bindings={**pins,str(Path(output).resolve()):sha(output),str(Path(plan_path).resolve()):sha(plan_path)});write(receipt_path,receipt);return dict(status='protocol_frozen',path=str(Path(receipt_path).resolve()),sha256=sha(receipt_path))

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True);a=sub.add_parser('authorize-preflight');a.add_argument('--config',required=True);a.add_argument('--output',required=True);a=sub.add_parser('freeze');a.add_argument('--config',required=True);a.add_argument('--output',required=True);a.add_argument('--receipt',required=True);a.add_argument('--plan',required=True);args=p.parse_args();result=authorize_preflight(args.config,args.output) if args.mode=='authorize-preflight' else freeze(args.config,args.output,args.receipt,args.plan);print(json.dumps(result))
if __name__=='__main__':
    try:main()
    except BaseException as error:print(json.dumps(dict(status='failed',fixed_error_code='CONTINUATION_PREPARATION_FAILURE',error_type=type(error).__name__)));sys.exit(1)
