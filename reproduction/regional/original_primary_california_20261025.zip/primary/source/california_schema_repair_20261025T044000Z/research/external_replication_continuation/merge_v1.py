"""Lossless canonical merge for a root lease after independent source preflight."""
from datetime import datetime,timezone
from pathlib import Path
import argparse,json,sys
try:from .closure_v1 import read,write,ref,checked,gate,utc,canon,objsha
except ImportError:from closure_v1 import read,write,ref,checked,gate,utc,canon,objsha

def event_key(event):
    if type(event) is not dict or type(event.get('event_id')) is not str or not event['event_id']:raise ValueError('EVENT_ID_SCHEMA')
    stamp=utc(event['origin_time_utc']);delta=stamp-datetime(1970,1,1,tzinfo=timezone.utc);micros=(delta.days*86400+delta.seconds)*1000000+delta.microseconds
    if 'origin_time_us' in event and (type(event['origin_time_us']) is not int or event['origin_time_us']!=micros):raise ValueError('EXACT_TIMESTAMP_BINDING')
    return micros,event['event_id']

def merge(config_path,output,receipt_path):
    config=read(config_path);trainref=config['training_catalogue'];protectedref=config['protected_catalogue'];amendment=config['schema_amendment'];preflight,pins=gate(config['preflight_admission'],bindings_required=[trainref,protectedref,amendment],classification='local_verified_empirical_rows')
    if preflight.get('schema_reconstruction_passed') is not True or preflight.get('training_admission_passed') is not True or preflight.get('target_adequacy',{}).get('admitted') is not True:raise ValueError('FULL_PREFLIGHT_REQUIRED')
    train=read(checked(trainref));protected=read(checked(protectedref));inputs=[('training',train,utc('1981-01-01T00:00:00Z'),utc('2011-01-01T00:00:00Z')),('protected',protected,utc('2011-01-01T00:00:00Z'),utc('2026-01-01T00:00:00Z'))];all_events=[];ids=set();lane_counts={}
    for lane,catalogue,start,end in inputs:
        if catalogue.get('schema_version')!=1 or type(catalogue.get('events')) is not list:raise ValueError('CANONICAL_SCHEMA')
        previous=None
        for event in catalogue['events']:
            key=event_key(event);stamp=utc(event['origin_time_utc'])
            if previous is not None and key<previous:raise ValueError('INPUT_NOT_NUMERIC_UTC_ID_ORDERED')
            if not start<=stamp<end or key[1] in ids:raise ValueError('LANE_TIME_OR_DUPLICATE_ID')
            previous=key;ids.add(key[1]);all_events.append(event)
        lane_counts[lane]=len(catalogue['events'])
    all_events.sort(key=event_key);digest_before=objsha(all_events);source_refs=[trainref,protectedref];latest=max([train['provenance']['retrieved_utc'],protected['provenance']['retrieved_utc']],key=utc)
    # Root metadata describes a merge, not another retrieval. Every event object
    # is passed through untouched, including source tokens and opaque quality.
    source_snapshot=train['provenance']['source_snapshot']
    if source_snapshot!=protected['provenance']['source_snapshot'] or source_snapshot!='7105f6c1b861db46c3a8454984588f5b6a4a56e4':raise ValueError('SINGLE_PINNED_AGENCY_SOURCE_SNAPSHOT')
    combined=dict(schema_version=1,catalogue_id='SCEDC_external_continuation_lossless_merge_v1',provenance=dict(source_snapshot=source_snapshot,raw_manifest_sha256=objsha(source_refs),retrieved_utc=latest),merged_from=source_refs,events=all_events)
    write(output,combined);saved=read(output)
    if len(saved['events'])!=sum(lane_counts.values()) or objsha(saved['events'])!=digest_before:raise ValueError('LOSSLESS_MERGE_POSTWRITE_IDENTITY')
    epoch=utc('1981-01-01T00:00:00Z');days=[(utc(e['origin_time_utc'])-epoch).total_seconds()/86400 for e in all_events];folds=[]
    for i,(origin,end) in enumerate([('2011-01-01T00:00:00Z','2016-01-01T00:00:00Z'),('2016-01-01T00:00:00Z','2021-01-01T00:00:00Z'),('2021-01-01T00:00:00Z','2026-01-01T00:00:00Z')]):
        first=(utc('1986-01-01T00:00:00Z')-epoch).total_seconds()/86400;split=(utc(origin)-epoch).total_seconds()/86400;last=(utc(end)-epoch).total_seconds()/86400
        folds.append(dict(case_id=f'california_fold_{i}',n_training=sum(first<=t<split for t in days),n_training_parents=sum(t<split for t in days),n_test=sum(split<=t<last for t in days),n_test_parents=sum(t<last for t in days)))
    receipt=dict(schema_version=1,status='passed',passed=True,independent=False,kind='lossless_canonical_merge',input_refs=source_refs,output=ref(output),schema_amendment=amendment,preflight_admission=config['preflight_admission'],all_input_rows_preserved=True,event_fields_unchanged=True,ordering='exact integer Unixmicroseconds then eventID; no jitter/no same-time ordering causality',event_objects_sha256=digest_before,private_counts=dict(lane_counts,total=len(all_events)),private_fold_counts=folds,bindings={**pins,str(checked(trainref)):trainref['sha256'],str(checked(protectedref)):protectedref['sha256'],str(Path(output).resolve()):ref(output)['sha256'],str(checked(amendment)):amendment['sha256']})
    write(receipt_path,receipt);return dict(status='merged',path=str(Path(receipt_path).resolve()),sha256=ref(receipt_path)['sha256'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',required=True);p.add_argument('--receipt',required=True);a=p.parse_args();print(json.dumps(merge(a.config,a.output,a.receipt)))
if __name__=='__main__':
    try:main()
    except BaseException as error:print(json.dumps(dict(status='failed',fixed_error_code='LOSSLESS_MERGE_FAILURE',error_type=type(error).__name__)));sys.exit(1)
