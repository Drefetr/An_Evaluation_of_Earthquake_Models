"""Metadata-only continuation identity and governance primitives."""
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json,re
BASELINE_COMMIT='11b2af085f4dc5d823ebf058709985001500cfa8'
METHODS_SHA='8bc5cad81349f9746e56a756abbb26cb9d04ad4d874e834e249a5ad85f770138'
NZ_REGISTRATION_SHA='58d4b140075daac1e831619a1d603d9135714b334ef3e4dd221ebe64cf08e093'
CORE={
'__init__.py':'280323e95b5f7e863e140d48499bc625bb1eb05fb0c4f03d5c2fa086d2d001b7',
'objective.cpp':'8f3ca6cb1a8b5c518715e361532c62fa25893428f40c92efb80e841a8f391a2e',
'objective.dll':'c2452e74fcbe8d9d5c2ca11b99a15d6203f6a22f8361b6a9f8a52dd63819019b',
'compiled_objective.py':'c1f2e7774235459f92aeea0611a168e2e47c0120915807929999b01fb91e804f',
'geometry.py':'929f26bf1a0f0c0d67dce3caccdf89bd248aabb4ee34e79898b6356f5df2d4ce',
'fitting.py':'96e56fea145f8a0857f962129a483efbc2bee9e0e43c17d8d09218ece751b2d3',
'catalogue.py':'3999225daa7349502356b2ac875161969abdb2408054c035953cd9af8dc756c0',
'workflow.py':'af9fb2f166807d5d44cb9ea1cd6ef4e8565e3434ddb83b06d57903a50f7f13be',
'prospective.py':'582d95853836595846a14caf8cf598073c91d1b447bfb3c8dacd1f64734f37cf',
'synthetic.py':'7c6f19c6fbe848efac335fbddb5f0edf8ef307d69a3ec4e0dbc02db67c2d0e6e',
'build_objective.cmd':'8bc9df0468f41aeb6b529d37f46e8b9816cbc55861927023e07e3dc6c115d1ad'}
MACHINE_SOURCE_SHA='f69658991644e704e412b0ba2d27d420c36c3b1a6d2a1d2bda8ab47f2aba4100'
THREAD_NAMES=['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(65536),b''):digest.update(part)
    return digest.hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def objsha(v):return hashlib.sha256(canon(v)).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
def ref(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def checked(reference):
    if type(reference) is not dict or type(reference.get('path')) is not str or not Path(reference['path']).is_absolute():raise ValueError('ABSOLUTE_REFERENCE_REQUIRED')
    path=Path(reference['path']).resolve()
    if sha(path)!=reference.get('sha256'):raise ValueError('REFERENCE_IDENTITY_CHANGED')
    return path

def utc(value):
    if type(value) is not str or re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)',value) is None:raise ValueError('UTC_SCHEMA')
    result=datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None or result.utcoffset().total_seconds()!=0:raise ValueError('UTC_REQUIRED')
    return result

def verify_core(study):
    directory=Path(study).resolve()/'source/research/external_replication'
    pins={str(directory/name):sha(directory/name) for name in CORE}
    if any(pins[str(directory/name)]!=expected for name,expected in CORE.items()):raise ValueError('BASELINE_11_CORE_OR_DLL_CHANGED')
    return pins

def verify_nz(reg_ref,acceptance_ref):
    if reg_ref.get('sha256')!=NZ_REGISTRATION_SHA:raise ValueError('OLD_NZ_REGISTRATION_IDENTITY')
    regpath=checked(reg_ref);acceptance=read(checked(acceptance_ref));reg=read(regpath)
    if reg.get('schema_version')!=5 or reg.get('status')!='frozen' or acceptance.get('status')!='accepted' or acceptance.get('passed') is not True or acceptance.get('independent') is not True or acceptance.get('california_release_authorized') is not True or acceptance.get('registration')!=reg_ref:raise ValueError('OLD_NZ_REGISTRATION_NOT_INDEPENDENTLY_ACCEPTED')
    # Do not dereference or copy the old112-artifact fit/parameter closure. Its
    # immutable registration and acceptance remain the authority at old paths.
    pins={str(regpath):reg_ref['sha256'],str(checked(acceptance_ref)):acceptance_ref['sha256']}
    for key in ['registration_closed_hashed','final_completion']:
        reference=acceptance[key];path=checked(reference);pins[str(path)]=reference['sha256']
    return pins

def gate(reference,*,bindings_required=(),classification=None):
    path=checked(reference);value=read(path)
    if value.get('status') not in ['passed','accepted'] or value.get('passed') is not True or value.get('independent') is not True:raise ValueError('INDEPENDENT_GATE_NOT_PASSED')
    if classification is not None and value.get('data_classification')!=classification:raise ValueError('INDEPENDENT_GATE_CLASSIFICATION')
    bindings=value.get('bindings')
    if type(bindings) is not dict:raise ValueError('INDEPENDENT_GATE_BINDINGS_REQUIRED')
    for needed in bindings_required:
        target=checked(needed)
        if bindings.get(str(target))!=needed['sha256']:raise ValueError('GATE_REQUIRED_INPUT_UNBOUND')
    pins={str(path):reference['sha256']}
    # All declared bindings are hash checked; event data are never displayed.
    for target,digest in bindings.items():
        check=checked(dict(path=target,sha256=digest));pins[str(check)]=digest
    return value,pins

def local_source_pins():
    here=Path(__file__).resolve().parent
    return {str(p):sha(p) for p in sorted(here.glob('*.py'))}
