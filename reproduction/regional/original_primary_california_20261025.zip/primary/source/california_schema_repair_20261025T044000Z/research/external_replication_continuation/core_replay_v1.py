"""Root-leased unchanged-core machine replay; no build, optimizer or network."""
from pathlib import Path
import argparse,contextlib,importlib,json,os,sys
try:from .closure_v1 import CORE,METHODS_SHA,MACHINE_SOURCE_SHA,BASELINE_COMMIT,read,write,ref,checked,verify_core,verify_nz,sha
except ImportError:from closure_v1 import CORE,METHODS_SHA,MACHINE_SOURCE_SHA,BASELINE_COMMIT,read,write,ref,checked,verify_core,verify_nz,sha

def prepare(config_path,output):
    config=read(config_path);study=Path(config['study']).resolve();pins=verify_core(study);methods=checked(config['methods_protocol'])
    if config['methods_protocol']['sha256']!=METHODS_SHA:raise ValueError('FIXED_METHODS_IDENTITY')
    pins.update(verify_nz(config['nz_registration'],config['nz_acceptance']));amendment=checked(config['schema_amendment'])
    if config['schema_amendment']['sha256']!='415cc953e92250b4f5091c6b4ea3dd1e0c681cc9a53ea5a93cd29fc81adf3d38':raise ValueError('QUALITY_AMENDMENT_IDENTITY')
    machine=study/'source/research/external_replication/machine_controls.py'
    if sha(machine)!=MACHINE_SOURCE_SHA:raise ValueError('BASELINE_MACHINE_SOURCE_CHANGED')
    here=Path(__file__).resolve().parent
    for path in [methods,amendment,machine,Path(sys.executable).resolve(),Path(config_path).resolve(),here/'__init__.py',here/'closure_v1.py',Path(__file__).resolve()]:pins[str(path)]=sha(path)
    protocol=read(methods);protocol.update(status='controls_frozen',artifact_pins=pins,continuation=dict(kind='identical_core_short_machine_replay',baseline_commit=BASELINE_COMMIT,study=str(study),core_files=CORE,nz_registration=config['nz_registration'],nz_acceptance=config['nz_acceptance'],schema_amendment=config['schema_amendment']),resources=dict(no_optimizer_fits=True,no_empirical_data=True))
    write(output,protocol);return dict(status='controls_protocol_frozen',path=str(Path(output).resolve()),sha256=sha(output))

def replay(protocol_path,output,baseline_ref=None):
    protocol=read(protocol_path);study=Path(protocol['continuation']['study']) if 'study' in protocol['continuation'] else Path(next(p for p in protocol['artifact_pins'] if Path(p).name=='machine_controls.py')).parents[3]
    pins=verify_core(study);sys.path.insert(0,str(study));machine=importlib.import_module('source.research.external_replication.machine_controls');workflow=importlib.import_module('source.research.external_replication.workflow')
    if Path(machine.__file__).resolve()!=study/'source/research/external_replication/machine_controls.py' or sha(machine.__file__)!=MACHINE_SOURCE_SHA:raise ValueError('MACHINE_MODULE_ORIGIN')
    out=Path(output);out.mkdir(parents=True,exist_ok=False);original=sys.argv[:]
    try:
        sys.argv=[str(machine.__file__),'--protocol',str(Path(protocol_path).resolve()),'--output',str(out)]
        with (out/'private_machine_stdout.log').open('x',encoding='utf-8') as sink:
            with contextlib.redirect_stdout(sink),contextlib.redirect_stderr(sink):code=machine.main()
    finally:sys.argv=original
    receipt=read(out/'machine_controls.json');bundle=read(out/'machine_bundle.json')
    if code not in [None,0] or receipt.get('passed') is not True or receipt.get('records')!=36 or bundle.get('data_classification')!='handcrafted_fixture' or len(bundle.get('records',[]))!=36:raise ValueError('SHORT_CORE_MACHINE_REPLAY_FAILED')
    same_baseline=None
    if baseline_ref is not None:
        baseline=read(checked(baseline_ref))
        if baseline.get('data_classification')!='handcrafted_fixture':raise ValueError('HANDCRAFTED_BASELINE_ONLY')
        same_baseline=bundle['raw']==baseline['raw'] and bundle['records']==baseline['records'] and bundle['nuisance_controls']==baseline['nuisance_controls']
        if not same_baseline:raise ValueError('BASELINE_SYN_NUMERIC_REPLAY_CHANGED')
    result=dict(schema_version=1,status='passed',passed=True,independent=False,data_classification='handcrafted_core_replay',baseline_commit=BASELINE_COMMIT,core_hashes=pins,unchanged_core_11=True,records=36,optimizer_fits=0,empirical_rows_read=False,baseline_comparison=baseline_ref,baseline_numeric_equal=same_baseline,protocol=ref(protocol_path),machine_receipt=ref(out/'machine_controls.json'),machine_bundle=ref(out/'machine_bundle.json'),bindings={**pins,str(Path(protocol_path).resolve()):sha(protocol_path),str(out/'machine_controls.json'):sha(out/'machine_controls.json'),str(out/'machine_bundle.json'):sha(out/'machine_bundle.json'),str(Path(__file__).resolve()):sha(__file__)})
    write(out/'core_replay_receipt.json',result);return dict(status='passed',path=str((out/'core_replay_receipt.json').resolve()),sha256=sha(out/'core_replay_receipt.json'))

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='mode',required=True);a=sub.add_parser('prepare');a.add_argument('--config',required=True);a.add_argument('--output',required=True);a=sub.add_parser('replay');a.add_argument('--protocol',required=True);a.add_argument('--output',required=True);a.add_argument('--baseline-synthetic-bundle');args=p.parse_args()
    result=prepare(args.config,args.output) if args.mode=='prepare' else replay(args.protocol,args.output,ref(args.baseline_synthetic_bundle) if args.baseline_synthetic_bundle else None);print(json.dumps(result))
if __name__=='__main__':
    try:main()
    except BaseException as error:print(json.dumps(dict(status='failed',fixed_error_code='CORE_REPLAY_FAILURE',error_type=type(error).__name__)));sys.exit(1)
