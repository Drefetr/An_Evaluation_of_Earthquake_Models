﻿"""Conservative full-cohort resource estimate; never excludes scientific rows."""
from pathlib import Path
import argparse,ctypes,json,sys
try:from .closure_v1 import read,write,ref,checked,utc
except ImportError:from closure_v1 import read,write,ref,checked,utc
from datetime import datetime,timezone

def available_physical_bytes():
    class MemoryStatus(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('total_phys',ctypes.c_ulonglong),('available_phys',ctypes.c_ulonglong),('total_page',ctypes.c_ulonglong),('available_page',ctypes.c_ulonglong),('total_virtual',ctypes.c_ulonglong),('available_virtual',ctypes.c_ulonglong),('extended',ctypes.c_ulonglong)]
    result=MemoryStatus();result.length=ctypes.sizeof(result)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(result)):raise RuntimeError('HARDWARE_MEMORY_SNAPSHOT_FAILED')
    return int(result.available_phys),int(result.total_phys)

def estimate(merge_ref,output,*,working_cap_bytes=6700000000,memory_budget_bytes=8700000000,reserve_bytes=512000000):
    path=checked(merge_ref);merge=read(path)
    if merge.get('kind')!='lossless_canonical_merge' or merge.get('passed') is not True or merge.get('all_input_rows_preserved') is not True:raise ValueError('LOSSLESS_MERGE_REQUIRED')
    free,total=available_physical_bytes();rows=[];disk=0
    for counts in merge['private_fold_counts']:
        nt,np_,ne,npe=[counts[k] for k in ['n_training','n_training_parents','n_test','n_test_parents']]
        if any(type(v) is not int or v<0 for v in [nt,np_,ne,npe]):raise ValueError('FULL_COUNT_SCHEMA')
        # Conservative envelope covers both NPZ adapters, C++ feature copies,
        # temporal density/derivative temporaries, spatial pairwise temporaries,
        # training KDE, and a512MB process/library baseline. Not a measured RSS.
        peak=512000000+128*max(nt*np_,ne*npe)+80*nt*nt+4096*(nt+np_+ne+npe)
        raw_cache=224*(nt*np_+ne*npe)+4096*(nt+np_+ne+npe);disk+=raw_cache
        rows.append(dict(counts=counts,estimated_peak_working_bytes=peak,estimated_uncompressed_cache_bytes=raw_cache))
    peak=max((v['estimated_peak_working_bytes'] for v in rows),default=512000000);limit=min(working_cap_bytes,memory_budget_bytes,max(0,free-reserve_bytes));fits=peak<=limit
    result=dict(schema_version=1,status='estimate_within_cap' if fits else 'engineering_required',kind='full_cohort_resource_estimate',independent=False,merge_receipt=merge_ref,all_rows_retained=True,population_eligibility_changed=False,event_count_cutoff=None,private_fold_estimates=rows,estimated_peak_working_bytes=peak,estimated_uncompressed_cache_bytes=disk,working_cap_bytes=working_cap_bytes,memory_budget_bytes=memory_budget_bytes,hardware_available_physical_bytes=free,hardware_total_physical_bytes=total,hardware_reserve_bytes=reserve_bytes,effective_working_limit_bytes=limit,estimated_within_cap=fits,measured_peak=False,created_utc=datetime.now(timezone.utc).isoformat(),required_if_exceeded='Root engineers/chunks under independently validated equivalent methods; never truncate/exclude rows to fit a count.',bindings={str(path):merge_ref['sha256'],merge['output']['path']:merge['output']['sha256']})
    write(output,result);return dict(status=result['status'],path=str(Path(output).resolve()),sha256=ref(output)['sha256'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--merge-receipt',required=True);p.add_argument('--output',required=True);a=p.parse_args();print(json.dumps(estimate(ref(a.merge_receipt),a.output)))
if __name__=='__main__':
    try:main()
    except BaseException as error:print(json.dumps(dict(status='failed',fixed_error_code='RESOURCE_ESTIMATE_FAILURE',error_type=type(error).__name__)));sys.exit(1)
