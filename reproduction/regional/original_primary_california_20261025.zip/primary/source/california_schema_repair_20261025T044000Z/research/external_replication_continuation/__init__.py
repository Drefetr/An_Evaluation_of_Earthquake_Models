"""Append-only continuation engineering; no experiment executes on import."""
