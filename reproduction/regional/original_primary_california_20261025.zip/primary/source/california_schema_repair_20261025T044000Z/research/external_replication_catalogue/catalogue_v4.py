"""Local-only SCEDC successor custody; no network acquisition. Never print empirical records or exceptions.

All scientific choices come from the separately frozen v2 protocol. The local
admission receipt is an orchestration attestation, not a security boundary.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
from decimal import Decimal
from fractions import Fraction
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import uuid

COMMIT = "7105f6c1b861db46c3a8454984588f5b6a4a56e4"
PROTOCOL_SHA256 = "d059ee7a2cf67407394830d632e6eb58620f52f04a1bcab1bf2e7c667543ee31"
METADATA_SHA256 = "abced6b1b610eb9853db7d4281564c8e6413270e4728b009f6d2c125d107142c"
BOUNDARY_SHA256 = "1152773bc3fdefd457071a6ce34a4b376344795dfae2ef268b38e40327b46e3d"
TIME_SCHEMA_SHA256 = "868f9d27d4fa2bdc16758b750b04a199bbc74c04eb94fcf58acd19ccefdca6ee"
QUALITY_SCHEMA_SHA256 = "415cc953e92250b4f5091c6b4ea3dd1e0c681cc9a53ea5a93cd29fc81adf3d38"
ORIGINAL_FREEZE_SHA256 = "b4cb80dda5441b21b84b24582cb85b6c0cdcf9b28b973a482aff10a64b317939"
REPAIR_INPUT_AUTHORIZATION_SHA256 = "7caaf6c82746992fb0085af60c8527b6031b09c5b983effa25b794cf5c5cf950"
DEPENDENCY_FILENAMES = ("catalogue_v4.py", "parse_v3.py")
AUTHORIZED_RUN = Path('${PROJECT_ROOT}\\research_runs\\california_schema_repair_20261025T044000Z')
LATITUDE_FLOAT_EDGES = (32.0, 33.666666666666664, 35.333333333333336, 37.0)
LONGITUDE_FLOAT_EDGES = (-121.0, -118.66666666666667, -116.33333333333333, -114.0)
FILE_CAP = 16 * 1024 * 1024
TOTAL_CAP = 128 * 1024 * 1024
CHUNK = 65536
UTC = dt.timezone.utc
EPOCH = dt.datetime(1970, 1, 1, tzinfo=UTC)
FIELDS = ("date", "time", "eventtype", "gtype", "magnitude", "magtype",
          "latitude", "longitude", "depth", "quality", "eventid", "nph", "ngrams")
SAFE_PROTECTED = {"status", "input_sha256", "source_commit", "bytes"}
SAFE_TRAINING = SAFE_PROTECTED | {"file_count", "schema_validation_pass_boolean", "eligible_training_total",
    "eligible_training_count_by_three_zones", "diagnostic_18_stratum_count", "diagnostic_18_corrected_modal_value",
    "diagnostic_18_admit_boolean", "diagnostic_overflow_total", "documented_missing_magnitude_total", "training_admit_boolean"}


class CustodyError(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def utcnow():
    return dt.datetime.now(UTC).isoformat()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".part")
    try:
        with temporary.open("xb") as stream:
            stream.write(json_bytes(value))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def append_json(path, value):
    with Path(path).open("ab") as stream:
        stream.write(json_bytes(value))
        stream.flush()
        os.fsync(stream.fileno())


def safe_receipt(receipt, lane):
    """Reject unknown fields/types before any object reaches public stdout."""
    expected = SAFE_TRAINING if lane == "train" else SAFE_PROTECTED
    if not isinstance(receipt, dict) or set(receipt) != expected | {"raw_manifest_sha256"}:
        raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
    if receipt["status"] != "success" or receipt["source_commit"] != COMMIT:
        raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
    for key in ("input_sha256", "raw_manifest_sha256"):
        if not isinstance(receipt[key], str) or re.fullmatch(r"[0-9a-f]{64}", receipt[key]) is None:
            raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
    if type(receipt["bytes"]) is not int or not 0 <= receipt["bytes"] <= TOTAL_CAP:
        raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
    if lane == "train":
        for key in ("file_count", "eligible_training_total", "diagnostic_overflow_total", "documented_missing_magnitude_total"):
            if type(receipt[key]) is not int or receipt[key] < 0:
                raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
        for key in ("schema_validation_pass_boolean", "training_admit_boolean"):
            if type(receipt[key]) is not bool:
                raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
        for key, length in (("eligible_training_count_by_three_zones", 3), ("diagnostic_18_stratum_count", 18)):
            if not isinstance(receipt[key], list) or len(receipt[key]) != length or any(type(n) is not int or n < 0 for n in receipt[key]):
                raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
        values = receipt["diagnostic_18_corrected_modal_value"]
        if not isinstance(values, list) or len(values) != 18 or any(not isinstance(n, str) or re.fullmatch(r"[0-9]+\.[0-9]{2}", n) is None for n in values):
            raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
        flags = receipt["diagnostic_18_admit_boolean"]
        if not isinstance(flags, list) or len(flags) != 18 or any(type(n) is not bool for n in flags):
            raise CustodyError("RECEIPT_ALLOWLIST_VIOLATION")
    return {key: receipt[key] for key in expected}


def verify_blob(path, entry):
    """Validate complete raw bytes against independently pinned Git metadata."""
    size = Path(path).stat().st_size
    if size != entry["size"] or size > FILE_CAP:
        raise CustodyError("RAW_SIZE_MISMATCH")
    git = hashlib.sha1(("blob " + str(size) + "\0").encode("ascii"))
    sha = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b""):
            git.update(chunk)
            sha.update(chunk)
    if git.hexdigest() != entry["sha"]:
        raise CustodyError("RAW_GIT_HASH_MISMATCH")
    return {"path": entry["path"], "bytes": size, "git_blob_sha1": git.hexdigest(),
            "sha256": sha.hexdigest()}


def read_json(path):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        raise CustodyError("CONTROL_JSON_INVALID") from None


def require_successor_run(run):
    if Path(run).resolve() != AUTHORIZED_RUN.resolve():
        raise CustodyError("SUCCESSOR_RUN_REQUIRED")


def controls(run):
    run = Path(run).resolve()
    require_successor_run(run)
    protocol_path = run / "design/acquisition_protocol_v2.json"
    metadata_path = run / "design/catalogue_source_metadata.json"
    amendment_path = run / "design/quality_schema_amendment_v1.json"
    if digest(protocol_path) != PROTOCOL_SHA256 or digest(metadata_path) != METADATA_SHA256:
        raise CustodyError("FROZEN_INPUT_PIN_MISMATCH")
    if digest(amendment_path) != QUALITY_SCHEMA_SHA256:
        raise CustodyError("QUALITY_SCHEMA_PIN_MISMATCH")
    amendment = read_json(amendment_path)
    if (amendment.get("kind") != "user_authorized_lossless_quality_metadata_schema_amendment"
            or Path(amendment.get("run_directory", "")).resolve() != run
            or amendment.get("quality_grammar", {}).get("allowed_codepoint_inclusive") != [33, 126]
            or amendment.get("quality_grammar", {}).get("minimum_length") != 1):
        raise CustodyError("QUALITY_SCHEMA_POLICY_MISMATCH")
    authorization = amendment.get("authorization", {})
    if digest(run / "design/user_authorization.md") != authorization.get("sha256"):
        raise CustodyError("USER_AUTHORIZATION_PIN_MISMATCH")
    input_authorization_path = run / "design/repair_input_authorization_v1.json"
    if digest(input_authorization_path) != REPAIR_INPUT_AUTHORIZATION_SHA256:
        raise CustodyError("REPAIR_INPUT_AUTHORIZATION_PIN_MISMATCH")
    input_authorization = read_json(input_authorization_path)
    freeze_path = run / "design/acquisition_freeze_v1.json"
    if digest(freeze_path) != ORIGINAL_FREEZE_SHA256:
        raise CustodyError("ORIGINAL_FREEZE_PIN_MISMATCH")
    freeze = read_json(freeze_path)
    if freeze.get("status") != "frozen_acquisition_and_partition_rules":
        raise CustodyError("G1_FREEZE_MISSING")
    pins = freeze.get("pins", {})
    authorities = amendment.get("preserved_authorities", {})
    predecessor = Path(amendment.get("predecessor_run_directory", ""))
    if (type(pins) is not dict or pins != authorities.get("original_absolute_freeze_pin_map")
            or pins.get(str(predecessor / "design/acquisition_protocol_v2.json")) != PROTOCOL_SHA256):
        raise CustodyError("FREEZE_PROTOCOL_PIN_MISSING")
    # The immutable freeze retains its original absolute old-run keys. Verify
    # those document/review authorities as written; never pretend relocation.
    for name, expected in pins.items():
        if digest(name) != expected:
            raise CustodyError("FREEZE_DEPENDENCY_CHANGED")
    methods_expected = pins.get(str(predecessor / "design/methods_protocol_v1.json"))
    if methods_expected is None or digest(run / "design/methods_protocol_v1.json") != methods_expected:
        raise CustodyError("SUCCESSOR_METHODS_COPY_PIN_MISMATCH")
    if digest(run / "design/boundary_contract_v1.json") != BOUNDARY_SHA256:
        raise CustodyError("BOUNDARY_CONTRACT_PIN_MISMATCH")
    if digest(run / "design/time_schema_amendment_v1.json") != TIME_SCHEMA_SHA256:
        raise CustodyError("TIME_SCHEMA_PIN_MISMATCH")
    admission = read_json(run / "reviews/catalogue_adapter_admission_v4.json")
    if (admission.get("status") != "accepted" or not admission.get("independent_review")
            or admission.get("passed") is not True or admission.get("controls_passed") is not True):
        raise CustodyError("ADAPTER_ADMISSION_MISSING")
    for key, expected in (("protocol_sha256", PROTOCOL_SHA256), ("boundary_contract_sha256", BOUNDARY_SHA256),
                          ("time_schema_amendment_sha256", TIME_SCHEMA_SHA256),
                          ("quality_schema_amendment_sha256", QUALITY_SCHEMA_SHA256)):
        if admission.get(key) != expected:
            raise CustodyError("ADMISSION_SCHEMA_MISMATCH")
    source_pins = admission.get("source_files_sha256", {})
    if type(source_pins) is not dict or set(source_pins) != set(DEPENDENCY_FILENAMES):
        raise CustodyError("ADMISSION_SOURCE_SET_INVALID")
    for name, expected in source_pins.items():
        if digest(Path(__file__).parent / name) != expected:
            raise CustodyError("ADMISSION_SOURCE_CHANGED")
    control_ref = admission.get("fixture_control_receipt", {})
    control_path = Path(control_ref.get("path", ""))
    if not control_path.is_absolute():
        control_path = run / control_path
    if not control_path.resolve().is_relative_to(run) or not control_path.is_file() or digest(control_path) != control_ref.get("sha256"):
        raise CustodyError("ADMISSION_FIXTURE_RECEIPT_PIN_MISMATCH")
    cache_path = run / "inputs/cached_raw_custody_v1.json"
    cache_sha = digest(cache_path)
    cache_ref = input_authorization.get("cached_raw_custody", {})
    if (cache_sha != admission.get("cached_raw_custody_sha256") or cache_ref.get("sha256") != cache_sha
            or Path(cache_ref.get("path", "")).resolve() != cache_path.resolve()):
        raise CustodyError("CACHED_RAW_CUSTODY_PIN_MISMATCH")
    cache = read_json(cache_path)
    if (cache.get("status") != "copied_exact_original_official_snapshot"
            or type(cache.get("network_requests")) is not int or cache["network_requests"] != 0
            or type(cache.get("raw_files")) is not int or cache["raw_files"] != 45
            or type(cache.get("files")) is not list or len(cache["files"]) != 45):
        raise CustodyError("CACHED_RAW_CUSTODY_INVALID")
    metadata = read_json(metadata_path)
    entries = metadata.get("selected_blobs", [])
    expected_paths = {f"SCEC_DC/{year}.catalog" for year in range(1981, 2026)}
    if (metadata.get("sha") != COMMIT or metadata.get("tree_truncated") is not False
            or len(entries) != 45 or {x.get("path") for x in entries} != expected_paths):
        raise CustodyError("SOURCE_INVENTORY_INVALID")
    if any(x["size"] > FILE_CAP for x in entries) or sum(x["size"] for x in entries) > TOTAL_CAP:
        raise CustodyError("SOURCE_INVENTORY_CAP")
    return entries



def load_parser():
    try:
        spec = importlib.util.spec_from_file_location("scedc_private_parser_v3", Path(__file__).with_name("parse_v3.py"))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    except Exception:
        raise CustodyError("PARSER_IMPORT_FAILED") from None




def source_time(date, clock):
    try:
        value = dt.datetime.strptime(date + " " + clock, "%Y/%m/%d %H:%M:%S.%f" if "." in clock else "%Y/%m/%d %H:%M:%S").replace(tzinfo=UTC)
        delta = value - EPOCH
        micros = (delta.days * 86400 + delta.seconds) * 1000000 + delta.microseconds
        return value, micros, date.replace("/", "-") + "T" + clock + "Z"
    except Exception:
        raise CustodyError("INVALID_SOURCE_TIMESTAMP") from None


def in_population(tokens):
    if tokens[2] != "eq":
        return "excluded_type"
    latitude, longitude, depth = (Decimal(tokens[i]) for i in (6, 7, 8))
    if not (Decimal(32) <= latitude <= Decimal(37) and Decimal(-121) <= longitude <= Decimal(-114)):
        return "excluded_geography"
    if not Decimal(-5) <= depth <= Decimal(40):
        return "excluded_depth"
    if tokens[5] == "n":
        return "excluded_magnitude_missing"
    return "eligible_geometry"


def exact_axis_index(token, minimum, maximum):
    """Exact source-decimal/rational comparison, independent of Decimal context."""
    value = Fraction(Decimal(token))
    if value < minimum or value > maximum:
        return -1
    scaled = (value - minimum) * 3
    width = maximum - minimum
    return 0 if scaled < width else 1 if scaled < 2 * width else 2


def float_axis_index(token, edges):
    value = float(Decimal(token))
    if value < edges[0] or value > edges[-1]:
        return -1
    return 0 if value < edges[1] else 1 if value < edges[2] else 2


def validate_boundary_assignment(latitude, longitude):
    source = (exact_axis_index(latitude, 32, 37), exact_axis_index(longitude, -121, -114))
    converted = (float_axis_index(latitude, LATITUDE_FLOAT_EDGES),
                 float_axis_index(longitude, LONGITUDE_FLOAT_EDGES))
    if source != converted:
        raise CustodyError("SOURCE_BOUNDARY_ASSIGNMENT_MISMATCH")
    return source


def zone_index(latitude):
    return exact_axis_index(latitude, 32, 37)


def canonical(tokens, year, lineno, micros, iso):
    return {"event_id": "scedc:" + tokens[10], "origin_time_utc": iso, "origin_time_us": micros,
            "latitude": float(Decimal(tokens[6])), "longitude": float(Decimal(tokens[7])),
            "depth_km": float(Decimal(tokens[8])), "magnitude": float(Decimal(tokens[4])),
            "magnitude_type": tokens[5], "event_type": tokens[2], "source_year": year,
            "source_line_1based": lineno, "source_tokens": dict(zip(FIELDS, tokens)),
            "review_status": None, "uncertainty": None, "location_quality": tokens[9], "geographic_type": tokens[3]}


def diagnostic_record(tokens, year, lineno, record):
    """Date-only diagnostic representation; unavailable clocks remain null."""
    result = canonical(tokens, year, lineno, record["timestamp_us"], record["origin_time_utc"])
    result.update(source_date=record["source_date"], clock_validation_status=record["clock_validation_status"])
    return result


def parse_lane(raw, entries, parser, lane, private, opposite_index=None):
    seen = {}
    duplicates = []
    events, diagnostic = [], []
    raw_counts = {}
    precision = {k: {} for k in ("time", "latitude", "longitude", "depth", "magnitude")}
    counts = [[0] * 3 for _ in range(6)]
    hist = [[[0] * 65 for _ in range(3)] for _ in range(6)]
    missing = overflow = 0
    clock_counts = {}
    diagnostic_clock_unavailable = 0
    for entry in entries:
        year = int(Path(entry["path"]).stem)
        with (raw / Path(entry["path"]).name).open("r", encoding="ascii", errors="strict") as stream:
            for lineno, line in enumerate(stream, 1):
                try:
                    record = parser.parse_structural_line(line)
                    if record is None:
                        continue
                    tokens = line.split()
                    if len(tokens) != 13:
                        raise CustodyError("SOURCE_TOKEN_COUNT")
                    if tokens[2] not in {"eq", "qb", "nt", "ex", "sh", "sn", "st", "th", "uk"} or tokens[3] not in {"l", "r", "t"}:
                        raise CustodyError("UNKNOWN_SOURCE_TYPE_CODE")
                    if record.get("original_tokens") != tokens:
                        raise CustodyError("PARSER_CANONICAL_DISAGREEMENT")
                    if record["clock_validation_status"] == "valid":
                        stamp, micros, iso = source_time(tokens[0], tokens[1])
                        if record.get("timestamp_us") != micros or record.get("origin_time_utc") != iso:
                            raise CustodyError("PARSER_CANONICAL_DISAGREEMENT")
                    elif record["clock_validation_status"] == "unsupported_second_60":
                        micros = iso = None
                        if record["timestamp_us"] is not None or record["origin_time_utc"] is not None:
                            raise CustodyError("PARSER_CANONICAL_DISAGREEMENT")
                    else:
                        raise CustodyError("PARSER_CLOCK_STATUS_INVALID")
                    validate_boundary_assignment(tokens[6], tokens[7])
                    if record["source_year"] != year:
                        raise CustodyError("ANNUAL_YEAR_MISMATCH")
                    rowhash = hashlib.sha256(json_bytes(tokens)).digest()
                    previous = seen.get(tokens[10])
                    if previous:
                        if previous[0] != rowhash:
                            raise CustodyError("CONFLICTING_DUPLICATE_ID")
                        duplicates.append({"source_year": year, "source_line_1based": lineno,
                                           "original_year": previous[1], "original_line_1based": previous[2]})
                        continue
                    seen[tokens[10]] = (rowhash, year, lineno)
                    status = record["clock_validation_status"]
                    clock_counts[status] = clock_counts.get(status, 0) + 1
                    if status != "valid":
                        append_json(private / "private_clock_unavailable.jsonl", {
                            "source_year": year, "source_line_1based": lineno,
                            "clock_validation_status": status})
                    for name, index in (("time", 1), ("latitude", 6), ("longitude", 7), ("depth", 8), ("magnitude", 4)):
                        digits = str(len(tokens[index].split(".", 1)[1])) if "." in tokens[index] else "0"
                        precision[name][digits] = precision[name].get(digits, 0) + 1
                    reason = in_population(tokens)
                    raw_counts[reason] = raw_counts.get(reason, 0) + 1
                    if reason == "excluded_magnitude_missing":
                        missing += 1
                    if reason != "eligible_geometry":
                        continue
                    magnitude = Decimal(tokens[4])
                    if magnitude >= 2:
                        diagnostic.append(diagnostic_record(tokens, year, lineno, record))
                        diagnostic_clock_unavailable += status != "valid"
                        if lane == "train":
                            period, zone = (year - 1981) // 5, zone_index(tokens[6])
                            counts[period][zone] += 1
                            if magnitude > Decimal("8.5"):
                                overflow += 1
                            else:
                                index = min(int((magnitude - Decimal(2)) * 10), 64)
                                hist[period][zone][index] += 1
                    if magnitude >= 4:
                        if status != "valid":
                            raise CustodyError("MODEL_CLOCK_UNAVAILABLE")
                        events.append(canonical(tokens, year, lineno, micros, iso))
                except Exception as error:
                    append_json(private / "schema_failures.jsonl", {"utc": utcnow(), "source_year": year,
                                "source_line_1based": lineno, "error_class": type(error).__name__,
                                "error_code": error.code if isinstance(error, CustodyError) else "SOURCE_SCHEMA_FAILURE"})
                    code = error.code if isinstance(error, CustodyError) and error.code in {"SOURCE_BOUNDARY_ASSIGNMENT_MISMATCH", "MODEL_CLOCK_UNAVAILABLE"} else "SOURCE_SCHEMA_FAILURE"
                    raise CustodyError(code) from None
    if opposite_index is not None:
        other = read_json(opposite_index)
        if not isinstance(other, dict) or not isinstance(other.get("ids"), dict):
            raise CustodyError("CROSS_LANE_ID_INDEX_INVALID")
        if seen.keys() & other["ids"].keys():
            # Time lanes are disjoint: a repeated source ID cannot be the same
            # canonical event and must be resolved privately, never fuzzy-merged.
            raise CustodyError("CROSS_LANE_ID_CONFLICT")
    atomic_json(private / "raw_id_index.json", {"source_snapshot": COMMIT,
                "ids": {key: value[0].hex() for key, value in seen.items()}})
    events.sort(key=lambda r: (r["origin_time_us"], r["event_id"]))
    diagnostic.sort(key=lambda r: (r["source_date"], r["event_id"]))
    local_audit = {"raw_reason_counts": raw_counts, "duplicate_crosswalk": duplicates,
                   "serialized_precision_counts": precision, "unique_raw_ids": len(seen),
                   "model_event_count": len(events), "diagnostic_event_count": len(diagnostic),
                   "raw_clock_status_counts": clock_counts,
                   "diagnostic_clock_unavailable_count": diagnostic_clock_unavailable}
    atomic_json(private / "private_parse_audit.json", local_audit)
    if lane == "protected":
        return events, diagnostic, None
    corrected, admit = [], []
    for period in range(6):
        for zone in range(3):
            bins = hist[period][zone]
            mode = max(i for i, n in enumerate(bins) if n == max(bins))
            value = Decimal("2.0") + Decimal(mode) / 10 + Decimal("0.05") + Decimal("0.5")
            corrected.append(str(value))
            admit.append(counts[period][zone] >= 100 and value <= 4 and not overflow)
    scored = [r for r in events if r["source_year"] >= 1986]
    zone_counts = [sum(zone_index(r["source_tokens"]["latitude"]) == zone for r in scored) for zone in range(3)]
    summary = {"eligible_training_total": len(scored), "eligible_training_count_by_three_zones": zone_counts,
               "diagnostic_18_stratum_count": [n for period in counts for n in period],
               "diagnostic_18_corrected_modal_value": corrected, "diagnostic_18_admit_boolean": admit,
               "diagnostic_overflow_total": overflow, "documented_missing_magnitude_total": missing,
               "training_admit_boolean": all(admit) and len(scored) >= 180 and min(zone_counts) >= 30}
    atomic_json(private / "training_admission.json", summary)
    return events, diagnostic, summary


def acquire(run, lane, local_only=True):
    require_successor_run(run)
    if local_only is not True:
        raise CustodyError("LOCAL_CACHED_ONLY")
    if lane not in {"train", "protected"}:
        raise CustodyError("INVALID_LANE")
    entries = controls(run)
    entries = [e for e in entries if (int(Path(e["path"]).stem) < 2011) == (lane == "train")]
    private = run / ("inputs/california/train" if lane == "train" else "protected/california")
    if any((private / name).exists() for name in ("raw_manifest.json", "canonical_model.json", "canonical_diagnostic.json", "custody_receipt.json")):
        raise CustodyError("SUCCESSOR_OUTPUT_ALREADY_EXISTS")
    raw = private / "raw"
    if not raw.is_dir():
        raise CustodyError("CACHED_RAW_DIRECTORY_MISSING")
    lock = private / ".acquire.lock"
    try:
        fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError:
        raise CustodyError("LANE_LOCK_HELD") from None
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(json_bytes({"pid": os.getpid(), "created_utc": utcnow(), "lane": lane}))
        parser = load_parser()
        opposite_index = run / ("protected/california/raw_id_index.json" if lane == "train"
                                else "inputs/california/train/raw_id_index.json")
        if lane == "protected" and not opposite_index.exists():
            raise CustodyError("TRAINING_CUSTODY_MISSING")
        raw_receipts = []
        for entry in entries:
            raw_receipts.append(verify_blob(raw / Path(entry["path"]).name, entry))
        manifest = {"schema_version": 4, "source_snapshot": COMMIT, "protocol_sha256": PROTOCOL_SHA256,
                    "boundary_contract_sha256": BOUNDARY_SHA256,
                    "time_schema_amendment_sha256": TIME_SCHEMA_SHA256,
                    "quality_schema_amendment_sha256": QUALITY_SCHEMA_SHA256,
                    "source_metadata_sha256": METADATA_SHA256, "files": raw_receipts}
        manifest_path = private / "raw_manifest.json"
        atomic_json(manifest_path, manifest)
        retrieval_path = private / "retrieval_receipt.json"
        if not retrieval_path.exists():
            atomic_json(retrieval_path, {"retrieved_utc": utcnow()})
        retrieved = read_json(retrieval_path)["retrieved_utc"]
        provenance = {"source_snapshot": COMMIT, "raw_manifest_sha256": digest(manifest_path), "retrieved_utc": retrieved,
                      "time_schema_amendment_sha256": TIME_SCHEMA_SHA256,
                      "quality_schema_amendment_sha256": QUALITY_SCHEMA_SHA256}
        events, diagnostic, summary = parse_lane(raw, entries, parser, lane, private,
                                                opposite_index if opposite_index.exists() else None)
        canonical_path = private / "canonical_model.json"
        atomic_json(canonical_path, {"schema_version": 1, "catalogue_id": "SCEDC-routine-revised-" + lane,
                                    "provenance": provenance, "events": events})
        atomic_json(private / "canonical_diagnostic.json", {"schema_version": 2,
                    "representation": "source_calendar_date_diagnostic",
                    "catalogue_id": "SCEDC-date-diagnostic-M2-" + lane, "provenance": provenance, "events": diagnostic})
        atomic_json(private / "private_diagnostic_receipt.json", {
                    "input_sha256": digest(private / "canonical_diagnostic.json"),
                    "time_schema_amendment_sha256": TIME_SCHEMA_SHA256,
                    "quality_schema_amendment_sha256": QUALITY_SCHEMA_SHA256,
                    "representation": "source_calendar_date_diagnostic"})
        receipt = {"status": "success", "input_sha256": digest(canonical_path),
                   "raw_manifest_sha256": provenance["raw_manifest_sha256"],
                   "source_commit": COMMIT, "bytes": sum(e["bytes"] for e in raw_receipts)}
        if lane == "train":
            receipt.update(summary)
            receipt.update(file_count=len(raw_receipts), schema_validation_pass_boolean=True)
        atomic_json(private / "custody_receipt.json", receipt)
        return receipt
    finally:
        lock.unlink()


def main(argv=None):
    command = argparse.ArgumentParser(description="Private local SCEDC catalogue custody; no empirical rows on stdout")
    command.add_argument("action", choices=("validate-local-train", "validate-local-protected"))
    command.add_argument("--run", type=Path, required=True)
    args = command.parse_args(argv)
    lane = "protected" if args.action.endswith("protected") else "train"
    try:
        run = args.run.resolve()
        require_successor_run(run)
        private = run / ("inputs/california/train" if lane == "train" else "protected/california")
        private.mkdir(parents=True, exist_ok=True)
        # Capture even an unexpected imported-library print locally. The only
        # public tool output is the allowlisted receipt after this scope.
        with (private / "private_runtime_output.log").open("a", encoding="utf-8") as sink:
            with contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
                receipt = acquire(run, lane, local_only=True)
        print(json.dumps(safe_receipt(receipt, lane), sort_keys=True, allow_nan=False))
        return 0
    except BaseException as error:
        code = error.code if isinstance(error, CustodyError) else "INTERRUPTED" if isinstance(error, KeyboardInterrupt) else "UNEXPECTED_LOCAL_FAILURE"
        # Never stringify an unexpected exception: it may contain a data row.
        print(json.dumps({"status": "failed", "error_code": code}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
