"""Leased raw/canonical preflight; public output obeys lane release policy."""
import argparse,json,hashlib
from pathlib import Path
from . import empirical_io_v1 as I


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--mode',choices=['train','protected','merged'],required=True);p.add_argument('--protocol');p.add_argument('--output',required=True);a=p.parse_args();run=Path(a.run)
    try:
        if a.mode=='merged':
            I.require(a.protocol is not None,'MERGED_RELEASE_PROTOCOL_REQUIRED');protocol=I.read(a.protocol)
            I.require(protocol.get('status')=='frozen' and protocol.get('science_gate_passed') is True and protocol.get('protected_release_authorized') is True,'PROTECTED_RELEASE_REQUIRED')
            for name,digest in protocol['artifact_pins'].items():I.require(I.sha(name)==digest,'FROZEN_DEPENDENCY_CHANGED')
        train=I.load_ca_lane(run,'train') if a.mode in ['train','merged'] else None
        protected=I.load_ca_lane(run,'protected') if a.mode in ['protected','merged'] else None
        lane=train or protected
        result=dict(passed=True,mode=a.mode,schema_reconstruction_passed=True,input_sha256=lane['canonical_sha256'],diagnostic_sha256=lane['diagnostic_sha256'],raw_manifest_sha256=lane['raw_manifest_sha256'],source_commit=I.COMMIT,bytes=lane['raw_bytes'],file_count=lane['file_count'])
        if a.mode in ['train','merged']:
            source=I.merge_ca(train,protected) if a.mode=='merged' else train
            admissions=[I.ca_training_admission(source['raw'],source['diagnostic'],cutoff) for cutoff in ([2011,2016,2021] if a.mode=='merged' else [2011])]
            result.update(training_admissions=admissions,training_admission_passed=all(r['admitted'] for r in admissions),passed=all(r['admitted'] for r in admissions))
            if a.mode=='merged':result.update(protected_input_sha256=protected['canonical_sha256'],protected_diagnostic_sha256=protected['diagnostic_sha256'],unique_model_events=len(source['raw']['times']))
        # Protected-only mode deliberately emits no event, diagnostic, stratum,
        # duplicate or clock-status counts, even in the saved scalar report.
    except Exception as error:
        result=dict(passed=False,mode=a.mode,fixed_error_code='EMPIRICAL_PREFLIGHT_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
