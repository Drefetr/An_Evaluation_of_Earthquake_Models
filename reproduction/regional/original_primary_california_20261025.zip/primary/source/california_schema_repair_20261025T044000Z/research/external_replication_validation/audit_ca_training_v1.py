"""Complete independent California training lineage, nuisance and cache audit.
Authoring uses code/schema only. All raw rows stay local. Root leases execution.
"""
import hashlib,json,math
from pathlib import Path
import numpy as np
from . import empirical_io_v1 as I,empirical_oracle_v2 as E,empirical_cache_v1 as C
from . import oracle as O,nuisance_oracle as N
from .raw_input import fit_beta
from .audit_nz_initialization_v3 import MODELS,SCALES,close,same


def audit_training(case_path,protocol_path,methods_path,raw,catalogue_sha256,expected_case):
    protocol=I.read(protocol_path);protocol_sha256=I.sha(protocol_path);methods=I.read(methods_path);case=I.read(case_path)
    I.require(protocol['status']=='frozen' and protocol['science_gate_passed'] is True,'INITIALIZATION_PROTOCOL_ADMISSION')
    for name,digest in protocol['artifact_pins'].items():I.require(I.sha(name)==digest,'FROZEN_DEPENDENCY_CHANGED')
    I.require(protocol['data']['sha256']==catalogue_sha256 and not protocol['data'].get('legacy_csv',False),'VERIFIED_CA_INPUT_ONLY')
    for key in ['models','parameter_bounds','parameter_order','fit_policy','primary_selection','background','kernel_contract']:I.require(protocol[key]==methods[key],'FROZEN_REGISTERED_MATHEMATICAL_PROCEDURE')
    I.require(protocol['models']==MODELS and protocol['primary_selection']['sigma_km']==SCALES and protocol['background']['bandwidth_km']==SCALES and protocol['common_nuisance']['excess_cut']==.5 and protocol['common_nuisance']['productivity']['r']==.7,'FROZEN_ROSTER_AND_MARK_RECIPE')
    core_names=['__init__.py','objective.cpp','objective.dll','compiled_objective.py','geometry.py','fitting.py','catalogue.py','workflow.py','prospective.py','synthetic.py','build_objective.cmd']
    core_pins={name:digest for name,digest in protocol['artifact_pins'].items() if Path(name).name in core_names and Path(name).parent.name=='external_replication'}
    I.require(len(core_pins)==11 and {Path(k).name for k in core_pins}==set(core_names),'EXACT_CORE_SOURCE_PIN_ROSTER')
    t=raw['times'];q=raw['excess'];cells=raw['cells'];train_start=expected_case['train_start'];train_end=expected_case['train_end'];T0=expected_case['T0'];case_id=expected_case['case_id'];tr=(t>=train_start)&(t<train_end);ntr=int(tr.sum());pi=O.reference_mass(cells,tr);beta=fit_beta(q[tr]);kde=N.select_bandwidth(raw['xy'][tr],raw['rectangles'])
    I.require(case['case']==expected_case and case['profile']=='california' and case['n_train']==ntr and case['catalogue_sha256']==catalogue_sha256 and case['protocol_sha256']==protocol_sha256 and case['status']=='complete','INITIALIZATION_CASE_BINDING')
    I.require(np.all(np.bincount(cells[tr]//3,minlength=3)>=30) and abs(case['beta']-beta)<=1e-10,'RAW_TRAINING_NUISANCE_ELIGIBILITY');close(case['reference_pi'],pi,1e-12,'RAW_HIERARCHICAL_REFERENCE');I.require(case['kde_selection']['selected_bandwidth']==kde['selected_bandwidth'],'RAW_LOO_H_SELECTION')
    close(case['training_cell_counts'],np.bincount(cells[tr],minlength=9),0.,'TRAINING_COUNTS');I.require(ntr>=180,'TRAINING_COUNT_MINIMUM')
    paths=case['procedures'];I.require(len(paths)==10 and all(Path(p).resolve().parent==Path(case_path).resolve().parent for p in paths),'TEN_PROCEDURE_BINDINGS')
    expected_ids=[case_id+'__selector_fixedML_smooth_cont_sigma'+str(int(s)) for s in SCALES]+[case_id+'__main_'+m for m in ['fixedML_smooth_lift','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']]
    fits=[I.read(p) for p in paths];I.require([f['procedure_id'] for f in fits]==expected_ids,'EXACT_TEN_PROCEDURE_ORDER');byid={f['procedure_id']:f for f in fits};models={};records=[];starts=floors=returns=candidates=0;allcache=set();lineage=[];a0=float(np.clip(np.log(.6*ntr/(train_end-train_start)),-11.5,-.1));ap=float(np.clip(np.log(ntr/(train_end-train_start)),-12,0));fp=protocol['fit_policy']
    def add(f,pars,value):records.append(dict(start=train_start,end=train_end,train_start=train_start,train_end=train_end,T0=T0,beta=beta,sigma=f['sigma'],bandwidth=kde['selected_bandwidth'],spatial=f['spatial'],model=f['model'],pars=pars,history_policy='continuous',production=value,require_gradient=True))
    cache_contracts={}
    bounds=protocol['parameter_bounds'];pb={k:list(bounds[k]) for k in ['a','d','n']}
    expected_bounds={'fixedML':[pb[k] for k in ['a','d','n']],'commonML':[pb[k] for k in ['a','d','n']]+[[float(np.log(v)) for v in bounds['tau_days']]],'Omori':[pb[k] for k in ['a','d','n']]+[[float(np.log(v)) for v in bounds['c_days']],list(bounds['p'])]}
    def feasible(pars,temporal):
        b=expected_bounds[temporal];return isinstance(pars,list) and len(pars)==len(b) and all(isinstance(v,(int,float)) and math.isfinite(v) and lo<=v<=hi for v,(lo,hi) in zip(pars,b))
    for ordinal,(path,f) in enumerate(zip(paths,fits)):
        temporal='fixedML' if ordinal<7 else 'commonML' if ordinal==7 else 'Omori';spatial='cont' if ordinal<6 or ordinal in [7,8] else 'lift';sigma=SCALES[ordinal] if ordinal<6 else case['selected_sigma']
        I.require(f['temporal']==temporal and f['model']=={'fixedML':'E_fixed','commonML':'E_free','Omori':'E_omori'}[temporal] and f['spatial']==spatial and f['sigma']==sigma and f['background']=='smooth' and f['role']==('primary_selector' if ordinal<6 else 'primary_main') and f['bounds']==expected_bounds[temporal],'EXACT_MODEL_BOUNDS_ROSTER')
        I.require(set(f['cache_paths'])=={'train16','train32'},'EXACT_TRAIN_CACHE_KEYS')
        for label,cachepath in f['cache_paths'].items():
            key=f'{spatial}_smooth_sigma{sigma:g}';order=int(label[5:]);cachepath=str(Path(cachepath).resolve())
            I.require(Path(cachepath).name==f'cache_{key}_{label}.npz' and Path(cachepath).parent==Path(path).resolve().parent,'CACHE_PATH_ORDER_BINDING')
            contract=dict(catalogue_sha256=catalogue_sha256,protocol_sha256=protocol_sha256,case_id=case_id,training_start=train_start,training_end=train_end,reference_pi=case['reference_pi'],pi=case['reference_pi'],profile='california',start=train_start,end=train_end,T0=T0,order=order,sigma=sigma,family='continuous' if spatial=='cont' else 'center',cache_key=key,nuisance_policy='training_only',production_source_pins=core_pins)
            I.require(cachepath not in cache_contracts or cache_contracts[cachepath]==contract,'SHARED_CACHE_BINDING');cache_contracts[cachepath]=contract
        registry=I.read(Path(path).with_name('registry_'+f['procedure_id']+'.json'));I.require(registry['sha256']==I.sha(path) and registry['procedure_id']==f['procedure_id'],'FIT_REGISTRY')
        I.require(registry['path']==str(Path(path).resolve()) and registry['model']==f['model'] and registry['cache_paths']==f['cache_paths'],'REGISTRY_FULL_BINDINGS')
        I.require(f['complete'] is True and f['case_id']==case_id,'COMPLETE_FIT');allcache.update(str(Path(p).resolve()) for p in f['cache_paths'].values())
        ss=[s for s in f['slots'] if s['kind']=='start'];ff=[s for s in f['slots'] if s['kind']=='floor'];cc=f['accepted_candidates'];I.require(len(ss)==8 and [s['slot'] for s in ss]==list(range(8)) and len(ff)==(2 if f['temporal']=='commonML' else 1),'START_AND_FLOOR_DENOMINATOR');I.require(len(cc)==8+len(ff) and [c['candidate_id'] for c in cc]==list(range(len(cc))),'CANDIDATE_DENOMINATOR')
        I.require(sum(c['origin']=='solver' for c in cc)==8,'EXACT_ACCEPTED_SOLVER_DENOMINATOR')
        selected=min(cc,key=lambda c:(c['evaluation']['joint_nll'],c['candidate_id']));I.require(f['selected']==selected,'MINIMUM_TRAINING_SELECTION')
        for c in cc:I.require(feasible(c['pars'],temporal),'CANDIDATE_PARAMETER_BOUNDS');I.require(c['quadrature_error']<=1e-4 and abs(c['quadrature_error']-abs(c['evaluation']['joint_nll']-c['fine_evaluation']['joint_nll']))<=1e-12,'CANDIDATE_QUADRATURE');I.require(c['origin'] in ['solver','poisson_floor','fixedML_tau1_floor'],'NO_UNPLANNED_CANDIDATE');add(f,c['pars'],c['evaluation']);add(f,c['pars'],c['fine_evaluation'])
        for slot in ss:
            I.require(feasible(slot['requested_start'],temporal) and same(slot['start'],slot['requested_start']),'START_PARAMETER_BOUNDS')
            I.require(slot['status']=='complete' and len(slot['attempts']) in [1,2] and sum(bool(v['accepted']) for v in slot['attempts'])==1,'COMPLETE_START_LINEAGE')
            for tier,v in enumerate(slot['attempts']):
                I.require(v['tier']==tier and v['method']==('L-BFGS-B' if tier==0 else 'Powell') and same(v['start'],slot['requested_start']),'ORIGINAL_START_RECOVERY')
                if tier:I.require(slot['attempts'][0]['accepted'] is False,'FAILURE_ONLY_RECOVERY')
                expected_options={k:value for k,value in (fp['optimizer'] if tier==0 else fp['failure_only_recovery'][0]).items() if k not in ['method','same_original_start']}
                I.require(v['options']==expected_options,'EXACT_SOLVER_OPTIONS')
                if 'initial_nll' in v:
                    I.require(math.isfinite(v['initial_nll']),'FINITE_INITIAL_NLL');add(f,slot['requested_start'],dict(joint_nll=v['initial_nll']));records[-1]['scalar_initial_nll']=True
                if 'pars' in v:I.require(v.get('finite_feasible') is feasible(v['pars'],temporal),'SOLVER_FINITE_FEASIBLE_FLAG')
                if v['accepted']:
                    I.require(v.get('success') is True and v.get('finite_feasible') is True and math.isfinite(v['reported_nll']) and abs(v['reported_nll']-v['evaluation']['joint_nll'])<=1e-7 and v['evaluation']['joint_nll']<=v['initial_nll']+1e-8 and abs(v['evaluation']['joint_nll']-v['fine_evaluation']['joint_nll'])<=1e-4,'ACCEPTED_SOLVER_CONDITIONS')
                    matched=[c for c in cc if c.get('slot')==slot['slot'] and c.get('tier')==tier and c['origin']=='solver']
                    I.require(len(matched)==1 and matched[0]['pars']==v['pars'] and matched[0]['evaluation']==v['evaluation'] and matched[0]['fine_evaluation']==v['fine_evaluation'],'ACCEPTED_SLOT_CANDIDATE_LINEAGE')
                if v.get('finite_feasible'):add(f,v['pars'],v['evaluation']);add(f,v['pars'],v['fine_evaluation']);returns+=1
        for floor in ff:I.require(floor['status']=='complete' and any(c['candidate_id']==floor['candidate_id'] and same(c['pars'],floor['pars']) and c['origin']==floor['origin'] for c in cc),'EXACT_FLOOR_LINEAGE')
        poisson=next(s for s in ff if s['origin']=='poisson_floor');expected=[ap,0.,0.]+([0.] if f['temporal']=='commonML' else [0.,1.3] if f['temporal']=='Omori' else []);close(poisson['pars'],expected,1e-12,'EXACT_POISSON_POINT')
        if f['temporal']=='fixedML':expected=[[a0+s['a_offset'],s['d'],s['n']] for s in fp['fixedML_starts']]
        else:
            point=models['fixedML_smooth_'+f['spatial']]['selected']['pars'];expected=[point+[math.log(x)] for x in fp['commonML_tau_starts_days']] if f['temporal']=='commonML' else [point+[math.log(c),p] for c,p in fp['Omori_cp_starts']]
            if f['temporal']=='commonML':nested=next(s for s in ff if s['origin']=='fixedML_tau1_floor');close(nested['pars'],point+[0.],1e-12,'EXACT_FIXEDML_NESTING')
        for slot,point in zip(ss,expected):close(slot['requested_start'],point,1e-12,'PRESCRIBED_START')
        if f['role']=='primary_main':models[f['temporal']+'_smooth_'+f['spatial']]=f
        starts+=8;floors+=len(ff);candidates+=len(cc);lineage.append(dict(procedure_id=f['procedure_id'],candidates=len(cc),selected_candidate_id=selected['candidate_id'],near_optimal_candidates=[c['candidate_id'] for c in cc if c['evaluation']['joint_nll']<=selected['evaluation']['joint_nll']+4e-4]))
        # All selectors complete before the first main; expose only the one
        # training-selected alias for matched temporal start construction.
        if f is fits[5]:
            ordinal,winning=min(enumerate(fits[:6]),key=lambda pair:(pair[1]['selected']['evaluation']['joint_nll'],pair[0],pair[1]['selected']['candidate_id']));models['fixedML_smooth_cont']=winning
            I.require(case['selected_sigma']==SCALES[ordinal],'SHARED_SIGMA_SELECTION');alias=I.read(Path(path).with_name('alias_fixedML_smooth_cont.json'));I.require(alias==case['model_aliases']['fixedML_smooth_cont'] and alias['source_procedure_id']==winning['procedure_id'] and alias['source_sha256']==I.sha(paths[ordinal]) and alias['source_candidate_id']==winning['selected']['candidate_id'] and alias['no_additional_fit'] is True,'FIXEDML_MAIN_ALIAS')
    I.require(starts==80 and floors==11 and candidates==91 and set(models)==set(MODELS),'FULL_INITIALIZATION_DENOMINATORS')
    for mid,f in models.items():I.require(case['models'][mid]['procedure_id']==f['procedure_id'] and case['models'][mid]['selected']==f['selected'] and case['models'][mid]['cache_paths']==f['cache_paths'] and f['sigma']==case['selected_sigma'],'MATCHED_MODEL_BINDINGS')
    I.require(set(case['cache_paths'])=={Path(k).name.rsplit('_train',1)[0][6:] for k in allcache} and {str(Path(v).resolve()) for paths in case['cache_paths'].values() for v in paths.values()}==allcache,'CASE_ALL_CACHE_BINDINGS')
    I.require(len(allcache)==14,'FULL_NUISANCE_CACHE_DENOMINATOR')
    cache_reports=[];geometry_cache={}
    for path in sorted(allcache):cache_reports.append(C.cache_audit(path,raw,pi,case['beta'],kde['selected_bandwidth'],geometry_cache,cache_contracts[path]))
    bundle=dict(schema_version=1,data_classification='local_verified_empirical_rows',source_verification_passed=True,profile='california',production_source_pins=protocol['artifact_pins'],raw={k:raw[k] for k in ['times','excess','latitude','longitude']},records=records,nuisance_controls=[dict(train_start=train_start,train_end=train_end,production_kde_selection=case['kde_selection'])])
    numerical=E.audit(bundle)
    return dict(status='passed',passed=True,independent=True,case_id=case_id,scope='Full independently raw-reconstructed CA training audit; no production imports/DLL',denominators=dict(procedures=10,starts=80,floors=11),model_roster=MODELS,candidate_count=candidates,finite_solver_returns=returns,scored_training_events=ntr,lineage=lineage,cache_reports=cache_reports,numerical=numerical),dict(case=case,fits=fits,paths=paths,records=records,bundle=bundle,cache_contracts=cache_contracts,geometry_cache=geometry_cache,pi=pi,beta=beta,bandwidth=kde['selected_bandwidth'])
