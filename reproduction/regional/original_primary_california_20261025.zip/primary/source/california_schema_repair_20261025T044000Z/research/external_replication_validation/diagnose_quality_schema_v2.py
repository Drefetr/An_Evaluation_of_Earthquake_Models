"""Root-leased local IO diagnosis only. No acquisition, canonicalization or admission.

Original strict parser is loaded twice from identical pinned source bytes. One
private diagnostic instance changes ONLY QUALITIES membership to the USER-
authorized nonempty variable-width printable-ASCII token predicate. Actual quality tokens
are never substituted, reported, normalized, dropped or used for eligibility.
"""
from pathlib import Path
from decimal import Decimal
import argparse,contextlib,datetime,hashlib,importlib.util,json,os

class DiagnosticError(ValueError): pass

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_parser(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

class PrintableASCIIToken:
    def __contains__(self,value):
        return type(value) is str and len(value)>=1 and all(33<=ord(c)<=126 for c in value)

def classify(value):
    return dict(width_one=len(value)==1,printable_single_ASCII=len(value)==1 and value in PrintableASCIIToken(),printable_ASCII_token=value in PrintableASCIIToken(),
                ASCII_only=all(ord(c)<128 for c in value),
                has_C0_or_DEL=any(ord(c)<32 or ord(c)==127 for c in value))

def parse(module,line):
    try: return 'passed',module.parse_structural_line(line)
    except module.ParseError as error:
        code=str(error)
        if code not in module.FIXED_CODES:raise DiagnosticError('UNSAFE_PARSER_ERROR') from None
        return code,None

def self_controls(strict,opaque):
    tests=0
    def check(value):
        nonlocal tests
        if not value:raise DiagnosticError('SYN_CONTROL_FAILED')
        tests+=1
    tokens=['2000/01/02','03:04:05.000','eq','l','4.1','l','34.0','-118.0','10.0','A','SYN_QUALITY_ONLY','10','12']
    for quality in ['A','B','C','D','Z']:
        row=tokens.copy();row[9]=quality;a,b=parse(strict,' '.join(row));c,d=parse(opaque,' '.join(row));check(a==c=='passed' and b==d)
    for quality in ['E','?','0','~','AA','OPAQUE_QUALITY']:
        row=tokens.copy();row[9]=quality;a,_=parse(strict,' '.join(row));c,d=parse(opaque,' '.join(row));check(a=='unknown_quality' and c=='passed' and d['quality']==quality and d['original_tokens']==row)
    for quality in ['', 'A A','A\tB','\t','\x00','\x7f','\u0100']:
        check(quality not in PrintableASCIIToken())
    for index,value,code in [(4,'bad','invalid_numeric'),(6,'91','invalid_numeric'),(5,'?','unknown_magtype'),(11,'-1','invalid_count'),(0,'2000/02/30','invalid_date'),(1,'25:00:00','invalid_time'),(2,'??','invalid_eventtype'),(3,'?','invalid_record')]:
        row=tokens.copy();row[9]='?';row[index]=value;result,_=parse(opaque,' '.join(row));check(result==code)
    row=tokens.copy();row[9]='?';row[1]='03:04:60.0';code,record=parse(opaque,' '.join(row));check(code=='passed' and record['clock_validation_status']=='unsupported_second_60' and record['timestamp_us'] is None)
    check(parse(strict,'# synthetic comment')[1] is None and parse(opaque,'# synthetic comment')[1] is None)
    return tests

def diagnose(raw_dir,parser_path,expected_parser_sha256):
    if digest(parser_path)!=expected_parser_sha256:raise DiagnosticError('PARSER_SOURCE_PIN_MISMATCH')
    strict=load_parser(parser_path,'_quality_strict_diagnostic');opaque=load_parser(parser_path,'_quality_opaque_diagnostic')
    if strict.QUALITIES!=frozenset(['A','B','C','D','Z']) or opaque.QUALITIES!=strict.QUALITIES:raise DiagnosticError('UNEXPECTED_BASELINE_QUALITY_SCHEMA')
    opaque.QUALITIES=PrintableASCIIToken();syn=self_controls(strict,opaque)
    raw_dirs=[Path(p) for p in raw_dir];files=sorted((p for folder in raw_dirs for p in folder.glob('*.catalog')),key=lambda p:p.name)
    if {p.name for p in files}!={str(y)+'.catalog' for y in range(1981,2026)} or len(files)!=45:raise DiagnosticError('EXACT45_CACHED_RAW_FILES_REQUIRED')
    paths_by_name={p.name:p for p in files}
    if not files:raise DiagnosticError('NO_PINNED_RAW_FILES')
    strict_errors={};opaque_errors={};shape={k:0 for k in ['width_one','printable_single_ASCII','printable_ASCII_token','ASCII_only','has_C0_or_DEL']}
    counts=dict(raw_noncomment_rows=0,strict_passed=0,strict_unknown_quality=0,opaque_passed=0,unknown_quality_opaque_passed=0,unknown_quality_other_structural_failure=0,annual_year_mismatch=0,unknown_quality_geometry_type_depth_and_magnitude_label_eligible=0,unknown_quality_M4_non_time_candidate=0,unknown_quality_M2_non_time_candidate=0,unknown_quality_M4_clock_unavailable=0,unknown_quality_M2_clock_unavailable=0,known_quality_record_disagreement=0,read_encoding_failures=0,all_opaque_M4_non_time_candidates=0,all_opaque_M4_valid_clock_candidates=0,all_opaque_M2_non_time_candidates=0)
    inventory=[]
    for path in files:
        if not path.stem.isdigit() or len(path.stem)!=4:raise DiagnosticError('UNEXPECTED_RAW_FILENAME')
        year=int(path.stem);inventory.append(dict(name=path.name,sha256=digest(path),bytes=path.stat().st_size))
        try:
            with path.open(encoding='ascii',errors='strict') as stream:
                for line in stream:
                    if not line.strip() or line.lstrip().startswith('#'):continue
                    counts['raw_noncomment_rows']+=1
                    sc,sr=parse(strict,line);oc,record=parse(opaque,line)
                    if sc=='passed':counts['strict_passed']+=1
                    else:strict_errors[sc]=strict_errors.get(sc,0)+1
                    if oc=='passed':counts['opaque_passed']+=1
                    else:opaque_errors[oc]=opaque_errors.get(oc,0)+1
                    if sc=='passed' and (oc!='passed' or record!=sr):counts['known_quality_record_disagreement']+=1
                    if record is not None and record['source_year']!=year:counts['annual_year_mismatch']+=1
                    if record is not None:
                        whole=record['original_tokens'];in_geometry=(whole[2]=='eq' and Decimal(32)<=Decimal(whole[6])<=Decimal(37) and Decimal(-121)<=Decimal(whole[7])<=Decimal(-114) and Decimal(-5)<=Decimal(whole[8])<=Decimal(40) and whole[5]!='n')
                        counts['all_opaque_M4_non_time_candidates']+=int(in_geometry and Decimal(whole[4])>=4)
                        counts['all_opaque_M4_valid_clock_candidates']+=int(in_geometry and Decimal(whole[4])>=4 and record['clock_validation_status']=='valid')
                        counts['all_opaque_M2_non_time_candidates']+=int(in_geometry and Decimal(whole[4])>=2)
                    if sc!='unknown_quality':continue
                    counts['strict_unknown_quality']+=1
                    tokens=line.split()
                    if len(tokens)!=13:raise DiagnosticError('IMPOSSIBLE_STRICT_QUALITY_TOKEN_COUNT')
                    for key,value in classify(tokens[9]).items():shape[key]+=int(value)
                    if oc!='passed':counts['unknown_quality_other_structural_failure']+=1;continue
                    counts['unknown_quality_opaque_passed']+=1
                    eligible=(tokens[2]=='eq' and Decimal(32)<=Decimal(tokens[6])<=Decimal(37) and Decimal(-121)<=Decimal(tokens[7])<=Decimal(-114) and Decimal(-5)<=Decimal(tokens[8])<=Decimal(40) and tokens[5]!='n')
                    counts['unknown_quality_geometry_type_depth_and_magnitude_label_eligible']+=int(eligible)
                    for label,threshold in [('M4',Decimal(4)),('M2',Decimal(2))]:
                        candidate=eligible and Decimal(tokens[4])>=threshold
                        counts['unknown_quality_'+label+'_non_time_candidate']+=int(candidate)
                        counts['unknown_quality_'+label+'_clock_unavailable']+=int(candidate and record['clock_validation_status']!='valid')
        except UnicodeDecodeError:counts['read_encoding_failures']+=1
    if digest(parser_path)!=expected_parser_sha256:raise DiagnosticError('PARSER_SOURCE_CHANGED_DURING_DIAGNOSIS')
    for item in inventory:
        if digest(paths_by_name[item['name']])!=item['sha256']:raise DiagnosticError('RAW_SOURCE_CHANGED_DURING_DIAGNOSIS')
    inventory_sha=hashlib.sha256(json.dumps(inventory,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return dict(status='diagnosed_not_admitted',kind='authorized_variablewidth_quality_schema_metadata_only_diagnostic',parser_sha256=expected_parser_sha256,diagnostic_source_sha256=digest(__file__),raw_file_count=len(files),raw_inventory_sha256=inventory_sha,counts=counts,strict_fixed_error_counts=strict_errors,opaque_fixed_error_counts=opaque_errors,unsupported_quality_shape_counts=shape,synthetic_checks_passed=syn,affected_eligibility_assessed_occurrences=counts['unknown_quality_opaque_passed'],all_unsupported_quality_resolved=bool(counts['unknown_quality_opaque_passed']==counts['strict_unknown_quality']),genuine_other_structural_error_counts=opaque_errors,raw_rows_emitted=0,metadata_tokens_emitted=0,source_years_or_locations_emitted=0,canonical_outputs_created=0,source_files_modified=0,requests=0,fits=0,scores=0,scope='Raw-row occurrence counts, not deduplicated catalogue counts or adequacy outcomes; no schema/population admission is granted.')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--raw-dir',required=True,action='append');ap.add_argument('--parser',required=True);ap.add_argument('--expected-parser-sha256',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    try:
        with open(os.devnull,'w',encoding='utf-8') as sink:
            with contextlib.redirect_stdout(sink),contextlib.redirect_stderr(sink):result=diagnose(args.raw_dir,args.parser,args.expected_parser_sha256)
        with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
        print(json.dumps(dict(status='diagnosed_not_admitted',receipt_sha256=digest(args.output))));return 0
    except BaseException as error:
        name=type(error).__name__ if type(error).__name__ in ['DiagnosticError','ValueError','OSError','UnicodeDecodeError','AssertionError','TypeError','KeyError'] else 'Exception'
        print(json.dumps(dict(status='failed',fixed_error_code='QUALITY_DIAGNOSTIC_FAILED',error_type=name)));return 1

if __name__=='__main__':raise SystemExit(main())
