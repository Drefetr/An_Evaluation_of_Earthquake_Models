"""Audit saved producer machine fixtures with independent direct history.

Never imports or loads a production module/DLL. Execute under a serial numerical
lease after producer bundle creation. Detailed raw fixture stays local; stdout
contains only scalar check/error counts. No empirical bundle is admitted here.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from . import oracle as O
from . import oracle_known_v1 as K
from . import nuisance_oracle as N
from .raw_input import fit_beta

PROFILES={
    'california':dict(latitude_edges=[32,32+5/3,32+10/3,37],longitude_edges=[-121,-121+7/3,-121+14/3,-114],phi0=34.5,lambda0=-117.5),
    'new_zealand':dict(latitude_edges=[-48.5,-43.5,-38.5,-33.5],longitude_edges=[165,170,175,180],phi0=-41,lambda0=172.5)}
MODELS={'E_fixed':'fixedML','E_free':'commonML','E_omori':'Omori','fixedML':'fixedML','commonML':'commonML','Omori':'Omori'}
REQUIRED=['joint_nll','joint_logscore','timing_logscore','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore','integrated_intensity','trigger_exposure','gradient','cell_integrated_intensity','event_log_point_intensity','event_log_ground_intensity','event_log_cell_intensity','event_log_zone_intensity']


def derive(v,cells):
    v=dict(v);v['conditional_location_logscore']=v['conditional_zone_logscore']+v['conditional_cell_logscore']+v['within_cell_density_logscore']
    v['timing_event_logscore']=math.fsum(v['event_log_ground_intensity']);v['timing_exposure_logscore']=-v['integrated_intensity']
    v['event_log_point_intensity_sum']=math.fsum(v['event_log_point_intensity']);v['event_log_ground_intensity_sum']=v['timing_event_logscore'];v['event_log_intensity_sum']=v['event_log_point_intensity_sum']
    v['zone_integrated_intensity']=v['cell_integrated_intensity'].reshape(3,3).sum(axis=1)
    v['cell_point_event_log_intensity_sum']=np.bincount(cells,weights=v['event_log_point_intensity'],minlength=9)
    v['cell_point_logscore']=v['cell_point_event_log_intensity_sum']-v['cell_integrated_intensity']
    return v


def audit(bundle):
    O.require(bundle.get('schema_version')==1 and bundle.get('data_classification') in ['handcrafted_fixture','generated_declared_synthetic'],'Only declared nonempirical machine bundles admitted')
    pins=bundle.get('production_source_pins',{})
    O.require(bool(pins),'Missing production source/binary pins')
    for path,digest in pins.items():O.require(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,'Producer source/binary identity changed')
    raw=bundle['raw'];t,q,lat,lon=map(lambda k:np.asarray(raw[k],float),['times','excess','latitude','longitude'])
    O.require(t.ndim==1 and t.shape==q.shape==lat.shape==lon.shape and all(np.isfinite(a).all() for a in [t,q,lat,lon]) and np.all(np.diff(t)>=0) and np.all(q>=0),'Raw fixture arrays')
    cfg=PROFILES[bundle['profile']];xy=O.project(lat,lon,cfg['phi0'],cfg['lambda0']);rect=O.rectangles(cfg['latitude_edges'],cfg['longitude_edges'],cfg['phi0'],cfg['lambda0']);cells=O.labels(xy,rect)
    records=[];maximum=0.;gradmax=0.;checks=0;geometry_cache={};evaluation_cache={}
    for record in bundle['records']:
        start,end=map(float,[record['start'],record['end']]);tr=(t>=record['train_start'])&(t<record['train_end']);event=(t>=start)&(t<end)
        history=record.get('history_policy','continuous')
        O.require(history in ['continuous','fixed_preissue'],'Declared history policy')
        parent=t<start if history=='fixed_preissue' else t<end
        area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]);pi=area/area.sum() if record.get('reference_policy')=='uniform_area' else O.reference_mass(cells,tr)
        beta=float(record['beta'])
        if record.get('beta_policy')=='training_conditional':O.require(abs(beta-fit_beta(q[tr]))<=1e-10,'Independent beta mismatch')
        O.require(record['spatial'] in ['cont','continuous','lift','center'],'Frozen spatial family')
        family='continuous' if record['spatial'] in ['cont','continuous'] else 'lift'
        key=(start,end,float(record['train_start']),float(record['train_end']),history,record.get('reference_policy'),beta,float(record['sigma']),float(record['bandwidth']),family,record.get('known_background'))
        if key not in geometry_cache:
            g=O.geometry(xy[parent],xy[event],xy[tr],rect,pi,float(record['sigma']),float(record['bandwidth']),family)
            if record.get('known_background') is not None:g=K.set_known_background(g,record['known_background'])
            geometry_cache[key]=g
        g=geometry_cache[key];evaluation_key=(key,MODELS[record['model']],tuple(map(float,record['pars'])),float(record['T0']))
        if evaluation_key not in evaluation_cache:
            evaluation_cache[evaluation_key]=derive(K.evaluate(MODELS[record['model']],record['pars'],t[parent],q[parent],t[event],q[event],beta,start,end,float(record['T0']),g),cells[event])
        expected=evaluation_cache[evaluation_key]
        actual=record['production'];required=REQUIRED if record.get('require_gradient',True) else [k for k in REQUIRED if k!='gradient']
        O.require(all(k in actual for k in required),'Missing proper score/gradient component')
        errors={}
        for key in actual:
            if key not in expected:continue
            a,e=np.asarray(actual[key],float),np.asarray(expected[key],float)
            O.require(a.shape==e.shape and np.isfinite(a).all(),'Saved component shape or finite check')
            error=float(np.max(abs(a-e),initial=0.));errors[key]=error;checks+=1
            if key=='gradient':gradmax=max(gradmax,error);O.require(error<=2e-5,'Independent gradient mismatch')
            else:maximum=max(maximum,error);O.require(error<=1e-4,'Independent proper score/decomposition mismatch')
        records.append(dict(model=record['model'],spatial=record['spatial'],history_policy=history,maximum_absolute_error=max(errors.values(),default=0.),component_errors=errors))
    nuisance=[]
    for control in bundle.get('nuisance_controls',[]):
        tr=(t>=control['train_start'])&(t<control['train_end']);actual=control['production_kde_selection'];expected=N.select_bandwidth(xy[tr],rect)
        O.require(actual['selected_bandwidth']==expected['selected_bandwidth'],'Independent h selection mismatch')
        O.require(len(actual['candidates'])==len(expected['candidates'])==6,'Complete h candidate denominator')
        err=0.
        for a,e in zip(actual['candidates'],expected['candidates']):
            O.require(a['bandwidth']==e['bandwidth'] and a['n_loo']==e['n_loo'],'LOO candidate lineage')
            delta=abs(a['loo_logscore']-e['loo_logscore']);err=max(err,delta);O.require(delta<=1e-4,'Independent LOO score mismatch');checks+=1
        nuisance.append(dict(maximum_absolute_loo_error=float(err),selected_bandwidth=expected['selected_bandwidth']))
    O.require(len(records)>0,'Empty machine denominator')
    return dict(passed=True,scope='Saved nonempirical producer bundle independently reconstructed without production imports or DLL',records=len(records),component_checks=checks,maximum_absolute_score_error=maximum,maximum_absolute_gradient_error=gradmax,nuisance_controls=nuisance,record_audits=records)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',required=True);parser.add_argument('--output',required=True);args=parser.parse_args()
    try:
        path=Path(args.bundle);result=audit(json.loads(path.read_text()));result['bundle_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception as error:
        result=dict(passed=False,fixed_error_code='INDEPENDENT_MACHINE_RECONSTRUCTION_FAILED',error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({k:v for k,v in result.items() if k in ['passed','records','component_checks','maximum_absolute_score_error','maximum_absolute_gradient_error','fixed_error_code','error_type']},allow_nan=False))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
