"""Independent boundary-mass/refinement audit; no production imports or DLL.

Consumes only declared handcrafted producer matrices. Emits scalar errors and
the conservative log-normalizer refinement bound for <=1500 control targets.
"""
import argparse,hashlib,json,math
from pathlib import Path
import numpy as np
from . import oracle as O
from .audit_machine_bundle import PROFILES


def audit(bundle):
    O.require(bundle['kind']=='handcrafted_geometry_fixture' and bundle['scales']==[5.,15.,50.,150.,500.,1500.],'Declared boundary fixture')
    O.require({p['profile'] for p in bundle['profiles']}==set(PROFILES) and len(bundle['profiles'])==2,'Both frozen profiles')
    maximum_absolute=0.;maximum_relative=0.;refinement_log=0.;whole_error=0.;matrices=0;points=0
    for profile in bundle['profiles']:
        cfg=PROFILES[profile['profile']];lat=np.asarray(profile['latitude']);lon=np.asarray(profile['longitude'])
        xy=O.project(lat,lon,cfg['phi0'],cfg['lambda0']);rect=O.rectangles(cfg['latitude_edges'],cfg['longitude_edges'],cfg['phi0'],cfg['lambda0']);area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]);outer=[rect[:,0].min(),rect[:,1].max(),rect[:,2].min(),rect[:,3].max()]
        O.require(len(xy)==16 and len(profile['records'])==6,'Boundary denominator')
        O.require(np.max(abs(xy-np.asarray(profile['parent_xy'])))<=1e-9 and np.max(abs(rect-np.asarray(profile['rectangles'])))<=1e-9 and np.max(abs(area-np.asarray(profile['cell_areas'])))<=1e-6,'Independent profile reconstruction')
        O.require(np.array_equal(O.labels(xy,rect),profile['cells']),'Coordinate and projected boundary ownership')
        for record,scale in zip(profile['records'],bundle['scales']):
            O.require(record['sigma']==scale,'Complete frozen scale order')
            fine=np.array([[O.rectangle_mass(b,p,scale,epsabs=1e-11,epsrel=2e-12)[0] for b in rect] for p in xy])
            coarse=np.array([[O.rectangle_mass(b,p,scale)[0] for b in rect] for p in xy])
            whole=np.array([O.rectangle_mass(outer,p,scale,epsabs=1e-11,epsrel=2e-12)[0] for p in xy])
            actual=np.asarray(record['rectangle_integrals']);O.require(actual.shape==fine.shape and np.isfinite(actual).all() and np.all(actual>0),'Positive saved boundary matrix')
            delta=abs(actual-fine);relative=delta/fine
            O.require(np.all(delta<=np.maximum(1e-8,1e-9*abs(fine))),'Independent rectangle-mass mismatch')
            O.require(np.max(abs(actual.sum(axis=1)-np.asarray(record['domain_integral'])))<=1e-8,'Saved domain mass identity')
            O.require(np.all(abs(fine.sum(axis=1)-whole)<=np.maximum(1e-8,1e-11*abs(whole))),'Independent domain partition additivity')
            O.require(np.all(whole>0) and np.all(whole<math.pi*scale*scale),'Finite-domain unit-kernel bound')
            maximum_absolute=max(maximum_absolute,float(delta.max()));maximum_relative=max(maximum_relative,float(relative.max()));refinement_log=max(refinement_log,float(np.max(abs(np.log(coarse/fine)))));whole_error=max(whole_error,float(np.max(abs(fine.sum(axis=1)-whole))));matrices+=1
        points+=len(xy)
    # Positive weighted sums have a relative error no greater than the largest
    # component error. Thus the sampled log-normalizer refinement error bounds
    # a sum over up to1500 retained synthetic targets conservatively.
    score_bound=1500.*refinement_log
    O.require(score_bound<=1e-4,'Boundary integration refinement score bound')
    return dict(passed=True,profiles=2,parent_points=points,matrices=matrices,individual_rectangle_checks=matrices*16*9,maximum_absolute_mass_error=maximum_absolute,maximum_relative_mass_error=maximum_relative,maximum_positive_quad_partition_error=whole_error,maximum_log_mass_refinement_error=refinement_log,refinement_logscore_bound_for_1500_targets=score_bound,scope='Handcrafted boundary points/all6scales; positive quadrature refinement and producer antiderivative reconciliation, no universal interval proof')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bundle',required=True);p.add_argument('--output',required=True);args=p.parse_args()
    try:
        result=audit(json.loads(Path(args.bundle).read_text()));result['bundle_sha256']=hashlib.sha256(Path(args.bundle).read_bytes()).hexdigest()
    except Exception as error:result=dict(passed=False,fixed_error_code='BOUNDARY_ORACLE_FAILURE',error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False))
    raise SystemExit(0 if result['passed'] else 1)
