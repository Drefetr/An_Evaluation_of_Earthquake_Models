"""Root-leased independent repair-source canonical/eligibility preflight.

No production imports or DLL. Full fixed source retained; resource counts are
planning inputs only. No arbitrary row-count cutoff is a scientific gate.
"""
import argparse,json
from pathlib import Path
from . import empirical_io_v2 as I


def verify_authorization(path):
    authorization=I.read(path)
    I.require(authorization.get('status')=='frozen' and authorization.get('kind')=='independent_source_reconstruction_and_preflight_only' and authorization.get('protected_release_authorized') is True and authorization.get('fit_authorized') is False,'PREFLIGHT_ONLY_IO_AUTHORITY_REQUIRED')
    pins=authorization['artifact_pins'];I.require(type(pins) is dict and bool(pins),'PREFLIGHT_PIN_MAP')
    for filename,digest in pins.items():I.require(I.sha(filename)==digest,'PREFLIGHT_FROZEN_DEPENDENCY_CHANGED')
    return authorization


def execute(run,mode,authorization_path):
    run=Path(run);authorization=verify_authorization(authorization_path)
    required=[run/'design/quality_schema_amendment_v1.json',run/'design/repair_input_authorization_v1.json',Path(__file__),Path(I.__file__),Path(I.R.__file__)]
    I.require(all(authorization['artifact_pins'].get(str(p.resolve()))==I.sha(p) for p in required),'PREFLIGHT_AMENDMENT_INPUT_BINDINGS')
    train=I.load_ca_lane(run,'train') if mode in ['train','merged'] else None
    protected=I.load_ca_lane(run,'protected') if mode in ['protected','merged'] else None
    lane=train or protected;bindings={}
    def bind(filename,digest=None):
        filename=str(Path(filename).resolve());actual=I.sha(filename)
        I.require(digest is None or actual==digest,'PREFLIGHT_CURRENT_BINDING');I.require(filename not in bindings or bindings[filename]==actual,'PREFLIGHT_SHARED_BINDING');bindings[filename]=actual
    bind(authorization_path)
    for filename,digest in authorization['artifact_pins'].items():bind(filename,digest)
    for item in [train,protected]:
        if item is not None:
            for filename,digest in item['bindings'].items():
                if Path(filename).resolve().is_relative_to(run.resolve()):I.require(authorization['artifact_pins'].get(filename)==digest,'PREFLIGHT_ALL_CURRENT_SOURCE_INPUTS_PINNED')
                bind(filename,digest)
    result=dict(status='passed',passed=True,independent=True,data_classification='local_verified_empirical_rows',mode=mode,schema_reconstruction_passed=True,input_sha256=lane['canonical_sha256'],diagnostic_sha256=lane['diagnostic_sha256'],raw_manifest_sha256=lane['raw_manifest_sha256'],source_commit=I.COMMIT,quality_schema_amendment_sha256=I.QUALITY_AMENDMENT,bytes=lane['raw_bytes'],file_count=lane['file_count'],bindings=bindings,source_reconstruction_only=True,fit_execution_authorized=False)
    if mode in ['train','merged']:
        source=I.merge_ca(train,protected) if mode=='merged' else train
        admissions=[I.ca_training_admission(source['raw'],source['diagnostic'],cutoff) for cutoff in ([2011,2016,2021] if mode=='merged' else [2011])]
        result.update(training_admissions=admissions,training_admission_passed=all(row['admitted'] for row in admissions),passed=bool(all(row['admitted'] for row in admissions)),unchanged_predecessor_training=train['unchanged_predecessor_training'])
        if mode=='merged':
            raw=source['raw'];epoch=I.R.utc('1981-01-01T00:00:00Z');counts=[];cases=[]
            for first,last in [(2011,2016),(2016,2021),(2021,2026)]:
                lo=(I.R.utc(f'{first}-01-01T00:00:00Z')-epoch).total_seconds()/86400.;hi=(I.R.utc(f'{last}-01-01T00:00:00Z')-epoch).total_seconds()/86400.;n=int(((raw['times']>=lo)&(raw['times']<hi)).sum());counts.append(n)
                training_start=(I.R.utc('1986-01-01T00:00:00Z')-epoch).total_seconds()/86400.;ntr=int(((raw['times']>=training_start)&(raw['times']<lo)).sum());npr=int((raw['times']<lo).sum());nfpr=int((raw['times']<hi).sum())
                cases.append(dict(origin_year=first,scored_training_events=ntr,training_parents_including_warmup=npr,test_targets=n,forecast_parents_before_window_end=nfpr,dense_pair_entries_training=ntr*npr,dense_pair_entries_forecast=n*nfpr))
            targets=dict(window_events=counts,total_events=sum(counts),minimum_total_events=100,minimum_events_per_window=20,admitted=bool(sum(counts)>=100 and all(n>=20 for n in counts)))
            planning=dict(actual_full_merged_model_rows=len(raw['times']),includes_warmup=True,scientific_row_count_cutoff=None,counts_for_capacity_planning_only=True,no_sample_exclusions=True,cases=cases)
            result.update(protected_input_sha256=protected['canonical_sha256'],protected_diagnostic_sha256=protected['diagnostic_sha256'],unique_model_events=len(raw['times']),resource_planning=planning,target_adequacy=targets,bytes=train['raw_bytes']+protected['raw_bytes'],file_count=train['file_count']+protected['file_count'],passed=bool(result['passed'] and targets['admitted']))
    result['status']='passed' if result['passed'] else 'ineligible_under_unchanged_scientific_diagnostic'
    return result


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',required=True);ap.add_argument('--mode',choices=['train','protected','merged'],required=True);ap.add_argument('--authorization',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    try:result=execute(args.run,args.mode,args.authorization)
    except Exception as error:result=dict(status='failed',passed=False,independent=True,mode=args.mode,fixed_error_code='REPAIR_EMPIRICAL_PREFLIGHT_FAILED',error_type=type(error).__name__)
    passed=result['passed']
    if args.mode=='protected':
        result=({k:result[k] for k in ['input_sha256','source_commit','bytes']}|dict(status='success')) if passed else dict(status='failed',fixed_error_code='REPAIR_EMPIRICAL_PREFLIGHT_FAILED',error_type=result.get('error_type','ValueError'))
    with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    if args.mode=='protected':print(json.dumps(result,allow_nan=False))
    else:print(json.dumps({k:result[k] for k in ['status','passed','independent','mode','schema_reconstruction_passed','training_admission_passed','unique_model_events','file_count','bytes','fixed_error_code','error_type'] if k in result},allow_nan=False))
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
