"""Independent empirical saved-cache reconstruction for arbitrary frozen windows.
No production imports or DLL calls. Raw arrays and detailed components stay local.
"""
import hashlib,json
from pathlib import Path
import numpy as np
from . import empirical_io_v1 as I,oracle as O

def cache_audit(path,raw,pi,beta,bandwidth,geometry_cache,contract):
    start=contract['start'];end=contract['end'];T0=contract['T0'];training=(raw['times']>=contract['training_start'])&(raw['times']<contract['training_end']);parent=raw['times']<end;event=(raw['times']>=start)&parent
    with np.load(path,allow_pickle=False) as saved:
        meta=json.loads(str(saved['metadata_json'].item()));arrays={k:saved[k].copy() for k in saved.files if k!='metadata_json'}
    I.require(all(meta.get(k)==v for k,v in contract.items()),'CACHE_EXACT_FROZEN_BINDINGS')
    identity=dict(meta);identity.pop('cache_identity_sha256',None)
    I.require(meta['cache_identity_sha256']==hashlib.sha256(json.dumps(identity,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest(),'CACHE_METADATA_IDENTITY')
    I.require(meta['array_sha256']=={k:hashlib.sha256(v.tobytes(order='C')).hexdigest() for k,v in arrays.items()},'CACHE_ARRAY_HASHES')
    I.require(meta['beta']==beta and meta['background']=='kde' and meta['known_background_override'] is False and meta['kde_bandwidth']==bandwidth,'CACHE_FROZEN_NUISANCE')
    I.require(meta['reference_pi']==meta['pi'] and float(np.max(abs(np.asarray(meta['reference_pi'])-pi)))<=1e-12 and meta['r']==.7 and meta['kde_floor']==.05 and meta['strict_left_limit'] is True,'CACHE_METADATA_MATHEMATICS')
    for name,digest in meta['production_source_pins'].items():I.require(I.sha(name)==digest,'CACHE_PRODUCTION_SOURCE_IDENTITY')
    I.require(meta['family'] in ['continuous','center'],'CACHE_FAMILY_ROSTER')
    family='continuous' if meta['family']=='continuous' else 'lift';key=(float(meta['sigma']),family,start,end,contract['training_start'],contract['training_end'])
    if key not in geometry_cache:geometry_cache[key]=O.geometry(raw['xy'][parent],raw['xy'][event],raw['xy'][training],raw['rectangles'],pi,key[0],bandwidth,family)
    g=geometry_cache[key];t=raw['times'][parent];q=raw['excess'][parent];cells=raw['cells'][parent];et=raw['times'][event];eq=raw['excess'][event];ec=raw['cells'][event];pxy=raw['xy'][parent];exy=raw['xy'][event];kxy=raw['xy'][training];rect=raw['rectangles'];area=g['area'];density=pi/area
    F=np.array([[O.rectangle_mass(b,p,key[0])[0] for b in rect] for p in pxy]) if family=='continuous' else np.empty((len(t),0))
    kF=np.array([[O.rectangle_mass(b,p,bandwidth)[0] for b in rect] for p in kxy]);kZ=kF.sum(axis=1)
    point=O.kernel(exy,pxy,key[0])*density[ec,None]/g['parent_normalizer'][None,:] if family=='continuous' else g['parent_cell'][:,ec].T/area[ec,None]
    bg=.05*density[ec]+.95*np.mean(O.kernel(exy,kxy,bandwidth)/kZ[None,:],axis=1)
    weights,rates=O.mixture();centers=np.column_stack(((rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2))
    expected=dict(parent_time=t,parent_excess=q,parent_cell=cells,event_time=et,event_excess=eq,event_cell=ec,event_x=2*et/T0-1,event_parent_lag=et[:,None]-t[None,:],parent_exposure_lo=np.maximum(start-t,0.),parent_exposure_hi=end-t,mixture_weights=weights,mixture_rates=rates,quad_time=np.empty(0),quad_x=np.empty(0),quad_w=np.empty(0),parent_latitude=raw['latitude'][parent],parent_longitude=raw['longitude'][parent],parent_xy=pxy,event_xy=exy,event_parent_density=point,parent_cell_mass=g['parent_cell'],parent_rectangle_integrals=F,parent_normalizer=g['parent_normalizer'],parent_fertility=.3*np.exp(.7*beta*q),event_background_density=bg,background_cell_mass=g['background_cell'],reference_pi=pi,cell_pi=pi,cell_areas=area,rectangles=rect,cell_centers_xy=centers,kde_training_xy=kxy,kde_training_cells=raw['cells'][training],kde_rectangle_integrals=kF,kde_normalizers=kZ)
    I.require(set(arrays)==set(expected),'CACHE_COMPLETE_FEATURE_SET')
    errors={};exact={'parent_time','parent_excess','parent_cell','event_time','event_excess','event_cell','event_x','event_parent_lag','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates','quad_time','quad_x','quad_w','parent_latitude','parent_longitude','kde_training_cells'}
    for name,value in expected.items():
        actual=arrays[name];value=np.asarray(value)
        I.require(actual.dtype==np.dtype('float64') and actual.shape==value.shape and np.isfinite(actual).all(),'CACHE_FEATURE_SHAPE_FINITE')
        delta=abs(actual-value);error=float(np.max(delta,initial=0.));errors[name]=error
        if name in exact:I.require(np.array_equal(actual,value),'CACHE_RAW_NUMERIC_IDENTITY')
        elif name in ['parent_rectangle_integrals','kde_rectangle_integrals']:I.require(np.all(delta<=np.maximum(1e-8,1e-9*abs(value))),'CACHE_POSITIVE_RECTANGLE_RECONSTRUCTION')
        else:I.require(np.all(delta<=1e-14+2e-10*abs(value)),'CACHE_RAW_GEOMETRY_RECONSTRUCTION')
    return dict(path_sha256=I.sha(path),sigma=key[0],family=family,order=meta['order'],feature_checks=len(expected),maximum_feature_absolute_error=max(errors.values()),feature_errors=errors)

