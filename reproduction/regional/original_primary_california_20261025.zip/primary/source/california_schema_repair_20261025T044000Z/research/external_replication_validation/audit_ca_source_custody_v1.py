"""Root-leased byte/metadata custody checks only; never parse event rows."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json

COMMIT='7105f6c1b861db46c3a8454984588f5b6a4a56e4'
TREE='35c28fa2cc0cd524d30da65ffb59c8493c1c9cd6'
SEALS={'prior_research_run':('89618b87c7b2fb354dd328a6e997a8062938e8a45765d68c9b7cf18e3c7179de',1043),'prior_writing_run':('c84d7d5b364793f275fecd25cb1072cf81298effd72e6ff2fdfeae644288db5e',89)}
class CustodyError(ValueError):pass

def need(condition,code):
    if not condition:raise CustodyError(code)

def load(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):h.update(part)
    return h.hexdigest()
def reference(path):return dict(path=str(Path(path).resolve()),sha256=digest(path))
def utc(value):return datetime.fromisoformat(value.replace('Z','+00:00'))
def safe_child(base,name):
    target=(Path(base)/name).resolve();need(target.is_relative_to(Path(base).resolve()),'PATH_OUTSIDE_DECLARED_ROOT');return target

def blob_identity(path,expected_size):
    need(type(expected_size) is int and 0<expected_size<=16777216,'BLOB_SIZE_CAP')
    need(path.is_file() and not path.is_symlink() and not (getattr(path.stat(),'st_file_attributes',0)&0x400),'RAW_FILE_NOT_REGULAR')
    need(path.stat().st_size==expected_size,'BLOB_SIZE_MISMATCH')
    git=hashlib.sha1(('blob '+str(expected_size)+'\0').encode('ascii'));strong=hashlib.sha256();total=0
    with path.open('rb') as stream:
        for part in iter(lambda:stream.read(1048576),b''):total+=len(part);git.update(part);strong.update(part)
    need(total==expected_size and path.stat().st_size==expected_size,'BLOB_CHANGED_SIZE')
    return git.hexdigest(),strong.hexdigest()

def audit_seal(base,expected_sha,expected_count):
    base=Path(base).resolve();manifest=base/'seal_manifest.json';need(digest(manifest)==expected_sha,'PRIOR_SEAL_MANIFEST_IDENTITY');records=load(manifest)['files'];need(type(records) is dict and len(records)==expected_count,'PRIOR_SEAL_DENOMINATOR')
    for name,record in records.items():
        path=safe_child(base,name);need(path.is_file() and path.stat().st_size==record['bytes'] and digest(path)==record['sha256'],'PRIOR_SEALED_FILE_IDENTITY')
    need(digest(manifest)==expected_sha,'PRIOR_SEAL_CHANGED')
    return dict(manifest=reference(manifest),sealed_file_count=len(records),file_failures=0,passed=True)

def audit(state_path):
    state=load(state_path);run=Path(state['run']).resolve();protected=run/'protected/california';raw=protected/'raw';manifest_path=protected/'raw_manifest.json';manifest=load(manifest_path);protocol_path=run/'design/acquisition_protocol_v2.json';metadata_path=run/'design/catalogue_source_metadata.json';protocol=load(protocol_path);metadata=load(metadata_path)
    need(manifest['schema_version']==3 and manifest['protocol_sha256']==digest(protocol_path) and manifest['source_metadata_sha256']==digest(metadata_path),'MANIFEST_AUTHORITY_SHA')
    need(manifest['boundary_contract_sha256']==digest(run/'design/boundary_contract_v1.json') and manifest['time_schema_amendment_sha256']==digest(run/'design/time_schema_amendment_v1.json'),'SCHEMA_AMENDMENT_PIN')
    need(manifest['source_snapshot']==protocol['source']['commit']==metadata['sha']==COMMIT and protocol['source']['root_tree_sha']==metadata['root_tree_sha']==TREE and metadata['tree_truncated'] is False,'OFFICIAL_SOURCE_COMMIT_TREE')
    years=protocol['partitions']['protected_snapshot_files'];need(years==list(range(2011,2026)),'PROTECTED_FILE_ROSTER')
    expected=['SCEC_DC/'+str(y)+'.catalog' for y in years];records=manifest['files'];need([x['path'] for x in records]==expected and len(records)==15,'RAW_MANIFEST_COMPLETE15')
    need({x.name for x in raw.iterdir() if x.is_file()}=={Path(x).name for x in expected},'RAW_DIRECTORY_EXACT15_NO_PART_INPUT')
    blobs={x['path']:x for x in metadata['selected_blobs']};need(len(blobs)==45 and len(metadata['selected_blobs'])==45,'OFFICIAL_TREE_45_UNIQUE_BLOBS')
    total=0;identities=[]
    for entry in records:
        official=blobs[entry['path']];need(official['type']=='blob' and official['mode']=='100644','OFFICIAL_BLOB_TYPE')
        need(entry['git_blob_sha1']==official['sha'] and entry['bytes']==official['size'],'MANIFEST_GIT_METADATA_AGREEMENT')
        path=safe_child(raw,Path(entry['path']).name);git,strong=blob_identity(path,entry['bytes'])
        need(git==entry['git_blob_sha1'] and strong==entry['sha256'],'RAW_OFFICIAL_BLOB_SHA1_SHA256')
        total+=entry['bytes'];identities.append(dict(path=entry['path'],bytes=entry['bytes'],git_blob_sha1=git,sha256=strong))
    need(total==protocol['acquisition']['expected_protected_bytes'] and total<=protocol['acquisition']['max_total_bytes'],'TOTAL_TRANSFER_BYTES')
    attempts_path=protected/'transfer_attempts.jsonl';attempts=[json.loads(line) for line in attempts_path.read_text().splitlines() if line];need(len(attempts)==15,'TRANSFER_ATTEMPT_DENOMINATOR')
    byfile={};starts=[];finishes=[]
    for attempt in attempts:
        need(attempt['file'] not in byfile and attempt['file'] in expected,'TRANSFER_FILE_ROSTER');byfile[attempt['file']]=attempt
        need(type(attempt['attempt']) is int and attempt['attempt']==1 and attempt['status']=='success','EXPECTED_TERMINAL_TRANSFER_SUCCESS')
        size=blobs[attempt['file']]['size'];need(attempt['bytes_received']==size,'TRANSFER_SIZE_RECEIPT')
        length=attempt['headers'].get('Content-Length');need(length is None or (type(length) is str and length.isascii() and length.isdecimal() and int(length)==size),'TRANSFER_CONTENT_LENGTH')
        start,end=utc(attempt['started_utc']),utc(attempt['finished_utc']);need(start<=end,'TRANSFER_CLOCK_ORDER');starts.append(start);finishes.append(end)
    need(set(byfile)==set(expected),'ALL15_TRANSFERS_ACCOUNTED')
    retrieval=load(protected/'retrieval_receipt.json');need(max(finishes)<=utc(retrieval['retrieved_utc']),'RETRIEVAL_COMPLETED_AFTER_TRANSFERS')
    terminal_path=run/'reports/california-protected-acquisition-v1_process.json';terminal=load(terminal_path);spec_path=run/'tasks/california-protected-acquisition-v1_spec.json'
    need(terminal['terminal'] is True and terminal['status']=='failed' and terminal['returncode']!=0 and terminal['spec_sha256']==digest(spec_path),'FAILED_ACQUISITION_TERMINAL_PRESERVED')
    need(utc(terminal['started_utc'])<=min(starts)<=max(finishes)<=utc(terminal['observed_utc']),'TERMINAL_TRANSFER_CLOCK_ORDER')
    acceptance_path=run/'reviews/prospective_registration_wfs_v5_independent_acceptance_v1.json';accepted=load(acceptance_path);need(accepted['passed'] is True and accepted['independent'] is True and accepted['california_release_authorized'] is True and utc(accepted['independent_acceptance_completed_utc'])<=min(starts),'ACQUISITION_AFTER_SAVED_REGISTRATION_ACCEPTANCE')
    need(not (protected/'canonical_model.json').exists() and not (protected/'diagnostic_m2.json').exists(),'NO_SUCCESSFUL_CANONICAL_PRODUCTS')
    disposition_path=run/'reviews/california_source_ineligibility_independent_disposition_v1.json';disposition=load(disposition_path);need(disposition['status']=='stopped_at_source_admission' and disposition['california_lane_admitted'] is False and disposition['checks']['proposed_printable_single_ASCII_gate_failed'] is True,'CA_SOURCE_STOP_PRESERVED')
    shape_path=run/'reviews/california_quality_schema_shape_diagnosis_v1.json';shape=load(shape_path);need(shape['counts']['strict_unknown_quality']==134 and shape['counts']['unknown_quality_opaque_passed']==0 and shape['unsupported_quality_shape_counts']['printable_single_ASCII']==0,'NARROW_DIAGNOSTIC_FAILURE_PRESERVED')
    registration_path=run/'prospective_registration_v5.json';registration=load(registration_path);pins=registration['artifact_pins'];old_protocol_path=run/'protocol_nz_initialization_v2.json';old=load(old_protocol_path)['artifact_pins'];need(len(pins)==112 and len(old)==49 and all(pins.get(p)==h for p,h in old.items()),'REGISTERED_SOURCE_PIN_DENOMINATORS')
    for p,h in pins.items():need(digest(p)==h,'REGISTERED_SOURCE_PIN_CHANGED')
    need(reference(registration_path)==accepted['registration'],'ACCEPTED_REGISTRATION_BYTES_UNCHANGED')
    seals={key:audit_seal(state[key],expected,count) for key,(expected,count) in SEALS.items()};need(sum(x['sealed_file_count'] for x in seals.values())==1132,'PRIOR_SEAL_TOTAL1132')
    g0_path=run/'reviews/g0_source_closure_audit.json';g0=load(g0_path);need(g0['passed'] is True and g0['research']['manifest_sha256']==SEALS['prior_research_run'][0] and g0['writing']['manifest_sha256']==SEALS['prior_writing_run'][0],'G0_AUTHORITY_AGREEMENT')
    authority=[manifest_path,protocol_path,metadata_path,run/'design/boundary_contract_v1.json',run/'design/time_schema_amendment_v1.json',attempts_path,protected/'retrieval_receipt.json',terminal_path,spec_path,disposition_path,shape_path,registration_path,old_protocol_path,acceptance_path,g0_path,Path(__file__)]
    return dict(schema_version=1,status='passed',passed=True,independent=True,data_classification='local_protected_source_bytes_metadata_only',scope='Custody/byte identity only; never parser/schema/population/model admission.',official_source_commit=COMMIT,official_root_tree_sha=TREE,raw_files_verified=15,raw_bytes_verified=total,successful_terminal_file_transfers=15,raw_identity_inventory_sha256=hashlib.sha256(json.dumps(identities,sort_keys=True,separators=(',',':')).encode()).hexdigest(),registered_pins_verified=112,original_initialization_pins_retained=49,prior_seals=seals,prior_sealed_files_verified=1132,checks=dict(raw_manifest_schema3_authority_hashes=True,all15_official_Git_blob_SHA1_and_size_and_SHA256=True,all15_terminal_file_transfer_receipts=True,failed_acquisition_terminal_and_spec_preserved=True,acquisition_after_independent_registration_acceptance=True,no_successful_protected_canonical_created=True,CA_original_and_narrow_shape_stop_preserved=True,affected_eligibility_unassessed_not_zero=True,registered112_and_original49_unchanged=True,prior1132_files_authority_hashes_unchanged=True),bindings={str(p.resolve()):digest(p) for p in authority},canonical_required=False,canonical_created=False,event_rows_parsed=0,event_rows_emitted=0,quality_tokens_emitted=0,source_queries=0,fits=0,scores=0,scientific_lane_admitted=False,completed_utc=datetime.now(timezone.utc).isoformat())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--state',required=True);ap.add_argument('--output',required=True);args=ap.parse_args()
    try:
        result=audit(args.state)
        with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
        print(json.dumps(dict(status='passed',receipt_sha256=digest(args.output),raw_files_verified=15,registered_pins_verified=112,prior_sealed_files_verified=1132)));return 0
    except BaseException as error:
        code=str(error) if isinstance(error,CustodyError) else 'LOCAL_CUSTODY_AUDIT_FAILED'
        # CustodyError instances are raised only from literal codes above.
        name=type(error).__name__ if type(error).__name__ in ['CustodyError','OSError','ValueError','TypeError','KeyError','AssertionError'] else 'Exception'
        print(json.dumps(dict(status='failed',fixed_error_code=code,error_type=name)));return 1
if __name__=='__main__':raise SystemExit(main())
