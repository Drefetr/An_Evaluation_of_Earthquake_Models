"""Independent known-law override for declared synthetic controls.

The base oracle remains pinned and unchanged. Evaluation is its exact function
with one explicit fixed-background density override; exposure uses the matching
independently integrated cell masses. No production imports or DLL loading.
"""
import math
import numpy as np
from . import oracle as base
require=base.require
temporal=base.temporal
immigrant_integral=base.immigrant_integral
kernel=base.kernel

def evaluate(model,parameters,parent_time,parent_excess,event_time,event_excess,beta,start,end,T0,g,chunk=64):
    """Raw chronological history plus independently built geometry, no event cache.

    Returns local detailed arrays and scalar score components. Never forward the
    full return to a model context. Event time/excess arrays must match the
    exact scoring subset of parent history; outer harness verifies row identity.
    """
    pars=np.asarray(parameters,float);dim={'fixedML':3,'commonML':4,'Omori':5}[model]
    require(pars.shape==(dim,) and np.isfinite(pars).all(),"Finite parameter coordinates")
    t,q,te,qe=map(lambda x:np.asarray(x,float),(parent_time,parent_excess,event_time,event_excess))
    require(t.shape==q.shape and te.shape==qe.shape and np.all(np.diff(t)>=0),"Raw chronological history")
    require(np.all((t<end)&(q>=0)) and np.all((te>=start)&(te<end)) and beta>0,"Frozen event/history eligibility")
    require(len(t)==len(g['parent_xy']) and len(te)==len(g['event_xy']),"Raw geometry cardinality")
    a,d,n=pars[:3];require(n>=0,"Nonnegative branching")
    fert=.3*np.exp(.7*beta*q);lo=np.maximum(start-t,0.);hi=end-t
    _,J,ed=temporal(model,pars,np.empty(0),lo,hi)
    K=float(fert@J);B,Bd=immigrant_integral(a,d,start,end,T0)
    exposure=B+n*K;cellcomp=B*g['background_cell']+n*((fert*J)@g['parent_cell'])
    gradient=np.zeros(dim);gradient[:3]=[B,Bd,K]
    for j,(_,DJ) in enumerate(ed):gradient[3+j]=n*float(fert@DJ)
    lp=np.empty(len(te));lg=np.empty(len(te));lc=np.empty(len(te));lz=np.empty(len(te))
    for begin in range(0,len(te),chunk):
        stop=min(begin+chunk,len(te));rows=np.arange(begin,stop);tx=2*te[rows]/T0-1
        lag=te[rows,None]-t[None,:];valid=lag>0
        kv,_,der=temporal(model,pars,lag[valid],lo,hi)
        D=np.zeros_like(lag);D[valid]=kv;weighted=D*fert[None,:]
        cell=g['event_cell'][rows]
        if g['spatial']=='continuous':
            offspring=kernel(g['event_xy'][rows],g['parent_xy'],g['scale'])*g['density'][cell,None]/g['parent_normalizer'][None,:]
        else:offspring=g['parent_cell'][:,cell].T/g['area'][cell,None]
        bg=g['event_background_density_override'][rows] if 'event_background_density_override' in g else g['floor']*g['density'][cell]+(1-g['floor'])*np.mean(kernel(g['event_xy'][rows],g['training_xy'],g['bandwidth'])/g['kde_normalizer'][None,:],axis=1)
        mu=np.exp(a+d*tx);base=mu*bg;Hp=np.sum(weighted*offspring,axis=1)
        point=base+n*Hp;ground=mu+n*weighted.sum(axis=1)
        cells=mu[:,None]*g['background_cell'][None,:]+n*(weighted@g['parent_cell'])
        zones=cells.reshape(len(rows),3,3).sum(axis=2);ii=np.arange(len(rows))
        require(np.all(point>0) and np.all(ground>0) and np.all(cells>0),"Positive proper intensities")
        lp[rows]=np.log(point);lg[rows]=np.log(ground);lc[rows]=np.log(cells[ii,cell]);lz[rows]=np.log(zones[ii,cell//3])
        gradient[:3]-=[math.fsum(base/point),math.fsum(tx*base/point),math.fsum(Hp/point)]
        for j,(dk,_) in enumerate(der):
            DD=np.zeros_like(lag);DD[valid]=dk
            gradient[3+j]-=n*math.fsum(np.sum(DD*fert[None,:]*offspring,axis=1)/point)
    mark=len(te)*math.log(beta)-beta*math.fsum(qe)
    score=math.fsum(lp)-exposure+mark
    result=dict(joint_nll=-score,joint_logscore=score,timing_logscore=math.fsum(lg)-exposure,
                conditional_zone_logscore=math.fsum(lz-lg),conditional_cell_logscore=math.fsum(lc-lz),
                within_cell_density_logscore=math.fsum(lp-lc),mark_logscore=mark,
                integrated_intensity=exposure,trigger_exposure=K,immigrant_exposure=B,
                cell_integrated_intensity=cellcomp,gradient=gradient,
                event_log_point_intensity=lp,event_log_ground_intensity=lg,
                event_log_cell_intensity=lc,event_log_zone_intensity=lz)
    require(all(np.isfinite(np.asarray(v)).all() for v in result.values()),"Finite independent result")
    require(abs(float(cellcomp.sum())-exposure)<=1e-10*max(1,exposure),"Spatial compensator conservation")
    return result


def set_known_background(g,law):
    """Return private geometry with the declared uniform/two-kernel true law."""
    g=dict(g);rect=g['rect'];area=g['area'];uniform=area/area.sum()
    if law=='uniform':
        density=np.full(len(g['event_xy']),1/area.sum());mass=uniform
    else:
        require(law=='smooth','Frozen known-background law')
        xl,xh=rect[:,0].min(),rect[:,1].max();yl,yh=rect[:,2].min(),rect[:,3].max()
        centers=np.array([[xl+.32*(xh-xl),yl+.28*(yh-yl)],[xl+.68*(xh-xl),yl+.73*(yh-yl)]])
        F=np.array([[base.rectangle_mass(b,p,150.)[0] for b in rect] for p in centers]);Z=F.sum(axis=1)
        density=.05/area.sum()+.95*np.mean(base.kernel(g['event_xy'],centers,150.)/Z[None,:],axis=1)
        mass=.05*uniform+.95*np.mean(F/Z[:,None],axis=0)
    require(np.all(density>0) and abs(float(mass.sum())-1)<1e-12,'Known law unit mass')
    g['event_background_density_override']=density;g['background_cell']=mass
    return g
