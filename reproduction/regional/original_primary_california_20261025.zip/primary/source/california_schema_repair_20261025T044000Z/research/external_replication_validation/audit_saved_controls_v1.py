"""Complete saved synthetic-fit audit; no production imports or DLL loading.

Author artifacts are read locally. Every accepted candidate, finite feasible
solver return, exact floor, selection and near-optimal forecast pool is checked.
Only aggregate error/count receipts go to stdout. Root leases execution.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
from . import oracle as O
from . import oracle_known_v1 as K
from .audit_machine_bundle import audit,PROFILES,derive

MODELS=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
LAWS=[dict(name='TS_commonML_uniform',seed=89113,mark_seed=73113,location_seed=59113,kernel='ml',background='uniform',tau=.6,c=.25,p=1.45,n=.25),dict(name='TS_Omori_smooth',seed=89119,mark_seed=73119,location_seed=59119,kernel='omori',background='smooth',tau=.6,c=.25,p=1.45,n=.25)]


def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def same(a,b):return np.asarray(a).shape==np.asarray(b).shape and bool(np.all(np.asarray(a)==np.asarray(b)))
def require_close(a,b,tolerance,message):O.require(np.asarray(a).shape==np.asarray(b).shape and float(np.max(abs(np.asarray(a)-np.asarray(b)),initial=0.))<=tolerance,message)


def audit_case(folder,law,protocol):
    gen=read(folder/'generation.json');row=read(folder/'synthetic_training_case.json');training=read(folder/'training_case.json');case=row['case']
    O.require(gen['complete'] and gen['scenario']==law and gen['profile']=='california','Declared fixed-seed history identity')
    expected_parameters=dict(rate=.35,horizon=420.,T0=420.,beta=2.85,sigma=50.,background_h=150.,floor=.05)
    O.require(gen['parameters']==expected_parameters,'Synthetic generating parameters')
    O.require(all(case[k]==v for k,v in dict(train_start=0.,train_end=294.,test_start=294.,test_end=420.,T0=420.).items()),'Frozen294 chronology')
    raw={k:gen[k] for k in ['times','excess','latitude','longitude']};t=np.asarray(raw['times']);q=np.asarray(raw['excess']);cfg=PROFILES['california'];xy=O.project(raw['latitude'],raw['longitude'],cfg['phi0'],cfg['lambda0']);rect=O.rectangles(cfg['latitude_edges'],cfg['longitude_edges'],cfg['phi0'],cfg['lambda0']);area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]);pi=area/area.sum();cells=O.labels(xy,rect)
    identities=['synthetic:'+str(i) for i in range(len(t))]
    raw_digest=hashlib.sha256(json.dumps(dict(raw,event_ids=identities),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    config_digest=hashlib.sha256(json.dumps(dict(scenario=law,profile='california',law=gen['parameters']),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    provenance=row['generation_provenance']
    O.require(training['catalogue_sha256']==raw_digest and row['catalogue_sha256']==raw_digest and provenance['raw_rows_sha256']==raw_digest and provenance['generating_configuration_sha256']==config_digest and provenance['generation_file_sha256']==sha(folder/'generation.json'),'Exact raw/configuration/generation provenance')
    O.require(np.all(np.diff(t)>0) and np.all((t>=0)&(t<420)) and np.isfinite(q).all() and np.all(q>=0),'Generated raw eligibility')
    tr=(t>=0)&(t<294);te=(t>=294)&(t<420);O.require(tr.sum()>=50 and te.sum()>=20,'Fixed seed adequacy')
    require_close(gen['reference_pi'],pi,1e-12,'Generating reference area mismatch');require_close(training['reference_pi'],pi,1e-12,'Fit known reference mismatch');O.require(training['beta']==2.85,'Fit known beta mismatch')
    O.require(set(row['models'])==set(MODELS) and len(training['procedures'])==5,'Complete five-arm denominator')
    pins=protocol['artifact_pins'];bundle=dict(schema_version=1,data_classification='generated_declared_synthetic',profile='california',raw=raw,production_source_pins=pins,records=[],nuisance_controls=[dict(train_start=0.,train_end=294.,production_kde_selection=training['kde_selection'])])
    count=dict(procedures=0,starts=0,floors=0,candidates=0,solver_returns=0,near_optimal_forecasts=0)
    fitted={};scorefiles={};a0=float(np.clip(np.log(.6*int(tr.sum())/294.),-11.5,-.1));ap=float(np.clip(np.log(int(tr.sum())/294.),-12,0));fp=protocol['fit_policy']
    def record(fit,pars,production,forecast=False,require_gradient=True):
        bundle['records'].append(dict(start=294. if forecast else 0.,end=420. if forecast else 294.,train_start=0.,train_end=294.,T0=420.,beta=2.85,sigma=50.,bandwidth=training['kde_selection']['selected_bandwidth'],spatial=fit['spatial'],model=fit['model'],pars=pars,history_policy='continuous',reference_policy='uniform_area',known_background=law['background'],production=production,require_gradient=require_gradient))
    for path in training['procedures']:
        fit=read(path);fitted[fit['temporal']+'_smooth_'+fit['spatial']]=fit
        registry=read(folder/('registry_'+fit['procedure_id']+'.json'))
        O.require(registry['sha256']==sha(path) and registry['procedure_id']==fit['procedure_id'],'Fit registry exact identity')
        O.require(fit['complete'] is True and fit['sigma']==50. and fit['case_id']==law['name'],'Complete fixedsigma fit')
        starts=[s for s in fit['slots'] if s['kind']=='start'];floors=[s for s in fit['slots'] if s['kind']=='floor'];candidates=fit['accepted_candidates']
        O.require(len(starts)==8 and [s['slot'] for s in starts]==list(range(8)),'Complete eight-start roster')
        O.require(len(floors)==(2 if fit['temporal']=='commonML' else 1),'Exact floor denominator')
        O.require([c['candidate_id'] for c in candidates]==list(range(len(candidates))),'Complete candidate identity sequence')
        O.require(all(c['origin'] in ['solver','poisson_floor','fixedML_tau1_floor'] for c in candidates),'No truth or unplanned candidate insertion')
        winner=min(candidates,key=lambda c:(c['evaluation']['joint_nll'],c['candidate_id']))
        O.require(fit['selected']['candidate_id']==winner['candidate_id'] and same(fit['selected']['pars'],winner['pars']),'Training-only minimum selection')
        score=read(folder/('score_'+fit['procedure_id']+'.json'));scorefiles[fit['procedure_id']]=score
        O.require(score['training_fit_sha256']==sha(path) and score['status']=='complete','Forecast bound to immutable fit')
        forecasts={c['candidate_id']:c for c in score['all_candidate_forecasts']}
        O.require(set(forecasts)=={c['candidate_id'] for c in candidates},'All candidate forecast denominator')
        expected_near=[c['candidate_id'] for c in candidates if c['evaluation']['joint_nll']<=winner['evaluation']['joint_nll']+4e-4]
        O.require([c['candidate_id'] for c in score['near_optimal_forecasts']]==expected_near,'Complete near-optimal pool lineage')
        spread=(max(forecasts[i]['forecast']['joint_logscore'] for i in expected_near)-min(forecasts[i]['forecast']['joint_logscore'] for i in expected_near))/int(te.sum())
        O.require(abs(spread-score['forecast_spread_nats_per_event'])<=1e-12 and spread<.01,'Near-optimal spread gate')
        for candidate in candidates:
            record(fit,candidate['pars'],candidate['evaluation']);record(fit,candidate['pars'],candidate['fine_evaluation'])
            forecast=forecasts[candidate['candidate_id']]
            O.require(same(forecast['pars'],candidate['pars']) and forecast['training_joint_nll']==candidate['evaluation']['joint_nll'],'Forecast candidate binding')
            record(fit,candidate['pars'],forecast['forecast'],True,False);record(fit,candidate['pars'],forecast['fine_forecast'],True,False)
        solver=[]
        for slot in starts:
            O.require(slot['status']=='complete' and len(slot['attempts']) in [1,2],'Start terminal lineage')
            for tier,attempt in enumerate(slot['attempts']):
                O.require(attempt['tier']==tier and attempt['method']==('L-BFGS-B' if tier==0 else 'Powell'),'Failure-only recovery order')
                O.require(same(attempt['start'],slot['requested_start']),'Exact original-start recovery')
                if tier:O.require(slot['attempts'][0]['accepted'] is False,'Recovery only after original failure')
                if attempt.get('finite_feasible'):
                    record(fit,attempt['pars'],attempt['evaluation']);record(fit,attempt['pars'],attempt['fine_evaluation']);solver.append((slot['slot'],tier,attempt))
            O.require(sum(bool(a['accepted']) for a in slot['attempts'])==1,'One accepted return per completed start')
        saved_solver=score['all_solver_return_forecasts'];O.require(len(saved_solver)==len(solver),'All feasible solver-return forecast denominator')
        for saved,(slot,tier,attempt) in zip(saved_solver,solver):
            O.require(saved['slot']==slot and saved['tier']==tier and same(saved['pars'],attempt['pars']) and saved['accepted']==attempt['accepted'],'Solver-return forecast identity')
            record(fit,attempt['pars'],saved['forecast'],True,False);record(fit,attempt['pars'],saved['fine_forecast'],True,False)
        poisson=next(s for s in floors if s['origin']=='poisson_floor');expected=[ap,0.,0.]+([0.] if fit['temporal']=='commonML' else [0.,1.3] if fit['temporal']=='Omori' else [])
        require_close(poisson['pars'],expected,1e-12,'Exact admissible Poisson floor')
        for floor in floors:O.require(floor['status']=='complete' and any(c['candidate_id']==floor['candidate_id'] and same(c['pars'],floor['pars']) for c in candidates),'All floor candidate lineage')
        count['procedures']+=1;count['starts']+=8;count['floors']+=len(floors);count['candidates']+=len(candidates);count['solver_returns']+=len(solver);count['near_optimal_forecasts']+=len(expected_near)
    # Starts may depend only on the matched fixedML selected training solution.
    for mid,fit in fitted.items():
        temporal=fit['temporal']
        if temporal=='fixedML':expected=[[a0+s['a_offset'],s['d'],s['n']] for s in fp['fixedML_starts']]
        else:
            point=fitted['fixedML_smooth_'+fit['spatial']]['selected']['pars']
            expected=[point+[math.log(tau)] for tau in fp['commonML_tau_starts_days']] if temporal=='commonML' else [point+[math.log(c),p] for c,p in fp['Omori_cp_starts']]
            if temporal=='commonML':
                nested=next(s for s in fit['slots'] if s['kind']=='floor' and s['origin']=='fixedML_tau1_floor');require_close(nested['pars'],point+[0.],1e-12,'Exact fixedML tau1 nested floor')
        for slot,p in zip([s for s in fit['slots'] if s['kind']=='start'],expected):require_close(slot['requested_start'],p,1e-12,'Prescribed original start')
    alias=read(folder/'alias_fixedML_smooth_cont.json');fixed=fitted['fixedML_smooth_cont'];O.require(alias['source_procedure_id']==fixed['procedure_id'] and alias['source_candidate_id']==fixed['selected']['candidate_id'] and alias['sigma']==50. and alias['no_additional_fit'] is True,'Fixedsigma alias lineage')
    O.require(count['procedures']==5 and count['starts']==40 and count['floors']==6,'Complete per-law denominators')
    numerical=audit(bundle)
    temporal='commonML' if law['kernel']=='ml' else 'Omori';truthpars=[math.log(.35),0.,.25]+([math.log(.6)] if temporal=='commonML' else [math.log(.25),1.45]);witness=[]
    for start,end,event in [(0.,294.,tr),(294.,420.,te)]:
        parent=t<end;g=K.set_known_background(O.geometry(xy[parent],xy[event],xy[tr],rect,pi,50.,training['kde_selection']['selected_bandwidth'],'continuous'),law['background'])
        value=K.evaluate(temporal,truthpars,t[parent],q[parent],t[event],q[event],2.85,start,end,420.,g)
        witness.append(dict(start=start,end=end,joint_nll=float(value['joint_nll'])))
    O.require(fitted[temporal+'_smooth_cont']['selected']['evaluation']['joint_nll']<=witness[0]['joint_nll']+1e-4,'Containing-model training truth witness')
    saved=row['truth_evaluation'];O.require(same(saved['pars'],truthpars) and saved['nonfit_truth_not_candidate'] is True,'Nonfit truth identity')
    O.require(abs(saved['evaluation']['joint_nll']-witness[0]['joint_nll'])<=1e-4,'Raw nonfit truth value')
    return dict(passed=True,case=law['name'],counts=count,numerical=numerical,truth_witnesses=witness)


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--protocol',required=True);p.add_argument('--output',required=True);args=p.parse_args()
    try:
        protocol=read(args.protocol);results=[audit_case(Path(args.root)/law['name'],law,protocol) for law in LAWS]
        counts={key:sum(r['counts'][key] for r in results) for key in results[0]['counts']}
        result=dict(passed=True,scope='Full raw independent synthetic candidate/solver/floor/nearoptimal audit',counts=counts,cases=results,protocol_sha256=sha(args.protocol))
    except Exception as error:
        result=dict(passed=False,fixed_error_code='SAVED_SYNTHETIC_AUDIT_FAILED',error_type=type(error).__name__)
    with Path(args.output).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
    print(json.dumps(dict(passed=result['passed'],counts=result.get('counts'),maximum_absolute_score_error=max((r['numerical']['maximum_absolute_score_error'] for r in result.get('cases',[])),default=None),fixed_error_code=result.get('fixed_error_code')),allow_nan=False))
    return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
