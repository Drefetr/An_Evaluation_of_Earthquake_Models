"""Independent local raw/canonical provenance and population reconstruction.

No production imports, DLLs, source queries or printing. Every returned row,
identifier, coordinate and diagnostic collection stays inside local programs.
"""
import csv,hashlib,json,math
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
import numpy as np
from . import oracle as O
from . import raw_input_v3 as R
from .audit_machine_bundle import PROFILES

COMMIT='7105f6c1b861db46c3a8454984588f5b6a4a56e4'
METADATA='abced6b1b610eb9853db7d4281564c8e6413270e4728b009f6d2c125d107142c'
NZ_HASH='feacccb7581d1c4c33f88874cd6b198c41639da6930a7fc35e46f910a594fb3e'
NZ_METADATA='1ebff42b90d356dc4a0b119aa317817726e3e3e6804d803b436446428bfb2259'
QUALITY_AMENDMENT='415cc953e92250b4f5091c6b4ea3dd1e0c681cc9a53ea5a93cd29fc81adf3d38'
REPAIR_INPUT_AUTHORIZATION='7caaf6c82746992fb0085af60c8527b6031b09c5b983effa25b794cf5c5cf950'
FIELDS=['date','time','eventtype','gtype','magnitude','magtype','latitude','longitude','depth','quality','eventid','nph','ngrams']


def require(ok,code):
    if not bool(ok):raise ValueError(code)
def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def token_hash(tokens):return hashlib.sha256((json.dumps(tokens,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()


def source_tokens(paths,needed_ids=None):
    result={};index={}
    for path in paths:
        with Path(path).open(encoding='ascii') as stream:
            for line_no,line in enumerate(stream,1):
                if not line.strip() or line.lstrip().startswith('#'):continue
                tokens=line.split();require(len(tokens)==13,'RAW_TOKEN_COUNT');identity=tokens[10]
                if identity in index:require(index[identity]==token_hash(tokens),'RAW_ID_CONFLICT')
                else:
                    index[identity]=token_hash(tokens)
                    if needed_ids is None or 'scedc:'+identity in needed_ids:result['scedc:'+identity]=dict(tokens=tokens,year=int(Path(path).stem),line=line_no)
    return result,index


def expected_record(tokens,year,line,us,iso):
    return dict(event_id='scedc:'+tokens[10],origin_time_utc=iso,origin_time_us=us,latitude=float(Decimal(tokens[6])),longitude=float(Decimal(tokens[7])),depth_km=float(Decimal(tokens[8])),magnitude=float(Decimal(tokens[4])),magnitude_type=tokens[5],event_type=tokens[2],source_year=year,source_line_1based=line,source_tokens=dict(zip(FIELDS,tokens)),review_status=None,uncertainty=None,location_quality=tokens[9],geographic_type=tokens[3])


def equal_record(actual,expected):
    return isinstance(actual,dict) and set(actual)==set(expected) and actual==expected and all(type(actual[k]) is type(v) for k,v in expected.items())


def load_ca_lane(run,lane):
    """Validate every admitted canonical field against independently parsed raw."""
    run=Path(run);require(lane in ['train','protected'],'LANE')
    metadata_path=run/'design/catalogue_source_metadata.json';require(sha(metadata_path)==METADATA,'SOURCE_METADATA_IDENTITY');metadata=read(metadata_path)
    require(metadata['sha']==COMMIT and metadata['tree_truncated'] is False,'SOURCE_SNAPSHOT')
    folder=run/('inputs/california/train' if lane=='train' else 'protected/california');manifest_path=folder/'raw_manifest.json';manifest=read(manifest_path)
    require(manifest['schema_version']==4 and manifest['source_snapshot']==COMMIT,'RAW_MANIFEST_EPOCH')
    require(manifest['protocol_sha256']==sha(run/'design/acquisition_protocol_v2.json') and manifest['source_metadata_sha256']==METADATA,'RAW_MANIFEST_AUTHORITY')
    require(manifest['boundary_contract_sha256']==sha(run/'design/boundary_contract_v1.json'),'BOUNDARY_SCHEMA_IDENTITY')
    amendment_path=run/'design/quality_schema_amendment_v1.json';require(sha(amendment_path)==QUALITY_AMENDMENT and manifest['quality_schema_amendment_sha256']==QUALITY_AMENDMENT,'QUALITY_SCHEMA_IDENTITY')
    amendment=read(amendment_path);authority=amendment['preserved_authorities'];require(sha(run/'design/acquisition_protocol_v2.json')==authority['acquisition_protocol_v2_sha256'] and sha(run/'design/boundary_contract_v1.json')==authority['boundary_contract_v1_sha256'] and sha(run/'design/time_schema_amendment_v1.json')==authority['time_schema_amendment_v1_sha256'],'UNCHANGED_SOURCE_CONTRACTS');grammar=amendment['quality_grammar'];require(amendment['kind']=='user_authorized_lossless_quality_metadata_schema_amendment' and grammar['minimum_length']==1 and grammar['allowed_codepoint_inclusive']==[33,126] and grammar['whitespace_allowed_within_token'] is False and grammar['non_ASCII_allowed'] is False,'OPAQUE_QUALITY_CONTRACT')
    input_auth_path=run/'design/repair_input_authorization_v1.json';require(sha(input_auth_path)==REPAIR_INPUT_AUTHORIZATION and amendment['repair_input_authorization']['sha256']==REPAIR_INPUT_AUTHORIZATION,'REPAIR_INPUT_AUTHORITY');input_auth=read(input_auth_path)
    custody_path=run/'inputs/cached_raw_custody_v1.json';require(input_auth['cached_raw_custody']['sha256']==sha(custody_path),'CACHED_SOURCE_CUSTODY_BINDING');custody=read(custody_path);require(custody['status']=='copied_exact_original_official_snapshot' and custody['network_requests']==0 and custody['raw_files']==45,'CACHED_SOURCE_ONLY')
    custody_entries={e['file']:e for e in custody['files'] if e['lane']==lane}
    require(manifest['time_schema_amendment_sha256']==sha(run/'design/time_schema_amendment_v1.json'),'TIME_SCHEMA_IDENTITY')
    wanted=[e for e in metadata['selected_blobs'] if (int(Path(e['path']).stem)<2011)==(lane=='train')]
    require(len(wanted)==(30 if lane=='train' else 15),'ANNUAL_DENOMINATOR')
    actual={e['path']:e for e in manifest['files']};require(len(actual)==len(manifest['files'])==len(wanted) and set(actual)=={e['path'] for e in wanted},'RAW_MANIFEST_FILES')
    require(len(custody_entries)==len(wanted) and set(custody_entries)=={Path(e['path']).name for e in wanted},'CACHED_SOURCE_FILE_ROSTER')
    pins={};paths=[]
    for entry in wanted:
        record=actual[entry['path']];require(record['bytes']==entry['size'] and record['git_blob_sha1']==entry['sha'],'RAW_OFFICIAL_BLOB_BINDING')
        copied=custody_entries[Path(entry['path']).name];require(copied['bytes']==record['bytes'] and copied['sha256']==record['sha256'],'CACHED_RAW_BYTE_IDENTITY')
        path=folder/'raw'/Path(entry['path']).name;paths.append(path);pins[path.name]=record
    raw=R.read_annual_raw(paths,pins);needed_ids=set(raw['row_ids'])|{row['event_id'] for row in raw['diagnostic_rows']};tokens,index=source_tokens(paths,needed_ids)
    saved_index=read(folder/'raw_id_index.json');require(saved_index['source_snapshot']==COMMIT and saved_index['ids']==index,'ALL_RAW_ID_INDEX')
    model=read(folder/'canonical_model.json');diagnostic=read(folder/'canonical_diagnostic.json');retrieved=read(folder/'retrieval_receipt.json')['retrieved_utc'];R.utc(retrieved)
    provenance=dict(source_snapshot=COMMIT,raw_manifest_sha256=sha(manifest_path),retrieved_utc=retrieved,time_schema_amendment_sha256=manifest['time_schema_amendment_sha256'],quality_schema_amendment_sha256=manifest['quality_schema_amendment_sha256'])
    require(model['schema_version']==1 and model['catalogue_id']=='SCEDC-routine-revised-'+lane and model['provenance']==provenance,'CANONICAL_MODEL_HEADER')
    require(diagnostic['schema_version']==2 and diagnostic['representation']=='source_calendar_date_diagnostic' and diagnostic['catalogue_id']=='SCEDC-date-diagnostic-M2-'+lane and diagnostic['provenance']==provenance,'CANONICAL_DIAGNOSTIC_HEADER')
    require([e['event_id'] for e in model['events']]==raw['row_ids'],'CANONICAL_MODEL_ROW_IDENTITY')
    exact_times=[];excess=[]
    epoch=datetime(1981,1,1,tzinfo=timezone.utc)
    for i,event in enumerate(model['events']):
        source=tokens[event['event_id']];t=source['tokens'];iso=t[0].replace('/','-')+'T'+t[1]+'Z';us=int(raw['origin_us'][i]);expected=expected_record(t,source['year'],source['line'],us,iso)
        require(equal_record(event,expected),'CANONICAL_MODEL_FIELD_MISMATCH')
        # Independently execute the frozen datetime/POSIX-double input policy.
        # Source clocks/US were verified separately; no event cache supplies t.
        exact_times.append((R.utc(iso)-epoch).total_seconds()/86400.)
        excess.append(float(Decimal(t[4]))-4.)
    require([e['event_id'] for e in diagnostic['events']]==[e['event_id'] for e in raw['diagnostic_rows']],'DIAGNOSTIC_ROW_IDENTITY')
    for event,independent in zip(diagnostic['events'],raw['diagnostic_rows']):
        source=tokens[event['event_id']];t=source['tokens'];iso=None if independent['origin_time_us'] is None else t[0].replace('/','-')+'T'+t[1]+'Z'
        expected=expected_record(t,source['year'],source['line'],independent['origin_time_us'],iso);expected.update(source_date=independent['source_date'],clock_validation_status=independent['clock_validation_status'])
        require(equal_record(event,expected),'CANONICAL_DIAGNOSTIC_FIELD_MISMATCH')
    # Inputs used by the numerical procedure are independently recomputed from
    # raw tokens using the registered binary64 datetime/magnitude operations.
    raw['times']=np.asarray(exact_times);raw['excess']=np.asarray(excess)
    authority_paths=[metadata_path,run/'design/acquisition_protocol_v2.json',run/'design/boundary_contract_v1.json',run/'design/time_schema_amendment_v1.json',amendment_path,input_auth_path,custody_path,manifest_path,folder/'raw_id_index.json',folder/'canonical_model.json',folder/'canonical_diagnostic.json',folder/'retrieval_receipt.json',*paths]
    unchanged_training=None
    if lane=='train':
        for key,current in [('old_training_model',model),('old_training_diagnostic',diagnostic)]:
            previous=input_auth[key];previous_path=Path(previous['path']);require(sha(previous_path)==previous['sha256'],'OLD_TRAINING_CANONICAL_IDENTITY');prior=read(previous_path)
            require(prior['events']==current['events'],'EXACT_PREDECESSOR_TRAINING_ALL_EVENT_FIELDS');authority_paths.append(previous_path)
        unchanged_training=dict(model_events_exact=True,diagnostic_events_exact=True,only_header_and_provenance_epoch_changed=True)
    bindings={str(Path(path).resolve()):sha(path) for path in authority_paths}
    return dict(raw=raw,diagnostic=raw['diagnostic_rows'],raw_id_index=index,canonical_sha256=sha(folder/'canonical_model.json'),diagnostic_sha256=sha(folder/'canonical_diagnostic.json'),raw_manifest_sha256=sha(manifest_path),raw_bytes=sum(e['bytes'] for e in manifest['files']),file_count=len(paths),bindings=bindings,quality_schema_amendment_sha256=QUALITY_AMENDMENT,unchanged_predecessor_training=unchanged_training)


def merge_ca(train,protected):
    require(not (train['raw_id_index'].keys()&protected['raw_id_index'].keys()),'CROSS_LANE_RAW_ID_CONFLICT')
    a,b=train['raw'],protected['raw'];order=np.lexsort((np.asarray(a['row_ids']+b['row_ids']),np.r_[a['times'],b['times']]))
    raw={k:np.r_[a[k],b[k]][order] for k in ['times','excess','latitude','longitude','cells','source_year','source_line','origin_us']}
    raw['xy']=np.vstack([a['xy'],b['xy']])[order];raw['row_ids']=[(a['row_ids']+b['row_ids'])[i] for i in order];raw['rectangles']=a['rectangles']
    return dict(raw=raw,diagnostic=sorted(train['diagnostic']+protected['diagnostic'],key=lambda e:(e['source_date'],e['event_id'])))


def ca_training_admission(raw,diagnostic,cutoff_year):
    require(cutoff_year in [2011,2016,2021],'FROZEN_TRAINING_ORIGIN')
    periods=(cutoff_year-1981)//5;counts=np.zeros((periods,3),dtype=int);hist=np.zeros((periods,3,65),dtype=int);overflow=0
    for row in diagnostic:
        year=int(row['source_date'][:4])
        if not 1981<=year<cutoff_year:continue
        period=(year-1981)//5;zone=int(row['cell'])//3;mag=Decimal(row['magnitude']);counts[period,zone]+=1
        if mag>Decimal('8.5'):overflow+=1
        else:hist[period,zone,min(int((mag-2)*10),64)]+=1
    corrected=[];flags=[]
    for p in range(periods):
        for z in range(3):
            mode=max(i for i,n in enumerate(hist[p,z]) if n==int(hist[p,z].max()));value=Decimal('2.55')+Decimal(mode)/10;corrected.append(str(value));flags.append(bool(counts[p,z]>=100 and value<=4 and overflow==0))
    epoch=datetime(1981,1,1,tzinfo=timezone.utc);start=(datetime(1986,1,1,tzinfo=timezone.utc)-epoch).days;end=(datetime(cutoff_year,1,1,tzinfo=timezone.utc)-epoch).days;mask=(raw['times']>=start)&(raw['times']<end);zones=np.bincount(raw['cells'][mask]//3,minlength=3)
    return dict(cutoff_year=cutoff_year,scored_training_events=int(mask.sum()),training_zone_counts=zones.tolist(),stratum_counts=counts.ravel().tolist(),corrected_modal_values=corrected,stratum_admitted=flags,overflow=overflow,admitted=bool(all(flags) and mask.sum()>=180 and np.all(zones>=30)))


def read_legacy_nz(path,metadata_path):
    require(sha(path)==NZ_HASH and sha(metadata_path)==NZ_METADATA,'LEGACY_NZ_SOURCE_IDENTITY');metadata=read(metadata_path)
    require(metadata['processed_sha256']==NZ_HASH and metadata['local_filters']['depth']=='finite <=40 km, excluding unknown sentinel -9 km; other negative depths retained','LEGACY_NZ_POPULATION_METADATA')
    with Path(path).open(newline='',encoding='utf-8-sig') as stream:rows=list(csv.DictReader(stream))
    require(len(rows)==913,'LEGACY_NZ_913_DENOMINATOR');ids=[];t=[];q=[];lat=[];lon=[];previous=None;time_error=0.
    for row in rows:
        try:
            identity=row['event_id'];stamp=R.utc(row['time_utc']);td=float(row['t_days']);mag=float(row['magnitude']);excess=float(row['excess']);depth=float(row['depth']);latitude=float(row['latitude']);longitude=float(row['longitude'])
            require(bool(identity) and row['event_type']=='earthquake' and row['magnitude_type']!='' and np.isfinite([td,mag,excess,depth,latitude,longitude]).all(),'LEGACY_NZ_ROW_SCHEMA')
            require(depth<=40 and depth!=-9 and mag>=5 and excess>=0 and 165<=longitude<=180 and -48.5<=latitude<=-33.5 and R.utc('1960-01-01T00:00:00Z')<=stamp<R.utc('2026-10-15T00:00:00Z'),'LEGACY_NZ_ROW_POPULATION')
            computed=(stamp-R.utc('1960-01-01T00:00:00Z')).total_seconds()/86400.;time_error=max(time_error,abs(td-computed));require(abs(td-computed)<=1e-9 and abs(mag-5-excess)<=2e-12,'LEGACY_NZ_NUMERIC_PREPARATION')
            key=(td,identity);require(previous is None or previous<=key,'LEGACY_NZ_CHRONOLOGY');previous=key
            ids.append(identity);t.append(td);q.append(excess);lat.append(latitude);lon.append(longitude)
        except Exception:raise ValueError('LEGACY_NZ_ROW_INVALID') from None
    require(len(set(ids))==913,'LEGACY_NZ_IDENTITY');cfg=PROFILES['new_zealand'];xy=O.project(lat,lon,cfg['phi0'],cfg['lambda0']);rect=O.rectangles(cfg['latitude_edges'],cfg['longitude_edges'],cfg['phi0'],cfg['lambda0'])
    return dict(times=np.asarray(t),excess=np.asarray(q),latitude=np.asarray(lat),longitude=np.asarray(lon),xy=xy,cells=O.labels(xy,rect),rectangles=rect,row_ids=ids,catalogue_sha256=NZ_HASH,maximum_utc_t_days_difference=time_error,source_population='finite depth<=40 excluding-9; other negative retained')
