"""Independent preferred-QuakeML RAW reconstruction; no production imports.
Author from frozen source contract, never from empirical rows. Root leases runs.
Only fixed failure labels or aggregate count/hash/field-check receipts escape.
"""
import argparse,hashlib,json,math,re
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
import xml.etree.ElementTree as ET
import urllib.parse

Q='{http://quakeml.org/xmlns/quakeml/1.2}'
B='{http://quakeml.org/xmlns/bed/1.2}'
CAP=134217728
CONTRACT_SHA='921cd589b8438cee16898bbb88e73de5e33ca142084016a167d7ae8ceeae40cf'
DEPS=('parse_capture_xml.py','xml_cohort_contract_v1.json')
BASE_QUERY=dict(starttime='1960-01-01T00:00:00Z',minlatitude='-48.5',maxlatitude='-33.5',minlongitude='165',maxlongitude='180',minmagnitude='4.9',eventtype='earthquake',format='xml',orderby='time-asc',nodata='404')
CONTROLS=dict(schema='geonet-quakeml-preferred-1.2-v1',max_records=5000,minimum_records=1,forbid_pagination=True,rely_on_unpaginated_service_contract=True,require_complete_xml_document=True,forbid_dtd_entities=True)
NUMERIC=('latitude','longitude','magnitude','depth_km','source_depth_m')
FIELDS=('event_id','origin_time_utc','origin_time_us','latitude','longitude','depth_km','magnitude','magnitude_type','event_type','source_year','source_line_1based','source_event_index_1based','source_event_public_id','source_preferred_origin_id','source_preferred_magnitude_id','source_depth_m')
OPTIONAL_ASSOCIATIONS=('source_magnitude_origin_id','source_preferred_magnitude_origin_id')
REASONS=('excluded_magnitude_below5','excluded_unknown_depth_sentinel','excluded_depth_above40','kept_shallow_M5')


class AuditError(Exception):
    def __init__(self,code):self.code=code;super().__init__(code)

def require(ok,code):
    if not ok:raise AuditError(code)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def utc(value):
    require(type(value) is str and re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|\+00:00)',value) is not None,'XML_RAW_UTC_SCHEMA')
    try:return datetime.fromisoformat(value.replace('Z','+00:00'))
    except Exception:raise AuditError('XML_RAW_UTC_CALENDAR') from None

def us(value):
    delta=utc(value)-datetime(1970,1,1,tzinfo=timezone.utc)
    return (delta.days*86400+delta.seconds)*1000000+delta.microseconds

def number(token):
    require(type(token) is str and token==token.strip() and bool(token),'XML_RAW_DECIMAL_TOKEN')
    require(re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',token) is not None,'XML_RAW_DECIMAL_LEXICAL')
    try:value=Decimal(token)
    except Exception:raise AuditError('XML_RAW_DECIMAL_SCHEMA') from None
    require(value.is_finite() and math.isfinite(float(value)),'XML_RAW_DECIMAL_FINITE')
    return value

def one(node,name,optional=False):
    values=node.findall(B+name)
    require(len(values)==1 or optional and not values,'XML_RAW_REQUIRED_CHILD_CARDINALITY')
    return values[0] if values else None

def text(node,path,optional=False):
    for i,name in enumerate(path.split('/')):
        node=one(node,name,optional=optional and i==0)
        if node is None:return None
    require(node.text is not None and bool(node.text.strip()),'XML_RAW_REQUIRED_TEXT')
    return node.text.strip()

def resource(node):
    value=node.get('publicID')
    require(type(value) is str and value==value.strip() and bool(value),'XML_RAW_PUBLIC_ID')
    return value


def reconstruct(raw,query):
    require(0<len(raw)<=CAP,'XML_RAW_BYTE_CAP')
    try:decoded=raw.decode('utf-8-sig')
    except Exception:raise AuditError('XML_RAW_UTF8') from None
    require('\x00' not in decoded and re.search(r'<!\s*(?:DOCTYPE|ENTITY)\b',decoded,re.I) is None,'XML_RAW_DTD_ENTITY_FORBIDDEN')
    declaration=re.match(r'\s*<\?xml[^?]*encoding\s*=\s*["\']([^"\']+)',decoded,re.I)
    require(declaration is None or declaration.group(1).lower() in ['utf-8','utf8'],'XML_RAW_ENCODING_DECLARATION')
    try:root=ET.fromstring(decoded)
    except Exception:raise AuditError('XML_RAW_DOCUMENT_PARSE') from None
    require(root.tag==Q+'quakeml','XML_RAW_ROOT_NAMESPACE')
    eps=root.findall(B+'eventParameters');require(len(eps)==1,'XML_RAW_EVENT_PARAMETERS')
    events=eps[0].findall(B+'event');require(0<len(events)<5000,'XML_RAW_BROAD_RECORD_CAP')
    require(len(list(root.iter(B+'event')))==len(events),'XML_RAW_EVENT_PLACEMENT')
    global_ids=set();normalized=set();rows=[];hist={k:{} for k in ['magnitude','latitude','longitude','depth_m','depth_km']};origin_count=magnitude_count=0
    for ordinal,event in enumerate(events,1):
        public=resource(event);identity=public.rsplit('/',1)[-1];require(bool(identity),'XML_RAW_ID_TAIL')
        event_id='geonet:'+identity;require(event_id not in normalized,'XML_RAW_NORMALIZED_ID_COLLISION');normalized.add(event_id)
        origins=event.findall(B+'origin');magnitudes=event.findall(B+'magnitude');origin_count+=len(origins);magnitude_count+=len(magnitudes)
        for node in [event]+origins+magnitudes:
            value=resource(node);require(value not in global_ids,'XML_RAW_GLOBAL_RESOURCE_DUPLICATE');global_ids.add(value)
        origin_map={resource(node):node for node in origins};mag_map={resource(node):node for node in magnitudes}
        preferred_origin=text(event,'preferredOriginID');preferred_mag=text(event,'preferredMagnitudeID')
        require(preferred_origin in origin_map and preferred_mag in mag_map,'XML_RAW_DANGLING_PREFERRED_REFERENCE')
        require(text(event,'type')=='earthquake','XML_RAW_EVENT_TYPE')
        origin=origin_map[preferred_origin];mag=mag_map[preferred_mag];association=text(mag,'originID',optional=True)
        require(association is None or association in origin_map,'XML_RAW_MAGNITUDE_ORIGIN_ASSOCIATION')
        stamp=text(origin,'time/value');clock=utc(stamp);clock_us=us(stamp)
        latitude=text(origin,'latitude/value');longitude=text(origin,'longitude/value');depth_m=text(origin,'depth/value');magnitude=text(mag,'mag/value');magtype=text(mag,'type')
        lat,lon,dm,m=map(number,[latitude,longitude,depth_m,magnitude]);parts=dm.as_tuple();dk=Decimal((parts.sign,parts.digits,parts.exponent-3));require(math.isfinite(float(dk)),'XML_RAW_DEPTH_CONVERSION_FINITE')
        require(utc(query['starttime'])<=clock<=utc(query['endtime']) and Decimal(query['minlatitude'])<=lat<=Decimal(query['maxlatitude']) and Decimal(query['minlongitude'])<=lon<=Decimal(query['maxlongitude']) and m>Decimal(query['minmagnitude']),'XML_RAW_QUERY_POPULATION')
        require(not origin.find(B+'depth').attrib and not one(origin.find(B+'depth'),'value').attrib,'XML_RAW_UNKNOWN_DEPTH_UNIT_OR_SCHEMA')
        row=dict(event_id=event_id,origin_time_utc=stamp,origin_time_us=clock_us,latitude=latitude,longitude=longitude,depth_km=str(dk),magnitude=magnitude,magnitude_type=magtype,event_type='earthquake',source_year=clock.year,source_line_1based=ordinal,source_event_index_1based=ordinal,source_event_public_id=public,source_preferred_origin_id=preferred_origin,source_preferred_magnitude_id=preferred_mag,source_depth_m=depth_m)
        reasons=[]
        if m<5:reasons.append(REASONS[0])
        if dk==-9:reasons.append(REASONS[1])
        if dk>40:reasons.append(REASONS[2])
        rows.append(dict(row=row,association=association,reasons=reasons,selected=not reasons,primary_reason=reasons[0] if reasons else REASONS[3]))
        for key,token in [('magnitude',magnitude),('latitude',latitude),('longitude',longitude),('depth_m',depth_m),('depth_km',str(dk))]:
            mantissa=token.lower().split('e',1)[0];places=str(len(mantissa.partition('.')[2]));hist[key][places]=hist[key].get(places,0)+1
    require(len(list(root.iter(B+'origin')))==origin_count and len(list(root.iter(B+'magnitude')))==magnitude_count,'XML_RAW_SOLUTION_PLACEMENT')
    ordered=sorted(rows,key=lambda item:(item['row']['origin_time_us'],item['row']['event_id']));selected=[item for item in ordered if item['selected']];require(bool(selected),'XML_RAW_EMPTY_SCIENTIFIC_COHORT')
    return rows,ordered,selected,hist


def compare_events(actual,expected,field_checks):
    require(type(actual) is list and len(actual)==len(expected),'XML_RAW_CANONICAL_ROW_DENOMINATOR')
    for saved,item in zip(actual,expected):
        row=item['row'];require(type(saved) is dict and set(FIELDS)<=set(saved) and set(saved)<=set(FIELDS)|set(OPTIONAL_ASSOCIATIONS),'XML_RAW_CANONICAL_FIELD_ROSTER')
        for key in FIELDS:
            value=saved[key];target=row[key]
            if key in NUMERIC:
                require(number(value)==number(target),'XML_RAW_CANONICAL_DECIMAL_VALUE')
                if key=='source_depth_m':require(value==target,'XML_RAW_CANONICAL_SOURCE_DEPTH_TOKEN')
            elif key=='origin_time_utc':require(us(value)==row['origin_time_us'],'XML_RAW_CANONICAL_CLOCK_VALUE')
            else:require(type(value) is type(target) and value==target,'XML_RAW_CANONICAL_FIELD_VALUE')
            field_checks[key]=field_checks.get(key,0)+1
        for key in set(saved)&set(OPTIONAL_ASSOCIATIONS):require(saved[key]==item['association'],'XML_RAW_CANONICAL_MAGNITUDE_ASSOCIATION');field_checks[key]=field_checks.get(key,0)+1


def audit(capture_root,query_file,query_sha,source_directory,include_precision=False):
    capture_root=Path(capture_root).resolve();source_directory=Path(source_directory).resolve();query_file=Path(query_file).resolve();require(sha(query_file)==query_sha,'XML_RAW_EXPECTED_QUERY_HASH')
    spec=read(query_file);require(type(spec) is dict and type(spec.get('query')) is dict,'XML_RAW_TRUSTED_QUERY_DESCRIPTOR');query=spec['query'];expected_design=spec.get('design_sha256',query_sha);require(type(expected_design) is str and re.fullmatch('[0-9a-f]{64}',expected_design) is not None,'XML_RAW_EXPECTED_DESIGN_HASH')
    require(type(query) is dict and set(query)==set(BASE_QUERY)|{'endtime'} and all(query[k]==v for k,v in BASE_QUERY.items()),'XML_RAW_FIXED_QUERY');require(utc(query['endtime'])>=utc(query['starttime']),'XML_RAW_QUERY_INTERVAL')
    files={key:capture_root/name for key,name in dict(receipt='capture_receipt.json',raw='raw_response.xml',broad='canonical_broad_preferred_history.json',cohort='canonical_shallow_m5_history.json',ledger='cohort_reference_exclusion_ledger.json').items()};receipt=read(files['receipt']);require(files['raw'].is_file() and 0<files['raw'].stat().st_size<=CAP,'XML_RAW_PRELOAD_BYTE_CAP');raw=files['raw'].read_bytes();digest=hashlib.sha256(raw).hexdigest()
    require(receipt['query']==query and Path(receipt['raw_path']).resolve()==files['raw'] and receipt['raw_sha256']==digest,'XML_RAW_CAPTURE_QUERY_HASH_REFERENCE')
    if expected_design is not None:require(receipt['design_sha256']==expected_design,'XML_RAW_CAPTURE_DESIGN_REFERENCE')
    for key,field in [('broad','broad_canonical_sha256'),('cohort','canonical_sha256'),('ledger','cohort_ledger_sha256')]:require(sha(files[key])==receipt[field],'XML_RAW_ARTIFACT_HASH_REFERENCE')
    require(set(receipt['parser_dependency_pins'])==set(DEPS) and receipt['parser_dependency_pins']['parse_capture_xml.py']==receipt['parser_sha256'] and receipt['parser_dependency_pins']['xml_cohort_contract_v1.json']==CONTRACT_SHA,'XML_RAW_PARSER_CLOSURE_REFERENCE')
    for name,digest_expected in receipt['parser_dependency_pins'].items():require(sha(source_directory/name)==digest_expected,'XML_RAW_PARSER_CURRENT_IDENTITY')
    provenance=receipt['provenance'];require(set(provenance)=={'source_snapshot','raw_manifest_sha256','retrieved_utc'} and provenance['raw_manifest_sha256']==digest and type(provenance['source_snapshot']) is str and bool(provenance['source_snapshot']),'XML_RAW_CAPTURE_PROVENANCE');received=utc(provenance['retrieved_utc'])
    attempts=sorted(capture_root.glob('attempt_[0-9][0-9]/private_transport_receipt.json'));require(1<=len(attempts)<=3 and [p.parent.name for p in attempts]==[f'attempt_{i:02d}' for i in range(1,len(attempts)+1)],'XML_RAW_TRANSPORT_ATTEMPT_CUSTODY')
    attempt_raws=[]
    for i,path in enumerate(attempts):
        entry=read(path);require(entry['query']==query and entry['endpoint']=='https://service.geonet.org.nz/fdsnws/event/1/query','XML_RAW_ATTEMPT_FIXED_QUERY');body=path.parent/'raw_response.xml';require(Path(entry['raw_path']).resolve()==body,'XML_RAW_ATTEMPT_BODY_PATH')
        if body.exists():require(entry['raw_sha256']==sha(body) and entry['stored_bytes']==body.stat().st_size and 0<=body.stat().st_size<=CAP,'XML_RAW_ATTEMPT_BODY_HASH');attempt_raws.append(body)
        else:require(entry['raw_sha256'] is None and entry['stored_bytes']==0,'XML_RAW_ATTEMPT_MISSING_BODY')
        if i<len(attempts)-1:require(entry['retry'] is True and entry['error_code'] in ['TRANSIENT_BODY_FAILURE','TRANSIENT_CONNECTION_FAILURE','HTTP_STATUS_UNEXPECTED'],'XML_RAW_FIXED_RETRY_CUSTODY')
    transport=read(attempts[-1]);require(transport['query']==query and transport['endpoint']=='https://service.geonet.org.nz/fdsnws/event/1/query' and transport['status']==200 and transport['error_code'] is None and transport['closed_eof'] is True,'XML_RAW_ACCEPTED_TRANSPORT')
    require(Path(transport['raw_path']).resolve()==attempts[-1].parent/'raw_response.xml' and sha(transport['raw_path'])==digest and transport['raw_sha256']==digest and transport['stored_bytes']==len(raw) and transport['observed_bytes']==len(raw),'XML_RAW_ACCEPTED_BODY_CUSTODY')
    require(utc(transport['request_start_utc'])<=utc(transport['response_completed_utc'])==received and utc(query['endtime'])<=utc(transport['request_start_utc']),'XML_RAW_CAPTURE_CLOCK_METADATA')
    final=urllib.parse.urlsplit(transport['final_url']);pairs=urllib.parse.parse_qsl(final.query,keep_blank_values=True);require((final.scheme,final.netloc,final.path,final.fragment)==('https','service.geonet.org.nz','/fdsnws/event/1/query','') and len(pairs)==len(query) and dict(pairs)==query,'XML_RAW_FINAL_URL_FIXED_QUERY')
    header=transport['headers'];require((header.get('Content-Encoding') or '').strip().lower() in ['', 'identity'] and (header.get('Content-Type') or '').split(';',1)[0].strip().lower() in ['application/xml','text/xml','application/quakeml+xml','application/vnd.quakeml+xml'],'XML_RAW_RESPONSE_HEADER_CONTRACT')
    if header.get('Content-Length') is not None:require(re.fullmatch(r'[0-9]+',header['Content-Length'].strip()) is not None and int(header['Content-Length'])==len(raw) and transport['content_length_match'] is True,'XML_RAW_TRANSPORT_LENGTH')
    else:require(transport['content_length_match'] is None,'XML_RAW_NO_INVENTED_LENGTH')
    rows,ordered,selected,hist=reconstruct(raw,query);field_checks={};broad=read(files['broad']);cohort=read(files['cohort'])
    for canonical,expected in [(broad,ordered),(cohort,selected)]:
        require(canonical['schema_version']==1 and canonical['provenance']==provenance and type(canonical['catalogue_id']) is str and bool(canonical['catalogue_id']),'XML_RAW_CANONICAL_METADATA');compare_events(canonical['events'],expected,field_checks)
    ledger_doc=read(files['ledger']);require(ledger_doc['raw_sha256']==digest and ledger_doc['query']==query,'XML_RAW_LEDGER_METADATA');ledger=ledger_doc['rows'];require(type(ledger) is list and len(ledger)==len(rows),'XML_RAW_LEDGER_DENOMINATOR');counts={key:0 for key in REASONS}
    private_ledger=receipt['completeness_evidence']['eligibility_ledger_private'];require(type(private_ledger) is list and len(private_ledger)==len(rows),'XML_RAW_PRIVATE_EVIDENCE_LEDGER_DENOMINATOR')
    for entry,private_entry,item in zip(ledger,private_ledger,rows):
        row=item['row'];expected=dict(event_id=row['event_id'],source_line_1based=row['source_line_1based'],source_event_index_1based=row['source_event_index_1based'],selected=item['selected'],primary_reason=item['primary_reason'],all_exclusion_reasons=item['reasons'],source_event_public_id=row['source_event_public_id'],source_preferred_origin_id=row['source_preferred_origin_id'],source_preferred_magnitude_id=row['source_preferred_magnitude_id'],source_depth_m=row['source_depth_m'])
        require(type(entry) is dict and set(entry)==set(expected),'XML_RAW_LEDGER_FIELD_ROSTER')
        for key,value in expected.items():require(type(entry[key]) is type(value) and entry[key]==value,'XML_RAW_LEDGER_SOURCE_VALUE');field_checks['ledger_'+key]=field_checks.get('ledger_'+key,0)+1
        core={'event_id','source_line_1based','source_event_index_1based','selected','primary_reason','all_exclusion_reasons'};require(type(private_entry) is dict and core<=set(private_entry)<=set(expected),'XML_RAW_PRIVATE_EVIDENCE_LEDGER_FIELDS')
        for key,value in private_entry.items():require(type(value) is type(expected[key]) and value==expected[key],'XML_RAW_PRIVATE_EVIDENCE_LEDGER_VALUE');field_checks['evidence_ledger_'+key]=field_checks.get('evidence_ledger_'+key,0)+1
        counts[item['primary_reason']]+=1
    evidence=receipt['completeness_evidence'];require(evidence['complete'] is True and evidence['truncation_detected'] is False and type(evidence['controls']) is dict and set(evidence['controls'])==set(CONTROLS) and all(type(evidence['controls'][k]) is type(v) and evidence['controls'][k]==v for k,v in CONTROLS.items()),'XML_RAW_COMPLETENESS_METADATA')
    require(all(type(evidence.get(k)) is int for k in ['full_query_record_count','cohort_record_count','record_count']) and evidence['full_query_record_count']==len(rows) and evidence['cohort_record_count']==len(selected) and evidence['record_count']==len(selected) and type(evidence['eligibility_reason_counts']) is dict and set(evidence['eligibility_reason_counts'])==set(counts) and all(type(v) is int for v in evidence['eligibility_reason_counts'].values()) and evidence['eligibility_reason_counts']==counts,'XML_RAW_EVIDENCE_COUNTS');require(receipt['source_API_unpaginated_contract_verified'] is False and receipt['physical_detection_completeness_verified'] is False and receipt['operational_registration_source_admitted'] is False,'XML_RAW_CLAIM_SCOPE')
    nested=evidence['full_query_parse_evidence'];require(nested['complete'] is True and nested['truncation_detected'] is False and nested['controls']==evidence['controls'] and type(nested['record_count']) is int and nested['record_count']==len(rows),'XML_RAW_BROAD_EVIDENCE_METADATA')
    bindings={str(path.resolve()):sha(path) for path in list(files.values())+[query_file]+attempts+attempt_raws+[source_directory/name for name in DEPS]}
    result=dict(status='passed',passed=True,independent=True,scope='Independent directRAW preferredXML/fullcohort/canonical/ledger/metadata reconstruction; no productionparserimports orDLL',data_classification='local_verified_source_XML',raw_sha256=digest,canonical_sha256=receipt['canonical_sha256'],broad_canonical_sha256=receipt['broad_canonical_sha256'],ledger_sha256=receipt['cohort_ledger_sha256'],query_file_sha256=query_sha,bytes=len(raw),broad_records=len(rows),cohort_records=len(selected),exclusive_reason_counts=counts,field_checks=sum(field_checks.values()),field_check_counts=field_checks,bindings=bindings,physical_detection_completeness_proved=False,source_API_unpaginated_assumption_remains=True,operational_registration_admitted=False)
    if include_precision:result['source_serialized_numeric_fractional_digit_histograms']=hist
    return result


def self_controls(fixture_path):
    """Root-leased handcrafted source-reader controls; never reads a catalogue."""
    fx=read(fixture_path);checks=[]
    def check(label,condition):require(bool(condition),'XML_RAW_SELF_CONTROL_FAILED');checks.append(label)
    def reject(label,raw):
        caught=False
        try:reconstruct(raw,fx['query'])
        except AuditError:caught=True
        check(label,caught)
    raw=fx['valid_xml'].encode();rows,ordered,selected,hist=reconstruct(raw,fx['query']);row=ordered[0]['row']
    check('preferred_identity',row['event_id']==fx['expected']['valid_id'])
    check('preferred_exact_magnitude',row['magnitude']==fx['expected']['valid_magnitude'])
    check('exact_metres_to_km',row['depth_km']==fx['expected']['valid_depth_km'])
    check('integer_microsecond_clock',row['origin_time_us']==fx['expected']['valid_origin_time_us'])
    check('single_complete_record',len(rows)==len(ordered)==len(selected)==1)
    full,ordered,cohort,_=reconstruct(fx['cohort_xml'].encode(),fx['query'])
    check('all_broad_rows_before_filter',len(full)==fx['expected']['cohort_full_count'])
    check('exact_scientific_membership',[i['row']['event_id'] for i in cohort]==fx['expected']['cohort_selected_ids'])
    check('source_ordinals_retained',[i['row']['source_event_index_1based'] for i in cohort]==fx['expected']['cohort_source_ordinals'])
    check('reason_count_reconstruction',{reason:sum(i['primary_reason']==reason for i in full) for reason in REASONS}==fx['expected']['exclusive_counts'])
    reject('server_strict_boundary',fx['strict_server_boundary_xml'].encode())
    reject('truncated_document',raw[:-10])
    reject('forbidden_doctype',b'<!DOCTYPE q:quakeml [<!ENTITY SYN "x">]>'+raw)
    reject('wrong_namespace',raw.replace(b'http://quakeml.org/xmlns/quakeml/1.2',b'http://example.invalid/wrong'))
    reject('preferred_reference_missing',raw.replace(b'<preferredOriginID>',b'<SYNwrong>').replace(b'</preferredOriginID>',b'</SYNwrong>'))
    reject('invalid_clock_seconds',raw.replace(b'04:05:06.123456Z',b'04:05:60.123456Z'))
    reject('unsupported_clock_precision',raw.replace(b'04:05:06.123456Z',b'04:05:06.1234567Z'))
    saved=dict(row);field_checks={};compare_events([saved],[rows[0]],field_checks);check('exact_canonical_baseline',len(field_checks)==len(FIELDS))
    saved['magnitude']='5';caught=False
    try:compare_events([saved],[rows[0]],{})
    except AuditError:caught=True
    check('decimal_quantization_loss_rejected',caught)
    return dict(status='passed',passed=True,scope='Wholly handcrafted independent RAW XML reader controls',checks=len(checks),network_requests=0,production_imports=0,dll_loads=0,fits=0)


def main():
    p=argparse.ArgumentParser();p.add_argument('--capture-root',required=True);p.add_argument('--expected-query',required=True);p.add_argument('--expected-query-sha256',required=True);p.add_argument('--source-directory',required=True);p.add_argument('--include-precision',action='store_true');p.add_argument('--output',required=True);a=p.parse_args()
    try:result=audit(a.capture_root,a.expected_query,a.expected_query_sha256,a.source_directory,a.include_precision)
    except Exception as error:result=dict(status='failed',passed=False,independent=True,fixed_error_code=error.code if isinstance(error,AuditError) else 'XML_RAW_SOURCE_AUDIT_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['status','passed','fixed_error_code','error_type','raw_sha256','canonical_sha256','bytes','broad_records','cohort_records','field_checks'] if k in result},allow_nan=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
