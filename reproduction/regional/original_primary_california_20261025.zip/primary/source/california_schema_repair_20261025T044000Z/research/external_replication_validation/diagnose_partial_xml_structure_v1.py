"""Standalone root-leased tag-count diagnosis of an INCOMPLETE XML prefix.
No XML event/value/attribute parsing, no source query, no production imports.
Tag counts never certify a complete response, valid source or eligible events.
"""
import argparse,hashlib,json,re
from pathlib import Path

CAP=134217728
QUERY=dict(starttime='1960-01-01T00:00:00Z',endtime='2026-10-15T00:00:00Z',minlatitude='-48.5',maxlatitude='-33.5',minlongitude='165',maxlongitude='180',minmagnitude='4.9',eventtype='earthquake',format='xml',orderby='time-asc',nodata='404')
NAMES=('event','origin','magnitude','pick','arrival','stationMagnitude','amplitude')
# Match comments/CDATA/processing instructions/declarations before start tags.
# Attribute bodies are only skipped, never extracted, decoded, saved or emitted.
TOKENS=re.compile(rb"<!--.*?(?:-->|$)|<!\[CDATA\[.*?(?:\]\]>|$)|<\?.*?(?:\?>|$)|<![^>]*(?:>|$)|<(?P<closing>/)?(?P<qname>(?:[A-Za-z_][A-Za-z0-9_.-]*:)?[A-Za-z_][A-Za-z0-9_.-]*)(?=[\x20\t\r\n/>])(?:[^\"'<>]|\"[^\"]*\"|'[^']*')*>",re.S)


class DiagnosticError(Exception):
    def __init__(self,code):self.code=code;super().__init__(code)

def require(ok,code):
    if not ok:raise DiagnosticError(code)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def count_tags(raw):
    require(type(raw) is bytes,'PARTIAL_XML_INPUT_TYPE')
    counts={name:0 for name in NAMES}
    for token in TOKENS.finditer(raw):
        name=token.group('qname')
        if name is None or token.group('closing') is not None:continue
        local=name.rsplit(b':',1)[-1]
        for allowed in NAMES:
            if local==allowed.encode('ascii'):counts[allowed]+=1;break
    return counts


def diagnose(raw_path,raw_sha,transport_path,transport_sha):
    raw_path=Path(raw_path).resolve();transport_path=Path(transport_path).resolve()
    require(re.fullmatch('[0-9a-f]{64}',raw_sha) is not None and re.fullmatch('[0-9a-f]{64}',transport_sha) is not None,'PARTIAL_XML_EXPECTED_HASH_SCHEMA')
    require(sha(transport_path)==transport_sha,'PARTIAL_XML_TRANSPORT_IDENTITY')
    transport=json.loads(transport_path.read_text(encoding='utf-8-sig'))
    require(transport['query']==QUERY and transport['endpoint']=='https://service.geonet.org.nz/fdsnws/event/1/query','PARTIAL_XML_DECLARED_QUERY')
    require(Path(transport['raw_path']).resolve()==raw_path and transport['raw_sha256']==raw_sha,'PARTIAL_XML_RAW_REFERENCE')
    require(transport['status']==200 and transport['error_code']=='RESPONSE_BYTE_CAP' and transport['closed_eof'] is False,'PARTIAL_XML_CAP_FAILURE_REQUIRED')
    size=raw_path.stat().st_size;require(size==CAP and transport['stored_bytes']==size and transport['observed_bytes']>size,'PARTIAL_XML_BOUNDED_PREFIX_CUSTODY')
    headers=transport['headers'];require((headers.get('Content-Encoding') or '').strip().lower() in ['', 'identity'] and (headers.get('Content-Type') or '').split(';',1)[0].strip().lower() in ['application/xml','text/xml','application/quakeml+xml','application/vnd.quakeml+xml'],'PARTIAL_XML_UNSUPPORTED_TRANSPORT_REPRESENTATION')
    raw=raw_path.read_bytes();require(len(raw)==size and hashlib.sha256(raw).hexdigest()==raw_sha,'PARTIAL_XML_RAW_IDENTITY')
    return dict(status='diagnostic_completed',scope='Lexical opening-tag counts in preserved incomplete response prefix; not XML/source/population validation',query=dict(QUERY),bytes=size,raw_sha256=raw_sha,transport_sha256=transport_sha,opening_tag_counts=count_tags(raw),closed_eof=False,response_complete=False,source_admitted=False,counts_are_eligible_or_cohort_events=False,limitations='Counts include namespace-local opening tag tokens only; comments/CDATA/PI/declarations skipped. No preferred-reference, namespace, schema, completeness or population interpretation. No values/attributes/IDs read into output.')


def self_controls():
    checks=0
    def check(ok):
        nonlocal checks
        require(bool(ok),'PARTIAL_XML_SYN_CONTROL_FAILED');checks+=1
    result=count_tags(b'<q:event><origin/><q:magnitude note="SYN"/><pick/><q:arrival/><stationMagnitude/><a:amplitude/></q:event>')
    check(result=={name:1 for name in NAMES})
    check(count_tags(b'<eventParameters/><eventType/><events/>')=={name:0 for name in NAMES})
    check(count_tags(b'<!-- <event/> --><event/>')['event']==1)
    check(count_tags(b'<![CDATA[<origin/>]]><origin/>')['origin']==1)
    check(count_tags(b'<?SYN <pick/> ?><pick/>')['pick']==1)
    check(count_tags(b'<other note="<event/>"></other>')['event']==0)
    check(count_tags(b'<event/><origin')=={name:int(name=='event') for name in NAMES})
    check(count_tags(b'<event/><!-- <origin/>')['origin']==0)
    check(count_tags(b'<magnitude/><![CDATA[<arrival/>')['arrival']==0)
    return dict(status='diagnostic_controls_passed',checks=checks,network_requests=0,production_imports=0,event_values_emitted=False)


def main():
    cli=argparse.ArgumentParser();cli.add_argument('--raw');cli.add_argument('--expected-raw-sha256');cli.add_argument('--transport-receipt');cli.add_argument('--expected-transport-sha256');cli.add_argument('--self-controls',action='store_true');cli.add_argument('--output',required=True);a=cli.parse_args()
    try:
        if a.self_controls:
            require(all(v is None for v in [a.raw,a.expected_raw_sha256,a.transport_receipt,a.expected_transport_sha256]),'PARTIAL_XML_SYN_ONLY_ARGUMENTS');result=self_controls()
        else:
            require(all(type(v) is str and bool(v) for v in [a.raw,a.expected_raw_sha256,a.transport_receipt,a.expected_transport_sha256]),'PARTIAL_XML_REQUIRED_ARGUMENTS');result=diagnose(a.raw,a.expected_raw_sha256,a.transport_receipt,a.expected_transport_sha256)
    except BaseException as error:result=dict(status='diagnostic_failed',fixed_error_code=error.code if isinstance(error,DiagnosticError) else 'PARTIAL_XML_DIAGNOSTIC_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False));return 1 if result['status']=='diagnostic_failed' else 0


if __name__=='__main__':raise SystemExit(main())
