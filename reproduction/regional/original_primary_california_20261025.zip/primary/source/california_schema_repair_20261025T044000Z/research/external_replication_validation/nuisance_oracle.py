"""Independent raw-row nuisance reconstruction; no production imports."""
import math
import numpy as np
from . import oracle as O


def select_bandwidth(xy,rect,candidates=(5.,15.,50.,150.,500.,1500.),floor=.05):
    xy=np.asarray(xy,float);N=len(xy);cells=O.labels(xy,rect)
    O.require(N>=2 and len(set(candidates))==len(candidates),'Unique LOO candidates and enough rows')
    area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2])
    loo=np.empty(N)
    for i in range(N):
        others=np.delete(cells,i)
        pi=O.reference_mass(others,np.ones(len(others),dtype=bool))
        loo[i]=pi[cells[i]]/area[cells[i]]
    records=[]
    for h in candidates:
        F=np.array([[O.rectangle_mass(b,p,h)[0] for b in rect] for p in xy]);Z=F.sum(axis=1)
        K=O.kernel(xy,xy,h)/Z[None,:]
        # Row identity only: identical-coordinate OTHER rows remain kernels.
        np.fill_diagonal(K,0.)
        density=floor*loo+(1-floor)*K.sum(axis=1)/(N-1)
        O.require(np.all(density>0),'Positive proper LOO density')
        records.append(dict(bandwidth=float(h),loo_logscore=math.fsum(np.log(density)),n_loo=N))
    winner=max(records,key=lambda r:(r['loo_logscore'],-r['bandwidth']))
    return dict(selected_bandwidth=winner['bandwidth'],candidates=records)
