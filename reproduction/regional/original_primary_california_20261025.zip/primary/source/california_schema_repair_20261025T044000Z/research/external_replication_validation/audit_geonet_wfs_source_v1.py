"""Independent RAW preferred WFS CSV source audit; pure standard library.
No production parser imports, requests, DLLs, fits or event-valued output.
Root reviews/freezes this source and leases all controls/actual capture audits.
"""
import argparse,csv,hashlib,io,json,re
from datetime import datetime,timezone
from decimal import Decimal
from pathlib import Path
import urllib.parse

CAP=134217728
ENDPOINT='https://wfs.geonet.org.nz/geonet/ows'
DEPENDENCIES=('parse_capture.py','cohort_contract_v1.json')
CONTRACT_SHA='2fb2e290a0a9b967cb82b4726a5dd28b6b313b58a053a407b93895a8c8b0feda'
HEADER=('publicid','eventtype','origintime','modificationtime','longitude','latitude','magnitude','depth','magnitudetype','depthtype','evaluationmethod','evaluationstatus','evaluationmode','earthmodel','usedphasecount','usedstationcount','magnitudestationcount','minimumdistance','azimuthalgap','originerror','magnitudeuncertainty')
REQUIRED=('publicid','eventtype','origintime','depth','magnitude','magnitudetype','latitude','longitude')
MEASUREMENTS=('magnitude','latitude','longitude','depth_km')
REASONS=('invalid_or_missing_magnitude','invalid_or_missing_coordinates','event_type_not_earthquake','invalid_or_missing_depth','unknown_depth_sentinel_minus_9','depth_over_40_km','included')
CONTROLS=dict(schema='geonet-wfs-csv-preferred-v1',max_records=5000,minimum_records=1,forbid_pagination=True,reject_at_max_records=True,require_final_newline=True,rely_on_unpaginated_service_contract=True)
FIXED_QUERY=dict(service='WFS',version='1.0.0',request='GetFeature',typeName='geonet:quake_search_v1',outputFormat='csv',maxFeatures='5000')
CQL=re.compile(r"origintime>='1960-01-01T00:00:00Z' AND origintime<'([^']+)' AND magnitude>=5 AND BBOX\(origin_geom,165,-48\.5,180,-33\.5\)")
FIELDS=('event_id','origin_time_utc','origin_time_us','latitude','longitude','depth_km','magnitude','magnitude_type','event_type','source_year','source_line_1based','source_row_index_1based','source_public_id','source_tokens')


class AuditError(Exception):
    def __init__(self,code):self.code=code;super().__init__(code)

def require(ok,code):
    if not ok:raise AuditError(code)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def same(a,b):
    if type(a) is not type(b):return False
    if type(a) is dict:return set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b

def utc(value):
    require(type(value) is str and re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?(?:Z|\+00:00)',value) is not None,'WFS_RAW_UTC_SCHEMA')
    try:return datetime.fromisoformat(value.replace('Z','+00:00'))
    except Exception:raise AuditError('WFS_RAW_UTC_CALENDAR') from None

def micros(value):
    delta=utc(value)-datetime(1970,1,1,tzinfo=timezone.utc)
    return (delta.days*86400+delta.seconds)*1000000+delta.microseconds

def numeric(token):
    require(type(token) is str,'WFS_RAW_NUMERIC_TYPE');trim=token.strip()
    if not trim or re.fullmatch(r'[+-]?(?:nan|inf|infinity)',trim,re.I) is not None:return None
    require(re.fullmatch(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?',trim) is not None,'WFS_RAW_NUMERIC_LEXICAL')
    try:value=Decimal(trim)
    except Exception:raise AuditError('WFS_RAW_DECIMAL_PARSE') from None
    require(value.is_finite(),'WFS_RAW_DECIMAL_FINITE');return value

def query_interval(query):
    require(type(query) is dict and set(query)==set(FIXED_QUERY)|{'cql_filter'} and all(type(query[k]) is str and query[k]==v for k,v in FIXED_QUERY.items()),'WFS_RAW_FIXED_QUERY')
    match=CQL.fullmatch(query['cql_filter']) if type(query['cql_filter']) is str else None;require(match is not None,'WFS_RAW_FIXED_CQL')
    start=micros('1960-01-01T00:00:00Z');cutoff=micros(match.group(1));require(cutoff>start,'WFS_RAW_CUTOFF');return start,cutoff,match.group(1)


def reconstruct(raw,query):
    require(type(raw) is bytes and 0<len(raw)<=CAP and raw.endswith(b'\n'),'WFS_RAW_BYTES_OR_FINAL_LF');start,end,_=query_interval(query)
    try:decoded=raw.decode('utf-8-sig')
    except Exception:raise AuditError('WFS_RAW_UTF8') from None
    require('\x00' not in decoded,'WFS_RAW_NUL');reader=csv.reader(io.StringIO(decoded,newline=''),strict=True)
    try:header=next(reader)
    except Exception:raise AuditError('WFS_RAW_CSV_HEADER') from None
    require(len(header)==21 and len(set(header))==21 and set(header)==set(HEADER),'WFS_RAW_KNOWN_21_HEADER')
    rows=[];seen=set();hist={k:{} for k in MEASUREMENTS};unknown={k:0 for k in MEASUREMENTS}
    try:
        for ordinal,values in enumerate(reader,1):
            require(ordinal<5000 and len(values)==21 and reader.line_num==ordinal+1,'WFS_RAW_ROW_CAP_WIDTH_LINE')
            require(all(type(value) is str and '\r' not in value and '\n' not in value for value in values),'WFS_RAW_EMBEDDED_NEWLINE')
            token=dict(zip(header,values));public=token['publicid'];require(bool(public) and public==public.strip() and not any(ord(c)<32 or ord(c)==127 for c in public),'WFS_RAW_PUBLIC_ID')
            identity=public if public.startswith('geonet:') else 'geonet:'+public;require(identity not in seen,'WFS_RAW_DUPLICATE_NORMALIZED_ID');seen.add(identity)
            stamp=micros(token['origintime']);require(start<=stamp<end,'WFS_RAW_QUERY_CLOCK_BOUNDS');clock=utc(token['origintime'])
            magnitude,latitude,longitude,depth=map(numeric,[token['magnitude'],token['latitude'],token['longitude'],token['depth']])
            require(magnitude is None or magnitude>=5,'WFS_RAW_QUERY_MAGNITUDE_BOUNDS')
            require(latitude is None or Decimal('-48.5')<=latitude<=Decimal('-33.5'),'WFS_RAW_QUERY_LATITUDE_BOUNDS')
            require(longitude is None or Decimal(165)<=longitude<=Decimal(180),'WFS_RAW_QUERY_LONGITUDE_BOUNDS')
            eventtype=token['eventtype'].strip();magtype=token['magnitudetype'].strip()
            row=dict(event_id=identity,origin_time_utc=token['origintime'],origin_time_us=stamp,latitude=None if latitude is None else token['latitude'],longitude=None if longitude is None else token['longitude'],depth_km=None if depth is None else token['depth'],magnitude=None if magnitude is None else token['magnitude'],magnitude_type=magtype,event_type=eventtype,source_year=clock.year,source_line_1based=ordinal+1,source_row_index_1based=ordinal,source_public_id=public,source_tokens=token)
            reasons=[]
            if magnitude is None:reasons.append(REASONS[0])
            if latitude is None or longitude is None:reasons.append(REASONS[1])
            if eventtype!='earthquake':reasons.append(REASONS[2])
            if depth is None:reasons.append(REASONS[3])
            else:
                if depth==-9:reasons.append(REASONS[4])
                if depth>40:reasons.append(REASONS[5])
            rows.append(dict(row=row,reasons=reasons,selected=not reasons,primary=reasons[0] if reasons else REASONS[-1]))
            for name in MEASUREMENTS:
                if row[name] is None:unknown[name]+=1
                else:
                    mantissa=row[name].strip().lower().split('e',1)[0];digits=str(len(mantissa.partition('.')[2]));hist[name][digits]=hist[name].get(digits,0)+1
    except csv.Error:raise AuditError('WFS_RAW_CSV_STRUCTURE') from None
    require(bool(rows),'WFS_RAW_EMPTY_BROAD');ordered=sorted(rows,key=lambda item:(item['row']['origin_time_us'],item['row']['event_id']));selected=[item for item in ordered if item['selected']];require(bool(selected),'WFS_RAW_EMPTY_COHORT')
    return header,rows,ordered,selected,hist,unknown


def compare_canonical(obj,expected,provenance,cohort):
    require(set(obj)=={'schema_version','catalogue_id','provenance','events'} and type(obj['schema_version']) is int and obj['schema_version']==1 and same(obj['provenance'],provenance),'WFS_RAW_CANONICAL_HEADER')
    require(obj['catalogue_id']==('geonet-wfs-shallow-M5-preferred-v1' if cohort else 'geonet-wfs-preferred-broad-v1'),'WFS_RAW_CANONICAL_ROLE')
    require(type(obj['events']) is list and len(obj['events'])==len(expected),'WFS_RAW_CANONICAL_DENOMINATOR');checks=0
    for actual,item in zip(obj['events'],expected):
        require(type(actual) is dict and set(actual)==set(FIELDS),'WFS_RAW_CANONICAL_FIELD_ROSTER')
        for key,value in item['row'].items():require(same(actual[key],value),'WFS_RAW_CANONICAL_SOURCE_FIELD');checks+=1
        checks+=len(item['row']['source_tokens'])
    return checks


def evidence_check(evidence,header,query,rows,selected,hist,unknown,counts,broad=False):
    require(evidence['complete'] is True and evidence['truncation_detected'] is False and same(evidence['controls'],CONTROLS) and same(evidence['query'],query) and same(evidence['source_header'],header),'WFS_RAW_EVIDENCE_SCHEMA')
    require(type(evidence['record_count']) is int and evidence['record_count']==(len(rows) if broad else len(selected)) and type(evidence['full_query_record_count']) is int and evidence['full_query_record_count']==len(rows),'WFS_RAW_EVIDENCE_COUNTS')
    require(same(evidence['source_unknown_numeric_counts'],unknown) and same(evidence['source_serialized_numeric_fractional_digit_histograms'],hist),'WFS_RAW_UNKNOWN_AND_PRECISION_ACCOUNTING')
    require(evidence['source_API_unpaginated_contract_verified'] is False and evidence['physical_detection_completeness_verified'] is False and evidence['measurement_accuracy_verified'] is False,'WFS_RAW_EVIDENCE_CLAIM_SCOPE')
    if not broad:require(type(evidence['cohort_record_count']) is int and evidence['cohort_record_count']==len(selected) and same(evidence['eligibility_reason_counts'],counts),'WFS_RAW_COHORT_EVIDENCE_COUNTS')


def audit(capture_root,design_path,design_sha,source_directory,include_precision=False):
    root=Path(capture_root).resolve();design_path=Path(design_path).resolve();source=Path(source_directory).resolve();require(sha(design_path)==design_sha,'WFS_RAW_DESIGN_IDENTITY');design=read(design_path);query=design['query'];require(design['status']=='frozen' and design['kind'] in ['historical_source_probe_design_nonissued','initialization_history_capture_design_nonissued'] and design['endpoint']==ENDPOINT and same(design['controls'],CONTROLS) and same(design['required_dependency_filenames'],list(DEPENDENCIES)),'WFS_RAW_FROZEN_SOURCE_DESIGN');start,cutoff,cutoff_text=query_interval(query)
    require(micros(design['cutoff_utc'])==cutoff and cutoff<=micros(design['design_frozen_at_utc']),'WFS_RAW_FROZEN_CUTOFF')
    require(sha(source/'cohort_contract_v1.json')==CONTRACT_SHA,'WFS_RAW_FROZEN_CONTRACT');contract=read(source/'cohort_contract_v1.json');require(set(contract['source_columns'])==set(HEADER) and same(contract['controls'],CONTROLS) and same(contract['reason_precedence'],list(REASONS)),'WFS_RAW_CONTRACT_SCHEMA')
    paths={k:root/v for k,v in dict(raw='raw_response.csv',broad='canonical_broad_preferred_history.json',canonical='canonical_shallow_m5_history.json',ledger='cohort_reference_exclusion_ledger.json').items()};receipt_path=root/'capture_receipt.json';completion_path=root/'capture_completion_receipt.json';receipt=read(receipt_path);completion=read(completion_path)
    require(receipt['status']=='complete' and receipt['issued'] is False and receipt['operational_capture'] is False and completion['status']=='complete' and completion['issued'] is False and completion['does_not_satisfy_future_daily_capture'] is True,'WFS_RAW_NONISSUED_CAPTURE_SCOPE')
    require(same(receipt['query'],query) and receipt['design_sha256']==design_sha and same(receipt['controls'],CONTROLS) and micros(receipt['cutoff_utc'])==cutoff and receipt['design_frozen_at_utc']==design['design_frozen_at_utc'],'WFS_RAW_CAPTURE_QUERY_DESIGN')
    require(paths['raw'].is_file() and 0<paths['raw'].stat().st_size<=CAP,'WFS_RAW_PRELOAD_CAP');raw=paths['raw'].read_bytes();rawsha=hashlib.sha256(raw).hexdigest();require(receipt['raw_sha256']==rawsha and Path(receipt['raw_path']).resolve()==paths['raw'],'WFS_RAW_RAW_REFERENCE')
    fields={'raw':'raw_sha256','broad':'broad_canonical_sha256','canonical':'canonical_sha256','ledger':'cohort_ledger_sha256'};artifact_refs={}
    for key,path in paths.items():
        expected=dict(path=str(path.resolve()),sha256=sha(path));require(same(receipt['artifact_refs'][key],expected) and receipt[fields[key]]==expected['sha256'],'WFS_RAW_ARTIFACT_BINDING');artifact_refs[key]=expected
    require(same(completion['controls'],CONTROLS) and completion['actual_registration_freeze_must_follow_this_completion'] is True,'WFS_RAW_PRE_FREEZE_COMPLETION_SCOPE')
    require(same(completion['artifact_refs'],artifact_refs) and same(completion['capture_receipt'],dict(path=str(receipt_path),sha256=sha(receipt_path))) and same(completion['design'],dict(path=str(design_path),sha256=design_sha)),'WFS_RAW_COMPLETION_BINDINGS')
    dep={name:sha(source/name) for name in DEPENDENCIES};require(dep==receipt['parser_dependency_pins']==completion['parser_dependency_pins'] and receipt['parser_sha256']==dep['parse_capture.py'],'WFS_RAW_PARSER_SOURCE_HASHES')
    governance=receipt['governance_refs'];require(same(governance,completion['governance_refs']) and same(governance['design'],dict(path=str(design_path),sha256=design_sha)) and same(governance['cohort_contract'],dict(path=str((source/'cohort_contract_v1.json').resolve()),sha256=CONTRACT_SHA)),'WFS_RAW_GOVERNANCE_BINDINGS');governance_paths=[]
    for name,reference in governance.items():
        path=Path(reference['path']);require(path.is_absolute() and sha(path)==reference['sha256'],'WFS_RAW_GOVERNANCE_FILE_HASH');governance_paths.append(path)
    began=micros(receipt['actual_request_start_utc']);received=micros(receipt['actual_receipt_utc']);data_completed=micros(receipt['archive_data_completed_utc']);done=micros(completion['actual_archive_completed_utc']);require(cutoff<=micros(design['design_frozen_at_utc'])<=began<=received<=data_completed<=done,'WFS_RAW_CAPTURE_CLOCK_ORDER')
    for key in ['cutoff_utc','design_frozen_at_utc','actual_request_start_utc','actual_receipt_utc']:require(completion[key]==receipt[key],'WFS_RAW_COMPLETION_CLOCK_BINDING')
    provenance=receipt['provenance'];require(set(provenance)=={'source_snapshot','raw_manifest_sha256','retrieved_utc'} and type(provenance['source_snapshot']) is str and bool(provenance['source_snapshot']) and provenance['raw_manifest_sha256']==rawsha and micros(provenance['retrieved_utc'])==received,'WFS_RAW_PROVENANCE')
    attempts=sorted(root.glob('attempt_[0-9][0-9]/private_transport_receipt.json'));require(1<=len(attempts)<=3 and [p.parent.name for p in attempts]==[f'attempt_{i:02d}' for i in range(1,len(attempts)+1)],'WFS_RAW_ATTEMPT_SEQUENCE');attempt_bodies=[]
    for i,path in enumerate(attempts):
        entry=read(path);require(entry['query']==query and entry['endpoint']==ENDPOINT,'WFS_RAW_ATTEMPT_FIXED_QUERY');body=path.parent/'raw_response.csv';require(Path(entry['raw_path']).resolve()==body,'WFS_RAW_ATTEMPT_RAW_PATH')
        if body.exists():require(entry['raw_sha256']==sha(body) and entry['stored_bytes']==body.stat().st_size and body.stat().st_size<=CAP,'WFS_RAW_ATTEMPT_BODY_HASH');attempt_bodies.append(body)
        else:require(entry['raw_sha256'] is None and entry['stored_bytes']==0,'WFS_RAW_ATTEMPT_MISSING_BODY')
        if i<len(attempts)-1:require(entry['retry'] is True and entry['error_code'] in ['HTTP_STATUS_UNEXPECTED','TRANSIENT_BODY_FAILURE','TRANSIENT_CONNECTION_FAILURE'],'WFS_RAW_FIXED_RETRY')
    transport=read(attempts[-1]);require(transport['status']==200 and transport['error_code'] is None and transport['closed_eof'] is True and transport['raw_sha256']==rawsha and transport['stored_bytes']==transport['observed_bytes']==len(raw) and sha(transport['raw_path'])==rawsha,'WFS_RAW_COMPLETE_TRANSPORT')
    require(micros(transport['request_start_utc'])==began and micros(transport['response_completed_utc'])==received,'WFS_RAW_TRANSPORT_CLOCK_BINDING');final=urllib.parse.urlsplit(transport['final_url']);pairs=urllib.parse.parse_qsl(final.query,keep_blank_values=True);require((final.scheme,final.netloc,final.path,final.fragment)==('https','wfs.geonet.org.nz','/geonet/ows','') and len(pairs)==len(query) and dict(pairs)==query,'WFS_RAW_FINAL_URL_QUERY')
    headers=transport['headers'];require((headers.get('Content-Encoding') or '').strip().lower() in ['', 'identity'] and (headers.get('Content-Type') or '').split(';',1)[0].strip().lower() in ['text/csv','application/csv'],'WFS_RAW_RESPONSE_REPRESENTATION')
    if headers.get('Content-Length') is None:require(transport['content_length_match'] is None,'WFS_RAW_NO_INVENTED_LENGTH')
    else:require(re.fullmatch('[0-9]+',headers['Content-Length'].strip()) is not None and int(headers['Content-Length'])==len(raw) and transport['content_length_match'] is True,'WFS_RAW_TRANSPORT_LENGTH')
    header,rows,ordered,selected,hist,unknown=reconstruct(raw,query);checks=compare_canonical(read(paths['broad']),ordered,provenance,False)+compare_canonical(read(paths['canonical']),selected,provenance,True)
    doc=read(paths['ledger']);require(doc['raw_sha256']==rawsha and same(doc['query'],query) and type(doc['rows']) is list and len(doc['rows'])==len(rows),'WFS_RAW_LEDGER_METADATA');counts={reason:0 for reason in REASONS};expected_ledger=[]
    for item in rows:
        row=item['row'];entry={key:row[key] for key in ['event_id','source_public_id','source_row_index_1based','source_line_1based']};entry.update(selected=item['selected'],primary_reason=item['primary'],all_exclusion_reasons=item['reasons']);expected_ledger.append(entry);counts[item['primary']]+=1
    require(same(doc['rows'],expected_ledger),'WFS_RAW_ALL_ROW_LEDGER');checks+=7*len(rows)
    evidence=receipt['completeness_evidence'];require(same(evidence['eligibility_ledger_private'],expected_ledger),'WFS_RAW_PRIVATE_EVIDENCE_LEDGER');evidence_check(evidence,header,query,rows,selected,hist,unknown,counts);broad_evidence=evidence['full_query_parse_evidence'];evidence_check(broad_evidence,header,query,rows,selected,hist,unknown,counts,True)
    require(receipt['source_API_unpaginated_contract_verified'] is False and receipt['physical_detection_completeness_verified'] is False and receipt['operational_registration_source_admitted'] is False,'WFS_RAW_SOURCE_CLAIM_SCOPE')
    bindings={str(path.resolve()):sha(path) for path in list(paths.values())+[receipt_path,completion_path,design_path]+governance_paths+attempts+attempt_bodies+[source/name for name in DEPENDENCIES]}
    result=dict(status='passed',passed=True,independent=True,data_classification='local_verified_source_WFS_CSV',scope='Independent directRAW preferredWFSCSV canonical/cohort/allrowledger/provenance/transport reconstruction; no production imports/DLL',raw_sha256=rawsha,canonical_sha256=receipt['canonical_sha256'],parser_dependency_pins=dep,capture_receipt=dict(path=str(receipt_path),sha256=sha(receipt_path)),completion_receipt=dict(path=str(completion_path),sha256=sha(completion_path)),header_sha256=hashlib.sha256(json.dumps(header,separators=(',',':')).encode()).hexdigest(),bytes=len(raw),broad_records=len(rows),cohort_records=len(selected),exclusive_reason_counts=counts,source_unknown_numeric_counts=unknown,field_checks=checks,bindings=bindings,physical_detection_completeness_proved=False,source_API_unpaginated_assumption_remains=True,operational_registration_admitted=False)
    if include_precision:result['source_serialized_numeric_fractional_digit_histograms']=hist
    return result


def self_controls():
    """Wholly handcrafted source-row controls; no source file or data query."""
    checks=0
    query=dict(FIXED_QUERY,cql_filter="origintime>='1960-01-01T00:00:00Z' AND origintime<'2005-01-01T00:00:00Z' AND magnitude>=5 AND BBOX(origin_geom,165,-48.5,180,-33.5)")
    def check(ok):
        nonlocal checks
        require(bool(ok),'WFS_RAW_SYN_CONTROL_FAILED');checks+=1
    def row(identity='SYN_A',**changes):
        values={key:'' for key in HEADER};values.update(publicid=identity,eventtype='earthquake',origintime='2004-02-03T04:05:06.123456Z',longitude='174.000000000000000001',latitude='-41',magnitude='5.0000000000000000001',depth='40',magnitudetype='Mw',earthmodel='SYN, quoted auxiliary');values.update(changes);return values
    def encoded(rows,header=HEADER):
        buffer=io.StringIO(newline='');writer=csv.writer(buffer,lineterminator='\n');writer.writerow(header)
        for record in rows:writer.writerow([record[key] for key in header])
        return buffer.getvalue().encode()
    def reject(raw):
        caught=False
        try:reconstruct(raw,query)
        except AuditError:caught=True
        check(caught)
    base=row();header,original,ordered,selected,hist,unknown=reconstruct(encoded([base]),query)
    check(len(original)==len(selected)==1 and ordered[0]['row']['magnitude']==base['magnitude']);check(ordered[0]['row']['origin_time_us']==1075781106123456);check(ordered[0]['row']['source_tokens']==base);check(ordered[0]['row']['source_line_1based']==2)
    sample=[row('SYN_A'),row('SYN_B',eventtype='quarry_blast'),row('SYN_C',depth='-9'),row('SYN_D',depth='40.0000000000000001'),row('SYN_E',depth='-8'),row('SYN_F',magnitude='NaN',latitude='',depth='+Inf',eventtype='')]
    _,items,_,chosen,_,missing=reconstruct(encoded(sample),query);check([i['row']['event_id'] for i in chosen]==['geonet:SYN_A','geonet:SYN_E']);check(items[-1]['reasons']==list(REASONS[:4]));check(missing==dict(magnitude=1,latitude=1,longitude=0,depth_km=1))
    _,_,_,chosen,_,_=reconstruct(encoded([row(magnitude=' 5.000 ',eventtype=' earthquake ',magnitudetype='   ')]),query);check(chosen[0]['row']['magnitude']==' 5.000 ' and chosen[0]['row']['magnitude_type']=='' and chosen[0]['row']['event_type']=='earthquake')
    for token in ['', ' NaN ', '+nan','-Inf','INFINITY','+infinity']:check(numeric(token) is None)
    for changes in [dict(magnitude='4.9999999999999999'),dict(depth='sNaN'),dict(latitude='-48.500000000000001'),dict(origintime='2004-02-03T04:05:60Z'),dict(publicid=' SYN '),dict(earthmodel='SYN\nMULTILINE')]:reject(encoded([row(**changes)]))
    reject(encoded([base,base]));reject(encoded([row('SYN_A'),row('geonet:SYN_A')]));reject(encoded([base])[:-1]);reject(encoded([base],HEADER[:-1]));reject(encoded([]));reject(encoded([row(eventtype='')]))
    reverse=tuple(reversed(HEADER));check(reconstruct(encoded([base],reverse),query)[0]==list(reverse))
    broken=dict(ordered[0]['row']);broken['magnitude']='5';caught=False
    try:compare_canonical(dict(schema_version=1,catalogue_id='geonet-wfs-preferred-broad-v1',provenance={},events=[broken]),ordered,{},False)
    except AuditError:caught=True
    check(caught)
    return dict(status='passed',passed=True,scope='Wholly handcrafted independentRAWCSV reader controls',checks=checks,network_requests=0,production_imports=0,dll_loads=0,fits=0)


def main():
    cli=argparse.ArgumentParser();cli.add_argument('--capture-root');cli.add_argument('--design');cli.add_argument('--expected-design-sha256');cli.add_argument('--source-directory');cli.add_argument('--include-precision',action='store_true');cli.add_argument('--self-controls',action='store_true');cli.add_argument('--output',required=True);a=cli.parse_args()
    try:
        if a.self_controls:require(all(v is None for v in [a.capture_root,a.design,a.expected_design_sha256,a.source_directory]),'WFS_RAW_SYN_ONLY_ARGUMENTS');result=self_controls()
        else:require(all(type(v) is str and bool(v) for v in [a.capture_root,a.design,a.expected_design_sha256,a.source_directory]),'WFS_RAW_AUDIT_ARGUMENTS');result=audit(a.capture_root,a.design,a.expected_design_sha256,a.source_directory,a.include_precision)
    except Exception as error:result=dict(status='failed',passed=False,independent=True,fixed_error_code=error.code if isinstance(error,AuditError) else 'WFS_RAW_SOURCE_AUDIT_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['status','passed','fixed_error_code','error_type','raw_sha256','canonical_sha256','bytes','broad_records','cohort_records','field_checks','checks'] if k in result},allow_nan=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
