"""Independent all-candidate California forecasts and sensitivity lineage.
All parameters originate from immutable training artifacts. No production imports.
"""
import math
from pathlib import Path
import numpy as np
from . import empirical_io_v2 as I,empirical_oracle_v2 as E,empirical_cache_v2 as C
from .audit_nz_initialization_v3 import close,same

SCORE_KEYS=['joint_logscore','timing_logscore','conditional_location_logscore','conditional_zone_logscore','conditional_cell_logscore','within_cell_density_logscore','mark_logscore','timing_event_logscore','timing_exposure_logscore','event_log_point_intensity_sum','event_log_ground_intensity_sum','event_log_intensity_sum','integrated_intensity','trigger_exposure','cell_integrated_intensity','zone_integrated_intensity','cell_point_event_log_intensity_sum','cell_point_logscore','event_log_point_intensity','event_log_cell_intensity','event_log_zone_intensity','event_log_ground_intensity']


def audit_forecast(folder,raw,context):
    folder=Path(folder);training=context['case'];case=training['case'];final=I.read(folder/'case.json');t=raw['times'];event=(t>=case['test_start'])&(t<case['test_end']);nt=int(event.sum());I.require(nt>0,'NONEMPTY_FIXED_TEST_WINDOW')
    for key,value in training.items():
        if key not in ['models','status']:I.require(final[key]==value,'NO_POST_OUTCOME_TRAINING_CHANGE')
    I.require(final['n_test']==nt and final['test_cell_counts']==np.bincount(raw['cells'][event],minlength=9).tolist(),'RAW_TEST_DENOMINATOR')
    scores={};records=[];near_count=solver_count=0;cache_contracts={};forecasts_by_id={};cache_reports=[];states=[]
    def add(fit,pars,production):
        I.require(set(production)==set(SCORE_KEYS),'COMPLETE_FORECAST_COMPONENT_SCHEMA')
        records.append(dict(start=case['test_start'],end=case['test_end'],train_start=case['train_start'],train_end=case['train_end'],T0=case['T0'],beta=context['beta'],sigma=fit['sigma'],bandwidth=context['bandwidth'],spatial=fit['spatial'],model=fit['model'],pars=pars,history_policy='continuous',production=production,require_gradient=False))
    def pair(fit,pars,saved):
        add(fit,pars,saved['forecast']);add(fit,pars,saved['fine_forecast'])
        error=abs(saved['forecast']['joint_logscore']-saved['fine_forecast']['joint_logscore']);I.require(abs(error-saved['forecast_quadrature_error'])<=1e-12,'FORECAST_COARSE_FINE_DIAGNOSTIC');return error
    for fit,path in zip(context['fits'],context['paths']):
        score=I.read(folder/('score_'+fit['procedure_id']+'.json'));scores[fit['procedure_id']]=score
        I.require(score['procedure_id']==fit['procedure_id'] and score['training_fit_path']==path and score['training_fit_sha256']==I.sha(path),'FORECAST_IMMUTABLE_TRAINING_BINDING')
        caches=score['forecast_cache_paths'];I.require(set(caches)=={'test16','test32'},'EXACT_FORECAST_CACHE_KEYS')
        for label,cachepath in caches.items():
            key=f"{fit['spatial']}_smooth_sigma{fit['sigma']:g}";cachepath=str(Path(cachepath).resolve());order=int(label[4:]);base=dict(context['cache_contracts'][str(Path(fit['cache_paths']['train16']).resolve())]);base.update(start=case['test_start'],end=case['test_end'],order=order,nuisance_policy='frozen_training_only');base.pop('cache_key')
            I.require(Path(cachepath).name==f'cache_{key}_{label}.npz' and Path(cachepath).parent==folder.resolve(),'FORECAST_CACHE_PATH_BINDING');I.require(cachepath not in cache_contracts or cache_contracts[cachepath]==base,'SHARED_FORECAST_CACHE_BINDING');cache_contracts[cachepath]=base
        candidates=fit['accepted_candidates'];forecasts=score['all_candidate_forecasts'];I.require(len(forecasts)==len(candidates) and [f['candidate_id'] for f in forecasts]==[c['candidate_id'] for c in candidates],'ALL_CANDIDATE_FORECAST_DENOMINATOR');byid={f['candidate_id']:f for f in forecasts};forecasts_by_id[fit['procedure_id']]=byid
        errors=[]
        for candidate,saved in zip(candidates,forecasts):
            I.require(saved['pars']==candidate['pars'] and saved['training_joint_nll']==candidate['evaluation']['joint_nll'],'FORECAST_CANDIDATE_PARAMETER_BINDING');errors.append(pair(fit,candidate['pars'],saved))
        near=[byid[c['candidate_id']] for c in candidates if c['evaluation']['joint_nll']<=fit['selected']['evaluation']['joint_nll']+4e-4];I.require(score['near_optimal_forecasts']==near,'FULL_NEAR_OPTIMAL_POOL')
        spread=(max(f['forecast']['joint_logscore'] for f in near)-min(f['forecast']['joint_logscore'] for f in near))/nt;stable=spread<.01;near_count+=len(near)
        I.require(abs(spread-score['forecast_spread_nats_per_event'])<=1e-12 and score['forecast_stable'] is stable,'NEAR_OPTIMAL_SPREAD_DIAGNOSTIC')
        I.require(score['forecast']==byid[fit['selected']['candidate_id']]['forecast'],'TRAINING_SELECTED_FORECAST_ONLY')
        returns=[(slot['slot'],attempt) for slot in fit['slots'] if slot['kind']=='start' for attempt in slot['attempts'] if attempt.get('finite_feasible')];saved_returns=score['all_solver_return_forecasts'];I.require(len(saved_returns)==len(returns),'ALL_SOLVER_RETURN_FORECASTS')
        for saved,(slot,attempt) in zip(saved_returns,returns):
            I.require(saved['slot']==slot and saved['tier']==attempt['tier'] and saved['accepted']==attempt['accepted'] and saved['pars']==attempt['pars'],'SOLVER_RETURN_FORECAST_BINDING');pair(fit,attempt['pars'],saved);solver_count+=1
        expected_status='complete' if fit['complete'] and stable and all(e<=1e-4 for e in errors) else 'unknown_incomplete';I.require(score['status']==expected_status,'FORECAST_STATUS_RULE');states.append(expected_status=='complete')
    I.require(final['scores']==scores and len(cache_contracts)==14,'FINAL_ALL_PROCEDURE_SCORE_BINDINGS')
    for mid,model in training['models'].items():
        expected=dict(model,**scores[model['procedure_id']]);I.require(final['models'][mid]==expected,'FINAL_MODEL_AND_SCORE_BINDING')
    selector=context['fits'][:6];best=min(f['selected']['evaluation']['joint_nll'] for f in selector);pool=[dict(procedure_id=fit['procedure_id'],sigma=fit['sigma'],**saved) for fit in selector for saved in forecasts_by_id[fit['procedure_id']].values() if saved['training_joint_nll']<=best+4e-4];spread=(max(f['forecast']['joint_logscore'] for f in pool)-min(f['forecast']['joint_logscore'] for f in pool))/nt;stable=spread<.01
    I.require(final['cross_grid_near_optimal_forecasts']==pool and abs(final['cross_grid_forecast_spread_nats_per_event']-spread)<=1e-12 and final['cross_grid_forecast_stable'] is stable,'CROSS_GRID_TRAINING_NEAR_OPTIMAL_POOL')
    I.require(final['status']==('complete' if training['status']=='complete' and all(states) and stable else 'unknown_incomplete'),'FINAL_UNKNOWN_SENSITIVITY_RULE')
    for path in sorted(cache_contracts):cache_reports.append(C.cache_audit(path,raw,context['pi'],training['beta'],context['bandwidth'],context['geometry_cache'],cache_contracts[path]))
    bundle=dict(context['bundle']);bundle['records']=records;bundle['nuisance_controls']=[];numerical=E.audit(bundle)
    return dict(passed=True,case_id=case['case_id'],target_events=nt,procedures=len(scores),all_candidate_forecasts=sum(len(s['all_candidate_forecasts']) for s in scores.values()),finite_solver_return_forecasts=solver_count,near_optimal_forecasts=near_count,cross_grid_near_optimal_forecasts=len(pool),cross_grid_forecast_spread_nats_per_event=spread,forecast_stable=all(states) and stable,scientific_status=final['status'],cache_reports=cache_reports,numerical=numerical)
