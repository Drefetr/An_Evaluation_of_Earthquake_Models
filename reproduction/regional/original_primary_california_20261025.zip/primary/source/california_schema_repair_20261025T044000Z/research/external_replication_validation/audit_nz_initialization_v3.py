"""Full independent 913-row NZ initialization audit before CA outcome release.

Raw CSV/depth provenance, nuisance construction, every start/return/floor,
selected/near-optimal lineage and every numerical cache are reconstructed.
No production imports/DLL loading; stdout contains only scalar receipts.
"""
import argparse,hashlib,json,math
from pathlib import Path
import numpy as np
from . import empirical_io_v1 as I,empirical_oracle_v2 as E
from . import oracle as O,nuisance_oracle as N
from .raw_input import fit_beta

MODELS=['fixedML_smooth_lift','fixedML_smooth_cont','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']
SCALES=[5.,15.,50.,150.,500.,1500.]


def ref(path):return dict(path=str(Path(path).resolve()),sha256=I.sha(path))
def same(a,b):return np.asarray(a).shape==np.asarray(b).shape and bool(np.all(np.asarray(a)==np.asarray(b)))
def close(a,b,tol,code):I.require(np.asarray(a).shape==np.asarray(b).shape and float(np.max(abs(np.asarray(a)-np.asarray(b)),initial=0.))<=tol,code)
def model_manifest(case):return dict(beta=case['beta'],reference_pi=case['reference_pi'],kde_selection=case['kde_selection'],selected_sigma=case['selected_sigma'],models={mid:dict(model=case['models'][mid]['model'],pars=case['models'][mid]['selected']['pars'],spatial=case['models'][mid]['spatial'],sigma=case['models'][mid]['sigma'],cache_paths=case['models'][mid]['cache_paths']) for mid in MODELS})


def cache_audit(path,raw,pi,beta,bandwidth,geometry_cache,contract):
    with np.load(path,allow_pickle=False) as saved:
        meta=json.loads(str(saved['metadata_json'].item()));arrays={k:saved[k].copy() for k in saved.files if k!='metadata_json'}
    I.require(all(meta.get(k)==v for k,v in contract.items()),'CACHE_EXACT_FROZEN_BINDINGS')
    identity=dict(meta);identity.pop('cache_identity_sha256',None)
    I.require(meta['cache_identity_sha256']==hashlib.sha256(json.dumps(identity,sort_keys=True,allow_nan=False,separators=(',',':')).encode()).hexdigest(),'CACHE_METADATA_IDENTITY')
    I.require(meta['array_sha256']=={k:hashlib.sha256(v.tobytes(order='C')).hexdigest() for k,v in arrays.items()},'CACHE_ARRAY_HASHES')
    I.require(meta['profile']=='new_zealand' and meta['start']==0. and meta['end']==24394. and meta['T0']==24394. and meta['beta']==beta and meta['background']=='kde' and meta['known_background_override'] is False and meta['kde_bandwidth']==bandwidth,'CACHE_FROZEN_NUISANCE')
    I.require(same(meta['reference_pi'],meta['pi']) and float(np.max(abs(np.asarray(meta['reference_pi'])-pi)))<=1e-12 and meta['r']==.7 and meta['kde_floor']==.05 and meta['strict_left_limit'] is True,'CACHE_METADATA_MATHEMATICS')
    for name,digest in meta['production_source_pins'].items():I.require(I.sha(name)==digest,'CACHE_PRODUCTION_SOURCE_IDENTITY')
    I.require(meta['family'] in ['continuous','center'],'CACHE_FAMILY_ROSTER')
    family='continuous' if meta['family']=='continuous' else 'lift';key=(float(meta['sigma']),family)
    if key not in geometry_cache:geometry_cache[key]=O.geometry(raw['xy'],raw['xy'],raw['xy'],raw['rectangles'],pi,key[0],bandwidth,family)
    g=geometry_cache[key];t=raw['times'];q=raw['excess'];cells=raw['cells'];rect=raw['rectangles'];area=g['area'];density=pi/area
    F=np.array([[O.rectangle_mass(b,p,key[0])[0] for b in rect] for p in raw['xy']]) if family=='continuous' else np.empty((len(t),0))
    kF=np.array([[O.rectangle_mass(b,p,bandwidth)[0] for b in rect] for p in raw['xy']]);kZ=kF.sum(axis=1)
    point=O.kernel(raw['xy'],raw['xy'],key[0])*density[cells,None]/g['parent_normalizer'][None,:] if family=='continuous' else g['parent_cell'][:,cells].T/area[cells,None]
    bg=.05*density[cells]+.95*np.mean(O.kernel(raw['xy'],raw['xy'],bandwidth)/kZ[None,:],axis=1)
    weights,rates=O.mixture();centers=np.column_stack(((rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2))
    expected=dict(parent_time=t,parent_excess=q,parent_cell=cells,event_time=t,event_excess=q,event_cell=cells,event_x=2*t/24394.-1,event_parent_lag=t[:,None]-t[None,:],parent_exposure_lo=np.zeros(len(t)),parent_exposure_hi=24394.-t,mixture_weights=weights,mixture_rates=rates,quad_time=np.empty(0),quad_x=np.empty(0),quad_w=np.empty(0),parent_latitude=raw['latitude'],parent_longitude=raw['longitude'],parent_xy=raw['xy'],event_xy=raw['xy'],event_parent_density=point,parent_cell_mass=g['parent_cell'],parent_rectangle_integrals=F,parent_normalizer=g['parent_normalizer'],parent_fertility=.3*np.exp(.7*beta*q),event_background_density=bg,background_cell_mass=g['background_cell'],reference_pi=pi,cell_pi=pi,cell_areas=area,rectangles=rect,cell_centers_xy=centers,kde_training_xy=raw['xy'],kde_training_cells=cells,kde_rectangle_integrals=kF,kde_normalizers=kZ)
    I.require(set(arrays)==set(expected),'CACHE_COMPLETE_FEATURE_SET')
    errors={};exact={'parent_time','parent_excess','parent_cell','event_time','event_excess','event_cell','event_x','event_parent_lag','parent_exposure_lo','parent_exposure_hi','mixture_weights','mixture_rates','quad_time','quad_x','quad_w','parent_latitude','parent_longitude','kde_training_cells'}
    for name,value in expected.items():
        actual=arrays[name];value=np.asarray(value)
        I.require(actual.dtype==np.dtype('float64') and actual.shape==value.shape and np.isfinite(actual).all(),'CACHE_FEATURE_SHAPE_FINITE')
        delta=abs(actual-value);error=float(np.max(delta,initial=0.));errors[name]=error
        if name in exact:I.require(np.array_equal(actual,value),'CACHE_RAW_NUMERIC_IDENTITY')
        elif name in ['parent_rectangle_integrals','kde_rectangle_integrals']:I.require(np.all(delta<=np.maximum(1e-8,1e-9*abs(value))),'CACHE_POSITIVE_RECTANGLE_RECONSTRUCTION')
        else:I.require(np.all(delta<=1e-14+2e-10*abs(value)),'CACHE_RAW_GEOMETRY_RECONSTRUCTION')
    return dict(path_sha256=I.sha(path),sigma=key[0],family=family,order=meta['order'],feature_checks=len(expected),maximum_feature_absolute_error=max(errors.values()),feature_errors=errors)


def audit(initialization,metadata_path):
    refs=[initialization[k] for k in ['methods_protocol','protocol','catalogue','training_case','parameter_manifest']]+initialization['fit_outputs']+initialization['nuisance_outputs']
    bindings={}
    for r in refs:I.require(I.sha(r['path'])==r['sha256'],'INITIALIZATION_FILE_HASH');bindings[str(Path(r['path']).resolve())]=r['sha256']
    I.require(len(bindings)==len(refs),'INITIALIZATION_UNIQUE_BINDINGS')
    protocol=I.read(initialization['protocol']['path']);methods=I.read(initialization['methods_protocol']['path']);case=I.read(initialization['training_case']['path'])
    I.require(protocol['status']=='frozen' and protocol['science_gate_passed'] is True,'INITIALIZATION_PROTOCOL_ADMISSION')
    for name,digest in protocol['artifact_pins'].items():I.require(I.sha(name)==digest,'FROZEN_DEPENDENCY_CHANGED')
    I.require(protocol['data']['sha256']==I.NZ_HASH and initialization['catalogue']['sha256']==I.NZ_HASH and protocol['data'].get('legacy_csv') is True,'ORIGINAL_913_INPUT_ONLY')
    for key in ['models','parameter_bounds','parameter_order','fit_policy','primary_selection','background','kernel_contract']:I.require(protocol[key]==methods[key],'FROZEN_REGISTERED_MATHEMATICAL_PROCEDURE')
    I.require(protocol['models']==MODELS and protocol['primary_selection']['sigma_km']==SCALES and protocol['background']['bandwidth_km']==SCALES and protocol['common_nuisance']['excess_cut']==.5 and protocol['common_nuisance']['productivity']['r']==.7,'FROZEN_ROSTER_AND_MARK_RECIPE')
    core_names=['__init__.py','objective.cpp','objective.dll','compiled_objective.py','geometry.py','fitting.py','catalogue.py','workflow.py','prospective.py','synthetic.py','build_objective.cmd']
    core_pins={name:digest for name,digest in protocol['artifact_pins'].items() if Path(name).name in core_names and Path(name).parent.name=='external_replication'}
    I.require(len(core_pins)==11 and {Path(k).name for k in core_pins}==set(core_names),'EXACT_CORE_SOURCE_PIN_ROSTER')
    raw=I.read_legacy_nz(initialization['catalogue']['path'],metadata_path);t=raw['times'];q=raw['excess'];cells=raw['cells'];pi=O.reference_mass(cells,np.ones(913,dtype=bool));beta=fit_beta(q);kde=N.select_bandwidth(raw['xy'],raw['rectangles'])
    I.require(case['case']==dict(case_id='nz_full_training',train_start=0.,train_end=24394.,T0=24394.) and case['profile']=='new_zealand' and case['n_train']==913 and case['catalogue_sha256']==I.NZ_HASH and case['protocol_sha256']==initialization['protocol']['sha256'] and case['status']=='complete','INITIALIZATION_CASE_BINDING')
    I.require(np.all(np.bincount(cells//3,minlength=3)>=30) and abs(case['beta']-beta)<=1e-10,'RAW_TRAINING_NUISANCE_ELIGIBILITY');close(case['reference_pi'],pi,1e-12,'RAW_HIERARCHICAL_REFERENCE');I.require(case['kde_selection']['selected_bandwidth']==kde['selected_bandwidth'],'RAW_LOO_H_SELECTION')
    I.require(I.read(initialization['parameter_manifest']['path'])==model_manifest(case),'FULL_PARAMETER_MANIFEST')
    paths=[r['path'] for r in initialization['fit_outputs']];I.require([str(Path(p).resolve()) for p in case['procedures']]==[str(Path(p).resolve()) for p in paths] and len(paths)==10,'TEN_PROCEDURE_BINDINGS')
    expected_ids=['nz_full_training__selector_fixedML_smooth_cont_sigma'+str(int(s)) for s in SCALES]+['nz_full_training__main_'+m for m in ['fixedML_smooth_lift','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']]
    fits=[I.read(p) for p in paths];I.require([f['procedure_id'] for f in fits]==expected_ids,'EXACT_TEN_PROCEDURE_ORDER');byid={f['procedure_id']:f for f in fits};models={};records=[];starts=floors=returns=candidates=0;allcache=set();lineage=[];a0=float(np.clip(np.log(.6*913/24394.),-11.5,-.1));ap=float(np.clip(np.log(913/24394.),-12,0));fp=protocol['fit_policy']
    def add(f,pars,value):records.append(dict(start=0.,end=24394.,train_start=0.,train_end=24394.,T0=24394.,beta=beta,sigma=f['sigma'],bandwidth=kde['selected_bandwidth'],spatial=f['spatial'],model=f['model'],pars=pars,history_policy='continuous',production=value,require_gradient=True))
    cache_contracts={}
    bounds=protocol['parameter_bounds'];pb={k:list(bounds[k]) for k in ['a','d','n']}
    expected_bounds={'fixedML':[pb[k] for k in ['a','d','n']],'commonML':[pb[k] for k in ['a','d','n']]+[[float(np.log(v)) for v in bounds['tau_days']]],'Omori':[pb[k] for k in ['a','d','n']]+[[float(np.log(v)) for v in bounds['c_days']],list(bounds['p'])]}
    def feasible(pars,temporal):
        b=expected_bounds[temporal];return isinstance(pars,list) and len(pars)==len(b) and all(isinstance(v,(int,float)) and math.isfinite(v) and lo<=v<=hi for v,(lo,hi) in zip(pars,b))
    for ordinal,(path,f) in enumerate(zip(paths,fits)):
        temporal='fixedML' if ordinal<7 else 'commonML' if ordinal==7 else 'Omori';spatial='cont' if ordinal<6 or ordinal in [7,8] else 'lift';sigma=SCALES[ordinal] if ordinal<6 else case['selected_sigma']
        I.require(f['temporal']==temporal and f['model']=={'fixedML':'E_fixed','commonML':'E_free','Omori':'E_omori'}[temporal] and f['spatial']==spatial and f['sigma']==sigma and f['background']=='smooth' and f['role']==('primary_selector' if ordinal<6 else 'primary_main') and f['bounds']==expected_bounds[temporal],'EXACT_MODEL_BOUNDS_ROSTER')
        I.require(set(f['cache_paths'])=={'train16','train32'},'EXACT_TRAIN_CACHE_KEYS')
        for label,cachepath in f['cache_paths'].items():
            key=f'{spatial}_smooth_sigma{sigma:g}';order=int(label[5:]);cachepath=str(Path(cachepath).resolve())
            I.require(Path(cachepath).name==f'cache_{key}_{label}.npz' and Path(cachepath).parent==Path(path).resolve().parent,'CACHE_PATH_ORDER_BINDING')
            contract=dict(catalogue_sha256=I.NZ_HASH,protocol_sha256=initialization['protocol']['sha256'],case_id='nz_full_training',training_start=0.,training_end=24394.,reference_pi=case['reference_pi'],pi=case['reference_pi'],order=order,sigma=sigma,family='continuous' if spatial=='cont' else 'center',cache_key=key,nuisance_policy='training_only',production_source_pins=core_pins)
            I.require(cachepath not in cache_contracts or cache_contracts[cachepath]==contract,'SHARED_CACHE_BINDING');cache_contracts[cachepath]=contract
        registry=I.read(Path(path).with_name('registry_'+f['procedure_id']+'.json'));I.require(registry['sha256']==I.sha(path) and registry['procedure_id']==f['procedure_id'],'FIT_REGISTRY')
        I.require(registry['path']==str(Path(path).resolve()) and registry['model']==f['model'] and registry['cache_paths']==f['cache_paths'],'REGISTRY_FULL_BINDINGS')
        I.require(f['complete'] is True and f['case_id']=='nz_full_training','COMPLETE_FIT');allcache.update(str(Path(p).resolve()) for p in f['cache_paths'].values())
        ss=[s for s in f['slots'] if s['kind']=='start'];ff=[s for s in f['slots'] if s['kind']=='floor'];cc=f['accepted_candidates'];I.require(len(ss)==8 and [s['slot'] for s in ss]==list(range(8)) and len(ff)==(2 if f['temporal']=='commonML' else 1),'START_AND_FLOOR_DENOMINATOR');I.require(len(cc)==8+len(ff) and [c['candidate_id'] for c in cc]==list(range(len(cc))),'CANDIDATE_DENOMINATOR')
        I.require(sum(c['origin']=='solver' for c in cc)==8,'EXACT_ACCEPTED_SOLVER_DENOMINATOR')
        selected=min(cc,key=lambda c:(c['evaluation']['joint_nll'],c['candidate_id']));I.require(f['selected']==selected,'MINIMUM_TRAINING_SELECTION')
        for c in cc:I.require(feasible(c['pars'],temporal),'CANDIDATE_PARAMETER_BOUNDS');I.require(c['quadrature_error']<=1e-4 and abs(c['quadrature_error']-abs(c['evaluation']['joint_nll']-c['fine_evaluation']['joint_nll']))<=1e-12,'CANDIDATE_QUADRATURE');I.require(c['origin'] in ['solver','poisson_floor','fixedML_tau1_floor'],'NO_UNPLANNED_CANDIDATE');add(f,c['pars'],c['evaluation']);add(f,c['pars'],c['fine_evaluation'])
        for slot in ss:
            I.require(feasible(slot['requested_start'],temporal) and same(slot['start'],slot['requested_start']),'START_PARAMETER_BOUNDS')
            I.require(slot['status']=='complete' and len(slot['attempts']) in [1,2] and sum(bool(v['accepted']) for v in slot['attempts'])==1,'COMPLETE_START_LINEAGE')
            for tier,v in enumerate(slot['attempts']):
                I.require(v['tier']==tier and v['method']==('L-BFGS-B' if tier==0 else 'Powell') and same(v['start'],slot['requested_start']),'ORIGINAL_START_RECOVERY')
                if tier:I.require(slot['attempts'][0]['accepted'] is False,'FAILURE_ONLY_RECOVERY')
                expected_options={k:value for k,value in (fp['optimizer'] if tier==0 else fp['failure_only_recovery'][0]).items() if k not in ['method','same_original_start']}
                I.require(v['options']==expected_options,'EXACT_SOLVER_OPTIONS')
                if 'initial_nll' in v:
                    I.require(math.isfinite(v['initial_nll']),'FINITE_INITIAL_NLL');add(f,slot['requested_start'],dict(joint_nll=v['initial_nll']));records[-1]['scalar_initial_nll']=True
                if 'pars' in v:I.require(v.get('finite_feasible') is feasible(v['pars'],temporal),'SOLVER_FINITE_FEASIBLE_FLAG')
                if v['accepted']:
                    I.require(v.get('success') is True and v.get('finite_feasible') is True and math.isfinite(v['reported_nll']) and abs(v['reported_nll']-v['evaluation']['joint_nll'])<=1e-7 and v['evaluation']['joint_nll']<=v['initial_nll']+1e-8 and abs(v['evaluation']['joint_nll']-v['fine_evaluation']['joint_nll'])<=1e-4,'ACCEPTED_SOLVER_CONDITIONS')
                    matched=[c for c in cc if c.get('slot')==slot['slot'] and c.get('tier')==tier and c['origin']=='solver']
                    I.require(len(matched)==1 and matched[0]['pars']==v['pars'] and matched[0]['evaluation']==v['evaluation'] and matched[0]['fine_evaluation']==v['fine_evaluation'],'ACCEPTED_SLOT_CANDIDATE_LINEAGE')
                if v.get('finite_feasible'):add(f,v['pars'],v['evaluation']);add(f,v['pars'],v['fine_evaluation']);returns+=1
        for floor in ff:I.require(floor['status']=='complete' and any(c['candidate_id']==floor['candidate_id'] and same(c['pars'],floor['pars']) and c['origin']==floor['origin'] for c in cc),'EXACT_FLOOR_LINEAGE')
        poisson=next(s for s in ff if s['origin']=='poisson_floor');expected=[ap,0.,0.]+([0.] if f['temporal']=='commonML' else [0.,1.3] if f['temporal']=='Omori' else []);close(poisson['pars'],expected,1e-12,'EXACT_POISSON_POINT')
        if f['temporal']=='fixedML':expected=[[a0+s['a_offset'],s['d'],s['n']] for s in fp['fixedML_starts']]
        else:
            point=models['fixedML_smooth_'+f['spatial']]['selected']['pars'];expected=[point+[math.log(x)] for x in fp['commonML_tau_starts_days']] if f['temporal']=='commonML' else [point+[math.log(c),p] for c,p in fp['Omori_cp_starts']]
            if f['temporal']=='commonML':nested=next(s for s in ff if s['origin']=='fixedML_tau1_floor');close(nested['pars'],point+[0.],1e-12,'EXACT_FIXEDML_NESTING')
        for slot,point in zip(ss,expected):close(slot['requested_start'],point,1e-12,'PRESCRIBED_START')
        if f['role']=='primary_main':models[f['temporal']+'_smooth_'+f['spatial']]=f
        starts+=8;floors+=len(ff);candidates+=len(cc);lineage.append(dict(procedure_id=f['procedure_id'],candidates=len(cc),selected_candidate_id=selected['candidate_id'],near_optimal_candidates=[c['candidate_id'] for c in cc if c['evaluation']['joint_nll']<=selected['evaluation']['joint_nll']+4e-4]))
        # All selectors complete before the first main; expose only the one
        # training-selected alias for matched temporal start construction.
        if f is fits[5]:
            ordinal,winning=min(enumerate(fits[:6]),key=lambda pair:(pair[1]['selected']['evaluation']['joint_nll'],pair[0],pair[1]['selected']['candidate_id']));models['fixedML_smooth_cont']=winning
            I.require(case['selected_sigma']==SCALES[ordinal],'SHARED_SIGMA_SELECTION');alias=I.read(Path(path).with_name('alias_fixedML_smooth_cont.json'));I.require(alias==case['model_aliases']['fixedML_smooth_cont'] and alias['source_procedure_id']==winning['procedure_id'] and alias['source_sha256']==I.sha(paths[ordinal]) and alias['source_candidate_id']==winning['selected']['candidate_id'] and alias['no_additional_fit'] is True,'FIXEDML_MAIN_ALIAS')
    I.require(starts==80 and floors==11 and candidates==91 and set(models)==set(MODELS),'FULL_INITIALIZATION_DENOMINATORS')
    for mid,f in models.items():I.require(case['models'][mid]['procedure_id']==f['procedure_id'] and case['models'][mid]['selected']==f['selected'] and case['models'][mid]['cache_paths']==f['cache_paths'] and f['sigma']==case['selected_sigma'],'MATCHED_MODEL_BINDINGS')
    I.require(set(case['cache_paths'])=={Path(k).name.rsplit('_train',1)[0][6:] for k in allcache} and {str(Path(v).resolve()) for paths in case['cache_paths'].values() for v in paths.values()}==allcache,'CASE_ALL_CACHE_BINDINGS')
    I.require(allcache=={str(Path(r['path']).resolve()) for r in initialization['nuisance_outputs']},'FULL_NUISANCE_CACHE_BINDINGS')
    cache_reports=[];geometry_cache={}
    for path in sorted(allcache):cache_reports.append(cache_audit(path,raw,pi,case['beta'],kde['selected_bandwidth'],geometry_cache,cache_contracts[path]))
    bundle=dict(schema_version=1,data_classification='local_verified_empirical_rows',source_verification_passed=True,profile='new_zealand',production_source_pins=protocol['artifact_pins'],raw={k:raw[k] for k in ['times','excess','latitude','longitude']},records=records,nuisance_controls=[dict(train_start=0.,train_end=24394.,production_kde_selection=case['kde_selection'])])
    numerical=E.audit(bundle)
    return dict(status='passed',passed=True,independent=True,scope='Full913rawCSV/depth/nuisance/candidate/solver/floor/cache audit; no production imports/DLL',bindings=bindings,denominators=dict(procedures=10,starts=80,floors=11),model_roster=MODELS,candidate_count=candidates,finite_solver_returns=returns,raw_rows=913,legacy_metadata=ref(metadata_path),source_population=raw['source_population'],lineage=lineage,cache_reports=cache_reports,numerical=numerical,gradient_policy='abs(delta)<=2e-5+2e-10*maxabs_per_coordinate',score_absolute_tolerance=1e-4)


def main():
    p=argparse.ArgumentParser();p.add_argument('--initialization',required=True);p.add_argument('--metadata',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    try:result=audit(I.read(a.initialization),a.metadata)
    except Exception as error:result=dict(status='failed',passed=False,independent=True,fixed_error_code='NZ_INITIALIZATION_RAW_AUDIT_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['status','passed','denominators','candidate_count','finite_solver_returns','raw_rows','fixed_error_code','error_type'] if k in result},allow_nan=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
