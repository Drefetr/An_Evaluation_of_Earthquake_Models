"""Independent-reader schema counterexamples, handcrafted only; root leases."""
import argparse,hashlib,json,tempfile
from pathlib import Path
from . import raw_input_v3 as R
from . import empirical_io_v2 as I
import numpy as np


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();checks=[]
    def check(name,ok):
        if not ok:raise ValueError('RAW_READER_FIXTURE_FAILED')
        checks.append(name)
    def row(identity,mag='4.0',clock='01:02:03.00',kind='eq',lat='34.0',year=1986):
        return f'{year}/02/03 {clock} {kind} l {mag} w {lat} -117.0 5.0 A {identity} 10 20\n'
    with tempfile.TemporaryDirectory(prefix='independent-raw-schema-fixtures-') as tmp:
        folder=Path(tmp)
        def run(text,year=1986):
            raw=text.encode('ascii') if isinstance(text,str) else text;path=folder/(str(year)+'.catalog');path.write_bytes(raw)
            pin=dict(bytes=len(raw),git_blob_sha1=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),sha256=hashlib.sha256(raw).hexdigest())
            return R.read_annual_raw([path],{path.name:pin})
        def reject(name,text,reason):
            try:run(text)
            except ValueError as error:check(name,str(error)==reason)
            else:check(name,False)
        text=row('SYN_READER_A')+row('SYN_READER_B','2.5','01:02:60.25')+row('SYN_READER_C','5.0','01:02:60.00','qb')
        result=run(text)
        check('model_has_only_valid_clock_M4',len(result['times'])==1 and result['row_ids']==['scedc:SYN_READER_A'])
        check('date_only_diagnostic_retains_all_M2',len(result['diagnostic_rows'])==2)
        unavailable=[r for r in result['diagnostic_rows'] if r['clock_validation_status']!='valid']
        check('unavailable_not_normalized',len(unavailable)==1 and unavailable[0]['origin_time_us'] is None and unavailable[0]['source_date']=='1986-02-03')
        check('excluded_type_never_model_or_diagnostic',all(r['event_id']!='scedc:SYN_READER_C' for r in result['diagnostic_rows']))
        reject('badclock_M4_aborts_entire_input',row('SYN_READER_A')+row('SYN_READER_D','4.0','01:02:60.00'),'MODEL_CLOCK_UNAVAILABLE')
        reject('second61_remains_fatal_offmodel',row('SYN_READER_A')+row('SYN_READER_E','2.5','01:02:61.00'),'Unsupported raw clock range')
        reject('bad_minute_remains_fatal_offmodel',row('SYN_READER_A')+row('SYN_READER_E','2.5','01:60:60.00'),'Unsupported raw clock range')
        reject('boundary_ambiguity_aborts_whole_input',row('SYN_READER_A')+row('SYN_READER_F','2.5','01:02:03.00',lat='33.666666666666664'),'Independent source boundary assignment mismatch')
        reject('duplicate_ID_conflict_is_fatal',row('SYN_READER_A')+row('SYN_READER_A','5.0'),'Conflicting raw duplicate ID')
        duplicate=run(row('SYN_READER_A')+row('SYN_READER_A'))
        check('exact_duplicate_collapse_recorded',len(duplicate['times'])==1 and duplicate['duplicates']==1)
        base=row('SYN_OPAQUE_QUALITY');baseline=run(base)
        for ordinal,quality in enumerate(['A','None','UNKNOWN_QUALITY','??','Q'*1024]):
            altered=base.replace(' A ', ' '+quality+' ');candidate=run(altered)
            invariant=all(np.array_equal(candidate[key],value) if isinstance(value,np.ndarray) else candidate[key]==value for key,value in baseline.items())
            check('quality_metadata_cannot_change_numeric_population_'+str(ordinal),invariant)
            tokens=altered.split();expected=I.expected_record(tokens,1986,1,int(baseline['origin_us'][0]),'1986-02-03T01:02:03.00Z')
            check('exact_opaque_quality_in_canonical_expected_fields_'+str(ordinal),expected['location_quality']==quality and expected['source_tokens']['quality']==quality)
        reject('quality_only_duplicate_change_is_not_silently_collapsed',base+base.replace(' A ',' UNKNOWN_QUALITY '),'Conflicting raw duplicate ID')
        for ordinal,quality in enumerate(['AA BB','', '\x00','\x1b','\x7f']):
            reason='Raw13field schema' if ordinal<2 else 'Raw opaque printable ASCII quality token'
            reject('quality_invalid_shape_or_control_'+str(ordinal),base.replace(' A ',' '+quality+' '),reason)
        reject('nonASCII_quality_rejected_at_reader_byte_boundary',base.encode('ascii').replace(b' A ',b' \xc3\xa9 '),'Raw ASCII decoding failure')
        reject('wide_quality_does_not_waive_bad_numeric',base.replace(' A ',' UNKNOWN_QUALITY ').replace('4.0','bad'),'Raw structural value invalid')
        reject('wide_quality_does_not_waive_bad_clock',base.replace(' A ',' UNKNOWN_QUALITY ').replace('01:02:03.00','01:02:61.00'),'Unsupported raw clock range')
        protected=run(row('SYN_READER_G',year=2011)+row('SYN_READER_H','2.5','01:02:60.25',year=2011),2011)
        check('same_date_only_policy_protected_fixture',len(protected['times'])==1 and len(protected['diagnostic_rows'])==2 and sum(r['origin_time_us'] is None for r in protected['diagnostic_rows'])==1)
    result=dict(status='passed',passed=True,independent=True,source_pins={str(Path(__file__).resolve()):hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),str(Path(R.__file__).resolve()):hashlib.sha256(Path(R.__file__).read_bytes()).hexdigest(),str(Path(I.__file__).resolve()):hashlib.sha256(Path(I.__file__).read_bytes()).hexdigest()},kind='handcrafted_independent_lossless_quality_reader_fixtures',checks=checks,check_count=len(checks),empirical_inputs=False,model_fits=0,network_requests=0)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(dict(passed=True,checks=len(checks),empirical_inputs=False)))


if __name__=='__main__':
    try:main()
    except Exception as error:print(json.dumps(dict(passed=False,fixed_error_code='INDEPENDENT_RAW_PARSER_FIXTURE_FAILURE',error_type=type(error).__name__)));raise SystemExit(1)
