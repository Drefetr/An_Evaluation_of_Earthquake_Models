"""Handcrafted-law oracle self controls; execute only under numerical lease.

This validates the independent evaluator itself, not production equivalence.
The only stdout is a scalar pass/check/error summary.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from . import oracle as O


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True);args=parser.parse_args()
    rect=O.rectangles([32,33.666666666666664,35.333333333333336,37],[-121,-118.66666666666667,-116.33333333333333,-114],34.5,-117.5)
    centers=np.column_stack(((rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2))
    training=np.vstack((centers,centers+np.array([1.,2.])))
    parents=np.vstack((training,centers[[0,4,8]]+np.array([2.,-1.])))
    t=np.r_[np.arange(18,dtype=float),[21.,25.,25.]];q=np.linspace(0,1.4,len(t));te=t[-3:];qe=q[-3:]
    pi=O.reference_mass(np.tile(np.arange(9),2),np.ones(18,dtype=bool));models={'fixedML':[-1,.1,.2],'commonML':[-1,.1,.2,.4],'Omori':[-1,.1,.2,-.7,1.3]}
    checks=[];gradmax=0.;decompmax=0.;nestmax=0.;timingmax=0.;massmax=0.;integralmax=0.
    results={}
    def evaluate(model,p,g):return O.evaluate(model,p,t,q,te,qe,1.1,20.,30.,40.,g,chunk=2)
    for family in ('continuous','lift'):
        g=O.geometry(parents,parents[-3:],training,rect,pi,50.,150.,family)
        massmax=max(massmax,float(np.max(abs(g['parent_cell'].sum(axis=1)-1))),abs(float(g['background_cell'].sum())-1))
        for model,p in models.items():
            p=np.array(p,float);v=evaluate(model,p,g);results[family,model]=v
            score=v['timing_logscore']+v['conditional_zone_logscore']+v['conditional_cell_logscore']+v['within_cell_density_logscore']+v['mark_logscore']
            decompmax=max(decompmax,abs(score-v['joint_logscore']))
            for k in range(len(p)):
                step=1e-5;plus=p.copy();minus=p.copy();plus[k]+=step;minus[k]-=step
                fd=(evaluate(model,plus,g)['joint_nll']-evaluate(model,minus,g)['joint_nll'])/(2*step)
                gradmax=max(gradmax,abs(fd-v['gradient'][k]))
            zero=p.copy();zero[2]=0;z=evaluate(model,zero,g)
            if len(p)>3:checks.append(dict(name='n0_temporal_gradient_'+family+'_'+model,passed=bool(np.all(z['gradient'][3:]==0))))
        fixed=evaluate('fixedML',models['fixedML'],g)
        free=evaluate('commonML',models['fixedML']+[0.],g)
        nestmax=max(nestmax,abs(fixed['joint_nll']-free['joint_nll']),float(np.max(abs(fixed['gradient']-free['gradient'][:3]))))
    for model in models:
        timingmax=max(timingmax,abs(results['continuous',model]['timing_logscore']-results['lift',model]['timing_logscore']))
    for d in (0.,1e-8,-1e-8,.4,-.7):
        B,Bd=O.immigrant_integral(-1,d,20,30,40)
        exact=quad(lambda x:math.exp(-1+d*(2*x/40-1)),20,30,epsabs=1e-12)[0]
        exactd=quad(lambda x:(2*x/40-1)*math.exp(-1+d*(2*x/40-1)),20,30,epsabs=1e-12)[0]
        integralmax=max(integralmax,abs(B-exact),abs(Bd-exactd))
    # Explicit tied-batch witness: both simultaneous targets use the identical
    # history cutoff; no tie's mark is admitted as another same-time parent.
    for model,p in models.items():
        lag=np.array([0.,-1.,1.]);valid=lag>0
        k,_,_=O.temporal(model,p,lag[valid],np.zeros(3),np.ones(3))
        masked=np.zeros(3);masked[valid]=k
        checks.append(dict(name='strict_positive_lag_'+model,passed=bool(np.all(masked[:2]==0))))
    checks.extend([
        dict(name='analytic_gradient_finite_difference',passed=gradmax<=1e-5),
        dict(name='proper_score_decomposition',passed=decompmax<=1e-10),
        dict(name='fixedML_exact_commonML_nesting',passed=nestmax<=1e-10),
        dict(name='normalized_spatial_fixed_parameter_timing',passed=timingmax<=1e-10),
        dict(name='unit_spatial_mass',passed=massmax<=1e-12),
        dict(name='analytic_immigrant_integral',passed=integralmax<=1e-10)])
    output=dict(passed=all(c['passed'] for c in checks),scope='independent oracle handcrafted self-controls only; production reconciliation pending',checks=checks,
                maximum_absolute_gradient_error=gradmax,maximum_decomposition_error=decompmax,maximum_nesting_error=nestmax,
                maximum_fixed_parameter_timing_error=timingmax,maximum_spatial_mass_error=massmax,maximum_immigrant_integral_error=integralmax)
    Path(args.output).write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(dict(passed=output['passed'],checks=len(checks),maximum_absolute_gradient_error=gradmax)))
    return 0 if output['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
