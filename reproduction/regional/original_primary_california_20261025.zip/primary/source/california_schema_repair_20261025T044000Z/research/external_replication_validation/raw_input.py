"""Independent local-only reconstruction from official annual raw bytes.

Does not import the production parser or accept its parsed rows as authority.
No printing, model calls, or raw-input interpolation in exception messages.
"""
from __future__ import annotations
from datetime import datetime,timezone
from decimal import Decimal, InvalidOperation
import hashlib
import math
from pathlib import Path
import re
import numpy as np
from scipy.optimize import brentq
from .oracle import require,project,rectangles,labels,reference_mass

UTC=timezone.utc
MAGTYPES={'e','w','b','s','l','lr','c','h','d','n'}
TIME=re.compile(r'^\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?$')
DATE=re.compile(r'^\d{4}/\d{2}/\d{2}$')


def utc(value):
    dt=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(dt.utcoffset() is not None and dt.utcoffset().total_seconds()==0,'UTC timestamp required')
    return dt


def micros(value):
    delta=value-datetime(1970,1,1,tzinfo=UTC)
    return (delta.days*86400+delta.seconds)*1000000+delta.microseconds


def read_annual_raw(paths,pins,profile,minimum=4.,time_epoch='1981-01-01T00:00:00Z'):
    """Return private arrays and row identities; never send the return to a model.

    pins maps annual filename to agency Git blob SHA1, bytes and optional SHA256.
    All source records validated before population filtering; same-ID conflicts
    fail even when one representation would fall outside model eligibility.
    """
    records={};duplicates=0;missing=0
    for path in map(Path,paths):
        raw=path.read_bytes();pin=pins[path.name]
        require(len(raw)==pin['bytes'],'Raw annual byte length mismatch')
        require(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin['git_blob_sha1'],'Raw annual Git identity mismatch')
        if pin.get('sha256'):require(hashlib.sha256(raw).hexdigest()==pin['sha256'],'Raw annual SHA256 mismatch')
        try: lines=raw.decode('ascii').splitlines()
        except UnicodeError:raise ValueError('Raw ASCII decoding failure') from None
        try: year=int(path.stem)
        except ValueError:raise ValueError('Annual filename invalid') from None
        for line_no,line in enumerate(lines,1):
            if not line.strip() or line.lstrip().startswith('#'):continue
            tokens=line.split();require(len(tokens)==13,'Raw schema field count mismatch')
            require(bool(DATE.fullmatch(tokens[0])) and bool(TIME.fullmatch(tokens[1])),'Raw datetime syntax mismatch')
            try:
                dt=datetime.fromisoformat(tokens[0].replace('/','-')+'T'+tokens[1]).replace(tzinfo=UTC)
                values=[Decimal(tokens[i]) for i in (4,6,7,8)]
                require(all(v.is_finite() for v in values),'Raw nonfinite numeric field')
                count0,count1=int(tokens[11]),int(tokens[12])
            except (ValueError,InvalidOperation):raise ValueError('Raw schema value invalid') from None
            require(dt.year==year,'Raw annual source year mismatch')
            require(tokens[5] in MAGTYPES and tokens[9] in {'A','B','C','D','Z'},'Raw undocumented code')
            require(count0>=0 and count1>=0,'Raw negative count')
            magnitude,latitude,longitude,depth=values
            require(-90<=latitude<=90 and -180<=longitude<=180,'Raw coordinate range')
            identity=tokens[10]
            if identity in records:
                require(records[identity]['tokens']==tokens,'Raw duplicate identity conflict')
                duplicates+=1;continue
            records[identity]=dict(tokens=tokens,dt=dt,us=micros(dt),magnitude=magnitude,
                                   latitude=latitude,longitude=longitude,depth=depth,
                                   year=year,line=line_no)
    epoch=utc(time_epoch);selected=[]
    for identity,row in records.items():
        t=row['tokens']
        if t[2]!='eq':continue
        if t[5]=='n':missing+=1;continue
        if row['magnitude']<Decimal(str(minimum)):continue
        if not Decimal(str(profile['latitude_edges'][0]))<=row['latitude']<=Decimal(str(profile['latitude_edges'][-1])):continue
        if not Decimal(str(profile['longitude_edges'][0]))<=row['longitude']<=Decimal(str(profile['longitude_edges'][-1])):continue
        if not Decimal('-5')<=row['depth']<=Decimal('40'):continue
        if not utc(profile['history_start_utc'])<=row['dt']<utc(profile['end_utc']):continue
        selected.append((identity,row))
    selected.sort(key=lambda pair:(pair[1]['us'],pair[0]))
    require(bool(selected),'Empty independent population')
    t=np.array([(r['us']-micros(epoch))/(86400*1000000) for _,r in selected])
    q=np.array([float(r['magnitude']-Decimal(str(minimum))) for _,r in selected])
    lat=np.array([float(r['latitude']) for _,r in selected]);lon=np.array([float(r['longitude']) for _,r in selected])
    xy=project(lat,lon,profile['phi0_degrees'],profile['lambda0_degrees'])
    rect=rectangles(profile['latitude_edges'],profile['longitude_edges'],profile['phi0_degrees'],profile['lambda0_degrees'])
    return dict(times=t,excess=q,latitude=lat,longitude=lon,xy=xy,cells=labels(xy,rect),rectangles=rect,
                row_ids=[i for i,_ in selected],source_year=np.array([r['year'] for _,r in selected]),
                source_line=np.array([r['line'] for _,r in selected]),origin_us=np.array([r['us'] for _,r in selected],dtype=np.int64),
                duplicates=duplicates,missing_magnitude_records=missing)


def fit_beta(q,cut=.5):
    q=np.asarray(q,float);require(np.all(np.isfinite(q)) and np.all(q>=0),'Finite nonnegative training marks')
    high=q>=cut;nh=int(high.sum());nl=len(q)-nh
    require(nh>0 and nl>0,'Both conditional mark bins required')
    residual=math.fsum(q[~high])+math.fsum(q[high]-cut);require(residual>0,'Positive training mark residual')
    def score(beta):
        x=beta*cut
        low=cut*(.5-x/12+x**3/720) if x<1e-5 else 1/beta-cut/math.expm1(x) if x<700 else 1/beta
        return nh/beta+nl*low-residual
    upper=max(2.,2*len(q)/residual)
    while score(upper)>0:upper*=2
    return float(brentq(score,1e-9,upper,xtol=1e-12,rtol=1e-12))


def training_nuisance(raw,start,end):
    mask=(raw['times']>=start)&(raw['times']<end)
    require(mask.sum()>=180 and np.all(np.bincount(raw['cells'][mask]//3,minlength=3)>=30),'Frozen training adequacy failure')
    return dict(mask=mask,beta=fit_beta(raw['excess'][mask]),reference_pi=reference_mass(raw['cells'],mask),training_xy=raw['xy'][mask])
