"""Root-leased full empirical CA audit, with protected release guard.
Raw reconstruction and every saved candidate/return/cache stay inside the process.
Stdout reports scalar counts/errors only. No production imports or DLL loading.
"""
import argparse,json
from pathlib import Path
import numpy as np
from . import empirical_io_v2 as I
from .audit_ca_training_v2 import audit_training
from .audit_ca_forecast_v2 import audit_forecast


def merged_input(path,train_path,protected_path,expected_sha):
    I.require(I.sha(path)==expected_sha,'MERGED_PROTOCOL_INPUT_HASH')
    path=Path(path)
    if path.suffix=='.jsonl':
        with path.open(encoding='utf-8-sig') as stream:items=[json.loads(line) for line in stream if line.strip()]
        header=items[0];I.require(header.get('record_type')=='catalogue_header','MERGED_JSONL_HEADER');obj=dict(header,events=items[1:])
    else:obj=I.read(path)
    expected=I.read(train_path)['events']+I.read(protected_path)['events'];expected.sort(key=lambda row:(I.R.utc(row['origin_time_utc']),row['event_id']))
    I.require(obj['schema_version']==1 and isinstance(obj['catalogue_id'],str) and obj['provenance']['source_snapshot']==I.COMMIT,'MERGED_CANONICAL_HEADER')
    I.require(all(k in obj['provenance'] for k in ['raw_manifest_sha256','retrieved_utc']) and obj['events']==expected,'MERGED_ALL_RAW_CANONICAL_FIELDS')
    I.R.utc(obj['provenance']['retrieved_utc'])


def frozen_case(spec,T0):
    epoch=I.R.utc('1981-01-01T00:00:00Z')
    return dict(case_id=spec['id'],fold_id=spec['fold'],T0=T0,**{key:(I.R.utc(spec[key+'_utc'])-epoch).total_seconds()/86400. for key in ['train_start','train_end','test_start','test_end','history_start']})


def audit(run,root,protocol_path,methods_path,mode):
    run=Path(run);root=Path(root);protocol=I.read(protocol_path)
    I.require(protocol['status']=='frozen' and protocol['science_gate_passed'] is True,'FROZEN_SCIENCE_GATE_REQUIRED')
    for path,digest in protocol['artifact_pins'].items():I.require(I.sha(path)==digest,'FROZEN_DEPENDENCY_CHANGED')
    I.require(I.sha(methods_path) in protocol['artifact_pins'].values(),'FROZEN_METHODS_BINDING')
    I.require(mode in ['train','full'],'AUDIT_MODE')
    if mode=='full':I.require(protocol.get('protected_release_authorized') is True,'PROTECTED_RELEASE_REQUIRED_BEFORE_ANY_PROTECTED_READ')
    train=I.load_ca_lane(run,'train');protected=I.load_ca_lane(run,'protected') if mode=='full' else None
    if mode=='train':
        source=train;catalogue_sha256=train['canonical_sha256'];I.require(Path(protocol['data']['catalogue']).resolve()==(run/'inputs/california/train/canonical_model.json').resolve() and protocol['data']['sha256']==catalogue_sha256,'EXACT_TRAIN_ONLY_INPUT')
    else:
        source=I.merge_ca(train,protected);catalogue_sha256=protocol['data']['sha256'];merged_input(protocol['data']['catalogue'],run/'inputs/california/train/canonical_model.json',run/'protected/california/canonical_model.json',catalogue_sha256)
    raw=source['raw'];admissions=[I.ca_training_admission(raw,source['diagnostic'],year) for year in ([2011] if mode=='train' else [2011,2016,2021])];I.require(all(a['admitted'] for a in admissions),'FROZEN_EXPANDING_TRAINING_ELIGIBILITY')
    specs=protocol['cases'][:1] if mode=='train' else protocol['cases'];I.require(len(protocol['cases'])==3 and len(specs)==(1 if mode=='train' else 3),'EXACT_CASE_DENOMINATOR')
    results=[]
    for ordinal,spec in enumerate(specs):
        case=frozen_case(spec,protocol['era']['T0_days']);I.require(case['case_id']==f'california_fold_{ordinal}' and case['history_start']==0. and case['train_start']==1826. and case['T0']==16436.,'FROZEN_CA_ERA')
        folder=root/case['case_id'];training,context=audit_training(folder/'training_case.json',protocol_path,methods_path,raw,catalogue_sha256,case)
        result=dict(training=training)
        if mode=='full':result['forecast']=audit_forecast(folder,raw,context)
        results.append(result)
    totals=dict(procedures=10*len(specs),starts=80*len(specs),floors=11*len(specs),candidates=sum(r['training']['candidate_count'] for r in results),finite_solver_returns=sum(r['training']['finite_solver_returns'] for r in results))
    # Adequacy is a fixed descriptive outcome check, evaluated only after the
    # release guard. Failure does not alter population, dates, models or fits.
    adequacy=None
    if mode=='full':
        counts=[r['forecast']['target_events'] for r in results];adequacy=dict(total_events=sum(counts),window_events=counts,admitted=bool(sum(counts)>=100 and min(counts)>=20))
    bindings={}
    def bind(path):
        path=Path(path).resolve();I.require(str(path) not in bindings,'UNIQUE_REPORT_ARTIFACT_BINDINGS');bindings[str(path)]=I.sha(path)
    if mode=='full':
        final_cases=[]
        for spec in specs:
            folder=root/spec['id'];training=I.read(folder/'training_case.json');final=I.read(folder/'case.json');final_cases.append(final);plan=I.read(folder/'procedure_plan.json');case=training['case']
            schedule=[dict(id=f"{spec['id']}__selector_fixedML_smooth_cont_sigma{sigma:g}",case=spec['id'],phase='primary_selector',temporal='fixedML',background='smooth',spatial='cont',sigma_km=sigma,starts=8) for sigma in [5.,15.,50.,150.,500.,1500.]]
            for mid in ['fixedML_smooth_lift','commonML_smooth_cont','Omori_smooth_cont','Omori_smooth_lift']:
                temporal,background,spatial=mid.split('_');schedule.append(dict(id=f"{spec['id']}__main_{mid}",case=spec['id'],phase='primary_main',temporal=temporal,background=background,spatial=spatial,sigma_km='selected_baseline_sigma',starts=8))
            I.require(plan==dict(case=case,schedule=schedule,procedures=10,mandatory_starts=80,exact_floor_slots=11),'FROZEN_PROCEDURE_PLAN_ARTIFACT')
            for name in ['training_case.json','case.json','procedure_plan.json','alias_fixedML_smooth_cont.json']:bind(folder/name)
            for path in training['procedures']:
                fit=I.read(path);bind(path);bind(folder/('registry_'+fit['procedure_id']+'.json'));bind(folder/('score_'+fit['procedure_id']+'.json'))
        expected_summary=dict(status='complete' if all(case['status']=='complete' for case in final_cases) else 'unknown_incomplete',mode='california',cases=final_cases,procedures=30,mandatory_starts=240,exact_floor_slots=33)
        I.require(I.read(root/'summary_private.json')==expected_summary,'EXACT_SAVED_SUMMARY_ALL_CASE_BINDING');bind(root/'summary_private.json');I.require(len(bindings)==103,'COMPLETE_REPORT_ARTIFACT_BINDINGS')
    numeric=[r['training']['numerical'] for r in results]+[r['forecast']['numerical'] for r in results if 'forecast' in r]
    return dict(status='passed',passed=True,independent=True,data_classification='local_verified_empirical_rows',scope='Independent SCEDC raw/canonical source and all saved training/forecast candidates, solver returns, floors, nuisance/cache, selection and sensitivity lineage',mode=mode,bindings=bindings,protocol_sha256=I.sha(protocol_path),input_sha256=catalogue_sha256,source_commit=I.COMMIT,denominators=totals,training_admissions=admissions,target_adequacy=adequacy,maximum_absolute_score_error=max(r['maximum_absolute_score_error'] for r in numeric),maximum_absolute_gradient_error=max(r['maximum_absolute_gradient_error'] for r in numeric),maximum_gradient_criterion_ratio=max(r['maximum_gradient_criterion_ratio'] for r in numeric),gradient_criterion='abs(delta)<=2e-5+2e-10*maxabs_per_coordinate',score_absolute_tolerance=1e-4,cases=results)


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--root',required=True);p.add_argument('--protocol',required=True);p.add_argument('--methods',required=True);p.add_argument('--mode',choices=['train','full'],required=True);p.add_argument('--output',required=True);a=p.parse_args()
    try:result=audit(a.run,a.root,a.protocol,a.methods,a.mode)
    except Exception as error:result=dict(status='failed',passed=False,independent=True,fixed_error_code='CA_SAVED_EMPIRICAL_AUDIT_FAILED',error_type=type(error).__name__)
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps({k:result[k] for k in ['status','passed','mode','denominators','maximum_absolute_score_error','maximum_absolute_gradient_error','maximum_gradient_criterion_ratio','fixed_error_code','error_type'] if k in result},allow_nan=False));return 0 if result['passed'] else 1


if __name__=='__main__':raise SystemExit(main())
