"""Independent SCEDC raw-row authority with explicit time and opaque-quality amendments.

No production parser imports, fabricated clocks or source-byte mutation. Strict
time is mandatory for every fixed-population M4 event. Separate M2 diagnostics
retain source calendar dates and null unavailable times. Quality is losslessly preserved opaque metadata; it never filters or weights. All returns are private.
"""
from datetime import datetime,timezone
from decimal import Decimal,InvalidOperation
from fractions import Fraction
import hashlib,re
from pathlib import Path
import numpy as np
from . import oracle as O
from .raw_input import fit_beta,training_nuisance,utc,micros

DATE=re.compile(r'^\d{4}/\d{2}/\d{2}$')
CLOCK=re.compile(r'^(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?$')
NUMBER=re.compile(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$')
MAG={'e','w','b','s','l','lr','c','h','d','n'}
EVENT={'eq','qb','nt','ex','sh','sn','st','th','uk'}
LAT=[32.,32+5/3,32+10/3,37.];LON=[-121.,-121+7/3,-121+14/3,-114.]


def axis(token,low,high,edges):
    value=Fraction(Decimal(token));exact=-1 if value<low or value>high else 0 if 3*(value-low)<high-low else 1 if 3*(value-low)<2*(high-low) else 2
    converted=float(Decimal(token));binary=-1 if converted<edges[0] or converted>edges[-1] else 0 if converted<edges[1] else 1 if converted<edges[2] else 2
    O.require(exact==binary,'Independent source boundary assignment mismatch')
    return exact


def read_annual_raw(paths,pins,profile=None,minimum=4.,time_epoch='1981-01-01T00:00:00Z'):
    O.require(minimum==4. and time_epoch=='1981-01-01T00:00:00Z','Frozen California population')
    if profile is not None:
        O.require(list(profile['latitude_edges'])==LAT and list(profile['longitude_edges'])==LON,'Frozen California edges')
    paths=list(map(Path,paths));O.require(len({p.name for p in paths})==len(paths),'Unique raw annual inputs')
    rows={};duplicate_count=0
    for path in paths:
        raw=path.read_bytes();pin=pins[path.name];O.require(path.suffix=='.catalog' and path.stem.isdecimal(),'Annual filename')
        year=int(path.stem);O.require(1981<=year<=2025,'Annual source interval')
        O.require(len(raw)==pin['bytes'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==pin['git_blob_sha1'],'Raw annual Git identity')
        if pin.get('sha256'):O.require(hashlib.sha256(raw).hexdigest()==pin['sha256'],'Raw annual SHA256 identity')
        try:lines=raw.decode('ascii').splitlines()
        except UnicodeError:raise ValueError('Raw ASCII decoding failure') from None
        for number,line in enumerate(lines,1):
            if not line.strip() or line.lstrip().startswith('#'):continue
            tokens=line.split();O.require(len(tokens)==13,'Raw13field schema')
            O.require(bool(DATE.fullmatch(tokens[0])),'Raw date syntax')
            try:
                date=datetime.strptime(tokens[0],'%Y/%m/%d').date()
                O.require(all(NUMBER.fullmatch(tokens[i]) for i in [4,6,7,8]),'Raw decimal syntax')
                mag,lat,lon,depth=[Decimal(tokens[i]) for i in [4,6,7,8]]
                O.require(all(v.is_finite() for v in [mag,lat,lon,depth]),'Raw finite numerics')
                O.require(all(re.fullmatch(r'\d+',tokens[i]) for i in [11,12]),'Raw nonnegative integer counts')
            except (ValueError,InvalidOperation):raise ValueError('Raw structural value invalid') from None
            O.require(date.year==year and tokens[2] in EVENT and tokens[3] in {'l','r','t'} and tokens[5] in MAG,'Raw year or documented code')
            O.require(bool(tokens[9]) and all(33<=ord(c)<=126 for c in tokens[9]),'Raw opaque printable ASCII quality token')
            O.require(-90<=lat<=90 and -180<=lon<=180,'Raw global coordinate range')
            yi=axis(tokens[6],32,37,LAT);xi=axis(tokens[7],-121,-114,LON)
            match=CLOCK.fullmatch(tokens[1]);O.require(bool(match),'Raw clock syntax')
            hour,minute,second=map(int,match.groups()[:3]);O.require(hour<24 and minute<60 and second<=60,'Unsupported raw clock range')
            if second==60:dt=None;us=None;clock_status='unsupported_second_60'
            else:
                fraction=match.group(4) or '';dt=datetime(date.year,date.month,date.day,hour,minute,second,int(fraction.ljust(6,'0')) if fraction else 0,tzinfo=timezone.utc);us=micros(dt);clock_status='valid'
            identity=tokens[10]
            if identity in rows:
                O.require(rows[identity]['tokens']==tokens,'Conflicting raw duplicate ID');duplicate_count+=1;continue
            rows[identity]=dict(tokens=tokens,source_date=date.isoformat(),dt=dt,us=us,clock_status=clock_status,mag=mag,lat=lat,lon=lon,depth=depth,cell=-1 if yi<0 or xi<0 else 3*yi+xi,year=year,line=number)
    model=[];diagnostic=[];clock_counts={};missing=0
    for identity,row in rows.items():
        clock_counts[row['clock_status']]=clock_counts.get(row['clock_status'],0)+1
        tokens=row['tokens'];geometry=tokens[2]=='eq' and row['cell']>=0 and Decimal(-5)<=row['depth']<=Decimal(40)
        if geometry and tokens[5]=='n':missing+=1
        eligible=geometry and tokens[5]!='n'
        if eligible and row['mag']>=2:diagnostic.append((identity,row))
        if eligible and row['mag']>=4:
            O.require(row['clock_status']=='valid' and row['us'] is not None,'MODEL_CLOCK_UNAVAILABLE')
            model.append((identity,row))
    O.require(bool(model),'Empty independent model population')
    model.sort(key=lambda pair:(pair[1]['us'],pair[0]));diagnostic.sort(key=lambda pair:(pair[1]['source_date'],pair[0]))
    epoch=micros(utc(time_epoch));t=np.array([(r['us']-epoch)/(86400*1000000) for _,r in model]);q=np.array([float(r['mag']-4) for _,r in model]);lat=np.array([float(r['lat']) for _,r in model]);lon=np.array([float(r['lon']) for _,r in model]);xy=O.project(lat,lon,34.5,-117.5);rect=O.rectangles(LAT,LON,34.5,-117.5);cells=O.labels(xy,rect)
    O.require(np.array_equal(cells,[r['cell'] for _,r in model]),'Independent projected boundary assignment')
    return dict(times=t,excess=q,latitude=lat,longitude=lon,xy=xy,cells=cells,rectangles=rect,row_ids=['scedc:'+i for i,_ in model],source_year=np.array([r['year'] for _,r in model]),source_line=np.array([r['line'] for _,r in model]),origin_us=np.array([r['us'] for _,r in model],dtype=np.int64),duplicates=duplicate_count,missing_magnitude_records=missing,raw_clock_status_counts=clock_counts,
                diagnostic_rows=[dict(event_id='scedc:'+i,source_date=r['source_date'],origin_time_us=r['us'],clock_validation_status=r['clock_status'],magnitude=str(r['mag']),cell=r['cell'],source_year=r['year'],source_line=r['line']) for i,r in diagnostic])
