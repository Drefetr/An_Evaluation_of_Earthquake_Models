"""Leased diagnostic replay: only safe assertion codes/locations/norms escape.

Calls the frozen auditor directly so the exception is visible before its generic
CLI catch. Never prints raw rows, event arrays, fitted parameters or log scores.
Preserves frozen sources, fits, histories and failed audit artifacts.
"""
import argparse,ast,hashlib,json,traceback
from pathlib import Path
import numpy as np
from . import audit_saved_controls_v1 as A


def literal_messages():
    safe=set()
    for path in Path(__file__).parent.glob('*.py'):
        if path.name=='diagnose_saved_audit_v1.py':continue
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='require' and len(node.args)>=2 and isinstance(node.args[1],ast.Constant) and isinstance(node.args[1].value,str):safe.add(node.args[1].value)
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='require_close' and node.args and isinstance(node.args[-1],ast.Constant) and isinstance(node.args[-1].value,str):safe.add(node.args[-1].value)
    return safe


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--protocol',required=True);p.add_argument('--output',required=True);args=p.parse_args();safe=literal_messages();result=dict(scope='Frozen saved-controls diagnostic replay; no source/input repair/refit/redraw',numerical_replay=True,case_count_completed=0,passed=False)
    try:
        protocol=A.read(args.protocol)
        for law in A.LAWS:
            result['active_case']=law['name'];A.audit_case(Path(args.root)/law['name'],law,protocol);result['case_count_completed']+=1
        result['passed']=True;result['status']='no_failure_reproduced'
    except Exception as error:
        result.update(status='failure_reproduced',error_type=type(error).__name__,safe_assertion=str(error) if str(error) in safe else 'UNCLASSIFIED_EXCEPTION_TEXT_SUPPRESSED')
        frames=[];tb=error.__traceback__
        while tb is not None:
            f=tb.tb_frame;name=Path(f.f_code.co_filename).name
            if name in ['audit_saved_controls_v1.py','audit_machine_bundle.py','oracle.py','oracle_known_v1.py','nuisance_oracle.py']:
                frames.append(dict(file=name,function=f.f_code.co_name,line=tb.tb_lineno))
                # Only aggregate numeric comparison metadata from the comparator
                # frame, never actual event vectors or model parameter values.
                if name=='audit_machine_bundle.py' and f.f_locals.get('key')=='gradient':
                    actual=np.asarray(f.f_locals.get('a'),float);expected=np.asarray(f.f_locals.get('e'),float)
                    if actual.shape==expected.shape and actual.ndim==1 and actual.size in [3,4,5] and np.isfinite(actual).all() and np.isfinite(expected).all():
                        delta=abs(actual-expected);denominator=1+np.maximum(abs(actual),abs(expected))
                        result['gradient_comparison']=dict(components=int(actual.size),maximum_absolute_error=float(delta.max()),maximum_scaled_error=float(np.max(delta/denominator)),actual_absmax=float(np.max(abs(actual))),independent_absmax=float(np.max(abs(expected))),largest_error_coordinate=int(np.argmax(delta)))
            tb=tb.tb_next
        result['safe_traceback']=frames
    result['protocol_sha256']=hashlib.sha256(Path(args.protocol).read_bytes()).hexdigest()
    with Path(args.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False))
    # Diagnostic success means the exact failure was captured, not that the
    # scientific audit passed. Root records these statuses separately.
    return 0 if result.get('status')=='failure_reproduced' else 1


if __name__=='__main__':raise SystemExit(main())
