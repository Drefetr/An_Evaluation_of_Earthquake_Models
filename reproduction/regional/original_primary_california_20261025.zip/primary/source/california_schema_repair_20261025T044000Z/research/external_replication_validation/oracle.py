"""Independent direct-history proper-score oracle.

All event-level inputs and returned arrays stay in local programs/files. This
module has no printing, provider calls, production imports, or cache loading.
Geometry uses positive-integrand adaptive quadrature rather than production
rectangle antiderivatives. Empirical execution requires the numerical lease.
"""
from __future__ import annotations
from functools import lru_cache
import math
import numpy as np
from scipy.integrate import quad


def require(condition, message):
    if not condition:
        raise ValueError(message)


def project(latitude, longitude, phi0, lambda0, radius=6371.0088):
    phi = np.radians(np.asarray(latitude, float))
    lam = np.radians(np.asarray(longitude, float))
    c = math.cos(math.radians(phi0))
    return np.column_stack((radius*c*(lam-math.radians(lambda0)),
                            radius*(np.sin(phi)-math.sin(math.radians(phi0)))/c))


def rectangles(latitude_edges, longitude_edges, phi0, lambda0):
    lat, lon = np.asarray(latitude_edges), np.asarray(longitude_edges)
    require(len(lat)==4 and len(lon)==4 and np.all(np.diff(lat)>0) and np.all(np.diff(lon)>0), "Frozen 3 by 3 support")
    xs = project(np.repeat(lat[0],4),lon,phi0,lambda0)[:,0]
    ys = project(lat,np.repeat(lon[0],4),phi0,lambda0)[:,1]
    return np.array([[xs[j],xs[j+1],ys[i],ys[i+1]] for i in range(3) for j in range(3)])


def labels(points, rect):
    out = []
    for x,y in np.asarray(points):
        candidates = [i for i,(xl,xh,yl,yh) in enumerate(rect) if xl<=x<=xh and yl<=y<=yh]
        require(bool(candidates), "Point outside frozen support")
        out.append(max(candidates))
    return np.array(out, dtype=int)


def rectangle_mass(bounds, parent, scale, epsabs=1e-9, epsrel=2e-11):
    return _rectangle_mass(tuple(map(float,bounds)),tuple(map(float,parent)),float(scale),float(epsabs),float(epsrel))


@lru_cache(maxsize=300000)
def _rectangle_mass(bounds,parent,scale,epsabs,epsrel):
    require(scale>0 and math.isfinite(scale), "Positive finite scale")
    xl,xh,yl,yh=bounds; px,py=parent
    require(xh>xl and yh>yl, "Positive rectangle area")
    lo,hi=(xl-px)/scale,(xh-px)/scale
    bottom,top=(yl-py)/scale,(yh-py)/scale
    nodes,weights=np.polynomial.legendre.leggauss(32)
    def cross(x):
        A=1+x*x; root=math.sqrt(A)
        theta0=math.atan2(bottom,root)
        delta=math.atan2((top-bottom)*root,A+bottom*top)
        if delta<=0: delta+=math.pi
        theta=theta0+(nodes+1)*delta/2
        return float(weights@np.cos(theta)**2)*delta/(2*A**1.5)
    cuts={lo,hi}
    for v in [0.]+[s*2.**k for k in range(-8,24) for s in [-1,1]]:
        if lo<v<hi: cuts.add(v)
    edges=sorted(cuts); terms=[]; errors=[]
    for a,b in zip(edges[:-1],edges[1:]):
        v,e=quad(cross,a,b,epsabs=epsabs/(scale*scale*(len(edges)-1)),epsrel=epsrel,limit=100)
        terms.append(v); errors.append(e)
    mass=scale*scale*math.fsum(terms)
    require(mass>0 and math.isfinite(mass), "Positive finite independently integrated mass")
    return mass,scale*scale*math.fsum(errors)


def reference_mass(cells, mask):
    counts=np.bincount(np.asarray(cells)[mask],minlength=9)
    zones=counts.reshape(3,3).sum(axis=1); N=int(counts.sum())
    require(N>0 and np.all(zones>0), "Positive training zone counts")
    pi=(zones/N).repeat(3)*(counts+.5)/(zones.repeat(3)+1.5)
    require(np.all(pi>0) and abs(pi.sum()-1)<1e-12, "Unit reference mass")
    return pi


def kernel(points, centers, scale):
    return (1+np.sum((np.asarray(points)[:,None,:]-np.asarray(centers)[None,:,:])**2,axis=2)/scale**2)**-2


def geometry(parent_xy,event_xy,training_xy,rect,pi,scale,bandwidth,spatial,floor=.05):
    parent_xy,event_xy,training_xy=map(lambda x:np.asarray(x,float),(parent_xy,event_xy,training_xy))
    area=(rect[:,1]-rect[:,0])*(rect[:,3]-rect[:,2]); density=pi/area
    if spatial=='continuous':
        mass=np.array([[rectangle_mass(b,p,scale)[0] for b in rect] for p in parent_xy])
        normalizer=mass@density
        parent_cell=mass*density[None,:]/normalizer[:,None]
    elif spatial=='lift':
        centers=np.column_stack(((rect[:,0]+rect[:,1])/2,(rect[:,2]+rect[:,3])/2))
        weighted=kernel(parent_xy,centers,scale)*pi[None,:]
        normalizer=weighted.sum(axis=1); parent_cell=weighted/normalizer[:,None]
    else:
        raise ValueError("Frozen continuous or lift spatial family required")
    kmass=np.array([[rectangle_mass(b,p,bandwidth)[0] for b in rect] for p in training_xy])
    kz=kmass.sum(axis=1)
    bcell=floor*pi+(1-floor)*np.mean(kmass/kz[:,None],axis=0)
    require(np.max(abs(parent_cell.sum(axis=1)-1),initial=0)<1e-12 and abs(bcell.sum()-1)<1e-12, "Unit offspring/background mass")
    return dict(parent_xy=parent_xy,event_xy=event_xy,training_xy=training_xy,rect=rect,pi=pi,
                area=area,density=density,scale=scale,bandwidth=bandwidth,spatial=spatial,
                parent_cell=parent_cell,parent_normalizer=normalizer,kde_normalizer=kz,
                background_cell=bcell,floor=floor,event_cell=labels(event_xy,rect))


def mixture():
    alpha=.5;step=.4;bound=1e-8
    c=4*math.sin(math.pi*alpha)/(math.pi*alpha)
    m=math.ceil(max(math.log(4)/alpha,math.log(c/bound)/alpha)/step)
    v=np.arange(-m,m+1)*step
    w=step*math.sin(math.pi*alpha)/(2*math.pi*(np.cosh(alpha*v)+math.cos(math.pi*alpha)))
    w[[0,-1]]*=.5
    return w/w.sum(),np.exp(v)


def temporal(model,parameters,u,lower,upper):
    """u contains only strictly positive lags; no simultaneous-event triggering."""
    k=np.zeros_like(u); J=np.zeros_like(lower); deriv=[]
    if model in ('fixedML','commonML'):
        tau=math.exp(parameters[3]) if model=='commonML' else 1.
        w,r=mixture();r=r/tau;dk=np.zeros_like(k);dJ=np.zeros_like(J)
        for weight,rate in zip(w,r):
            value=weight*rate*np.exp(-rate*u); k+=value; dk+=value*(rate*u-1)
            A=np.exp(-rate*lower);B=np.exp(-rate*upper)
            J+=weight*A*(-np.expm1(-rate*(upper-lower)))
            dJ+=weight*rate*(lower*A-upper*B)
        if model=='commonML':deriv=[(dk,dJ)]
    elif model=='Omori':
        c=math.exp(parameters[3]);p=parameters[4];require(p>1,"Unit Omori mass")
        L=np.log1p(u/c);k=(p-1)/c*np.exp(-p*L)
        L0=np.log1p(lower/c);L1=np.log1p(upper/c)
        A=np.exp((1-p)*L0);B=np.exp((1-p)*L1)
        J=A*(-np.expm1((1-p)*np.log1p((upper-lower)/(c+lower))))
        deriv=[(k*(-1+p*u/(c+u)),(p-1)*(A*lower/(c+lower)-B*upper/(c+upper))),
               (k*(1/(p-1)-L),-A*L0+B*L1)]
    else:raise ValueError("Frozen temporal family required")
    return k,J,deriv


def immigrant_integral(a,d,start,end,T0):
    """Analytic integral and d derivative; stable at d=0."""
    midpoint=(start+end)/T0-1; half=(end-start)/T0; z=d*half
    if abs(z)<1e-4:
        sinhc=1+z*z/6+z**4/120+z**6/5040
        ratio=z/3-z**3/45+2*z**5/945
    else:
        sinhc=math.sinh(z)/z;ratio=1/math.tanh(z)-1/z
    B=(end-start)*math.exp(a+d*midpoint)*sinhc
    return B,B*(midpoint+half*ratio)


def evaluate(model,parameters,parent_time,parent_excess,event_time,event_excess,beta,start,end,T0,g,chunk=64):
    """Raw chronological history plus independently built geometry, no event cache.

    Returns local detailed arrays and scalar score components. Never forward the
    full return to a model context. Event time/excess arrays must match the
    exact scoring subset of parent history; outer harness verifies row identity.
    """
    pars=np.asarray(parameters,float);dim={'fixedML':3,'commonML':4,'Omori':5}[model]
    require(pars.shape==(dim,) and np.isfinite(pars).all(),"Finite parameter coordinates")
    t,q,te,qe=map(lambda x:np.asarray(x,float),(parent_time,parent_excess,event_time,event_excess))
    require(t.shape==q.shape and te.shape==qe.shape and np.all(np.diff(t)>=0),"Raw chronological history")
    require(np.all((t<end)&(q>=0)) and np.all((te>=start)&(te<end)) and beta>0,"Frozen event/history eligibility")
    require(len(t)==len(g['parent_xy']) and len(te)==len(g['event_xy']),"Raw geometry cardinality")
    a,d,n=pars[:3];require(n>=0,"Nonnegative branching")
    fert=.3*np.exp(.7*beta*q);lo=np.maximum(start-t,0.);hi=end-t
    _,J,ed=temporal(model,pars,np.empty(0),lo,hi)
    K=float(fert@J);B,Bd=immigrant_integral(a,d,start,end,T0)
    exposure=B+n*K;cellcomp=B*g['background_cell']+n*((fert*J)@g['parent_cell'])
    gradient=np.zeros(dim);gradient[:3]=[B,Bd,K]
    for j,(_,DJ) in enumerate(ed):gradient[3+j]=n*float(fert@DJ)
    lp=np.empty(len(te));lg=np.empty(len(te));lc=np.empty(len(te));lz=np.empty(len(te))
    for begin in range(0,len(te),chunk):
        stop=min(begin+chunk,len(te));rows=np.arange(begin,stop);tx=2*te[rows]/T0-1
        lag=te[rows,None]-t[None,:];valid=lag>0
        kv,_,der=temporal(model,pars,lag[valid],lo,hi)
        D=np.zeros_like(lag);D[valid]=kv;weighted=D*fert[None,:]
        cell=g['event_cell'][rows]
        if g['spatial']=='continuous':
            offspring=kernel(g['event_xy'][rows],g['parent_xy'],g['scale'])*g['density'][cell,None]/g['parent_normalizer'][None,:]
        else:offspring=g['parent_cell'][:,cell].T/g['area'][cell,None]
        bg=g['floor']*g['density'][cell]+(1-g['floor'])*np.mean(kernel(g['event_xy'][rows],g['training_xy'],g['bandwidth'])/g['kde_normalizer'][None,:],axis=1)
        mu=np.exp(a+d*tx);base=mu*bg;Hp=np.sum(weighted*offspring,axis=1)
        point=base+n*Hp;ground=mu+n*weighted.sum(axis=1)
        cells=mu[:,None]*g['background_cell'][None,:]+n*(weighted@g['parent_cell'])
        zones=cells.reshape(len(rows),3,3).sum(axis=2);ii=np.arange(len(rows))
        require(np.all(point>0) and np.all(ground>0) and np.all(cells>0),"Positive proper intensities")
        lp[rows]=np.log(point);lg[rows]=np.log(ground);lc[rows]=np.log(cells[ii,cell]);lz[rows]=np.log(zones[ii,cell//3])
        gradient[:3]-=[math.fsum(base/point),math.fsum(tx*base/point),math.fsum(Hp/point)]
        for j,(dk,_) in enumerate(der):
            DD=np.zeros_like(lag);DD[valid]=dk
            gradient[3+j]-=n*math.fsum(np.sum(DD*fert[None,:]*offspring,axis=1)/point)
    mark=len(te)*math.log(beta)-beta*math.fsum(qe)
    score=math.fsum(lp)-exposure+mark
    result=dict(joint_nll=-score,joint_logscore=score,timing_logscore=math.fsum(lg)-exposure,
                conditional_zone_logscore=math.fsum(lz-lg),conditional_cell_logscore=math.fsum(lc-lz),
                within_cell_density_logscore=math.fsum(lp-lc),mark_logscore=mark,
                integrated_intensity=exposure,trigger_exposure=K,immigrant_exposure=B,
                cell_integrated_intensity=cellcomp,gradient=gradient,
                event_log_point_intensity=lp,event_log_ground_intensity=lg,
                event_log_cell_intensity=lc,event_log_zone_intensity=lz)
    require(all(np.isfinite(np.asarray(v)).all() for v in result.values()),"Finite independent result")
    require(abs(float(cellcomp.sum())-exposure)<=1e-10*max(1,exposure),"Spatial compensator conservation")
    return result
