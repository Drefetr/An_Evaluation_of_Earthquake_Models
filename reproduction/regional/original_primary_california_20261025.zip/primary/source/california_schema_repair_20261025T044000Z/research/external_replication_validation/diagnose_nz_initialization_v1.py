"""Leased replay emits only static whitelisted assertions and source locations.
No rows, IDs, fitted parameters, scores, arrays or exception values are printed.
Original49 pinned files, fits, histories and failed audit receipts stay unchanged.
"""
import argparse,ast,json
from pathlib import Path
from . import audit_nz_initialization_v3 as A

FILES=['audit_nz_initialization_v3.py','empirical_io_v1.py','empirical_oracle_v2.py','raw_input_v2.py','raw_input.py','oracle.py','oracle_known_v1.py','nuisance_oracle.py']


def literal_messages():
    safe=set()
    for name in FILES:
        for node in ast.walk(ast.parse(Path(__file__).with_name(name).read_text())):
            if not isinstance(node,ast.Call):continue
            if isinstance(node.func,ast.Attribute) and node.func.attr=='require' and len(node.args)>=2 and isinstance(node.args[1],ast.Constant) and isinstance(node.args[1].value,str):safe.add(node.args[1].value)
            if isinstance(node.func,ast.Name) and node.func.id=='close' and node.args and isinstance(node.args[-1],ast.Constant) and isinstance(node.args[-1].value,str):safe.add(node.args[-1].value)
            if isinstance(node.func,ast.Name) and node.func.id=='ValueError' and len(node.args)==1 and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):safe.add(node.args[0].value)
    return safe


def main():
    p=argparse.ArgumentParser();p.add_argument('--initialization',required=True);p.add_argument('--metadata',required=True);p.add_argument('--output',required=True);a=p.parse_args();safe=literal_messages()
    try:
        A.audit(A.I.read(a.initialization),a.metadata);result=dict(status='no_failure_reproduced')
    except Exception as error:
        message=str(error);result=dict(status='failure_reproduced',error_type=type(error).__name__,safe_assertion=message if message in safe else 'UNCLASSIFIED_EXCEPTION_TEXT_SUPPRESSED');frames=[];tb=error.__traceback__
        while tb is not None:
            filename=Path(tb.tb_frame.f_code.co_filename).name
            if filename in FILES:frames.append(dict(file=filename,function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno))
            tb=tb.tb_next
        result['safe_traceback']=frames
    with Path(a.output).open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2,allow_nan=False)
    print(json.dumps(result,allow_nan=False));return 0 if result['status']=='failure_reproduced' else 1


if __name__=='__main__':raise SystemExit(main())
