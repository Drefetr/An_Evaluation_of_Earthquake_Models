"""Independent external-replication validation; never imports production evaluators."""
