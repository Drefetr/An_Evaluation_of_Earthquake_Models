"""Run one conductor-approved numerical job under the shared serial lease.

Commands are explicit argv arrays in a pinned JSON specification. Closed lease
walls are conservatively charged, including launch and validation overhead.
The ledger is cooperative; it is not an OS memory or billing enforcement layer.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sqlite3
import sys
import time
import math


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, data):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    tmp.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True)
    parser.add_argument('--spec', required=True)
    args = parser.parse_args()
    run = Path(args.run).resolve()
    spec_path = Path(args.spec).resolve()
    raw = spec_path.read_bytes()
    spec = json.loads(raw.decode('utf-8-sig'))
    config = json.loads((run / 'config.json').read_text(encoding='utf-8-sig'))
    command = spec['command']
    if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
        raise ValueError('command must be a nonempty argv string array')
    task = spec['task_id']
    record_path = run / 'reports' / (task + '_process.json')
    if record_path.exists():
        raise FileExistsError('Preserve the existing job; use an explicit new task for recovery')
    charges_path = run / 'reports/numerical_charges.jsonl'
    charges = [json.loads(x) for x in charges_path.read_text().splitlines() if x] if charges_path.exists() else []
    spent = sum(x['charged_wall_seconds'] for x in charges)
    remaining = config['numerical_budget_seconds'] - spent
    requested = float(spec['timeout_seconds'])
    phase=spec.get('phase','engineering')
    normal=config['minimum_audit_reserve_seconds']+config['reporting_reserve_seconds']
    minimum=normal
    if phase in ['audit','reporting']:
        auth=spec.get('phase_authorization')
        if not auth:raise ValueError('Missing reviewed phase authorization')
        q=Path(auth['path']);v=json.loads(q.read_text(encoding='utf-8-sig'))
        if hashlib.sha256(q.read_bytes()).hexdigest()!=auth['sha256'] or not v.get('passed') or v.get('phase')!=phase:raise ValueError('Phase authorization changed/invalid')
        minimum=config['reporting_reserve_seconds'] if phase=='audit' else 0
    elif phase not in ['engineering','acquisition','training','observed']:raise ValueError('Unknown phase')
    protected=float(spec.get('protected_reserve_seconds',minimum))
    if not math.isfinite(requested) or requested<=0:raise ValueError('Timeout must be finite and positive')
    if not math.isfinite(protected) or protected<0:raise ValueError('Reserve must be finite and nonnegative')
    if protected<minimum:raise ValueError('Protected reserve below authorized phase minimum')
    if requested > remaining - protected:
        raise RuntimeError('Requested job would consume protected audit reserve')
    until_deadline = (dt.datetime.fromisoformat(config['deadline_utc'].replace('Z', '+00:00')) - dt.datetime.now(dt.timezone.utc)).total_seconds()
    if requested>until_deadline-protected-10.:raise RuntimeError('Requested job would consume protected cycle reserve')
    timeout = min(requested, remaining-protected-10., until_deadline-protected-10.)
    if not (requested > 0 and timeout >= 1.):
        raise RuntimeError('No sufficient numerical or cycle reserve remains')
    ledger = run / 'orchestration/swarm_state.py'

    def state(*parts):
        result = subprocess.run([sys.executable, '-B', str(ledger), parts[0], '--run', str(run), *map(str, parts[1:])], capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stdout + result.stderr)
        return json.loads(result.stdout)

    # An atomic prepared-spec claim prevents mutation and duplicate launches.
    with sqlite3.connect(run/'launch_control.sqlite3') as control:
        control.execute('BEGIN IMMEDIATE')
        row=control.execute('SELECT spec_sha256,status FROM launches WHERE task=?',(task,)).fetchone()
        if row!=(hashlib.sha256(raw).hexdigest(),'prepared'):raise RuntimeError('Unprepared, changed or already claimed numerical spec')
        changed=control.execute("UPDATE launches SET status='launching' WHERE task=? AND status='prepared' AND spec_sha256=?",(task,hashlib.sha256(raw).hexdigest())).rowcount
        if changed!=1:raise RuntimeError('Numerical spec claim failed')
    state('add', '--assignment', run / 'tasks' / (task + '.json'))
    lease = state('start', '--task', task, '--actor', 'conductor')
    with sqlite3.connect(run/'launch_control.sqlite3') as control:
        changed=control.execute("UPDATE launches SET status='active' WHERE task=? AND status='launching'",(task,)).rowcount
        if changed!=1:raise RuntimeError('Claimed numerical launch state changed')
    began = time.monotonic()
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    stdout_path = run / 'reports' / (task + '.stdout.log')
    stderr_path = run / 'reports' / (task + '.stderr.log')
    receipt = {'task_id': task, 'attempt_id': lease['attempt_id'], 'spec_sha256': hashlib.sha256(raw).hexdigest(), 'command': command, 'cwd': spec.get('cwd'), 'started_utc': stamp(), 'effective_timeout_seconds': timeout, 'prior_charged_wall_seconds': spent, 'terminal': False, 'memory_limit_note': 'Configured memory/disk ceilings are admission bounds, not OS enforcement; reviewed geometry and measured pilot required.'}
    write(record_path.with_suffix('.started.json'), receipt)
    process = None
    uncertain = False
    code = None
    try:
        with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
            process = subprocess.Popen(command, cwd=spec.get('cwd'), env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
            receipt.update(pid=process.pid, launched_utc=stamp())
            write(record_path.with_suffix('.started.json'), receipt)
            print(json.dumps({'task': task, 'attempt': lease['attempt_id'], 'pid': process.pid, 'timeout_seconds': timeout}), flush=True)
            try:
                code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                receipt['time_cap_reached'] = True
                # This is the still-running Popen child owned by this invocation.
                # No filenames or commands are passed through another shell.
                if process.poll() is None:
                    stopped = subprocess.run(['taskkill.exe', '/PID', str(process.pid), '/T', '/F'], capture_output=True, text=True)
                    receipt['termination'] = {'returncode': stopped.returncode, 'stdout': stopped.stdout, 'stderr': stopped.stderr}
                    if stopped.returncode:
                        uncertain = True
                try:
                    code = process.wait(timeout=10.)
                except subprocess.TimeoutExpired:
                    uncertain = True
    except BaseException as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
        uncertain = process is not None and process.poll() is None
    wall = time.monotonic() - began
    receipt.update(returncode=code, observed_utc=stamp(), charged_wall_seconds=wall, terminal=not uncertain)
    receipt['outputs'] = []
    for value in spec.get('expected_outputs', []):
        path = Path(value)
        receipt['outputs'].append({'path': str(path), 'exists': path.is_file(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None})
    if uncertain:
        receipt['status'] = 'held'
        write(record_path, receipt)
        state('hold', '--attempt', lease['attempt_id'], '--reason', 'Owned numerical process termination is uncertain; explicit recovery required.', '--evidence', record_path)
        print(json.dumps({'task': task, 'status': 'held', 'receipt': str(record_path)}), flush=True)
        return 2
    succeeded = code == 0 and not receipt.get('time_cap_reached', False) and all(x['exists'] for x in receipt['outputs'])
    receipt['status'] = 'succeeded' if succeeded else 'failed'
    with sqlite3.connect(run/'launch_control.sqlite3') as control:
        control.execute('UPDATE launches SET status=?,receipt=? WHERE task=?',(receipt['status'],str(record_path),task))
    write(record_path, receipt)
    with charges_path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps({'task_id': task, 'attempt_id': lease['attempt_id'], 'charged_wall_seconds': wall, 'receipt': str(record_path)}) + '\n')
    state('finish', '--attempt', lease['attempt_id'], '--outcome', receipt['status'], '--evidence', record_path)
    print(json.dumps({'task': task, 'status': receipt['status'], 'wall_seconds': wall, 'receipt': str(record_path)}), flush=True)
    return 0 if succeeded else 1


if __name__ == '__main__':
    raise SystemExit(main())
