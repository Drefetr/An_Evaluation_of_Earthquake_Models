"""Prepare an immutable, phase-authorized serial numerical launch."""
import argparse,json,sqlite3,hashlib,math
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--run',required=True);p.add_argument('--task',required=True);p.add_argument('--command-json',required=True);p.add_argument('--timeout',type=float,required=True);p.add_argument('--reserve',type=float);p.add_argument('--phase',choices=['engineering','acquisition','training','observed','audit','reporting'],default='engineering');p.add_argument('--authorization');p.add_argument('--outputs-json',default='[]');p.add_argument('--cwd',required=True);a=p.parse_args();r=Path(a.run);config=json.loads((r/'config.json').read_text());cmd=json.loads(a.command_json);outputs=json.loads(a.outputs_json)
normal=config['minimum_audit_reserve_seconds']+config['reporting_reserve_seconds'];minimum=normal;auth=None
if a.phase in ['audit','reporting']:
 if not a.authorization:raise ValueError('Audit/report reserve reduction requires reviewed phase authorization')
 q=Path(a.authorization).resolve();v=json.loads(q.read_text(encoding='utf-8-sig'))
 if not v.get('passed') or v.get('phase')!=a.phase:raise ValueError('Invalid phase authorization')
 minimum=config['reporting_reserve_seconds'] if a.phase=='audit' else 0
 auth=dict(path=str(q),sha256=hashlib.sha256(q.read_bytes()).hexdigest())
reserve=minimum if a.reserve is None else a.reserve
if not math.isfinite(reserve) or reserve<0:raise ValueError('Reserve must be finite and nonnegative')
if not math.isfinite(a.timeout) or a.timeout<=0:raise ValueError('Timeout must be finite and positive')
if reserve<minimum:raise ValueError('Reserve below phase minimum')
spec=dict(task_id=a.task,command=cmd,cwd=a.cwd,timeout_seconds=a.timeout,protected_reserve_seconds=reserve,phase=a.phase,phase_authorization=auth,expected_outputs=outputs)
assignment=dict(task_id=a.task,parent_id=None,kind='numerical',owner='conductor',objective=a.task,allowed_paths=list(dict.fromkeys([a.cwd,str(r)])),expected_outputs=outputs,depends_on=[],acceptance=['Terminal process and required output receipt; independent scientific acceptance separate'])
for path,value in [(r/'tasks'/(a.task+'.json'),assignment),(r/'tasks'/(a.task+'_spec.json'),spec)]:
 with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2,allow_nan=False)
with sqlite3.connect(r/'launch_control.sqlite3') as c:c.execute('INSERT INTO launches VALUES (?,?,?,?)',(a.task,hashlib.sha256((r/'tasks'/(a.task+'_spec.json')).read_bytes()).hexdigest(),'prepared',None))
print(r/'tasks'/(a.task+'_spec.json'))
