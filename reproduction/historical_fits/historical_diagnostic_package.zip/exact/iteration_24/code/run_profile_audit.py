"""Bounded ten-history optimization diagnostic; no power recalibration or simulation."""
from pathlib import Path
import os
for _k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_k]='1'
import argparse, importlib.util, multiprocessing as mp, queue, sys, time, traceback, uuid
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
AREA=ROOT/'iteration_24'
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import ChildJob, RunLock, atomic_bytes, canonical_hash, read_json, read_sealed, sealed_json, sha256, utc_now
IDS=['null_0000','null_0841','null_1292','new_r000','new_r076','null_1107','null_1166','new_r100','null_1345','new_r140']
SOURCES=['iteration_24/code/run_profile_audit.py','iteration_24/code/profile_optimizer.py',
 'iteration_21/code/staged_fit.py','iteration_20/code/restricted_fit.py',
 'iteration_20/code/restricted_history.py','iteration_18/code/cuda_oracle.py',
 'iteration_17/code/oracle_likelihood.py','iteration_19/code/run_full_cuda.py',
 'iteration_12/code/paired_history.py','iteration_12/code/stable_history.py',
 'iteration_5/code/empirical_process.py','iteration_5/code/kernels.py','iteration_6/code/checkpoint_io.py']
PLAN_KEYS=['config_path','config_sha256','contract','sources','ids','entries','baselines','law']

def require(ok,msg):
    if not ok: raise ValueError(msg)

def immutable(path,value):
    require(not path.exists(),'Refusing completed-record overwrite: '+str(path))
    sealed_json(path,value)

def lifetime():
    p=ROOT/'iteration_19/code/run_full_cuda.py'
    require(sha256(p)=='93f59620d6f7e9a0eccbf1ae3575429634080459b1ea38601b070a89ee906dbb','Lifetime helper changed')
    key='_profile_lifetime'
    if key not in sys.modules:
        spec=importlib.util.spec_from_file_location(key,p); module=importlib.util.module_from_spec(spec)
        sys.modules[key]=module; spec.loader.exec_module(module)
    return sys.modules[key]

def prepare(config,run):
    c=read_json(config)
    require(c['status']=='frozen_before_saved_history_profile_outcomes','Protocol not frozen')
    require(c['case_ids']==IDS,'Case set/order differs')
    priors=[read_sealed(ROOT/p) for p in c['extension']['prior_study_summary_paths']]
    require(all(p['sessions_closed'] is True for p in priors) and
            abs(sum(p['charged_seconds'] for p in priors)-c['resources']['prior_study_parent_seconds'])<1e-9,
            'Prior study accounting changed')
    require(c['resources']['total_parent_wall_seconds']==3600 and
            c['resources']['per_case_wall_seconds']=={id:(1200 if id=='null_1292' else 600) for id in IDS} and
            c['resources']['setup_wall_seconds']==60 and c['resources']['cleanup_reserve_seconds']==15,
            'Generous fixed-ten study resource contract changed')
    for r in c['authorities']:
        require(sha256(ROOT/r['path'])==r['sha256'],'Authority changed: '+r['path'])
    inv=read_sealed(ROOT/'iteration_17/results/inventory_20261016T120350054217Z.json')
    by={e['id']:e for e in inv['entries']}; entries=[by[i] for i in IDS]
    bases={}; declared={e['id']:e for e in c['cases']}
    for e in entries:
        for r in e['files'].values():require(sha256(ROOT/r['path'])==r['sha256'],'History artifact changed: '+r['path'])
        frozen=declared[e['id']]
        require(frozen['seed']==e['seed'] and frozen['clock_mode']==e['clock_mode'] and frozen['catalogue']==e['files']['catalogue.npz'],'Frozen catalogue binding differs')
        p='iteration_21/results/full_staged/cases/'+e['id']+'.json'
        require(frozen['primary_case']['path']==p and frozen['primary_case']['sha256']==sha256(ROOT/p),'Accepted baseline hash changed')
        v=read_sealed(ROOT/p)
        require(v['status']=='complete' and v['clock_mode']==e['clock_mode'] and v['catalogue_sha256']==e['files']['catalogue.npz']['sha256'],'Baseline incomplete/mismatched')
        bases[e['id']]={'path':p,'sha256':sha256(ROOT/p)}
    law=read_json(ROOT/'iteration_21/configs/staged_full_frozen.json')['law']
    a=dict(config_path=config.relative_to(ROOT).as_posix(),config_sha256=sha256(config),contract=c,
           sources={p:sha256(ROOT/p) for p in SOURCES},ids=IDS,entries=entries,baselines=bases,law=law)
    plan=dict(a,plan_id=canonical_hash(a))
    run.mkdir(parents=True,exist_ok=True)
    with RunLock(run/'audit.lock'):
        if (run/'plan.json').exists():
            old=read_sealed(run/'plan.json');require(old['plan_id']==plan['plan_id']==canonical_hash({k:old[k] for k in PLAN_KEYS}),'Prepared plan differs');return old
        immutable(run/'plan.json',dict(plan,prepared_utc=utc_now()))
        for p in SOURCES:atomic_bytes(run/'source_snapshots'/p,(ROOT/p).read_bytes())
        summary(plan,run,[],'prepared')
    return plan

def identity(plan,e):
    return dict(plan_id=plan['plan_id'],id=e['id'],seed=e['seed'],clock_mode=e['clock_mode'],
                inventory_entry_sha256=canonical_hash(e),catalogue_sha256=e['files']['catalogue.npz']['sha256'],baseline_sha256=plan['baselines'][e['id']]['sha256'])

def case_path(run,id):return run/'cases'/(id+'.json')

def first_case_gate(plan,run):
    path=run/'gates/first_case_review.json'
    if not path.exists():return None
    v=read_sealed(path)
    require(v['plan_id']==plan['plan_id'] and v['passed'] is True and v['source_hashes']==plan['sources'],
            'First-case review identity/source differs')
    require(v['reviewers']==['A','C'] and len(v['review_snapshots'])>=2,'First-case A/C evidence snapshots required')
    require(case_path(run,IDS[0]).exists() and v['first_case_sha256']==sha256(case_path(run,IDS[0])),
            'First-case reviewed bytes differ')
    for p,h in v['review_snapshots'].items():require(sha256(ROOT/p)==h,'First-case review snapshot changed')
    require(set(v['review_roles'])=={'A','C'},'First-case named review roles required')
    for role,p in v['review_roles'].items():
        require(p in v['review_snapshots'],'Named review is not a frozen snapshot')
        review=read_sealed(ROOT/p)
        require(review['role']==role and review['passed'] is True and review['plan_id']==plan['plan_id'] and
                review['first_case_sha256']==v['first_case_sha256'] and review['source_hashes']==plan['sources'],
                'First-case reviewer decision/bindings differ')
    return v

def cached(plan,e,run):
    p=case_path(run,e['id'])
    if not p.exists():return None
    v=read_sealed(p)
    require(all(v.get(k)==x for k,x in identity(plan,e).items()),'Cached identity differs')
    require(v['status'] in ('complete','failed','error','time_cap'),'Invalid terminal status')
    if v['status']=='complete':
        p=v['payload'];require(p['complete'] is True and p['status']=='complete' and p['all_mandated_solvers_successful'] is True,'Incomplete payload promoted')
        sys.path.insert(0,str(AREA/'code'))
        from profile_optimizer import validate_result
        require(validate_result(p,plan['contract']) is True,'Completed result structure/arithmetic differs')
        require([m['id'] for m in p['methods']]==['known_known','background_estimated'] and len(p['validation'])==4,'Incomplete methods/selected controls')
        require(all(m['complete'] is True and m['gates']['selected_values_passed'] is True and m['gates']['old_values_passed'] is True and m['gates']['direct_order_delta']<1e-4 and m['gates']['old_direct_order_delta']<1e-4 and m['gates']['old_direct_saved_delta']<1e-4 and m['gates']['old_points_not_worsened'] is True and m['gates']['direct_controls_passed'] is True and m['gates']['null_nested'] is True and m['gates']['all_mandated_solvers_successful'] is True for m in p['methods']),'Incomplete method gates')
        require(all(r['success'] is True for r in p['search_records']) and all(g['passed'] is True and g['absolute_difference']<1e-4 for g in p['validation']) and all(g['passed'] is True for g in p['controls']),'Failed solver/numerical controls')
        metrics=p['cuda_metrics'];require(metrics['dtype']=='float64' and all(metrics[k] is False for k in ('allow_tf32','mixed_precision','fast_math_requested')) and metrics['peak_allocated_bytes']<=2**30,'CUDA policy differs')
        require(p['feature_metadata']['clock_mode']==e['clock_mode'] and p['scalar_reduction_chunk_nodes']==2**20,'Output history/scalar policy differs')
        curves=p['methods'][1]['eta_profile'];require(len(curves)==11 and all(abs(q['eta']-i*3/10)<1e-14 for i,q in enumerate(curves)),'Incomplete eta profile')
        require(len(p['old32_controls'])==4 and all(q['passed'] is True and q['absolute_difference']<1e-4 and q['saved_absolute_difference']<1e-4 for q in p['old32_controls']),'Missing old selected CPU32 controls')
    return v

def summary(plan,run,sessions,reason):
    states={e['id']:(cached(plan,e,run) or {}).get('status','pending') for e in plan['entries']}
    v=dict(plan_id=plan['plan_id'],updated_utc=utc_now(),reason=reason,states=states,
           counts={s:list(states.values()).count(s) for s in sorted(set(states.values()))},
           all_complete=all(s=='complete' for s in states.values()),sessions_closed=all(s['closed'] for s in sessions),
           charged_seconds=sum(s['elapsed_seconds'] for s in sessions),active_ids=[s['active_id'] for s in sessions if not s['closed'] and s.get('active_id')],
           scientific_campaign_launched=False,power_reestimated=False)
    sealed_json(run/'summary.json',v);return v

def worker(plan,run_name,ready,inbox,outbox):
    run=Path(run_name); context=None; start=time.perf_counter()
    while not ready.wait(.1):
        parent=mp.parent_process()
        if parent is None or not parent.is_alive() or time.perf_counter()-start>15:return
    try:
        import numpy as np
        from threadpoolctl import threadpool_limits
        sys.path.insert(0,str(AREA/'code'));sys.path.insert(0,str(ROOT/'iteration_18/code'));sys.path.insert(0,str(ROOT/'iteration_17/code'))
        from profile_optimizer import fit_profile_case, validate_result
        from cuda_oracle import CudaOracleContext
        from oracle_likelihood import law_from_setting
        with threadpool_limits(limits=1):
            context=CudaOracleContext(max_allocated_bytes=2**30)
            outbox.put(dict(event='ready',warmup=context.warmup(),metadata=context.metadata))
            while True:
                task=inbox.get()
                if task is None:return
                e,attempt,deadline=task; began=time.perf_counter(); cpu=time.process_time(); index=0
                def progress(value):
                    nonlocal index
                    index+=1;p=run/'partials'/e['id']/attempt/f'{index:05d}.json'
                    immutable(p,dict(**identity(plan,e),attempt_id=attempt,elapsed_seconds=time.perf_counter()-began,progress=value))
                    outbox.put(dict(event='progress',id=e['id'],path=p.relative_to(ROOT).as_posix()))
                status='error';payload=None;error=None
                try:
                    for r in e['files'].values():require(sha256(ROOT/r['path'])==r['sha256'],'Input changed')
                    with np.load(ROOT/e['files']['catalogue.npz']['path'],allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
                    b=plan['baselines'][e['id']];require(sha256(ROOT/b['path'])==b['sha256'],'Baseline changed')
                    oldcase=read_sealed(ROOT/b['path']);s=plan['law']
                    law=law_from_setting(dict(beta=s['beta'],horizon=s['horizon_days'],coordinate_horizon=s['coordinate_horizon_days'],generating_fit=s['alternative_generating_fit']))
                    payload=fit_profile_case(arrays,law,clock_mode=e['clock_mode'],protocol=plan['contract'],oldcase=oldcase,
                                             context=context,deadline=deadline,progress_callback=progress)
                    if payload['complete']:require(validate_result(payload,plan['contract']) is True,'Produced complete payload failed structural validation')
                    status='complete' if payload['complete'] else 'time_cap' if payload.get('status')=='time_cap' else 'failed'
                except TimeoutError as exc:status='time_cap';error=str(exc)
                except Exception as exc:
                    error=f'{type(exc).__name__}: {exc}';progress(dict(event='exception',error=error,traceback=traceback.format_exc()))
                immutable(case_path(run,e['id']),dict(**identity(plan,e),attempt_id=attempt,status=status,payload=payload,error=error,
                          elapsed_seconds=time.perf_counter()-began,cpu_seconds=time.process_time()-cpu,partial_records=index,completed_utc=utc_now()))
                outbox.put(dict(event='finished',id=e['id'],status=status))
                if status!='complete':return
    except BaseException as exc:outbox.put(dict(event='worker_error',error=f'{type(exc).__name__}: {exc}',traceback=traceback.format_exc()))
    finally:
        if context is not None:context.close()

def execute(plan,run,began,worker_target=None):
    life=lifetime();limit=float(plan['contract']['resources']['total_parent_wall_seconds']);reserve=15.;handle=None;active=None;reason='active'
    with RunLock(run/'audit.lock'):
        require(canonical_hash({k:plan[k] for k in PLAN_KEYS})==plan['plan_id'],'Plan seal differs')
        require(sha256(ROOT/plan['config_path'])==plan['config_sha256'] and read_json(ROOT/plan['config_path'])==plan['contract'],'Config changed')
        require(plan['ids']==IDS and [e['id'] for e in plan['entries']]==IDS and set(plan['sources'])==set(SOURCES),'Plan source/case set differs')
        for p,h in plan['sources'].items():require(sha256(ROOT/p)==h,'Runtime source changed: '+p)
        freeze=read_sealed(AREA/'logs/runtime_source_freeze.json')
        require(freeze['plan_id']==plan['plan_id'] and freeze['validation_passed'] is True and freeze['sources']==plan['sources'],'Pre-execution freeze missing/differs')
        ledger=read_sealed(run/'sessions.json') if (run/'sessions.json').exists() else dict(plan_id=plan['plan_id'],sessions=[])
        require(ledger['plan_id']==plan['plan_id'],'Wrong ledger');sessions=ledger['sessions']
        for s in sessions:
            if not s['closed']:
                life.ensure_old_worker_dead(s)
                prefix=s['elapsed_seconds'];other=sum(x['elapsed_seconds'] for x in sessions if x is not s)
                bound=float(plan['contract']['resources']['per_case_wall_seconds'][s['active_id']]) if s.get('active_id') else 60. if s['stage']=='setup' else 0.
                assumed=min(max(0.,limit-other-prefix),bound+reserve)
                if s.get('active_id'):
                    e=next(e for e in plan['entries'] if e['id']==s['active_id']);old=cached(plan,e,run)
                    finish=run/'attempts'/(s['active_attempt_id']+'.finished.json')
                    if not finish.exists():immutable(finish,dict(plan_id=plan['plan_id'],id=e['id'],status=old['status'] if old else 'interrupted',reason='unclean_parent_recovery',case_sha256=sha256(case_path(run,e['id'])) if old else None))
                s.update(closed=True,elapsed_seconds=prefix+assumed,measured_prefix_seconds=prefix,assumed_unobserved_seconds=assumed,
                         reason='unclean_bounded_recovery',active_id=None,active_attempt_id=None,stage='closed')
        sealed_json(run/'sessions.json',dict(plan_id=plan['plan_id'],sessions=sessions))
        by={e['id']:e for e in plan['entries']};saved={i:cached(plan,by[i],run) for i in IDS}
        if any(v and v['status']!='complete' for v in saved.values()):summary(plan,run,sessions,'retained_failure_blocks_resume');return 2
        pending=[i for i in IDS if saved[i] is None]
        if not pending:summary(plan,run,sessions,'complete');return 0
        gate=first_case_gate(plan,run)
        first_stage=gate is None and saved[IDS[0]] is None
        if gate is None and not first_stage:
            summary(plan,run,sessions,'awaiting_first_case_review');return 3
        if first_stage:pending=[IDS[0]]  # Frozen first-case stage; all other IDs remain planned/pending.
        sid=uuid.uuid4().hex;s=dict(session_id=sid,started_utc=utc_now(),closed=False,elapsed_seconds=0.,active_id=None,active_attempt_id=None,worker_identity=None,stage='setup');sessions.append(s)
        s['first_case_stage']=first_stage
        deadline=began+max(0.,limit-sum(x['elapsed_seconds'] for x in sessions)-reserve)
        def save():
            s['elapsed_seconds']=time.perf_counter()-began;sealed_json(run/'sessions.json',dict(plan_id=plan['plan_id'],sessions=sessions));summary(plan,run,sessions,reason)
        try:
            save()
            if (run/'STOP').exists():reason='stop_requested'
            elif time.perf_counter()>=deadline:reason='global_budget'
            else:
                ctx=mp.get_context('spawn');ready=ctx.Event();inbox=ctx.Queue();outbox=ctx.Queue()
                p=ctx.Process(target=worker if worker_target is None else worker_target,args=(plan,str(run),ready,inbox,outbox))
                job=ChildJob();handle=(p,job,inbox);p.start();job.assign(p);s['worker_identity']=life.process_identity(p.pid)
                require(s['worker_identity'] is not None,'Owned worker identity unavailable');save();ready.set();setup=time.perf_counter();is_ready=False
                while pending or active:
                    now=time.perf_counter()
                    if now>=deadline:reason='global_budget';break
                    if active and now>=active['deadline']:reason='case_time_cap';break
                    if not is_ready and now-setup>=60:reason='setup_time_cap';break
                    if (run/'STOP').exists() and active is None:reason='stop_requested';break
                    if is_ready and active is None and pending:
                        id=pending.pop(0);cap=float(plan['contract']['resources']['per_case_wall_seconds'][id])
                        active=dict(id=id,attempt_id=sid+'_'+id,deadline=min(deadline,time.perf_counter()+cap))
                        s.update(active_id=id,active_attempt_id=active['attempt_id'],stage='case')
                        immutable(run/'attempts'/(active['attempt_id']+'.started.json'),dict(**identity(plan,by[id]),attempt_id=active['attempt_id'],started_utc=utc_now()))
                        save();inbox.put((by[id],active['attempt_id'],active['deadline']))
                    try:m=outbox.get(timeout=.1)
                    except queue.Empty:m=None
                    if m:
                        if m['event']=='ready':is_ready=True;s.update(stage='idle',warmup=m['warmup'],context_metadata=m['metadata']);save()
                        elif m['event']=='progress':
                            s['elapsed_seconds']=time.perf_counter()-began;sealed_json(run/'sessions.json',dict(plan_id=plan['plan_id'],sessions=sessions))
                            checkpoint=read_sealed(ROOT/m['path']);event=checkpoint['progress']
                            label=event.get('stage',event.get('event','checkpoint'))
                            print(f"{m['id']}: checkpoint {label}; {checkpoint['elapsed_seconds']:.1f}s",flush=True)
                        elif m['event']=='finished':
                            require(active and active['id']==m['id'],'Unexpected completion');v=cached(plan,by[m['id']],run);require(v is not None,'No durable completed case')
                            immutable(run/'attempts'/(active['attempt_id']+'.finished.json'),dict(plan_id=plan['plan_id'],id=active['id'],status=v['status'],case_sha256=sha256(case_path(run,active['id']))))
                            print(f"{active['id']}: {v['status']}; {v['elapsed_seconds']:.3f}s",flush=True)
                            active=None;s.update(active_id=None,active_attempt_id=None,stage='idle');save()
                            if v['status']!='complete':reason='first_unresolved_case';break
                        elif m['event']=='worker_error':s['worker_error']=m;reason='worker_error';break
                    if not p.is_alive() and (pending or active):reason='unexpected_worker_exit';break
                else:reason='first_case_gate_complete' if first_stage else 'complete'
        except KeyboardInterrupt:reason='keyboard_interrupt'
        except BaseException as exc:s['parent_error']=str(exc);reason='parent_error:'+type(exc).__name__;raise
        finally:
            if handle is not None:
                p,job,inbox=handle
                if p.pid is not None:
                    if active is None and p.is_alive():inbox.put(None);p.join(10)
                    life.stop_child(handle);s['worker_exitcode']=p.exitcode
                else:job.close()
            if active:
                e=by[active['id']];v=cached(plan,e,run)
                if v is None and reason in ('case_time_cap','global_budget'):
                    immutable(case_path(run,e['id']),dict(**identity(plan,e),attempt_id=active['attempt_id'],status='time_cap',payload=None,error=reason,partial_records_retained=True));v=cached(plan,e,run)
                p=run/'attempts'/(active['attempt_id']+'.finished.json')
                if not p.exists():immutable(p,dict(plan_id=plan['plan_id'],id=e['id'],status=v['status'] if v else 'interrupted',reason=reason,case_sha256=sha256(case_path(run,e['id'])) if v else None))
            s.update(closed=True,active_id=None,active_attempt_id=None,stage='closed',ended_utc=utc_now(),reason=reason);save()
        final=summary(plan,run,sessions,reason)
        if reason=='first_case_gate_complete':print('First-case stage complete; 1/10 cases complete, nine pending review before continuation.',flush=True)
        return 0 if final['all_complete'] or reason=='first_case_gate_complete' else 130 if reason in ('keyboard_interrupt','stop_requested') else 2

def main():
    began=time.perf_counter();p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path,default=AREA/'configs/profile_audit_frozen.json');p.add_argument('--run-dir',type=Path,default=AREA/'results/profile_audit')
    p.add_argument('--prepare-only',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--status',action='store_true');args=p.parse_args()
    run=args.run_dir.resolve();require(run.is_relative_to(AREA/'results'),'Output outside new iteration area')
    if args.status:
        value=read_sealed(run/'summary.json') if (run/'summary.json').exists() else {'prepared':False}
        if (run/'sessions.json').exists():
            ledger=read_sealed(run/'sessions.json');value['latest_checkpoint_charged_seconds']=sum(s['elapsed_seconds'] for s in ledger['sessions'])
            value['status_time_scope']='Most recent durable checkpoint; not a live GPU-time meter'
        print(value);return 0
    plan=prepare(args.config.resolve(),run)
    if args.prepare_only:print(dict(plan_id=plan['plan_id'],saved_history_fit_launched=False));return 0
    require(args.resume,'Use --resume to execute frozen bounded audit');return execute(plan,run,began)

if __name__=='__main__':raise SystemExit(main())
