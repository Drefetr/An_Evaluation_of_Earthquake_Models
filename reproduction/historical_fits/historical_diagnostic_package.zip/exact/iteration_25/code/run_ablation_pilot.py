"""Checkpointed fixed-ten preparation/manual runner. CLI status is read-only."""
from pathlib import Path
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
import argparse
import importlib.util
import math
import multiprocessing as mp
import queue
import sys
import time
import traceback
import uuid

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT / 'iteration_25'
RUN = AREA / 'results/ablation_pilot'
CONFIG = AREA / 'configs/ablation_protocol_frozen.json'
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import (ChildJob, RunLock, atomic_bytes, canonical_hash,
                           read_json, read_sealed, sealed_json, sha256, utc_now)

IDS = ['null_0000','null_0841','null_1292','new_r000','new_r076',
       'null_1107','null_1166','new_r100','null_1345','new_r140']
PRIOR_PLAN = ROOT / 'iteration_24/results/profile_audit/plan.json'
OWN_SOURCES = ['iteration_25/code/run_ablation_pilot.py',
               'iteration_25/code/ablation_fit.py',
               'iteration_25/run_ablation_pilot.ps1']
PLAN_KEYS = ['config_path','config_sha256','contract','sources','entries','benchmarks']
CLOSURE_ALLOWANCE_SECONDS = 1.


def require(ok, message):
    if not ok:
        raise ValueError(message)


def immutable(path, value):
    require(not Path(path).exists(), 'Refusing completed-record overwrite: '+str(path))
    sealed_json(path, value)


def lifetime():
    path = ROOT / 'iteration_19/code/run_full_cuda.py'
    require(sha256(path) == '93f59620d6f7e9a0eccbf1ae3575429634080459b1ea38601b070a89ee906dbb', 'Lifetime helper changed')
    name = '_ablation_lifetime'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name]


def prepare(config=CONFIG, run=RUN):
    c = read_json(config)
    require(c['status'] == 'frozen_before_new_ablation_outcomes', 'Protocol not frozen')
    require(c['case_ids'] == IDS, 'Case selection/order changed')
    for record in c['authorities']:
        require(sha256(ROOT/record['path']) == record['sha256'], 'Prior authority changed: '+record['path'])
    prior = read_sealed(PRIOR_PLAN)
    require(c['law'] == prior['law'], 'Generating/observation law changed')
    entries = prior['entries']
    require([e['id'] for e in entries] == IDS, 'Prior cohort changed')
    benchmarks = {}
    declared = {v['id']:v for v in c['cases']}
    for entry in entries:
        for record in entry['files'].values():
            require(sha256(ROOT/record['path']) == record['sha256'], 'History artifact changed')
        b = declared[entry['id']]['benchmark']
        require(b['path'] == f"iteration_24/results/profile_audit/cases/{entry['id']}.json" and sha256(ROOT/b['path']) == b['sha256'], 'Benchmark binding differs')
        require(declared[entry['id']]['clock_mode'] == entry['clock_mode'] and declared[entry['id']]['seed'] == entry['seed'], 'Clock/seed changed')
        benchmarks[entry['id']] = b
    sources = {p:sha256(ROOT/p) for p in list(prior['sources'])+OWN_SOURCES}
    require(all(sources[p] == h for p,h in prior['sources'].items()), 'Prior numerical source changed')
    body = dict(config_path=Path(config).relative_to(ROOT).as_posix(), config_sha256=sha256(config),
                contract=c, sources=sources, entries=entries, benchmarks=benchmarks)
    plan = dict(body, plan_id=canonical_hash(body), prepared_utc=utc_now())
    run = Path(run)
    run.mkdir(parents=True, exist_ok=True)
    with RunLock(run/'pilot.lock'):
        if (run/'plan.json').exists():
            old = read_sealed(run/'plan.json')
            require(old['plan_id'] == plan['plan_id'], 'Prepared plan differs')
            return old
        immutable(run/'plan.json', plan)
        for path in sources:
            atomic_bytes(run/'source_snapshots'/path, (ROOT/path).read_bytes())
        write_summary(plan,run,{i:'pending' for i in IDS},[], 'prepared')
    return plan


def guard(plan):
    require(canonical_hash({k:plan[k] for k in PLAN_KEYS}) == plan['plan_id'], 'Plan seal differs')
    require([e['id'] for e in plan['entries']] == IDS, 'Fixed ten required')
    c = plan['contract']
    require(c['case_ids'] == IDS and c['status'] == 'frozen_before_new_ablation_outcomes', 'Protocol scope differs')
    require(sha256(ROOT/plan['config_path']) == plan['config_sha256'] and read_json(ROOT/plan['config_path']) == c, 'Protocol bytes differ')
    require(c['resources']['total_parent_wall_seconds'] == 7200 and
            c['resources']['per_case_wall_seconds'] == {i:(1800 if i=='null_1292' else 900) for i in IDS}, 'Resource contract differs')
    for path,digest in plan['sources'].items():
        require(sha256(ROOT/path) == digest, 'Runtime source changed: '+path)
    freeze = read_sealed(AREA/'logs/runtime_source_freeze.json')
    require(freeze['plan_id'] == plan['plan_id'] and freeze['sources'] == plan['sources'] and freeze['validation_passed'] is True, 'Source freeze differs')
    require(set(freeze['review_roles']) == {'A','C'}, 'Actual A/C reviews required')
    for role,path in freeze['review_roles'].items():
        require(sha256(ROOT/path) == freeze['review_snapshots'][path], 'Review snapshot changed')
        review = read_sealed(ROOT/path)
        require(review['role'] == role and review['passed'] is True and review['plan_id'] == plan['plan_id'] and review['source_hashes'] == plan['sources'], 'Reviewer decision/binding differs')
    for path,digest in freeze['validation_snapshots'].items():
        require(sha256(ROOT/path) == digest, 'Validation snapshot changed')
    for b in plan['benchmarks'].values():
        require(sha256(ROOT/b['path']) == b['sha256'], 'Saved benchmark changed')


def identity(plan, entry):
    return dict(plan_id=plan['plan_id'], id=entry['id'], seed=entry['seed'], clock_mode=entry['clock_mode'],
                inventory_entry_sha256=canonical_hash(entry),
                catalogue_sha256=entry['files']['catalogue.npz']['sha256'],
                benchmark_sha256=plan['benchmarks'][entry['id']]['sha256'])


def cached(plan,entry,run):
    path = Path(run)/'cases'/(entry['id']+'.json')
    if not path.exists():
        return None
    case = read_sealed(path)
    require(all(case.get(k) == v for k,v in identity(plan,entry).items()), 'Cached case identity differs')
    require(case['status'] in ('complete','failed','error','time_cap'), 'Invalid case state')
    if case['status'] == 'complete':
        sys.path.insert(0,str(AREA/'code'))
        from ablation_fit import validate_result
        require(validate_result(case['payload'],plan['contract']) is True, 'Completed numerical payload differs')
        require(case['payload']['feature_metadata']['clock_mode']==entry['clock_mode'], 'Payload clock differs from case authority')
        require(case['payload']['benchmark_binding']['id']==entry['id'], 'Payload benchmark history differs from case authority')
    return case


def write_summary(plan,run,states,sessions,reason):
    value = dict(plan_id=plan['plan_id'],updated_utc=utc_now(),reason=reason,states=states,
                 counts={s:list(states.values()).count(s) for s in sorted(set(states.values()))},
                 all_complete=all(s=='complete' for s in states.values()),sessions_closed=all(s['closed'] for s in sessions),
                 charged_seconds=sum(s['elapsed_seconds'] for s in sessions),
                 active_ids=[s['active_id'] for s in sessions if not s['closed'] and s.get('active_id')],
                 new_models=['level_only','trend_only'],benchmarks_reused=True,
                 power_reestimated=False,new_simulations=False,new_catalogue=False)
    sealed_json(Path(run)/'summary.json',value)
    return value


def worker(plan,run_name,ready,inbox,outbox):
    run = Path(run_name)
    start = time.perf_counter()
    while not ready.wait(.05):
        parent = mp.parent_process()
        if parent is None or not parent.is_alive() or time.perf_counter()-start > 15:
            return
    context = None
    try:
        import numpy as np
        from threadpoolctl import threadpool_limits
        sys.path.insert(0,str(AREA/'code'))
        from ablation_fit import fit_ablation_case,validate_result
        sys.path.insert(0,str(ROOT/'iteration_18/code'))
        sys.path.insert(0,str(ROOT/'iteration_17/code'))
        from cuda_oracle import CudaOracleContext
        from oracle_likelihood import law_from_setting
        with threadpool_limits(limits=1):
            context = CudaOracleContext(max_allocated_bytes=2**30)
            outbox.put(dict(event='ready',warmup=context.warmup(),context_metadata=context.metadata))
            while True:
                task = inbox.get()
                if task is None:
                    return
                entry,attempt,deadline = task
                began = time.perf_counter();cpu_began = time.process_time();index = 0
                def progress(value):
                    nonlocal index
                    index += 1
                    path = run/'partials'/entry['id']/attempt/f'{index:05d}.json'
                    immutable(path,dict(**identity(plan,entry),attempt_id=attempt,elapsed_seconds=time.perf_counter()-began,progress=value))
                    outbox.put(dict(event='progress',id=entry['id'],path=path.relative_to(ROOT).as_posix()))
                payload = None;error = None;status = 'error'
                try:
                    for record in entry['files'].values():
                        require(sha256(ROOT/record['path']) == record['sha256'], 'History source changed')
                    with np.load(ROOT/entry['files']['catalogue.npz']['path'],allow_pickle=False) as z:
                        arrays = {k:z[k] for k in z.files}
                    b = plan['benchmarks'][entry['id']]
                    require(sha256(ROOT/b['path']) == b['sha256'], 'Benchmark source changed')
                    benchmark = read_sealed(ROOT/b['path'])
                    s = plan['contract']['law']
                    law = law_from_setting(dict(beta=s['beta'],horizon=s['horizon_days'],coordinate_horizon=s['coordinate_horizon_days'],generating_fit=s['alternative_generating_fit']))
                    payload = fit_ablation_case(arrays,law,clock_mode=entry['clock_mode'],protocol=plan['contract'],
                                                benchmark_case=benchmark,context=context,deadline=deadline,progress_callback=progress)
                    if payload.get('complete') is True:
                        require(validate_result(payload,plan['contract']) is True, 'Produced complete payload failed pure validation')
                        status = 'complete'
                    else:
                        status = 'time_cap' if payload.get('status')=='time_cap' else 'failed'
                except TimeoutError as exc:
                    status = 'time_cap';error = str(exc)
                except Exception as exc:
                    error = type(exc).__name__+': '+str(exc)
                    progress(dict(event='exception',error=error,traceback=traceback.format_exc()))
                path = run/'cases'/(entry['id']+'.json')
                immutable(path,dict(**identity(plan,entry),attempt_id=attempt,status=status,payload=payload,error=error,
                                    elapsed_seconds=time.perf_counter()-began,cpu_seconds=time.process_time()-cpu_began,
                                    partial_records=index,completed_utc=utc_now()))
                outbox.put(dict(event='finished',id=entry['id'],status=status))
                if status != 'complete':
                    return
    except BaseException as exc:
        outbox.put(dict(event='worker_error',error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc()))
    finally:
        if context is not None:
            context.close()


def execute(plan,run=RUN,began=None,worker_target=None):
    began = time.perf_counter() if began is None else began
    run = Path(run);life = lifetime();resources = plan['contract']['resources']
    limit = resources['total_parent_wall_seconds'];reserve = resources['cleanup_reserve_seconds']
    handle = None;active = None;reason = 'preflight';states = {i:'pending' for i in IDS}
    with RunLock(run/'pilot.lock'):
        guard(plan)
        ledger_path = run/'sessions.json'
        marker = run/'execution_started.json'
        require(ledger_path.exists() or not marker.exists(), 'Execution marker without ledger; refusing budget reset')
        require(ledger_path.exists() or not any((run/d).exists() for d in ('cases','attempts','partials')), 'Scientific traces without ledger; refusing budget reset')
        if not marker.exists():
            immutable(marker,dict(plan_id=plan['plan_id'],first_invoked_utc=utc_now(),scope='Execution accounting began; not proof a fit was launched'))
        else:
            require(read_sealed(marker)['plan_id']==plan['plan_id'], 'Execution marker belongs to another plan')
        ledger = read_sealed(ledger_path) if ledger_path.exists() else dict(plan_id=plan['plan_id'],sessions=[])
        require(ledger['plan_id'] == plan['plan_id'], 'Wrong session ledger')
        sessions = ledger['sessions']
        require(len({v['session_id'] for v in sessions})==len(sessions), 'Duplicate session identity')
        for index,old in enumerate(sessions):
            require(isinstance(old['closed'],bool) and math.isfinite(old['elapsed_seconds']) and old['elapsed_seconds']>=0, 'Invalid recorded elapsed time')
            require(old['closed'] or index==len(sessions)-1, 'Nonterminal open session')
        for old in sessions:
            if not old['closed']:
                life.ensure_old_worker_dead(old)
                prefix = old['elapsed_seconds'];others = sum(s['elapsed_seconds'] for s in sessions if s is not old)
                bound = resources['per_case_wall_seconds'][old['active_id']] if old.get('active_id') else resources['setup_wall_seconds']
                assumed = min(max(0.,limit-others-prefix),bound+reserve)
                if old.get('active_id'):
                    entry = next(e for e in plan['entries'] if e['id']==old['active_id'])
                    terminal = cached(plan,entry,run)
                    p = run/'attempts'/(old['active_attempt_id']+'.finished.json')
                    if not p.exists():
                        immutable(p,dict(plan_id=plan['plan_id'],id=old['active_id'],attempt_id=old['active_attempt_id'],status=terminal['status'] if terminal else 'interrupted',reason='unclean_parent_recovery',case_sha256=sha256(run/'cases'/(old['active_id']+'.json')) if terminal else None))
                old.update(closed=True,elapsed_seconds=prefix+assumed,measured_prefix_seconds=prefix,
                           assumed_unobserved_seconds=assumed,reason='unclean_bounded_inflight_reservation',
                           active_id=None,active_attempt_id=None,stage='closed',ended_utc=utc_now())
        prior = sum(s['elapsed_seconds'] for s in sessions)
        s = dict(session_id=uuid.uuid4().hex,started_utc=utc_now(),closed=False,elapsed_seconds=0.,
                 active_id=None,active_attempt_id=None,worker_identity=None,stage='preflight')
        sessions.append(s)
        def save():
            s['elapsed_seconds'] = time.perf_counter()-began
            sealed_json(ledger_path,dict(plan_id=plan['plan_id'],sessions=sessions))
        try:
            save()
            saved = {e['id']:cached(plan,e,run) for e in plan['entries']}
            states = {i:(saved[i] or {}).get('status','pending') for i in IDS}
            pending = [i for i in IDS if saved[i] is None]
            if any(v and v['status']!='complete' for v in saved.values()):
                reason = 'retained_failure_blocks_resume'
            elif (run/'fatal.json').exists():
                reason = 'retained_fatal_stop_blocks_resume'
            elif not pending:
                reason = 'complete'
            elif (run/'STOP').exists():
                reason = 'stop_requested'
            else:
                deadline = began+max(0.,limit-prior-reserve-CLOSURE_ALLOWANCE_SECONDS)
                if time.perf_counter() >= deadline:
                    reason = 'global_budget'
                else:
                    by = {e['id']:e for e in plan['entries']}
                    ctx = mp.get_context('spawn');ready = ctx.Event();inbox = ctx.Queue();outbox = ctx.Queue()
                    process = ctx.Process(target=worker if worker_target is None else worker_target,args=(plan,str(run),ready,inbox,outbox))
                    job = ChildJob();handle = (process,job,inbox)
                    process.start();job.assign(process);s['worker_identity'] = life.process_identity(process.pid)
                    require(s['worker_identity'] is not None, 'Owned worker identity unavailable')
                    s['stage'] = 'setup';save();ready.set();setup_began = time.perf_counter();is_ready = False
                    while pending or active:
                        now = time.perf_counter()
                        if now >= deadline:
                            reason = 'global_budget';break
                        if active and now >= active['deadline']:
                            reason = 'case_time_cap';break
                        if not is_ready and now-setup_began >= resources['setup_wall_seconds']:
                            reason = 'setup_time_cap';break
                        if active is None and (run/'STOP').exists():
                            reason = 'stop_requested';break
                        if is_ready and active is None and pending:
                            identifier = pending.pop(0);attempt = s['session_id']+'_'+identifier
                            active = dict(id=identifier,attempt_id=attempt,deadline=min(deadline,time.perf_counter()+resources['per_case_wall_seconds'][identifier]))
                            s.update(active_id=identifier,active_attempt_id=attempt,stage='case')
                            immutable(run/'attempts'/(attempt+'.started.json'),dict(**identity(plan,by[identifier]),attempt_id=attempt,started_utc=utc_now()))
                            save();inbox.put((by[identifier],attempt,active['deadline']))
                        try:
                            message = outbox.get(timeout=.05)
                        except queue.Empty:
                            message = None
                        if message:
                            if message['event']=='ready':
                                is_ready = True;s.update(stage='idle',warmup=message['warmup'],context_metadata=message['context_metadata']);save()
                            elif message['event']=='progress':
                                save();checkpoint = read_sealed(ROOT/message['path']);event = checkpoint['progress']
                                print(f"{message['id']}: {event.get('stage',event.get('event','checkpoint'))}; {checkpoint['elapsed_seconds']:.1f}s",flush=True)
                            elif message['event']=='finished':
                                require(active and active['id']==message['id'], 'Unexpected completion')
                                case = cached(plan,by[message['id']],run);require(case is not None,'No durable completed case')
                                states[message['id']] = case['status']
                                immutable(run/'attempts'/(active['attempt_id']+'.finished.json'),dict(plan_id=plan['plan_id'],id=message['id'],attempt_id=active['attempt_id'],status=case['status'],case_sha256=sha256(run/'cases'/(message['id']+'.json'))))
                                print(f"{message['id']}: {case['status']}; {case['elapsed_seconds']:.3f}s",flush=True)
                                active = None;s.update(active_id=None,active_attempt_id=None,stage='idle');save()
                                write_summary(plan,run,states,sessions,'active')
                                if case['status']!='complete':
                                    reason = 'first_unresolved_case';break
                            elif message['event']=='worker_error':
                                s['worker_error'] = message;reason = 'worker_error';break
                        if not process.is_alive() and (pending or active):
                            reason = 'unexpected_worker_exit';break
                    else:
                        reason = 'complete'
        except KeyboardInterrupt:
            reason = 'keyboard_interrupt'
        except BaseException as exc:
            reason = 'parent_error';s['error'] = type(exc).__name__+': '+str(exc)
        finally:
            # A cleanup failure deliberately leaves the durable session OPEN;
            # next invocation confirms death before conservative recovery debit.
            if handle is not None:
                process,job,inbox = handle
                if process.pid is not None:
                    if active is None and process.is_alive():
                        inbox.put(None);process.join(2)
                    life.stop_child(handle)
                    life.ensure_old_worker_dead(s)
                    s['worker_exitcode'] = process.exitcode
                else:
                    job.close()
            if active:
                entry = next(e for e in plan['entries'] if e['id']==active['id'])
                case = cached(plan,entry,run)
                if case is None and reason in ('case_time_cap','global_budget'):
                    immutable(run/'cases'/(active['id']+'.json'),dict(**identity(plan,entry),attempt_id=active['attempt_id'],status='time_cap',payload=None,error=reason,partial_records_retained=True))
                    states[active['id']] = 'time_cap'
                elif case:
                    states[active['id']] = case['status']
                finished = run/'attempts'/(active['attempt_id']+'.finished.json')
                if not finished.exists():
                    immutable(finished,dict(plan_id=plan['plan_id'],id=active['id'],attempt_id=active['attempt_id'],status=states[active['id']] if case or states[active['id']]=='time_cap' else 'interrupted',reason=reason))
            if reason in ('setup_time_cap','worker_error','unexpected_worker_exit','parent_error'):
                if not (run/'fatal.json').exists():
                    immutable(run/'fatal.json',dict(plan_id=plan['plan_id'],reason=reason,session_id=s['session_id'],recorded_utc=utc_now(),error=s.get('error'),worker_error=s.get('worker_error'),policy='Stop for review; ordinary resume may not silently retry a fatal execution failure'))
            measured = time.perf_counter()-began
            s.update(closed=True,measured_elapsed_seconds=measured,closure_allowance_seconds=CLOSURE_ALLOWANCE_SECONDS,
                     elapsed_seconds=measured+CLOSURE_ALLOWANCE_SECONDS,active_id=None,active_attempt_id=None,
                     stage='closed',ended_utc=utc_now(),reason=reason,
                     accounting_scope='Invocation before preflight through owned-worker cleanup and final payload adoption; final ledger/summary writes debited one operational second, not a proved latency bound')
            sealed_json(ledger_path,dict(plan_id=plan['plan_id'],sessions=sessions))
            final = write_summary(plan,run,states,sessions,reason)
        return 0 if final['all_complete'] else 130 if reason in ('keyboard_interrupt','stop_requested') else 2


def main():
    began = time.perf_counter()
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--prepare-only',action='store_true')
    modes.add_argument('--resume',action='store_true')
    modes.add_argument('--status',action='store_true')
    args = parser.parse_args()
    if args.status:
        value = read_sealed(RUN/'summary.json') if (RUN/'summary.json').exists() else dict(prepared=False)
        if (RUN/'sessions.json').exists():
            ledger = read_sealed(RUN/'sessions.json')
            value['last_durable_charged_seconds'] = sum(s['elapsed_seconds'] for s in ledger['sessions'])
        value['status_scope'] = 'Most recent completed checkpoint; not a live elapsed-time meter'
        print(value)
        return 0
    require(os.name=='nt','Production runner requires Windows job containment')
    if args.prepare_only:
        print(dict(plan_id=prepare()['plan_id'],saved_history_fit_launched=False))
        return 0
    require((RUN/'plan.json').exists(),'Run --prepare-only before manual evaluation')
    return execute(read_sealed(RUN/'plan.json'),RUN,began)


if __name__=='__main__':
    mp.freeze_support()
    raise SystemExit(main())
