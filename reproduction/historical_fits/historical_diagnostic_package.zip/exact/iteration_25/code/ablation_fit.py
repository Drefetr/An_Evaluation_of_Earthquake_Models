"""Finite level/trend ablation searches; no saved-history execution on import."""
from dataclasses import asdict
from pathlib import Path
import copy
import hashlib
import json
import math
import sys
import time
import numpy as np
from scipy.optimize import minimize

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
PROFILE_SHA = 'f0ab547015736eb9bfd6a3f3b8d08e60420516fda91a828149e5a5f087d9aff8'
if hashlib.sha256((ROOT / 'iteration_24/code/profile_optimizer.py').read_bytes()).hexdigest() != PROFILE_SHA:
    raise ValueError('Pinned profile objective changed')
sys.path.insert(0, str(ROOT / 'iteration_24/code'))
import profile_optimizer as profile
if Path(profile.__file__).resolve() != (ROOT / 'iteration_24/code/profile_optimizer.py').resolve():
    raise ValueError('Unexpected profile objective module')
ProfileObjective = profile.ProfileObjective
RestrictedHistory = profile.RestrictedHistory
CudaOracleContext = profile.CudaOracleContext
law_from_setting = profile.law_from_setting
clean = profile.clean
TOL = 1e-4
METHODS = ('level_only', 'trend_only')
BENCHMARKS = ('known_known', 'background_estimated')
SEARCH_SPEC = dict(
    a_bounds=[-12., 0.], d_bounds=[-2., 2.], eta_bounds=[0., 3.],
    amplitude_xtol=2e-12, amplitude_rtol=4*np.finfo(float).eps, amplitude_maxiter=100,
    level_eta_grid_points=17, trend_null_d_grid_points=17,
    trend_alternative_d_grid_points=7, trend_alternative_eta_grid_points=7,
    trend_powell_seeds=['top3_canonical_grid', 'own_selected_null', 'saved_known_known_alternative'],
    seed_deduplication='exact_coordinates_retain_first_maximum5',
    powell_options=dict(maxiter=2000, maxfev=100000, xtol=1e-6, ftol=1e-10),
    scalar_xatol=1e-7, scalar_maxiter=100, eta_profile_points=11,
    eta_profiles_per_method_mandatory=True,
    level_scalar_extras=['saved_known_known_alternative_eta', 'zero'],
    trend_null_scalar_extras=['supplied_d'],
    trend_profile_scalar_extras=['supplied_d', 'own_selected_null_d_exact_deduplicated'],
    local_bracket_rule='center<=both_neighbors_and_strictly_less_than_at_least_one;skip_fully_flat',
    eligible_floors='feasible_saved_known_known_null_and_alternative_and_own_new_null',
    both_free_benchmark_points_eligible=False,
    failed_solver_return_eligible=False, all_mandated_solvers_must_succeed=True,
    scalar_reduction_chunk_nodes=2**20, modal_query_chunk_nodes=32768,
    numerical_tolerance=TOL, benchmark_enclosure_flag_guard=2*TOL,
    benchmark_enclosure_material_threshold=.001,
    material_phase_NLL_gain=.001, material_absolute_statistic_change=.1,
    interaction_convention='D_BG-D_level-D_trend+D_KK')


def digest(value):
    return hashlib.sha256(json.dumps(clean(value), sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def best(points):
    require(bool(points), 'No eligible candidate')
    return min(points, key=lambda p: p['nll'])


def scalar_search(value, grid, extra, label, deadline, records):
    # Reuse the pinned scalar algorithm, preserving the full grid/extra trace.
    seen = []
    def capture(x):
        p = value(x)
        seen.append(copy.deepcopy(p))
        return p
    runs = []
    selected, eligible, stage = profile.scalar_search(capture, grid, extra, label=label, deadline=deadline, records=runs)
    stage.update(grid=list(map(float, grid)), extra=list(map(float, extra)),
                 grid_candidates=seen[:len(grid)], extra_candidates=seen[len(grid):len(grid)+len(extra)],
                 eligible=eligible, selected=selected, runs=runs)
    records.extend(runs)
    return selected, eligible, stage


def fit_ablation_case(arrays, law, clock_mode, protocol, benchmark_case, context, deadline, progress_callback=None):
    """Fit only the two new constrained procedures; old procedures are controls."""
    require(protocol.get('search') == clean(SEARCH_SPEC), 'Exact prospective search specification required')
    expected_law = law_from_setting(dict(beta=protocol['law']['beta'], horizon=protocol['law']['horizon_days'],
                                        coordinate_horizon=protocol['law']['coordinate_horizon_days'],
                                        generating_fit=protocol['law']['alternative_generating_fit']))
    require(asdict(law) == asdict(expected_law), 'Supplied full law differs from protocol')
    old = profile._old_methods(benchmark_case, law)
    began = time.perf_counter()
    reserve = protocol['resources']['validation_reserve_seconds'].get(benchmark_case.get('id'), 45.)
    search_deadline = deadline - reserve
    history = independent = objective = None
    records, methods, queries = [], [], []
    out = dict(schema_version=1, algorithm='bounded_level_trend_ablation', complete=False, status='partial',
               methods=methods, search_records=records, queries=queries,
               benchmark_binding=dict(id=benchmark_case.get('id'), canonical_case_sha256=digest(benchmark_case)),
               sources={'iteration_24/code/profile_optimizer.py': PROFILE_SHA})
    out['input_binding'] = profile.authority.input_binding(arrays, law, clock_mode, protocol)
    def emit(event):
        if progress_callback is not None:
            progress_callback(clean(event))
    try:
        profile.cpu._deadline(search_deadline)
        context.begin_measurement()
        history = RestrictedHistory(arrays, law, clock_mode=clock_mode, order=16, backend='cuda', context=context,
                                    deadline=search_deadline, chunk_nodes=32768, host_limit_bytes=2*2**30)
        objective = ProfileObjective(history, context=context, deadline=search_deadline, scalar_chunk_nodes=2**20)
        mark = history.mark_nll_constant
        out['mark_nll_constant'] = mark
        out['trigger_compensator'] = objective.trigger_compensator
        fixed_cache = {}
        def fixed(a, d, eta):
            key = (float(a), float(d), float(eta))
            if key not in fixed_cache:
                p = objective.fixed(*key, origin='fixed_amplitude')
                p['full_marked_nll'] = p['nll'] + mark
                fixed_cache[key] = p
            return copy.deepcopy(fixed_cache[key])
        def level(eta):
            p = objective.evaluate(law.d, float(eta))
            p['full_marked_nll'] = p['nll'] + mark
            queries.append(dict(model='level_only', d=law.d, eta=float(eta), pars=p['pars'], nll=p['nll']))
            return p
        def trend(d, eta):
            p = fixed(law.a, d, eta)
            queries.append(dict(model='trend_only', d=float(d), eta=float(eta), pars=p['pars'], nll=p['nll']))
            return p
        benchmarks = []
        for mid in BENCHMARKS:
            bm = dict(id=mid, saved_contrast16=old[mid]['contrast16'],
                      saved_contrast32=old[mid].get('contrast32', old[mid]['contrast16']))
            for phase in ('null', 'alternative'):
                r = old[mid][phase]
                bm[phase] = fixed(r['pars'][0], r['pars'][1], r['pars'][3])
                bm['saved_' + phase + '_nll'] = r['nll']
            benchmarks.append(bm)
        out['benchmark_methods'] = benchmarks
        out['benchmark_binding']['compact_selected_sha256'] = digest(benchmarks)
        kk, bg = benchmarks
        ln_candidates = [kk['null'], level(0.)]
        ln = best(ln_candidates)
        la, le, ls = scalar_search(level, np.linspace(0., 3., 17),
                                   [kk['alternative']['pars'][3], 0.], 'level_eta', search_deadline, records)
        level_curves = [dict(eta=float(e), selected=ln if i == 0 else level(float(e)), reused_null=i == 0)
                        for i,e in enumerate(np.linspace(0.,3.,11))]
        lc = [kk['alternative'], kk['null'], ln] + le + [c['selected'] for c in level_curves]
        lm = dict(id='level_only', null=ln, alternative=best(lc), null_candidates=ln_candidates,
                  candidates=lc, search=ls, eta_profile=level_curves, complete=False)
        methods.append(lm)
        emit(dict(event='search_stage_completed', stage='level_only', selected=lm['alternative']))
        tn, ne, ns = scalar_search(lambda d: trend(d, 0.), np.linspace(-2., 2., 17),
                                   [law.d], 'trend_null', search_deadline, records)
        nc = [kk['null']] + ne
        tn = best(nc)
        grid = [trend(d, eta) for d in np.linspace(-2., 2., 7) for eta in np.linspace(0., 3., 7)]
        seeds = [p['pars'][1::2] for p in sorted(grid, key=lambda p: p['nll'])[:3]] + [tn['pars'][1::2], kk['alternative']['pars'][1::2]]
        unique = []
        for seed in seeds:
            if seed not in unique:
                unique.append(seed)
        seed_points = [trend(*seed) for seed in unique]
        powell_candidates = []
        for index, start in enumerate(unique):
            profile.cpu._deadline(search_deadline)
            tick = time.perf_counter()
            try:
                r = minimize(lambda x: trend(float(x[0]), float(x[1]))['nll'], np.array(start), method='Powell',
                             bounds=[(-2., 2.), (0., 3.)], options=dict(SEARCH_SPEC['powell_options']))
                finite = np.isfinite(r.x).all() and np.isfinite(r.fun) and -2 <= r.x[0] <= 2 and 0 <= r.x[1] <= 3
                p = trend(*r.x) if finite else None
                success = bool(r.success and finite and abs(r.fun-p['nll']) < TOL)
                rec = dict(label='trend_alternative_Powell', index=index, start=start, bounds=[[-2., 2.], [0., 3.]],
                           success=success, returned_success=bool(r.success), status=int(r.status), message=str(r.message),
                           pars=np.asarray(r.x).tolist(), nll=float(r.fun), nit=int(r.nit), nfev=int(r.nfev),
                           candidate=p, elapsed_seconds=time.perf_counter()-tick)
                if success:
                    powell_candidates.append(p)
            except TimeoutError:
                raise
            except Exception as exc:
                rec = dict(label='trend_alternative_Powell', index=index, start=start, success=False,
                           error=type(exc).__name__ + ': ' + str(exc), elapsed_seconds=time.perf_counter()-tick)
            records.append(clean(rec))
            emit(dict(event='search_stage_completed', stage='trend_Powell', record=rec))
        curves = []
        curve_candidates = []
        profile_extras = list(dict.fromkeys([float(law.d),float(tn['pars'][1])]))
        for i, eta in enumerate(np.linspace(0., 3., 11)):
            if i == 0:
                p, eligible, stage = tn, nc, dict(label='trend_profile_0', reused_null=True, runs=[])
            else:
                p, eligible, stage = scalar_search(lambda d, eta=float(eta): trend(d, eta), np.linspace(-2., 2., 17),
                                                   profile_extras, 'trend_profile_' + str(i), search_deadline, records)
            curves.append(dict(eta=float(eta), selected=p, eligible=eligible, search=stage))
            curve_candidates.extend(eligible)
            emit(dict(event='eta_profile_completed', index=i, record=curves[-1]))
        tc = [kk['alternative'], kk['null'], tn] + grid + seed_points + powell_candidates + curve_candidates
        tm = dict(id='trend_only', null=tn, alternative=best(tc), null_candidates=nc, candidates=tc,
                  null_search=ns, grid_candidates=grid, powell_seeds=unique, seed_candidates=seed_points,
                  eta_profile=curves, complete=False)
        methods.append(tm)
        # The fixed mark-density term is identical in all four models. Store it
        # explicitly; full marked contrasts equal these stable ground contrasts.
        history.deadline = objective.deadline = deadline
        points = [('old_' + b['id'] + '_' + phase, b[phase]) for b in benchmarks for phase in ('null', 'alternative')]
        points += [('new_' + m['id'] + '_' + phase, m[phase]) for m in methods for phase in ('null', 'alternative')]
        for a in (-12., 0.):
            for eta in (0., 3.):
                points.append(('level_corner_a_' + str(a) + '_eta_' + str(eta), fixed(a, law.d, eta)))
        for d in (-2., 2.):
            for eta in (0., 3.):
                points.append(('trend_corner_d_' + str(d) + '_eta_' + str(eta), fixed(law.a, d, eta)))
        controls = []
        for label, p in points:
            v = history.objective(p['pars'], law.trigger, law.ratio, False)
            controls.append(dict(label=label, pars=p['pars'], profile16_nll=p['nll'], old_backend16_nll=v,
                                 absolute_difference=abs(v-p['nll']), passed=abs(v-p['nll']) < TOL))
        out['old_backend_controls'] = controls
        for m in methods + benchmarks:
            m['contrast16'] = history.contrast(m['null'], m['alternative'])
        out['cuda_metrics'] = context.cuda_metrics(32768)
        out['feature_metadata'] = dict(nodes16=history.nodes, clock_mode=history.mode, stress_modes=len(law.stress.mixture[0]),
                                       preparation16_seconds=history.preparation_seconds, geometry_authority='pinned RestrictedHistory',
                                       shared_geometry_limitation='Order16/32 controls share pinned geometry; synthetic literal controls do not prove every real-history geometry')
        history.close()
        history = None
        context.torch.cuda.empty_cache()
        independent = RestrictedHistory(arrays, law, clock_mode=clock_mode, order=32, backend='cpu', deadline=deadline,
                                         chunk_nodes=32768, host_limit_bytes=2*2**30)
        require(independent.mark_nll_constant == mark, 'Fixed marked-law constant changed across orders')
        cpu_rows = []
        for tag, group in [('old', benchmarks), ('new', methods)]:
            for m in group:
                for phase in ('null', 'alternative'):
                    p = m[phase]
                    v = independent.objective(p['pars'], law.trigger, law.ratio, False)
                    row = dict(label=tag+'_'+m['id']+'_'+phase, method=m['id'], phase=phase, pars=p['pars'],
                               profile16_nll=p['nll'], independent32_nll=v, absolute_difference=abs(v-p['nll']),
                               passed=abs(v-p['nll']) < TOL)
                    if tag == 'old':
                        row['saved_primary16_nll'] = m['saved_'+phase+'_nll']
                        row['saved_absolute_difference'] = abs(v-row['saved_primary16_nll'])
                        row['passed'] = bool(row['passed'] and row['saved_absolute_difference'] < TOL)
                    cpu_rows.append(row)
                m['contrast32'] = independent.contrast(m['null'], m['alternative'])
        out['cpu32_controls'] = cpu_rows
        out['feature_metadata'].update(nodes32=independent.nodes, preparation32_seconds=independent.preparation_seconds)
        out['benchmark_binding']['compact_selected_sha256'] = digest(benchmarks)
        direct_ok = all(abs(m['contrast16']['statistic']-m['contrast32']['statistic']) < TOL and
                        all(abs(m['contrast'+str(o)]['direct_minus_subtraction']) < TOL for o in (16, 32))
                        for m in methods+benchmarks)
        old_ok = all(abs(b['contrast'+str(o)]['statistic']-b['saved_contrast'+str(o)]['statistic']) < TOL
                     for b in benchmarks for o in (16, 32))
        common = []
        for m in methods:
            m['gains'] = {phase+'_NLL': kk[phase]['nll']-m[phase]['nll'] for phase in ('null', 'alternative')}
            m['benchmark_enclosure'] = {}
            for phase in ('null', 'alternative'):
                gap = bg[phase]['nll']-m[phase]['nll']
                m['benchmark_enclosure'][phase] = dict(signed_BG_minus_new_NLL=gap,
                                                      numerical_enclosure_flag=gap > 2*TOL,
                                                      material_enclosure_flag=gap >= .001)
            nested = m['alternative']['nll'] <= m['null']['nll']+1e-8
            floor = all(m[phase]['nll'] <= kk[phase]['nll']+1e-8 for phase in ('null', 'alternative'))
            own_runs = [r for r in records if (r['label'] == 'level_eta') == (m['id'] == 'level_only')]
            m['complete'] = bool(nested and floor and all(r['success'] for r in own_runs) and
                                 direct_ok and old_ok and all(r['passed'] for r in controls+cpu_rows) and
                                 all(m['contrast'+str(o)]['statistic'] >= -TOL for o in (16, 32)))
            for order in (16, 32):
                a, b = m['contrast'+str(order)], kk['contrast'+str(order)]
                rows = {r['label']: r for r in cpu_rows}
                if order == 16:
                    rows16 = {r['label']:r for r in controls}
                    g0, g1 = (rows16['old_known_known_'+phase]['old_backend16_nll']-rows16['new_'+m['id']+'_'+phase]['old_backend16_nll'] for phase in ('null','alternative'))
                else:
                    g0, g1 = (rows['old_known_known_'+phase]['independent32_nll'] - rows['new_'+m['id']+'_'+phase]['independent32_nll'] for phase in ('null', 'alternative'))
                lhs = a['statistic']-b['statistic']
                rhs = 2*(g1-g0)+a['direct_minus_subtraction']-b['direct_minus_subtraction']
                common.append(dict(method=m['id'], order=order, null_gain=g0, alternative_gain=g1,
                                   direct_statistic_change=lhs, common_backend_identity_rhs=rhs, residual=lhs-rhs))
        out['common_backend_identities'] = common
        for order in (16,32):
            rows = {r['label']:r for r in (controls if order == 16 else cpu_rows)}
            field = 'old_backend16_nll' if order == 16 else 'independent32_nll'
            g0,g1 = (rows['old_known_known_'+phase][field]-rows['old_background_estimated_'+phase][field] for phase in ('null','alternative'))
            c,b = bg['contrast'+str(order)],kk['contrast'+str(order)]
            lhs = c['statistic']-b['statistic']
            rhs = 2*(g1-g0)+c['direct_minus_subtraction']-b['direct_minus_subtraction']
            common.append(dict(method='background_estimated',order=order,null_gain=g0,alternative_gain=g1,
                               direct_statistic_change=lhs,common_backend_identity_rhs=rhs,residual=lhs-rhs))
        for r in common:
            r['direct_statistic_contraction_from_KK'] = -r['direct_statistic_change']
            r['material_phase_NLL_gain'] = max(r['null_gain'],r['alternative_gain']) >= .001
            r['material_absolute_direct_change'] = abs(r['direct_statistic_change']) >= .1
        out['nonadditive_interaction'] = {str(o): bg['contrast'+str(o)]['statistic']-methods[0]['contrast'+str(o)]['statistic']-methods[1]['contrast'+str(o)]['statistic']+kk['contrast'+str(o)]['statistic'] for o in (16, 32)}
        interactions = []
        for order in (16,32):
            rs = {r['method']:r for r in common if r['order'] == order}
            rhs = 2*math.fsum(sign*(rs[mid]['alternative_gain']-rs[mid]['null_gain']) for mid,sign in
                              [('background_estimated',1),('level_only',-1),('trend_only',-1)])
            rhs += math.fsum(sign*m['contrast'+str(order)]['direct_minus_subtraction'] for m,sign in [(bg,1),(methods[0],-1),(methods[1],-1),(kk,1)])
            lhs = out['nonadditive_interaction'][str(order)]
            interactions.append(dict(order=order,statistic=lhs,phase_gain_identity_rhs=rhs,residual=lhs-rhs,
                                     material_absolute_interaction=abs(lhs) >= .1))
        out['interaction_identities'] = interactions
        solvers_ok = all(r['success'] for r in records)
        complete = bool(all(m['complete'] for m in methods) and solvers_ok and direct_ok and old_ok and
                        all(r['passed'] for r in controls+cpu_rows) and all(abs(r['residual']) < 1e-8 for r in common+interactions))
        out.update(complete=complete, status='complete' if complete else 'unresolved_search_or_validation',
                   all_mandated_solvers_successful=solvers_ok, validation_reserve_seconds=reserve,
                   direct_controls_passed=direct_ok, saved_benchmark_controls_passed=old_ok)
        emit(dict(event='validation_completed', complete=complete))
    except Exception as exc:
        out.update(complete=False, status='time_cap' if isinstance(exc, TimeoutError) else 'unresolved',
                   error=type(exc).__name__+': '+str(exc))
    finally:
        if objective is not None:
            out.update(evaluations=objective.evaluations, fixed_evaluations=objective.fixed_evaluations,
                       evaluation_errors=objective.errors, background_integral_evaluations=objective.J_evaluations,
                       profile_requests=objective.profile_requests, profile_cache_hits=objective.cache_hits)
        for h in (history, independent):
            if h is not None:
                h.close()
        out['elapsed_seconds'] = time.perf_counter()-began
    return clean(out)


def validate_result(payload, protocol):
    """Pure structural/arithmetic validation; no likelihood, history or solver call."""
    require(protocol['search'] == clean(SEARCH_SPEC), 'Search protocol differs')
    require(payload.get('complete') is True and payload.get('status') == 'complete', 'Incomplete ablation')
    require(payload['algorithm'] == 'bounded_level_trend_ablation', 'Algorithm differs')
    require([m['id'] for m in payload['methods']] == list(METHODS), 'Two constrained procedures required')
    require([m['id'] for m in payload['benchmark_methods']] == list(BENCHMARKS), 'Benchmark coverage differs')
    fit = protocol['law']['alternative_generating_fit']
    expected_law = law_from_setting(dict(beta=protocol['law']['beta'], horizon=protocol['law']['horizon_days'],
                                        coordinate_horizon=protocol['law']['coordinate_horizon_days'], generating_fit=fit))
    binding = payload['input_binding']
    require(binding['contract_sha256'] == digest(protocol) and binding['law'] == clean(asdict(expected_law)), 'Input law/protocol binding differs')
    a0, d0, n = fit['pars'][:3]
    mark = payload['mark_nll_constant']
    require(math.isfinite(mark), 'Invalid marked-law constant')
    raw_profiles = payload['evaluations']
    def close(a, b, tol=1e-10):
        return math.isfinite(a) and math.isfinite(b) and abs(a-b) <= tol
    def point(p, mid=None):
        x = p['pars']
        require(len(x) == 4 and all(math.isfinite(v) for v in x) and -12 <= x[0] <= 0 and -2 <= x[1] <= 2 and
                x[2] == n and 0 <= x[3] <= 3 and math.isfinite(p['nll']), 'Nonfinite/out-of-model point')
        require(p['trigger'] == fit['trigger'] and p['ratio'] == fit['ratio'], 'Fixed trigger law changed')
        require(close(p['full_marked_nll'], p['nll']+mark), 'Full marked likelihood arithmetic differs')
        if mid == 'level_only':
            require(x[1] == d0, 'Level-only trend was estimated')
        if mid == 'trend_only':
            require(x[0] == a0, 'Trend-only amplitude was estimated')
        if p.get('origin') == 'amplitude_profile':
            index = p['evaluation_id']
            require(isinstance(index,int) and 0 <= index < len(raw_profiles), 'Missing profiled evaluation reference')
            original = raw_profiles[index]
            require(all(p[k] == original[k] for k in ('pars','nll','amplitude','J','origin')), 'Profile candidate detached from raw evaluation')
    for index,p in enumerate(raw_profiles):
        x,root = p['pars'],p['amplitude']
        require(p['evaluation_id'] == index and x[1] == d0 and x[2] == n and 0 <= x[3] <= 3 and
                p['trigger'] == fit['trigger'] and p['ratio'] == fit['ratio'], 'Raw profile escaped level model')
        require(root['root_converged'] is True and 0 <= root['iterations'] <= 100 and -12 <= root['a'] <= 0 and
                root['a'] == x[0] and close(root['A'],math.exp(root['a']),1e-12) and
                root['n_events'] == binding['arrays']['times']['shape'][0] and
                math.isfinite(p['J']) and p['J'] > 0 and all(math.isfinite(root[k]) for k in ('F_A_lower','F_A_upper','F_A_at_solution')), 'Amplitude root metadata failed')
        re = root['root_evaluations']
        require(len(re) >= 3 and re[0]['a'] == -12. and re[1]['a'] == 0. and re[-1]['a'] == root['a'] and
                all(-12 <= r['a'] <= 0 and math.isfinite(r['F_A']) for r in re) and
                re[0]['F_A'] == root['F_A_lower'] and re[1]['F_A'] == root['F_A_upper'] and
                re[-1]['F_A'] == root['F_A_at_solution'], 'Amplitude derivative trace differs')
        boundary = root['boundary']
        require((boundary == 'lower' and root['a'] == -12. and root['F_A_lower'] >= 0 and root['iterations'] == 0) or
                (boundary == 'upper' and root['a'] == 0. and root['F_A_upper'] <= 0 and root['iterations'] == 0) or
                (boundary is None and -12 < root['a'] < 0 and root['F_A_lower'] < 0 < root['F_A_upper']), 'Amplitude boundary/end signs differ')
        require(close(p['nll'],root['objective_without_trigger']+payload['trigger_compensator'],1e-8), 'Amplitude objective decomposition differs')
    runs = payload['search_records']
    expected_runs = []
    def stage(st, mid, grid, extra, eta=None):
        require(st['grid'] == list(map(float, grid)) and st['extra'] == list(map(float, extra)), 'Scalar grid/extra differs')
        gp, ep = st['grid_candidates'], st['extra_candidates']
        require(len(gp) == len(grid) and len(ep) == len(extra), 'Missing scalar grid/extra candidates')
        for p, value in zip(gp+ep, list(grid)+list(extra)):
            point(p, mid)
            require(p['pars'][3 if mid == 'level_only' else 1] == value, 'Grid coordinate differs')
            if eta is not None:
                require(p['pars'][3] == eta, 'Fixed profile eta differs')
        brackets = [[float(grid[i-1]), float(grid[i+1])] for i in range(1, len(grid)-1)
                    if gp[i]['nll'] <= gp[i-1]['nll'] and gp[i]['nll'] <= gp[i+1]['nll'] and
                    (gp[i]['nll'] < gp[i-1]['nll'] or gp[i]['nll'] < gp[i+1]['nll'])]
        require(st['local_brackets'] == brackets and st['solver_runs'] == len(brackets), 'Observed local bracket coverage differs')
        require([r['bounds'] for r in st['runs']] == brackets, 'Scalar solver coverage differs')
        require(st['eligible'] == gp+ep+[r['candidate'] for r in st['runs']], 'Scalar eligible candidates differ')
        require(st['selected'] == best(st['eligible']), 'Scalar winner differs')
        expected_runs.extend(st['runs'])
    benchmarks = payload['benchmark_methods']
    kk, bg = benchmarks
    for b in benchmarks:
        for phase in ('null', 'alternative'):
            point(b[phase])
            require(abs(b[phase]['nll']-b['saved_'+phase+'_nll']) < TOL, 'Saved benchmark value differs')
            if b['id'] == 'known_known':
                require(b[phase]['pars'][:2] == [a0, d0], 'KK benchmark infeasible')
        require(b['null']['pars'][3] == 0., 'Benchmark null eta differs')
    require(digest(benchmarks) == payload['benchmark_binding']['compact_selected_sha256'], 'Compact benchmark binding differs')
    lm, tm = payload['methods']
    stage(lm['search'], 'level_only', np.linspace(0., 3., 17), [kk['alternative']['pars'][3], 0.])
    require(len(lm['null_candidates']) == 2 and lm['null_candidates'][0] == kk['null'], 'Level null floor missing')
    require(len(lm['eta_profile']) == 11 and [c['eta'] for c in lm['eta_profile']] == list(np.linspace(0.,3.,11)), 'Level eta profile missing')
    for i,c in enumerate(lm['eta_profile']):
        point(c['selected'],'level_only')
        require(c['selected']['pars'][3] == c['eta'] and c['reused_null'] == (i == 0), 'Level eta coordinate differs')
    require(lm['eta_profile'][0]['selected'] == lm['null'], 'Level eta0 null differs')
    require(lm['candidates'] == [kk['alternative'], kk['null'], lm['null']]+lm['search']['eligible']+[c['selected'] for c in lm['eta_profile']], 'Level candidates differ')
    stage(tm['null_search'], 'trend_only', np.linspace(-2., 2., 17), [d0], 0.)
    require(tm['null_candidates'] == [kk['null']]+tm['null_search']['eligible'], 'Trend null floor missing')
    grid = tm['grid_candidates']
    require(len(grid) == 49 and [p['pars'][1::2] for p in grid] == [[float(d), float(e)] for d in np.linspace(-2., 2., 7) for e in np.linspace(0., 3., 7)], 'Trend 7x7 grid differs')
    seeds = [p['pars'][1::2] for p in sorted(grid, key=lambda p:p['nll'])[:3]]+[tm['null']['pars'][1::2], kk['alternative']['pars'][1::2]]
    unique = []
    for seed in seeds:
        if seed not in unique:
            unique.append(seed)
    powell = [r for r in runs if r['label'] == 'trend_alternative_Powell']
    require(tm['powell_seeds'] == unique == [r['start'] for r in powell] and len(unique) <= 5, 'Prescribed Powell starts differ')
    require([p['pars'][1::2] for p in tm['seed_candidates']] == unique, 'Seed candidates differ')
    expected_runs.extend(powell)
    curves = tm['eta_profile']
    require(len(curves) == 11 and [c['eta'] for c in curves] == list(np.linspace(0., 3., 11)), 'Eta-profile grid differs')
    require(curves[0]['selected'] == tm['null'] and curves[0]['eligible'] == tm['null_candidates'] and curves[0]['search']['reused_null'] is True, 'Eta0 must reuse null')
    for i, curve in enumerate(curves[1:], 1):
        stage(curve['search'], 'trend_only', np.linspace(-2., 2., 17), list(dict.fromkeys([float(d0),float(tm['null']['pars'][1])])), curve['eta'])
        require(curve['selected'] == curve['search']['selected'] and curve['eligible'] == curve['search']['eligible'], 'Eta-profile candidates differ')
    require(runs == expected_runs and runs and all(r['success'] is True for r in runs) and payload['all_mandated_solvers_successful'] is True, 'Mandatory solver failure or trace difference')
    require(tm['candidates'] == [kk['alternative'], kk['null'], tm['null']]+grid+tm['seed_candidates']+[r['candidate'] for r in powell]+[p for c in curves for p in c['eligible']], 'Trend eligible candidates differ')
    for r in runs:
        point(r['candidate'], 'level_only' if r['label'] == 'level_eta' else 'trend_only')
        require(close(r['nll'], r['candidate']['nll'], TOL) and 0 < r['nfev'], 'Solver returned value differs')
        if r['label'] == 'trend_alternative_Powell':
            require(r['nfev'] <= 100000 and r['nit'] <= 2000 and r['bounds'] == [[-2., 2.], [0., 3.]], 'Powell policy differs')
        else:
            require(r['nit'] <= 100, 'Scalar solver cap exceeded')
    for m in payload['methods']:
        mid = m['id']
        require(m['complete'] is True, 'Method incomplete')
        for p in m['candidates']+m['null_candidates']:
            point(p, mid)
        require(all(p['pars'][3] == 0. for p in m['null_candidates']), 'Null eta differs')
        require(m['null'] == best(m['null_candidates']) and m['alternative'] == best(m['candidates']), 'Winner selection differs')
        require(m['alternative']['nll'] <= m['null']['nll']+1e-8, 'New null not nested')
        for phase in ('null', 'alternative'):
            require(m[phase]['nll'] <= kk[phase]['nll']+1e-8 and close(m['gains'][phase+'_NLL'], kk[phase]['nll']-m[phase]['nll']), 'Feasible KK floor/gain differs')
            enc = m['benchmark_enclosure'][phase]
            gap = bg[phase]['nll']-m[phase]['nll']
            require(close(enc['signed_BG_minus_new_NLL'], gap) and enc['numerical_enclosure_flag'] == (gap > 2*TOL) and enc['material_enclosure_flag'] == (gap >= .001), 'Enclosure witness arithmetic differs')
    controlmap = {r['label']:r for r in payload['old_backend_controls']}
    cpumap = {r['label']:r for r in payload['cpu32_controls']}
    selected = {'old_'+b['id']+'_'+phase:b[phase] for b in benchmarks for phase in ('null', 'alternative')}
    selected.update({'new_'+m['id']+'_'+phase:m[phase] for m in payload['methods'] for phase in ('null', 'alternative')})
    corners = {'level_corner_a_'+str(a)+'_eta_'+str(e):[a,d0,n,e] for a in (-12.,0.) for e in (0.,3.)}
    corners.update({'trend_corner_d_'+str(d)+'_eta_'+str(e):[a0,d,n,e] for d in (-2.,2.) for e in (0.,3.)})
    require(len(payload['old_backend_controls']) == len(controlmap) == 16 and set(controlmap) == set(selected)|set(corners), 'CUDA16 control coverage differs')
    require(len(payload['cpu32_controls']) == len(cpumap) == 8 and set(cpumap) == set(selected), 'CPU32 control coverage differs')
    for label, r in controlmap.items():
        delta = abs(r['profile16_nll']-r['old_backend16_nll'])
        require(r['passed'] is True and delta < TOL and close(r['absolute_difference'], delta, 1e-12), 'Old backend control failed')
        require(r['pars'] == (selected[label]['pars'] if label in selected else corners[label]), 'Old backend control detached')
        if label in selected:
            require(r['profile16_nll'] == selected[label]['nll'], 'Selected16 control detached')
    for label, r in cpumap.items():
        delta = abs(r['profile16_nll']-r['independent32_nll'])
        require(r['passed'] is True and delta < TOL and close(r['absolute_difference'], delta, 1e-12) and
                r['pars'] == selected[label]['pars'] and r['profile16_nll'] == selected[label]['nll'], 'CPU32 selected control failed/detached')
        if label.startswith('old_'):
            bm = kk if r['method'] == 'known_known' else bg
            saved = bm['saved_'+r['phase']+'_nll']
            require(r['saved_primary16_nll'] == saved and abs(r['independent32_nll']-saved) < TOL and
                    close(r['saved_absolute_difference'], abs(r['independent32_nll']-saved), 1e-12), 'Saved CPU32 benchmark control failed')
    for tag, group in [('old',benchmarks), ('new',payload['methods'])]:
        for m in group:
            for order, rows, field in [(16,controlmap,'old_backend16_nll'), (32,cpumap,'independent32_nll')]:
                c = m['contrast'+str(order)]
                difference = 2*(rows[tag+'_'+m['id']+'_null'][field]-rows[tag+'_'+m['id']+'_alternative'][field])
                require(close(c['nll_subtraction_control'], difference, 1e-8) and
                        close(c['direct_minus_subtraction'], c['statistic']-difference, 1e-8) and abs(c['direct_minus_subtraction']) < TOL,
                        'Stable full-compensator direct control differs')
                require(c['statistic'] >= -TOL and all(math.isfinite(c[k]) for k in ('event_difference','background_compensator_difference','trigger_compensator_difference')), 'Invalid contrast')
                require(close(c['statistic'], 2*(c['event_difference']+c['background_compensator_difference']+c['trigger_compensator_difference']), 1e-8), 'Direct components differ')
                if tag == 'old':
                    require(abs(c['statistic']-m['saved_contrast'+str(order)]['statistic']) < TOL, 'Saved direct benchmark differs')
            require(abs(m['contrast16']['statistic']-m['contrast32']['statistic']) < TOL, 'Direct order control failed')
    ids = payload['common_backend_identities']
    require([(r['method'],r['order']) for r in ids] == [(m,o) for m in METHODS+('background_estimated',) for o in (16,32)], 'Common-backend identity coverage differs')
    for r in ids:
        m = next(m for m in payload['methods']+[bg] if m['id'] == r['method'])
        order = r['order']
        rows, field = (controlmap,'old_backend16_nll') if order == 16 else (cpumap,'independent32_nll')
        tag = 'old_' if m['id'] == 'background_estimated' else 'new_'
        g0,g1 = (rows['old_known_known_'+phase][field]-rows[tag+m['id']+'_'+phase][field] for phase in ('null','alternative'))
        c,b = m['contrast'+str(order)],kk['contrast'+str(order)]
        rhs = 2*(g1-g0)+c['direct_minus_subtraction']-b['direct_minus_subtraction']
        lhs = c['statistic']-b['statistic']
        require(close(r['null_gain'],g0) and close(r['alternative_gain'],g1) and close(r['direct_statistic_change'],lhs) and
                close(r['common_backend_identity_rhs'],rhs) and close(r['residual'],lhs-rhs) and abs(r['residual']) < 1e-8, 'Common-backend identity differs')
        require(close(r['direct_statistic_contraction_from_KK'],-lhs) and r['material_phase_NLL_gain'] == (max(g0,g1) >= .001) and
                r['material_absolute_direct_change'] == (abs(lhs) >= .1), 'Diagnostic phase/statistic screen differs')
    require([r['order'] for r in payload['interaction_identities']] == [16,32], 'Interaction identity coverage differs')
    for order in (16,32):
        expected = bg['contrast'+str(order)]['statistic']-lm['contrast'+str(order)]['statistic']-tm['contrast'+str(order)]['statistic']+kk['contrast'+str(order)]['statistic']
        require(close(payload['nonadditive_interaction'][str(order)], expected), 'Interaction arithmetic differs')
        rs = {r['method']:r for r in ids if r['order'] == order}
        rhs = 2*math.fsum(sign*(rs[mid]['alternative_gain']-rs[mid]['null_gain']) for mid,sign in
                          [('background_estimated',1),('level_only',-1),('trend_only',-1)])
        rhs += math.fsum(sign*m['contrast'+str(order)]['direct_minus_subtraction'] for m,sign in [(bg,1),(lm,-1),(tm,-1),(kk,1)])
        row = next(r for r in payload['interaction_identities'] if r['order'] == order)
        require(close(row['statistic'],expected) and close(row['phase_gain_identity_rhs'],rhs) and
                close(row['residual'],expected-rhs) and abs(row['residual']) < 1e-8 and
                row['material_absolute_interaction'] == (abs(expected) >= .1), 'Interaction phase identity/screen differs')
    require(payload['direct_controls_passed'] is True and payload['saved_benchmark_controls_passed'] is True, 'Direct gate flags differ')
    require(payload['sources'] == {'iteration_24/code/profile_optimizer.py': PROFILE_SHA}, 'Pinned objective source differs')
    metrics = payload['cuda_metrics']
    require(metrics['dtype'] == 'float64' and all(metrics[k] is False for k in ('allow_tf32','mixed_precision','fast_math_requested')) and metrics['peak_allocated_bytes'] <= 2**30, 'CUDA numerical/resource policy differs')
    require(payload['feature_metadata']['clock_mode'] in ('original_projected_clock','paired_clock') and payload['queries'] and
            payload['evaluations'] and payload['fixed_evaluations'] and not payload['evaluation_errors'], 'Missing/failed objective trace')
    for q in payload['queries']:
        require(q['pars'][1::2] == [q['d'],q['eta']] and q['model'] in METHODS and math.isfinite(q['nll']), 'Query trace differs')
        require(q['pars'][1] == d0 if q['model'] == 'level_only' else q['pars'][0] == a0, 'Query escaped constrained model')
    profiles = {(tuple(p['pars']),p['nll']) for p in raw_profiles}
    fixed = {(tuple(p['pars']),p['nll']) for p in payload['fixed_evaluations']}
    for p in payload['fixed_evaluations']:
        point(dict(p,full_marked_nll=p['nll']+mark))
    require(all((tuple(q['pars']),q['nll']) in (profiles if q['model'] == 'level_only' else fixed) for q in payload['queries']), 'Query detached from raw objective trace')
    return True
