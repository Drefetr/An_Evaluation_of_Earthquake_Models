param([switch]$Status)
$ErrorActionPreference = 'Stop'
$pilotWorkspace = Split-Path -Parent $PSScriptRoot
$pilotPython = Join-Path $env:LOCALAPPDATA 'Programs/Python/Python313/python.exe'
if (-not (Test-Path -LiteralPath $pilotPython)) {
    $pilotPython = (Get-Command python -ErrorAction Stop).Source
}
$pilotRunner = Join-Path $PSScriptRoot 'code/run_ablation_pilot.py'
$pilotMode = if ($Status) { '--status' } else { '--resume' }
Push-Location -LiteralPath $pilotWorkspace
try {
    Write-Host "Python: $pilotPython"
    & $pilotPython -B $pilotRunner $pilotMode
    $pilotExit = $LASTEXITCODE
}
finally {
    Pop-Location
}
exit $pilotExit
