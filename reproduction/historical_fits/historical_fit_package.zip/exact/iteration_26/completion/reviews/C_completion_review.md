# C completion review: PASS

C independently reconstructed every one of the1,150 level-only add-one ranks, exact tie counts, empirical sensitivity ranges and decisions from all2,149 accepted score receipts. Every discrete result and published CSV row matches. All2,300 inherited KK/BG query decisions match the accepted iteration21 source.

The six fixed-denominator cohort summaries and four paired summaries also agree. C checked the nominal CP intervals by binomial-tail inversion, separately from the frozen beta-quantile implementation, and checked descriptive paired sample-variance MCSEs. Six new literal tests pass. The audit imports neither the likelihood fitter nor the frozen collector; C performed no history likelihood evaluation, fit, GPU operation, simulation or bootstrap.

The result is123/150 level-only alternative rejections(82.0%; nominal conditional95% CP74.9–87.8%) and46/1,000 held-out null rejections. KK remains150/150 and49/1,000; BG remains68/150 and44/1,000. Level-only versus BG has62both,61level-only,6BG-only and21neither. Its net55/150difference is descriptive, not a causal share or deterministic ordering.

There are604 exact zero reference scores and630 query ties/nonpoint sensitivity ranges. No decision is unknown at the frozen threshold. All empirical radii are1e-6. D validates full numerical controls and the selected-NLL radius derivation; C independently verifies their resulting ordering sensitivity arithmetic. A validates the full source/input/attempt/preservation chain. These scopes do not replace a rigorous integration bound or global-optimum certificate.

The selected-ten pilot's raw-statistic contraction did not translate proportionally into calibrated rejection loss. The lower aggregate BG frequency directs attention to additional trend freedom or its joint behavior with level, but does not isolate a causal trend effect. Own-null banks change alongside query statistics. Close null marginal rates do not establish equal true size. Prior adaptive recipe selection, shared-bank dependence, nominal conditional intervals and inherited clock/repair qualifications remain explicit.

The single recommended next question is the missing trend-only matched-null cell with level supplied, under a separately prospective finite recipe and bounded resource contract. This review launches and authorizes no additional campaign.

The JSON binds full plan18aab96c7a42878ecb5f5ee97518731cb994dad8ccd7b9d85b9c9f7ef54dd303, the exact22-source map and accepted analysis signature7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c. Detailed interpretation is in completion/reports/C_interpretation.md; reproducible independent arithmetic and per-query counts are in the C-prefixed completion code, tests and result artifacts. A cross-review was requested; C does not claim a peer decision not yet received at creation.
