# D full-calibration completion review

**PASS for all-case numerical validation, source/provenance, lifecycle and resource completion.** Every one of the 2,149 saved payloads passed the frozen `level_only_fit.validate_result` through the actual runtime cache guard, including its actual uniformly pinned iteration 21 floor joins. This review performed no new fit, likelihood/history evaluation, GPU initialization, simulation, bootstrap or rank calculation.

The final sealed review is `D_completion_review.json`, SHA256 `e25825b3a0bd60acf913e5a038670559af1b0fd7246e3d86d7990c3b1cc9f956`. It binds accepted analysis signature `7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c` and full plan `18aab96c7a42878ecb5f5ee97518731cb994dad8ccd7b9d85b9c9f7ef54dd303`.

All 999 reference null histories, 1,000 held-out null histories and 150 alternative histories are present and complete. There are zero failed, censored, pending or execution-unknown cases and no retained fatal/error barrier. The accepted analysis records zero unknown decisions in its requested cohorts; that is a check of its saved terminal metadata, not a new calculation of decisions.

| Actual validated records | Count |
|---|---:|
| Complete cases and matched scalar/source receipts | 2,149 |
| Started / finished attempts | 2,149 / 2,149 |
| Successful mandated scalar solver records | 516 |
| Converged amplitude profiles | 61,054 |
| Profile requests | 71,115 |
| Original-backend CUDA16 point controls | 17,192 |
| Fresh CPU32 selected-point controls | 8,596 |
| Mandatory eta-profile points | 23,639 |
| Stable direct contrasts | 8,596 |
| Common-backend identity rows | 4,298 |
| Sealed partial records | 27,937 |

Each history has one recorded attempt in the one recorded generation. Started records match the exact plan/history/seed/catalogue/clock/baseline identity; finished records match the current immutable case bytes. All partial record seals and identities match those attempts, with no additional partial-attempt directory. Every case wall duration and independent parent start-to-case-commit interval is below its frozen 900/1800-second cap. This describes the recorded audit tree, not unrecorded machine-wide history.

The full session is closed, inactive and complete with worker exit zero. The pinned process lifetime helper found no process matching PID **17152**, creation token **134366992655324770**. All 22 live and archived runtime sources match the frozen plan. All 2,149 actual old-floor joins and accepted case/baseline/score-receipt joins passed, including exact T16/T32/envelope and role equality. Every accepted analysis manifest file matched its hash, and the archived runner plan/summary/sessions match the actual final records. Prior artifact preservation is separately reviewed by A; this review wrote only its new completion artifacts.

Maximum observed numerical discrepancies:

| Check | Maximum |
|---|---:|
| Profile16 versus original-backend16 | 2.9104e-11 |
| Profile16 versus selected CPU32 | 4.5475e-13 |
| Selected original-backend16 versus CPU32 | 1.8190e-12 |
| Saved baseline reproduction | 2.9104e-11 |
| Direct16 versus direct32 | 5.6843e-14 |
| Stable direct minus NLL subtraction | 6.4155e-11 |
| Common-backend scalar identity residual | 0 |

Every prescribed `1e-4` numerical gate and `1e-8` scalar identity gate passed. All empirical score envelopes equal the prospective `1e-6` floor. The raw stable T16 scores range from **0 to 124.34331352982127**, with no negative values in this realized run; no statistic was clipped or newly ranked by this audit.

Selected alternatives have eta=0 in 1,234 cases: 604 reference nulls, 629 held-out nulls and one alternative. No selected null/alternative amplitude hits either amplitude bound, and no selected eta hits its upper bound. Of the 61,054 amplitude profiles, 61,033 roots are interior and 21 select the valid upper amplitude endpoint at nonwinning profile candidates. These are optimization diagnostics, not rejection frequencies or causal explanations.

Clock metadata contains 2,148 original projected-clock histories and one paired-clock history. Event counts range from 329 to 30,276; the event-count and runtime extreme is `null_1292`. The maximum selected case wall duration is **117.738289 seconds**, with parent start-to-commit interval **117.752946 seconds**. The largest prepared quadrature arrays contain 5,990,944 order16 and 11,981,888 order32 nodes, processed under the frozen bounded construction/reduction policy. Maximum recorded Torch allocation is **169,438,720 bytes**, below the 1 GiB guard. This allocation measure is not total VRAM or host RSS.

| Resource accounting | Seconds |
|---|---:|
| Measured full parent invocation wall | 15609.504870599834 |
| Explicit final-write operational allowance | 1 |
| Charged full parent wall | **15610.504870599834** |
| Full fitting cap | 28800 |
| Sum of recorded case wall durations | 15308.03479540022 |
| Stored analysis measurement before final publication | 133.36297889985144 |
| Stored analysis measurement before manifest | 133.50080699985847 |
| Pure analysis cap | 600 |

The full fitting charge is about **4.336 hours**, below the eight-hour cap. These are **parent wall quantities, not GPU-seconds**. The explicit final-write allowance is an operational reservation, not measured latency or a proved bound. Stored analysis measurements stop before the stated final publication/manifest step; the accepted collector source additionally checks runtime through publication and lock release. The narrower case-wall sum does not replace the parent total. The D metadata audit itself took 292.700 seconds and did not add a scientific fit or alter a fitting ledger.

After C's sealed statistical receipt review passed, a separate finalization check matched all **six method-table rows** and **four paired-table rows** exactly to the accepted analysis: requested denominators, counts, unknowns, frequencies, nominal interval endpoints and displayed descriptive MCSEs. It also checked the completion summary's methods/paired fields and source/signature binding. No ranks, decisions, intervals or likelihoods were recomputed. C review SHA256 is `069fd37ce8d5ded727e67d061bece2e8e9c24f40615bd2c74b027299d7c68cd0`; its interpretation and exploratory reused-data qualifications remain necessary.

New supporting artifacts:

* `completion/results/D_numerical_summary.json`: `5d8297b6d472bd0e781d198cf96a805d09b7129a295ae1dd7ffb9b3e0ee41a68`.
* `completion/results/D_case_controls.csv`: `be7297d5d1ef9bcda874d9a1c6515b6132d3e60ab576cb6bfc5ecd87bfcefa14`.
* `completion/results/D_solver_records.csv`: `f3563db9190e2a1ddf57f8339fbb78d9636956ee84b7836f642e7754c9c4951a`.
* `completion/code/D_audit_completion.py`: `fde1f01fbeb4fea8bc5bcf19c2974c9194bf2e3cb4c14890a773ec25bfa8fbbb`.
* `completion/code/D_finalize_review.py`: `22aa2b63f8fbbb49b48ebd7ecf7ab5793c537a81cb32ea7ac15d7c5e591f002a`.

The pure validator and this metadata audit do not independently recompute geometry or prove universal integration accuracy/global optimization. The finite reused-data procedure and empirical envelopes do not establish confirmatory selection-adjusted error control or causal power attribution. Unused resource allowance does not authorize another campaign.
