# Completion editorial change map

`results_replacement.tex` is a new results/limitations insert for the restricted diagnostic ablation section. Pair it with the earlier26methods replacement and the frozen generating-law/source authorities. Do not reconstruct or silently modify the original thesis PDF/source.

Replace any provisional inference that large level-only raw-statistic contraction accounts for most of the calibrated detection collapse with the completed own-bank result:123/150 level-only versus68/150 level-plus-trend, with46/1000 and44/1000 held-out null rejections. Include all paired counts and the caveat that the cells compare finite procedures; no causal share or exact equal-size claim follows. Retain earlier finite-path score geometry as prior evidence, not a newly established ensemble-information result.

The result does not change the mathematical finite-mode theorem, no-feedback exact-memory counterexamples, physical-loading scope or observed-catalogue fit. No nonlinear infinite-memory ergodicity or physical shared-kernel identification is inferred. The remaining trend-only calibration is a proposed next bounded comparison, not an executed result.

No PDF was produced. The replacement uses standard LaTeX commands; no compilation/rendering claim is made.
