# C interpretation of the completed level-only calibration

The level-only procedure rejected123 of150 alternative histories after calibration against its own999-member null-reference bank:82.0%, with nominal conditional95% Clopper-Pearson interval74.9–87.8%. The corresponding held-out null result was46/1,000(4.6%). This is intermediate between the unchanged KK150/150 and both-background-free BG68/150 results. It does not turn the earlier four-path statistic contractions into an equally large calibrated detection loss.

All2,149 planned histories were completed under the frozen uniform iteration21 KK floor authority. The new level-only model fits a and eta while keeping d supplied; its null fits a with eta0. The old KK and BG outcomes retain their own frozen banks. The following are conditional frequencies on the same fixed cohorts, not a population power curve or an equal-size comparison.

| Procedure | Held-out null rejection | Nominal conditional95% CP interval | Alternative rejection | Nominal conditional95% CP interval |
|---|---:|---:|---:|---:|
| KK, a and d supplied | 49/1,000=4.9% | 3.65–6.43% | 150/150=100% | 97.57–100% |
| level_only, a fitted and d supplied | 46/1,000=4.6% | 3.39–6.09% | 123/150=82.0% | 74.90–87.79% |
| BG, a and d fitted | 44/1,000=4.4% | 3.21–5.86% | 68/150=45.33% | 37.20–53.66% |

The new method uses its own reference distribution; no KK or BG critical value was reused. A lower raw likelihood-ratio statistic need not imply rejection loss of the same magnitude because its null-reference distribution changes too. The iteration25 pilot established selected-path likelihood/statistic changes. It did not estimate calibrated detection. The completed level-only result now supplies that distinct calculation under one fixed alternative law.

## What the pairing establishes

Compared with KK, all123 level-only alternative rejections were also KK rejections, and27 were KK-only. The observed paired difference is−18.0percentage points, with descriptive paired MCSE3.15points.

Compared with BG, the alternative pair table is:

| | BG rejects | BG does not reject |
|---|---:|---:|
| Level-only rejects | 62 | 61 |
| Level-only does not reject | 6 | 21 |

Thus level-only has55 more rejections in aggregate, a paired difference of36.67percentage points with descriptive paired MCSE4.58points. The six BG-only histories prevent a deterministic ordering of the detectors. Parameter-space nesting orders ideal phasewise likelihood infima; it does not order independently calibrated likelihood-ratio decisions.

At the level-only-versus-BG comparison, additionally freeing trend is associated with a substantially lower aggregate conditional detection frequency under the respective own banks. This is evidence against interpreting background-level freedom alone as the whole explanation of the earlier BG result. It is not a causal partition into “level loss” and “trend loss,” an additive explained fraction, or proof that trend alone would produce the BG reduction. The missing trend-only calibrated cell and possible joint effects remain unresolved. Finite search, different fitted nuisance coordinates and procedure-specific null banks are part of the comparison.

The null marginals also conceal different rejection identities. Of the1,000 held-out nulls, level-only and KK share only four rejections, with42 level-only-only and45 KK-only. Level-only and BG share ten, with36 level-only-only and34 BG-only. Their paired null-frequency differences are−0.3 and+0.2percentage points, respectively. Close marginal frequencies and overlapping intervals do not establish equal true size or identical tests.

## What C independently verified

C wrote a new completion audit that imports neither the scientific fitter nor the frozen calibration collector. It reconstructed every one of the1,150 level-only central add-one ranks, exact>=tie counts, empirical sensitivity ranges and stable decisions from the2,149 accepted score receipts. Every result matches the accepted JSON and CSV exactly. It checked each saved KK/BG decision against the accepted iteration21 analysis, then independently reaggregated all six cohort tallies and four paired summaries.

Clopper-Pearson intervals were checked by inversion of binomial tails, independently of the frozen collector's beta-quantile implementation. The interval and other floating summaries agree within2e-12; discrete decisions and tables agree exactly. Six separate literal tests cover threshold/tie arithmetic, touching interval endpoints, unresolved outcomes, CP tail equations and paired sample variance.

The999 level reference scores include604 exact zeros and396 distinct numerical values. All tied references remain in the bank. There are630 queries with exact reference ties and nonpoint sensitivity ranges, yet none is ambiguous at the.05 decision boundary. All recorded empirical radii equal1e-6. Zero unknown decisions does not establish a rigorous integration-error bound: these are operational sensitivity intervals, and C's statistical audit consumes the accepted radii. D separately validates their selected-NLL derivation and numerical controls. C did not refit or evaluate a history likelihood.

The exact999/1,000/150 role split, complete closed/inactive calibration barrier, both source case-hash maps, accepted publication hashes and analysis signature were checked. Inherited clock and law authorities remain fixed, including paired null_0841 and projected extreme null_1292. The uniform old21 floor authority is an explicit finite-recipe change from iteration25; the pre-full-run benchmark had already shown exact selected-fit agreement on its ten overlapping pilot histories. Full-run cases were fitted afresh rather than imported from that benchmark.

## Scope and the next question

These histories and earlier results informed selection of the level-only procedure. Matching its reference bank does not restore a confirmatory exact5% guarantee for that adaptive selection process. The finite-rank proposition needs exchangeability of the complete selection-plus-scoring rule; that has not been established retrospectively. The CP intervals are nominal realized-bank conditional summaries under iid-query/fixed-procedure assumptions. They omit another reference bank's variability, generating-law uncertainty, adaptive selection and numerical-geometry uncertainty. Shared-bank decisions are dependent unconditionally, and a conditional null rejection probability need not equal or be below.05 for every realized bank.

The original diagnostic law, full marked likelihood and compensators, random event counts, mark distribution, supplied branching/productivity/beta values and finite kernels remain unchanged. No Fisher/Wilks/chi-square approximation is introduced. These results do not reconstruct the original physical loading model, identify an inhibition mechanism, discriminate arbitrary kernels, prove global optima or an intrinsic information limit. The separate historical57/150 result remains another numerical procedure, not a component or residual in this comparison.

The single best remaining question is: **with background level supplied, what matched-null conditional rejection behavior does trend_only—fitting d and eta—show on the same fixed law and role split?** It would fill the missing calibrated cell and test whether the observed BG reduction also occurs for trend freedom alone or depends on joint flexibility. It requires its own prospective finite recipe, matched null bank, numerical checks and resource contract. This is a recommendation only; C has not prepared, launched or authorized that additional campaign.

Accepted analysis: iteration_26/results/analysis/2026-10-17T125009077299_0000. Analysis signature:7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c. Summary SHA256:0c46b5756ef92965263112738baea86914da2e95d4aa00609c5931a750540aca. The sealed C audit and completion review bind the manifest, CSV, frozen protocol and exact source map.
