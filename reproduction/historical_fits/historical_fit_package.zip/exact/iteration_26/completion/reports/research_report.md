# Completed level-only matched-null calibration

The level-only detector rejected the null in **123/150 saved alternative histories (82.0%)**, with **46/1000 held-out null rejections (4.6%)**. Allowing both background level and trend to be estimated gave **68/150 (45.3%)** with **44/1000 (4.4%)**. The supplied-background procedure detected **150/150**, with **49/1000 (4.9%)**. These are each procedure's own matched-null decisions on the same queries, not scores compared with a shared or reused critical value.

This result changes the reading of the selected-ten raw-contrast pilot. Estimating level alone caused substantial raw-statistic contraction, yet retained much more calibrated detection than the procedure estimating both level and trend. The extra trend freedom, its interaction with level, and the associated finite fitting/calibration procedure warrant attention. Background level alone does not reproduce the previously observed collapse in detection under this one law. The experiment does not isolate a causal share of that loss.

## What completed

All **2,149 fresh level-only fits** completed: 999 null references, 1,000 disjoint held-out null queries and 150 unchanged alternatives. There are no failed, censored, missing or numerical-envelope-unknown cases in the accepted output. One owned worker generation closed, exited zero and is absent under its recorded PID/creation token. All 12 earlier benchmark fits remain separate; no winner was imported into the full run.

Full fitting charged **15610.504871 seconds (4 hours 20 minutes)**, including the explicit one-second operational closure allowance, inside the eight-hour cap. Measured elapsed through cleanup before that allowance was 15,609.504871 seconds. The saved collector manifest records approximately 133.50 seconds before its final manifest write, inside its separately specified 600-second analysis budget. An exact post-manifest/post-lock-release elapsed value was printed by the collector but is not durably saved in the supplied logs; we do not invent that number or treat the operational allowance as a proved latency bound.

The full plan is `18aab96c7a42878ecb5f5ee97518731cb994dad8ccd7b9d85b9c9f7ef54dd303`. The accepted analysis is `iteration_26/results/analysis/2026-10-17T125009077299_0000/`, signature `7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c`. Its sealed summary SHA256 is `0c46b5756ef92965263112738baea86914da2e95d4aa00609c5931a750540aca`. The original iteration26 preparation/status documents remain historical frozen snapshots; this completion area records the current state.

## Matched rejection and detection results

| Background treatment | Held-out null rejection | Alternative detection | Nominal conditional 95% interval for detection |
|---|---:|---:|---:|
| Level and trend supplied (earlier KK) |49/1000 =4.9% |150/150 =100% |97.6-100% |
| Level estimated, trend supplied (new26) |46/1000 =4.6% |123/150 =82.0% |74.9-87.8% |
| Level and trend estimated (earlier BG) |44/1000 =4.4% |68/150 =45.3% |37.2-53.7% |

The nominal conditional 95% null intervals are 3.65-6.43%,3.39-6.09% and3.21-5.86%, respectively. The observed null rates are similar; that is not proof that the procedures have exactly equal size or that calibration is uniformly valid over nuisance parameters. The 100% observed detection rate is 150 successful finite trials, not a guarantee of perfect population detection. Clopper-Pearson intervals and descriptive MCSEs here are conditional summaries with the limitations below, not selection-adjusted guarantees.

In the paired alternative comparison of level-only versus level-plus-trend, **62** are detected by both, **61** only by level-only, **6** only by level-plus-trend and **21** by neither. The net difference is **55/150 =36.67 percentage points**, with descriptive paired MCSE **4.58 percentage points**. Relative to supplied background, level-only misses **27** alternatives, an **18-point** difference. These differences telescope arithmetically but are not a factorial causal decomposition. The six reverse discordances also rule out describing one rejection rule as uniformly dominating the other on these histories.

The 999-member new reference bank has a substantial boundary atom: **604 scores equal exactly zero**. The independently checked tied-rank/add-one rule and interval endpoint conventions therefore matter. All 1,150 new query decisions remain stable under the specified empirical numerical intervals, despite ties and nonpoint rank sensitivity ranges. No boundary chi-square approximation, ordinary Wilks calibration or finite-second-moment Fisher argument was used.

## What this says about the research question

The 82% result supplies the true trend; it is a controlled diagnostic, not a ready-to-use result when trend is unknown. The earlier supplied-law/supplied-background results already showed that these stipulated observation laws can be separated over this horizon when their nuisance values are supplied. This follow-up shows substantial separation survives estimation of background level alone at this particular generating law. It therefore narrows the fitting-loss question: the weaker level-plus-trend detector cannot be explained merely by pointing to the raw contrast lost when background level is free.

A flexible null can fit average suppression by reducing its background level. Allowing trend as well can additionally imitate gradual changes. The observed calibrated result is consistent with that explanation, but does not prove it: level and trend may interact; the trend-only calibration is absent; and the finite optimizers, candidate selection and null score distributions are part of the compared procedures. Earlier optimizer robustness on ten selected paths is useful evidence but is not a global optimum certificate for every full-cohort fit. The now-completed experiment refines a diagnostic hypothesis rather than refuting the physical model or establishing a new stability theorem.

The two comparison columns for KK and BG are inherited, frozen iteration21 outcomes on these exact histories, not new refits in26. The new26column applies the uniformly frozen original21KK floor/eta-extra recipe afresh to all histories. The prior25pilot used original24floors on its ten cases. That operational change was declared before new outcomes; all ten benchmark overlap fits agreed exactly at their selected phase objectives. No data-dependent replacement seeds, altered marks, event-count filtering, new beta estimate, kernel search, bootstrap or new scientific simulation was introduced.

## Scope and unresolved limitations

The diagnostic intensity is

`lambda(t)=exp(a+d0*(2t/T-1)-eta*G(t))+n0*H(t)`.

Only a is estimated under eta=0; a and eta are estimated under the alternative. Trend, branching, mark law, productivity ratio and both 195-mode kernels remain supplied. The exact inherited alternative eta is 0.4885010300470942 and the horizon 24,394 days, with empty prehistory. Counts remain random and all saved marked histories are retained, including the 30,276-event null and the existing 0841 paired-clock repair. The source law is not the manuscript's original physical loading model, and this is not a new fit to observed New Zealand earthquake data.

These reused histories and earlier results informed the choice of procedure. A newly frozen score does not undo that selection. The ideal conservative add-one rank theorem requires exchangeability of the entire selection-plus-scoring rule; this condition is not proved retrospectively for the study. Null calibration is at one generating nuisance point, not least-favourable or uniform over the composite null box. Conditional nominal intervals omit bank construction, generating-law uncertainty, adaptive selection and numerical-geometry uncertainty. Queries sharing a bank are dependent unconditionally. The ID-specific clock/repair provenance remains explicit.

CPU32 and CUDA16 comparisons are empirical sensitivity controls using pinned shared geometry; they do not provide universal integration-error bounds. Finite successful searches do not certify all global maxima. The observed detection rates neither identify shared physical stress memory nor distinguish arbitrary stress kernels, and they do not extend first-moment finite-mode stability to nonlinear infinite-memory ergodicity. Original observed-catalogue conclusions and their limited sample size are unchanged.

## Review, artifacts and next step

All three actual completion reviews passed. D checked all 2,149 pure numerical payloads, 17,192 CUDA16 point controls, 8,596 CPU32 selected controls, 516 required scalar records and 27,937 partial checkpoints. A checked terminal/source preservation, all input/file lineages and rank integration; C independently reconstructed all query ranks, intervals and paired arithmetic. The agents share a workspace and context; this is cross-review, not independent academic refereeing. Detailed objections and timing qualifications are retained in `reviews/` and `reports/C_interpretation.md`.

Tables are generated from the saved accepted output in `results/method_comparison.csv` and `results/paired_comparison.csv`. The standalone scientific figure is `results/calibrated_comparison.png` and `.svg`; its PNG was visually inspected. No PDF or reconstructed original thesis is produced. Targeted replacement LaTeX and the editorial map are under `manuscript/`.

The single most useful next comparison is the remaining **trend-only matched-null cell**: supply background level, estimate trend and inhibition, and use that procedure's own null bank on the same histories under a separately frozen and benchmarked budget. It would help distinguish sensitivity loss from trend freedom alone from loss associated with joint level-trend estimation. This report does not launch that run or authorize 500 pairs, new catalogues or nested bootstrap. Confirmatory claims would need an appropriately reserved or newly generated evaluation set in a separately declared study.
