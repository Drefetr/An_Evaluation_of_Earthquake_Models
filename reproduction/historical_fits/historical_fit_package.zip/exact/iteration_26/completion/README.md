# Completed iteration 26 level-only calibration

Current result: 123/150 alternative detections (82.0%) and 46/1000 held-out null rejections (4.6%). The earlier level-plus-trend procedure detected 68/150 (45.3%) with 44/1000 null rejections; supplied background detected 150/150 with 49/1000 null rejections. Each used its own matched null bank on the same queries. All 2,149 new fits completed without failed/censored/unknown cases.

The current report is `reports/research_report.md`. The original iteration 26 README/STATUS are sealed preparation snapshots; this completion area records the completed state. Read `reports/C_interpretation.md` and the three `reviews/*_completion_review` files for precise qualifications and evidence. The agents' work is cross-review, not independent academic refereeing.

Saved accepted calibration: `../results/analysis/2026-10-17T125009077299_0000/`. Tables and standalone PNG/SVG comparison are in `results/`. New manuscript replacement source and an editorial map are in `manuscript/`. No original manuscript or frozen input/result is modified. No PDF was produced.

Read-only integrity and completion check:

```powershell
python -B iteration_26/completion/code/verify_completion.py
```

Add `--exhaustive` to hash the full 34,695-file precompletion snapshot, including all partial search checkpoints. The ordinary check verifies completion artifacts, preparation/prior authorities, all full case and inherited floor hashes, accepted publication and terminal state. Neither mode fits or simulates.

Recompute calibration arithmetic from saved score receipts, without writing to sealed authorities:

```powershell
python -B -c "import sys; sys.path.insert(0,'iteration_26/completion/code'); from C_recompute_calibration import audit; r=audit(); print(r['methods'])"
```

Regenerate descriptive tables and figure into a new directory:

```powershell
python -B iteration_26/completion/code/make_completion_tables.py --output-dir iteration_26/reproduction_tables_01
```

The generator refuses existing generated artifacts. Do not rerun the old full fitting launcher merely to inspect the completed output: it would update execution metadata. The accepted run and its manifests should remain unchanged. Any changed law, fitting search or additional scientific campaign needs a separately declared iteration/protocol.

The result is exploratory, conditional on one inherited law and realized reference bank. It does not prove exactly equal size, a causal partition of sensitivity loss, physical shared-memory inhibition, global optimizer optimality or new ergodicity. The remaining trend-only matched-null cell is the proposed next bounded comparison, not a run launched here.
