"""Bind D's completed audit to accepted analysis and check small display tables."""
from pathlib import Path
import csv,math,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sealed_json,sha256,utc_now


def rows(path):
    with path.open(newline='',encoding='utf-8') as stream:return list(csv.DictReader(stream))


def main():
    area=ROOT/'iteration_26';completion=area/'completion';accepted=area/'results/analysis/2026-10-17T125009077299_0000/summary.json'
    a=read_sealed(accepted);review_path=completion/'reviews/D_completion_review.json';d=read_sealed(review_path)
    assert d['passed'] is True and 'analysis_signature' not in d,'Final review already bound or numerical audit failed'
    assert a['analysis_signature']=='7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c' and a['plan_id']==d['plan_id']
    cpath=completion/'reviews/C_completion_review.json';c=read_sealed(cpath)
    assert c['role']=='C' and c['passed'] is True and c['analysis_signature']==a['analysis_signature']
    display=read_sealed(completion/'results/summary.json')
    assert display['source_sha256']==sha256(accepted) and display['analysis_signature']==a['analysis_signature']
    assert display['methods']==a['methods'] and display['paired']==a['paired']
    method_rows=rows(completion/'results/method_comparison.csv')
    assert len(method_rows)==6 and len({(r['procedure'],r['cohort']) for r in method_rows})==6
    for row in method_rows:
        saved=a['methods'][row['procedure']][row['cohort']]
        for k in ('requested','rejections','unknown'):assert int(row[k])==saved[k]
        assert float(row['conditional_frequency'])==saved['conditional_frequency']
        assert float(row['nominal_CP95_low'])==saved['exact_binomial_95_interval'][0]
        assert float(row['nominal_CP95_high'])==saved['exact_binomial_95_interval'][1]
        assert float(row['descriptive_MCSE'])==saved['monte_carlo_se']
    pair_rows=rows(completion/'results/paired_comparison.csv')
    assert len(pair_rows)==4 and len({(r['comparison'],r['cohort']) for r in pair_rows})==4
    for row in pair_rows:
        saved=a['paired'][row['comparison']][row['cohort']]
        assert int(row['requested'])==saved['requested']
        for k in ('neither','first_only','second_only','both','unknown'):assert int(row[k])==saved['table'][k]
        assert float(row['frequency_difference'])==saved['first_minus_second']
        assert float(row['descriptive_paired_MCSE'])==saved['descriptive_MCSE']
    d.update(analysis_signature=a['analysis_signature'],review_finalized_utc=utc_now(),
             accepted_statistical_review=dict(path=cpath.relative_to(ROOT).as_posix(),sha256=sha256(cpath),passed=True),
             table_crosscheck=dict(passed=True,method_rows=6,paired_rows=4,
                scope='Exact saved-summary/table equality after C statistical receipt review; no new ranks, decisions, intervals or likelihoods computed'))
    for path in [accepted,cpath,completion/'results/summary.json',completion/'results/method_comparison.csv',completion/'results/paired_comparison.csv',Path(__file__)]:
        d['evidence_sha256'][path.relative_to(ROOT).as_posix()]=sha256(path)
    sealed_json(review_path,d)
    print(dict(passed=True,analysis_signature=d['analysis_signature'],method_rows=6,paired_rows=4,final_review_sha256=sha256(review_path)))


if __name__=='__main__':main()
