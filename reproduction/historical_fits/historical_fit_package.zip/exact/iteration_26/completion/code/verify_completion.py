"""Read-only completion integrity check; never fits, simulates or evaluates likelihoods."""
from pathlib import Path
import argparse
import json
import math
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
AREA=ROOT/'iteration_26';COMP=AREA/'completion'
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sha256


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exhaustive',action='store_true',help='Also hash every precompletion file, including all partial checkpoints')
    args=parser.parse_args();errors=[];checked={}
    manifest=read_sealed(COMP/'logs/completion_manifest.json')
    preparation=read_sealed(AREA/'logs/preparation_manifest.json')
    prior=read_sealed(AREA/'logs/prior_preservation_before.json')
    for records in [manifest['artifact_sha256'],manifest['authorities_sha256'],preparation['artifact_sha256'],prior['artifact_sha256']]:
        checked.update(records)
    if args.exhaustive:checked.update(read_sealed(COMP/'logs/precompletion_snapshot.json')['artifact_sha256'])
    published=ROOT/manifest['accepted_analysis_path'];accepted=read_sealed(published/'manifest.json')
    for name,h in accepted['files'].items():checked[(published/name).relative_to(ROOT).as_posix()]=h
    result=read_sealed(published/'summary.json')
    for i,h in result['source_case_sha256'].items():checked[f'iteration_26/results/full_calibration/cases/{i}.json']=h
    for i,h in result['source_baseline_sha256'].items():checked[f'iteration_21/results/full_staged/cases/{i}.json']=h
    for path,h in checked.items():
        if not (ROOT/path).is_file() or sha256(ROOT/path)!=h:errors.append(path)
    summary=read_sealed(AREA/'results/full_calibration/summary.json');ledger=read_sealed(AREA/'results/full_calibration/sessions.json')
    sessions=ledger['sessions']
    if not (summary['counts']=={'complete':2149} and summary['terminal_complete'] and summary['reason']=='complete' and
            summary['sessions_closed'] and not summary['active'] and not summary['active_ids'] and
            summary['charged_seconds']==sum(s['elapsed_seconds'] for s in sessions) and
            all(s['closed'] and s['stage']=='closed' and not s.get('active_id') for s in sessions)):
        errors.append('terminal_metadata')
    sys.path.insert(0,str(AREA/'code'))
    from run_level_calibration import lifetime
    life=lifetime()
    for session in sessions:
        identity=session.get('worker_identity')
        if identity is not None and life.process_identity(identity['pid'])==identity:errors.append('owned_worker_generation_alive')
    for role in ['A','C','D']:
        review=read_sealed(COMP/f'reviews/{role}_completion_review.json')
        if review['role']!=role or review['passed'] is not True or review['analysis_signature']!=result['analysis_signature']:errors.append(role+'_review')
    print(json.dumps(dict(passed=not errors,errors=errors,hashes_checked=len(checked),exhaustive=args.exhaustive,
                         complete_cases=2149,analysis_signature=result['analysis_signature'],
                         level_alternatives=result['methods']['level_only']['alternative_frequency']['rejections'],
                         level_nulls=result['methods']['level_only']['heldout_null_size']['rejections'],
                         read_only=True,new_fits=0,new_simulations=0),indent=2))
    return 0 if not errors else 2


if __name__=='__main__':raise SystemExit(main())
