"""A completion provenance/arithmetic audit; no fitting/history/likelihood or CUDA work."""
from pathlib import Path
import csv
import hashlib
import json
import math
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_26/code'))
import run_level_calibration as runner
import calibrate_level_only as collector

AREA=ROOT/'iteration_26'
RUN=AREA/'results/full_calibration'
ANALYSIS=AREA/'results/analysis/2026-10-17T125009077299_0000'
OUT=AREA/'completion/results/A_completion_validation.json'


def check(ok,message):
    if not ok:raise AssertionError(message)


def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(2**20),b''):h.update(block)
    return h.hexdigest()


def main():
    began=time.perf_counter()
    check(not OUT.exists(),'A audit receipt already exists')
    plan=runner.read_sealed(RUN/'plan.json');summary=runner.read_sealed(RUN/'summary.json')
    ledger=runner.read_sealed(RUN/'sessions.json');analysis=runner.read_sealed(ANALYSIS/'summary.json')
    manifest=runner.read_sealed(ANALYSIS/'manifest.json')
    runner.guard(plan)  # read-only actual freeze/prelaunch/benchmark-postrun gate/source binding
    charge=collector.validate_terminal(plan,summary,ledger)
    check(not (RUN/'fatal.json').exists(),'Retained fatal barrier')
    check(runner.read_sealed(RUN/'execution_started.json')['plan_id']==plan['plan_id'],'Execution marker plan differs')
    for s in ledger['sessions']:
        identity=s['worker_identity']
        check(s['worker_exitcode']==0 and s['reason']=='complete' and identity is not None,'Generation did not complete normally')
        check(runner.lifetime().process_identity(identity['pid'])!=identity,'Owned PID/creation token is alive')
        check(s['elapsed_seconds']==s['measured_elapsed_seconds']+1.,'Measured/debited time differs')
    ids=runner.IDS;entries={e['id']:e for e in plan['entries']}
    check(plan['ids']==ids and list(entries)==ids,'Full role identity/order differs')
    check({p.stem for p in (RUN/'cases').glob('*.json')}==set(ids),'Case coverage differs')
    check(summary['states']==dict.fromkeys(ids,'complete'),'Full terminal states differ')
    check(entries['null_0841']['clock_mode']=='paired_clock' and entries['null_1292']['n_events']==30276,'Paired/extreme authority missing')
    check(analysis['plan_id']==manifest['plan_id']==plan['plan_id'],'Accepted analysis plan differs')
    check(analysis['source_hashes']==plan['sources'] and analysis['config_sha256']==plan['config_sha256'],'Analysis source/config differs')
    for path,digest in plan['sources'].items():
        check(file_hash(ROOT/path)==digest and file_hash(RUN/'source_snapshots'/path)==digest,'Current/source snapshot differs: '+path)
    for name,digest in manifest['files'].items():check(file_hash(ANALYSIS/name)==digest,'Published manifest file differs: '+name)
    for name in ('plan.json','summary.json','sessions.json'):
        check(file_hash(RUN/name)==file_hash(ANALYSIS/('runner_'+name)),'Archived runner bytes differ: '+name)
    check(analysis['runner_summary_sha256']==file_hash(RUN/'summary.json') and analysis['runner_sessions_sha256']==file_hash(RUN/'sessions.json'),'Analysis terminal hashes differ')
    check(analysis['summarizer_sha256']==plan['sources']['iteration_26/code/calibrate_level_only.py'],'Analysis producer differs')
    signature=runner.canonical_hash({k:analysis[k] for k in ('plan_id','config_sha256','source_case_sha256','source_baseline_sha256','prior_own_bank_analysis','summarizer_sha256')})
    check(signature==analysis['analysis_signature']==manifest['analysis_signature'],'Analysis signature differs')
    check(analysis['source_case_sha256']==manifest['source_case_sha256'] and analysis['source_baseline_sha256']==manifest['source_baseline_sha256'],'Published case maps differ')
    check(set(analysis['source_case_sha256'])==set(ids),'Accepted full case map quota differs')
    check(analysis['analysis_budget_seconds']==600 and analysis['full_run_charged_seconds']==charge,'Published accounting scope differs')
    check(0<=analysis['analysis_measured_seconds_before_final_publication']<=manifest['measured_seconds_before_manifest']<599,'Durable analysis timer exceeds reserve')
    check(manifest['closure_allowance_seconds']==analysis['closure_allowance_seconds']==1 and
          manifest['closure_allowance_is_measured_or_proven_bound'] is False,'Publication allowance interpretation differs')
    check(file_hash(ROOT/collector.STATS_PATH)==collector.STATS_SHA==analysis['statistical_authority_sha256']==manifest['statistical_authority_sha256'],'Finite rank authority differs')
    prior=runner.read_sealed(ROOT/collector.PRIOR_PLAN_PATH)
    old_analysis=runner.read_sealed(ROOT/collector.OLD_ANALYSIS_PATH)
    check(file_hash(ROOT/collector.PRIOR_PLAN_PATH)==collector.PRIOR_PLAN_SHA and file_hash(ROOT/collector.OLD_ANALYSIS_PATH)==collector.OLD_ANALYSIS_SHA,'Old accepted authority differs')
    check(plan['entries']==prior['entries'] and plan['contract']['law']==prior['contract']['law'],'Original law/cohort differs')
    old_rows={r['id']:r for r in old_analysis['outcomes']}
    preservation={}
    for relative in ('iteration_26/logs/preparation_manifest.json','iteration_26/logs/prior_preservation_before.json'):
        saved=runner.read_sealed(ROOT/relative);mapping=saved['artifact_sha256']
        for path,digest in mapping.items():check(file_hash(ROOT/path)==digest,'Preserved authority changed: '+path)
        preservation[relative]=dict(artifacts=len(mapping),passed=True,manifest_sha256=file_hash(ROOT/relative))
    input_files={};case_hashes={};receipt_scores={r['id']:r for r in analysis['score_receipts']}
    check(len(analysis['score_receipts'])==2149 and list(receipt_scores)==ids,'Score receipt quota/order differs')
    check(len(list((RUN/'attempts').glob('*.started.json')))==len(list((RUN/'attempts').glob('*.finished.json')))==2149,'Attempt quotas differ')
    benchmark=runner.read_sealed(AREA/'results/benchmark/plan.json')
    roles={'null_reference':0,'heldout_null':0,'alternative':0};timing_max=0.;positive_method_only=0
    for index,i in enumerate(ids):
        entry=entries[i];path=RUN/'cases'/(i+'.json');raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        check(digest==analysis['source_case_sha256'][i],'Case bytes differ from accepted analysis: '+i)
        case=json.loads(raw);case_hashes[i]=digest
        check(all(case.get(k)==v for k,v in runner.identity(plan,entry).items()),'Outer full case/input/seed/clock identity differs: '+i)
        check(case['status']=='complete' and not case.get('import_provenance'),'Incomplete/imported full case: '+i)
        check(0<=case['elapsed_seconds']<=plan['contract']['resources']['per_case_wall_seconds'][i],'Case cap differs: '+i)
        timing_max=max(timing_max,case['elapsed_seconds'])
        attempt=case['attempt_id'];check(any(attempt.startswith(s['session_id']+'_') for s in ledger['sessions']),'Case not produced by full generation: '+i)
        start=runner.read_sealed(RUN/'attempts'/(attempt+'.started.json'));finish=runner.read_sealed(RUN/'attempts'/(attempt+'.finished.json'))
        check(all(start.get(k)==v for k,v in runner.identity(plan,entry).items()) and finish['plan_id']==plan['plan_id'] and
              finish['id']==i and finish['status']=='complete' and finish['case_sha256']==digest,'Attempt/case binding differs: '+i)
        payload=case['payload'];binding=payload['input_binding'];base=payload['baseline_binding'];compact=payload['baseline_method']
        b=plan['benchmarks'][i];old_raw=(ROOT/b['path']).read_bytes();old=json.loads(old_raw);kk=old['payload']['methods'][0]
        check(b['path']==f'iteration_21/results/full_staged/cases/{i}.json' and hashlib.sha256(old_raw).hexdigest()==b['sha256']==analysis['source_baseline_sha256'][i]==old_analysis['source_case_sha256'][i],'Actual original21 floor bytes differ: '+i)
        check(old['plan_id']==base['plan_id']==b['plan_id']==prior['plan_id'] and old['id']==base['id']==i and old['catalogue_sha256']==entry['files']['catalogue.npz']['sha256'],'Baseline identity differs: '+i)
        check(base['saved_input_binding']=={k:kk['input_binding'][k] for k in ('arrays','law','clock_mode')} and
              binding['arrays']==kk['input_binding']['arrays'] and binding['law']==kk['input_binding']['law'] and
              binding['clock_mode']==entry['clock_mode'] and payload['feature_metadata']['clock_mode']==entry['clock_mode'],'Actual baseline/input projection differs: '+i)
        check(binding['contract_sha256']==runner.canonical_hash(plan['contract']),'Payload full contract differs: '+i)
        for phase in ('null','alternative'):
            check(compact[phase]['pars']==kk[phase]['pars'] and compact['saved_'+phase+'_nll']==kk[phase]['nll'],'Saved KK selected point differs: '+i)
        check(all(compact['saved_contrast'+str(o)]==kk['contrast'+str(o)] for o in (16,32)),'Saved KK contrast differs: '+i)
        check([m['id'] for m in payload['methods']]==['level_only'],'New method quota differs: '+i)
        score=payload['calibration_score'];rec=receipt_scores[i];method=payload['methods'][0]
        check(rec['statistic16']==score['statistic']==method['contrast16']['statistic'] and rec['numerical_envelope']==score['numerical_envelope'] and rec['statistic32']==method['contrast32']['statistic'],'Score receipt detached from case: '+i)
        check(rec['case_sha256']==digest and rec['baseline_sha256']==b['sha256'],'Receipt case hashes differ: '+i)
        role='null_reference' if index<999 else 'heldout_null' if index<1999 else 'alternative';check(rec['role']==role,'Score receipt role differs: '+i);roles[role]+=1
        for ref in entry['files'].values():
            check(input_files.setdefault(ref['path'],ref['sha256'])==ref['sha256'],'Inconsistent declared input file hash')
        if i in benchmark['ids']:check(digest!=file_hash(AREA/'results/benchmark/cases'/(i+'.json')),'Benchmark case imported as full case')
        positive_method_only+=1
    for path,digest in input_files.items():check(file_hash(ROOT/path)==digest,'Original input authority changed: '+path)
    # Sampling is declared by the already frozen benchmark; no outcome-based sample.
    # D owns the exhaustive all2149 numerical trace pass.
    import numpy as np
    for i in benchmark['ids']:
        case=runner.cached(plan,entries[i],RUN);binding=case['payload']['input_binding']
        with np.load(ROOT/entries[i]['files']['catalogue.npz']['path'],allow_pickle=False) as arrays:
            check(set(binding['arrays'])==set(arrays.files),'Sample array quota differs')
            for name in arrays.files:
                a=arrays[name];b=binding['arrays'][name]
                check(b['shape']==list(a.shape) and b['dtype']==a.dtype.str and b['sha256']==hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest(),'Sample actual array bytes differ: '+i+'/'+name)
    # Independent integer exceedances and envelope endpoints; no collector invocation.
    bank=[receipt_scores[i] for i in collector.REFERENCES];outcomes=analysis['outcomes']
    check([r['id'] for r in outcomes]==collector.QUERIES,'Query quota/order differs')
    for row in outcomes:
        rec=receipt_scores[row['id']];t=rec['statistic16'];epsilon=rec['numerical_envelope']
        k=sum(b['statistic16']>=t for b in bank)
        lo=sum(b['statistic16']-b['numerical_envelope']>=t+epsilon for b in bank)
        hi=sum(b['statistic16']+b['numerical_envelope']>=t-epsilon for b in bank)
        decision=True if hi<=49 else False if lo>=50 else None
        check(row['level_only']['rank']==(1+k)/1000 and row['level_only']['rank_sensitivity_range']==[(1+lo)/1000,(1+hi)/1000] and row['level_only']['reject'] is decision,'Independent rank/envelope arithmetic differs: '+row['id'])
        for name in ('known_known','background_estimated'):check(row[name]==old_rows[row['id']][name],'Old own-bank decision changed: '+row['id'])
    csv_rows=list(csv.DictReader((ANALYSIS/'outcomes.csv').open(newline='')));check(len(csv_rows)==1150,'CSV query quota differs')
    for actual,expected in zip(csv_rows,outcomes):
        check(actual['id']==expected['id'],'CSV identity/order differs')
        for method in collector.METHODS:
            for key in ('rank','reject','reason'):
                value=expected[method][key]
                check(actual[method+'_'+key]==('' if value is None else str(value)),'CSV field differs: '+actual['id'])
    counts={}
    for method in collector.METHODS:
        counts[method]={}
        for label,cohort in [('heldout_null_size',collector.CHECKS),('alternative_frequency',collector.ALTERNATIVES)]:
            by={row['id']:row for row in outcomes};decisions=[by[i][method]['reject'] for i in cohort]
            n=len(cohort);k=sum(v is True for v in decisions);u=sum(v is None for v in decisions)
            accepted=analysis['methods'][method][label]
            check(accepted['requested']==n and accepted['rejections']==k and accepted['unknown']==u,'Fixed denominator count differs')
            check(not u and accepted['conditional_frequency']==k/n,'Frequency/unknown withholding differs')
            counts[method][label]=dict(requested=n,rejections=k,unknown=u,frequency=k/n)
    # Every preservation-map entry is checked again after all read-only work.
    for relative in preservation:
        for path,digest in runner.read_sealed(ROOT/relative)['artifact_sha256'].items():check(file_hash(ROOT/path)==digest,'Audit changed preserved bytes: '+path)
    output=dict(role='A',passed=True,created_utc=runner.utc_now(),plan_id=plan['plan_id'],source_hashes=plan['sources'],
       analysis_path=ANALYSIS.relative_to(ROOT).as_posix(),analysis_summary_sha256=file_hash(ANALYSIS/'summary.json'),
       analysis_manifest_sha256=file_hash(ANALYSIS/'manifest.json'),analysis_signature=signature,
       runner_summary_sha256=file_hash(RUN/'summary.json'),runner_sessions_sha256=file_hash(RUN/'sessions.json'),
       plan_sha256=file_hash(RUN/'plan.json'),source_case_sha256=case_hashes,role_counts=roles,
       original_input_files_hashed=len(input_files),original21_floor_files_hashed=2149,all_case_outer_and_receipt_joins=positive_method_only,
       actual_array_hash_and_pure_numerical_validator_sample=benchmark['ids'],sample_selection='Already frozen12 benchmark IDs; not selected from full outcomes',
       session_count=len(ledger['sessions']),all_owned_generations_dead=True,all_worker_exitcodes_zero=True,charged_seconds=charge,
       measured_seconds=sum(s['measured_elapsed_seconds'] for s in ledger['sessions']),maximum_case_seconds=timing_max,
       publication_measured_seconds_before_manifest=manifest['measured_seconds_before_manifest'],publication_budget_seconds=600,
       publication_total_after_manifest_or_lock_release_not_independently_saved=True,closure_allowance_is_proved_bound=False,
       preservation=preservation,independent_new_rank_envelope_queries_checked=1150,unchanged_old_ownbank_decisions_checked=2300,
       publication_csv_cells_checked=1150*10,counts=counts,
       script_sha256=file_hash(Path(__file__)),elapsed_audit_seconds=time.perf_counter()-began,
       scientific_fits=0,likelihood_evaluations=0,GPU_initializations=0,new_simulations=0)
    runner.immutable(OUT,output)
    print(json.dumps({k:v for k,v in output.items() if k not in ('source_case_sha256','source_hashes')},indent=2))


if __name__=='__main__':main()
