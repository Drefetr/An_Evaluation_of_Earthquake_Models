"""Read-only input-source and attempt-generation field joins for all full cases."""
from pathlib import Path
import json
import sys
import time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_26/code'))
import run_level_calibration as r
import level_only_fit as fitter


def main():
    started=time.perf_counter();run=ROOT/'iteration_26/results/full_calibration'
    out=ROOT/'iteration_26/completion/results/A_generation_binding_validation.json'
    if out.exists():raise FileExistsError(out)
    plan=r.read_sealed(run/'plan.json');ledger=r.read_sealed(run/'sessions.json')
    expected=fitter.profile.authority.source_pins();sessions={s['session_id'] for s in ledger['sessions']}
    for i in plan['ids']:
        case=json.loads((run/'cases'/(i+'.json')).read_bytes());p=case['payload'];attempt=case['attempt_id']
        assert p['input_binding']['sources']==expected
        assert case['error'] is None and p['validation_reserve_seconds']==plan['contract']['resources']['validation_reserve_seconds'][i]
        assert attempt.rsplit('_'+i,1)[0] in sessions
        for suffix in ('started','finished'):
            record=r.read_sealed(run/'attempts'/(attempt+'.'+suffix+'.json'))
            assert record['attempt_id']==attempt and record['id']==i and record['plan_id']==plan['plan_id']
    r.immutable(out,dict(role='A',passed=True,plan_id=plan['plan_id'],cases=2149,input_source_pins=expected,
        attempt_records=4298,case_errors=0,validation_reserves_match=True,elapsed_seconds=time.perf_counter()-started,
        script_sha256=r.sha256(Path(__file__)),scope='Metadata source/attempt joins only; no fitter function, history construction, likelihood, optimizer or CUDA context invoked.'))
    print(dict(passed=True,cases=2149,attempt_records=4298,result_sha256=r.sha256(out)))


if __name__=='__main__':main()
