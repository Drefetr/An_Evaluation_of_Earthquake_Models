"""All-case pure numerical/provenance audit; no fitting, GPU or rank arithmetic."""
from pathlib import Path
from datetime import datetime
import collections,csv,io,json,math,sys,time

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_26/code'))
import run_level_calibration as runner
from checkpoint_io import read_sealed,sealed_json,atomic_bytes,sha256,canonical_hash,utc_now
AREA=ROOT/'iteration_26';RUN=AREA/'results/full_calibration'
ANALYSIS=AREA/'results/analysis/2026-10-17T125009077299_0000'
OUT=AREA/'completion/results';REV=AREA/'completion/reviews'


def need(ok,message):
    if not ok:raise AssertionError(message)


def write_csv(path,rows):
    need(not path.exists(),'Refusing existing completion artifact '+str(path))
    stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    atomic_bytes(path,stream.getvalue().encode())


def main():
    began=time.perf_counter();plan=read_sealed(RUN/'plan.json');runner.guard(plan)
    summary=read_sealed(RUN/'summary.json');ledger=read_sealed(RUN/'sessions.json')
    analysis=read_sealed(ANALYSIS/'summary.json');manifest=read_sealed(ANALYSIS/'manifest.json')
    need(summary['plan_id']==ledger['plan_id']==analysis['plan_id']==manifest['plan_id']==plan['plan_id'],'Plan lineage differs')
    need(plan['ids']==runner.IDS and summary['states']==dict.fromkeys(runner.IDS,'complete') and summary['counts']=={'complete':2149},'Full cohort not complete')
    need(summary['all_complete'] and summary['terminal_complete'] and summary['sessions_closed'] and not summary['active'] and not summary['active_ids'],'Not closed terminal completion')
    need(not (RUN/'fatal.json').exists(),'Retained fatal barrier')
    need(len(ledger['sessions'])==1,'Unexpected worker session count')
    session=ledger['sessions'][0]
    need(session['closed'] and session['stage']=='closed' and session['reason']=='complete' and session['worker_exitcode']==0 and
         session['active_id'] is None and session['active_attempt_id'] is None and not session.get('error') and not session.get('worker_error'),'Session failure/active work')
    need(session['elapsed_seconds']==session['measured_elapsed_seconds']+1.==summary['charged_seconds'] and session['closure_allowance_seconds']==1. and session['elapsed_seconds']<=28800,'Full wall accounting differs')
    current=runner.lifetime().process_identity(session['worker_identity']['pid']);need(current!=session['worker_identity'],'Owned process token still live')
    for name,digest in manifest['files'].items():need(sha256(ANALYSIS/name)==digest,'Accepted analysis artifact changed: '+name)
    for name in ('plan.json','summary.json','sessions.json'):need(sha256(RUN/name)==sha256(ANALYSIS/('runner_'+name)),'Accepted copied runner metadata differs')
    need(analysis['source_hashes']==plan['sources'] and analysis['full_run_charged_seconds']==session['elapsed_seconds'],'Analysis source/resource join differs')
    need(analysis['analysis_budget_seconds']==600. and analysis['analysis_measured_seconds_before_final_publication']<600. and
         manifest['measured_seconds_before_manifest']<600. and manifest['closure_allowance_seconds']==1. and
         manifest['closure_allowance_is_measured_or_proven_bound'] is False,'Analysis timing policy differs')
    for path,digest in plan['sources'].items():need(sha256(ROOT/path)==sha256(RUN/'source_snapshots'/path)==digest,'Live/archived source changed: '+path)
    need(set(analysis['source_case_sha256'])==set(manifest['source_case_sha256'])==set(plan['ids']),'Accepted case identity quota differs')
    need(set(analysis['source_baseline_sha256'])==set(manifest['source_baseline_sha256'])==set(plan['ids']),'Accepted baseline quota differs')
    receipts={r['id']:r for r in analysis['score_receipts']};need(len(analysis['score_receipts'])==len(receipts)==2149,'Score receipt quota differs')
    starts={p.name[:-len('.started.json')]:read_sealed(p) for p in (RUN/'attempts').glob('*.started.json')}
    ends={p.name[:-len('.finished.json')]:read_sealed(p) for p in (RUN/'attempts').glob('*.finished.json')}
    need(len(starts)==len(ends)==2149 and starts.keys()==ends.keys() and len(list((RUN/'attempts').iterdir()))==4298,'Attempt quota differs')
    need(collections.Counter(s['id'] for s in starts.values())==collections.Counter(plan['ids']),'Repeated/missing attempt')
    need({p.stem for p in (RUN/'cases').iterdir()}==set(plan['ids']),'Extra/missing case authority')
    counts=collections.Counter();maxima=collections.defaultdict(float);minima=dict(raw_T16=math.inf,raw_T32=math.inf,epsilon=math.inf,n_events=math.inf)
    clocks=collections.Counter();selected_bounds=collections.Counter();root_bounds=collections.Counter();roles={};case_rows=[];solver_rows=[];partdirs=set();case_hashes={}
    role_ids=plan['contract']['future_inference'];rolemap={i:role for role,key in [('reference','reference_ids'),('heldout_null','heldout_null_ids'),('alternative','alternative_ids')] for i in role_ids[key]}
    for index,e in enumerate(plan['entries'],1):
        identifier=e['id'];case=runner.cached(plan,e,RUN)  # exactly one full pure validate_result pass plus actual baseline joins
        need(case is not None and case['status']=='complete' and case['error'] is None,'Unresolved actual case '+identifier)
        aid=case['attempt_id'];need(aid==session['session_id']+'_'+identifier,'Attempt generation differs')
        start,finish=starts[aid],ends[aid];identity=runner.identity(plan,e)
        need(all(case[k]==start[k]==v for k,v in identity.items()),'Case/start provenance differs')
        digest=sha256(RUN/'cases'/(identifier+'.json'));case_hashes[identifier]=digest
        need(finish['status']=='complete' and finish['plan_id']==plan['plan_id'] and finish['id']==identifier and finish['attempt_id']==aid and finish['case_sha256']==digest,'Finished case binding differs')
        need(analysis['source_case_sha256'][identifier]==manifest['source_case_sha256'][identifier]==digest,'Accepted analysis case differs')
        baseline_sha=plan['benchmarks'][identifier]['sha256']
        need(analysis['source_baseline_sha256'][identifier]==manifest['source_baseline_sha256'][identifier]==baseline_sha,'Accepted uniform floor differs')
        cap=plan['contract']['resources']['per_case_wall_seconds'][identifier];interval=(datetime.fromisoformat(case['completed_utc'])-datetime.fromisoformat(start['started_utc'])).total_seconds()
        need(0<=case['elapsed_seconds']<=cap and 0<=interval<=cap,'Per-case cap exceeded')
        p=case['payload'];m=p['methods'][0];old=p['baseline_method'];role=rolemap[identifier];rc=roles.setdefault(role,collections.Counter())
        n_events=p['input_binding']['arrays']['times']['shape'][0];clocks[e['clock_mode']]+=1
        need(p['feature_metadata']['clock_mode']==e['clock_mode'],'Clock binding differs')
        cm={r['label']:r for r in p['old_backend_controls']};cp={r['label']:r for r in p['cpu32_controls']}
        deltas=[abs(cp['new_level_only_'+phase]['independent32_nll']-cm['new_level_only_'+phase]['old_backend16_nll']) for phase in ('null','alternative')]
        epsilon=max(1e-6,2*sum(deltas));t16=m['contrast16']['statistic'];t32=m['contrast32']['statistic']
        receipt=receipts[identifier]
        need(receipt['statistic16']==t16 and receipt['statistic32']==t32 and receipt['numerical_envelope']==epsilon and
             receipt['case_sha256']==digest and receipt['baseline_sha256']==baseline_sha,'Accepted receipt scalar/source mismatch')
        expected_role={'reference':'null_reference','heldout_null':'heldout_null','alternative':'alternative'}[role]
        need(receipt['role']==expected_role,'Accepted role differs')
        need(p['calibration_score']['statistic']==t16 and p['calibration_score']['numerical_envelope']==epsilon,'Recorded score/envelope differs')
        local=dict(old_backend_profile_difference=max(r['absolute_difference'] for r in cm.values()),CPU32_profile_difference=max(r['absolute_difference'] for r in cp.values()),
                   selected_original16_CPU32_difference=max(deltas),saved_baseline_difference=max(r.get('saved_absolute_difference',0.) for r in list(cm.values())+list(cp.values())),
                   direct_order_difference=max(abs(item['contrast16']['statistic']-item['contrast32']['statistic']) for item in (m,old)),
                   direct_subtraction_difference=max(abs(item['contrast'+str(o)]['direct_minus_subtraction']) for item in (m,old) for o in (16,32)),
                   identity_residual=max(abs(r['residual']) for r in p['common_backend_identities']))
        for k,v in local.items():maxima[k]=max(maxima[k],v)
        for k,v in [('raw_T16',t16),('raw_T32',t32),('epsilon',epsilon),('n_events',n_events)]:minima[k]=min(minima[k],v);maxima[k]=max(maxima[k],v)
        for k,v in [('case_wall_seconds',case['elapsed_seconds']),('parent_start_to_commit_seconds',interval),('peak_Torch_allocated_bytes',p['cuda_metrics']['peak_allocated_bytes']),('nodes16',p['feature_metadata']['nodes16']),('nodes32',p['feature_metadata']['nodes32'])]:maxima[k]=max(maxima[k],v)
        local_bounds=collections.Counter()
        for phase in ('null','alternative'):
            a,d,n,eta=m[phase]['pars']
            if a==-12.:local_bounds[phase+'_a_lower']+=1
            if a==0.:local_bounds[phase+'_a_upper']+=1
            if phase=='alternative' and eta==0.:local_bounds['alternative_eta_lower']+=1
            if phase=='alternative' and eta==3.:local_bounds['alternative_eta_upper']+=1
        selected_bounds.update(local_bounds);rc.update(local_bounds)
        for point in p['evaluations']:root_bounds[str(point['amplitude']['boundary'])]+=1
        parts=list((RUN/'partials'/identifier/aid).glob('*.json'));need(len(parts)==case['partial_records'],'Partial count differs')
        partdirs.add(RUN/'partials'/identifier/aid)
        for path in parts:
            value=read_sealed(path);need(value['attempt_id']==aid and all(value[k]==v for k,v in identity.items()),'Partial provenance/seal differs')
        additions=dict(cases=1,solver_records=len(p['search_records']),amplitude_profiles=len(p['evaluations']),queries=len(p['queries']),
                       CUDA16_point_controls=len(cm),CPU32_selected_controls=len(cp),eta_profile_points=len(m['eta_profile']),direct_contrasts=4,identity_rows=2,partial_records=len(parts))
        counts.update(additions);rc.update(additions)
        counts['negative_T16']+=int(t16<0);counts['empty_histories']+=int(n_events==0)
        for r in p['search_records']:
            solver_rows.append(dict(id=identifier,role=role,label=r['label'],index=r['index'],success=r['success'],status=r['status'],nit=r['nit'],nfev=r['nfev'],eta=r['candidate']['pars'][3],nll=r['nll'],elapsed_seconds=r['elapsed_seconds']))
        case_rows.append(dict(id=identifier,role=role,status='complete',clock_mode=e['clock_mode'],n_events=n_events,case_wall_seconds=case['elapsed_seconds'],
                              parent_start_to_commit_seconds=interval,cap_seconds=cap,solver_records=len(p['search_records']),amplitude_profiles=len(p['evaluations']),queries=len(p['queries']),
                              eta_profile_points=len(m['eta_profile']),null_a=m['null']['pars'][0],alternative_a=m['alternative']['pars'][0],alternative_eta=m['alternative']['pars'][3],
                              raw_T16=t16,raw_T32=t32,numerical_envelope=epsilon,peak_Torch_allocated_bytes=p['cuda_metrics']['peak_allocated_bytes'],
                              partial_records=len(parts),case_sha256=digest,baseline_sha256=baseline_sha,**local))
        if index%250==0:print('D validated '+str(index)+'/2149',flush=True)
    need({p.parent for p in (RUN/'partials').rglob('*.json')}==partdirs,'Orphan additional partial attempt')
    unknown={name:{cohort:r[cohort]['unknown'] for cohort in ('heldout_null_size','alternative_frequency')} for name,r in analysis['methods'].items()}
    need(all(v==0 for r in unknown.values() for v in r.values()),'Accepted analysis unknowns present')
    OUT.mkdir(parents=True,exist_ok=True);REV.mkdir(parents=True,exist_ok=True)
    numerical=dict(passed=True,scope='All2149 pure numerical/provenance validation and saved scalar aggregation; no new likelihood or rank arithmetic',
        plan_id=plan['plan_id'],counts=dict(counts),by_role={k:dict(v) for k,v in roles.items()},clock_counts=dict(clocks),selected_boundary_counts=dict(selected_bounds),
        amplitude_root_boundary_counts=dict(root_bounds),minima=minima,maxima=dict(maxima),failed_cases=0,censored_cases=0,execution_unknown_cases=0,accepted_analysis_unknown_counts=unknown,
        all2149_pure_validator_passed=True,accepted_score_receipts_matched=2149,case_hash_map_sha256=canonical_hash(case_hashes),
        new_fits=False,new_likelihood_evaluations=False,new_rank_calculations=False,GPU_initialized=False)
    npath=OUT/'D_numerical_summary.json';need(not npath.exists(),'Refusing numerical summary overwrite');sealed_json(npath,numerical)
    write_csv(OUT/'D_case_controls.csv',case_rows);write_csv(OUT/'D_solver_records.csv',solver_rows)
    pins=['iteration_26/results/full_calibration/plan.json','iteration_26/results/full_calibration/summary.json','iteration_26/results/full_calibration/sessions.json',
          'iteration_26/logs/runtime_source_freeze.json','iteration_26/reviews/benchmark_resource_gate.json',
          'iteration_26/results/analysis/2026-10-17T125009077299_0000/summary.json','iteration_26/results/analysis/2026-10-17T125009077299_0000/manifest.json',
          'iteration_26/completion/results/D_numerical_summary.json','iteration_26/completion/results/D_case_controls.csv','iteration_26/completion/results/D_solver_records.csv',
          Path(__file__).relative_to(ROOT).as_posix()]
    review=dict(role='D',stage='full_completion',review_utc=utc_now(),passed=True,decision='PASS_numerical_lifecycle_source_and_resource_completion; statistical_table_crossreview_reserved_to_C',
        plan_id=plan['plan_id'],source_hashes=plan['sources'],all2149_pure_validator_passed=True,counts=dict(counts),failed_cases=0,censored_cases=0,unknown_execution_cases=0,
        cases_started=2149,cases_finished=2149,partial_records_checked=counts['partial_records'],no_recorded_orphan_attempts=True,all_case_caps_respected=True,
        live_archived_runtime_sources_checked=len(plan['sources']),actual_uniform21_baseline_joins_checked=2149,accepted_case_and_baseline_hashes_checked=2149,
        accepted_scalar_receipts_checked=2149,analysis_files_byte_verified=len(manifest['files']),
        process_death=dict(recorded_identity=session['worker_identity'],current_identity=current,matching_creation_token_alive=False),
        resource=dict(measured_full_parent_seconds=session['measured_elapsed_seconds'],full_closure_operational_allowance_seconds=1.,charged_full_parent_seconds=session['elapsed_seconds'],full_cap_seconds=28800,
            sum_case_wall_seconds=sum(r['case_wall_seconds'] for r in case_rows),analysis_measured_before_final_publication_seconds=analysis['analysis_measured_seconds_before_final_publication'],
            analysis_measured_before_manifest_seconds=manifest['measured_seconds_before_manifest'],analysis_cap_seconds=600.,analysis_closure_operational_allowance_seconds=1.,
            scope='Parent wall, not GPU-seconds. Final-write allowances are operational reservations, not measurements/proven latency bounds. Stored analysis timings end before final publication/manifest; accepted collector also checks through-publication runtime.'),
        evidence_sha256={p:sha256(ROOT/p) for p in pins},audit_elapsed_seconds=time.perf_counter()-began,
        no_new_fits=True,no_new_likelihood_evaluations=True,no_new_rank_calculations=True,GPU_initialized=False,
        limitations=['The pure validator checks saved arithmetic and metadata; this does not independently recompute history geometry or certify global optimization',
                     'No absence claim is made about unrecorded machine-wide work','Reused-data conditional interval interpretation and paired statistical outcomes are reserved to independent C review'])
    path=REV/'D_completion_review.json';need(not path.exists(),'Refusing completion review overwrite');sealed_json(path,review)
    print(json.dumps(dict(passed=True,counts=dict(counts),clocks=dict(clocks),bounds=dict(selected_bounds),root_bounds=dict(root_bounds),minima=minima,maxima=dict(maxima),resource=review['resource'],
                         audit_seconds=review['audit_elapsed_seconds'],review_sha256=sha256(path),outputs={p:sha256(ROOT/p) for p in pins if '/completion/results/' in p}),indent=2))


if __name__=='__main__':main()
