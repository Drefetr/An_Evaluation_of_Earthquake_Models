"""Independent saved-score statistical audit. No fitter or collector is imported."""
from pathlib import Path
import csv
import io
import math
import sys
import time
from collections import Counter
from scipy.optimize import brentq
from scipy.stats import binom

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
AREA = ROOT / 'iteration_26'
ANALYSIS = AREA / 'results/analysis/2026-10-17T125009077299_0000'
SUMMARY_SHA = '0c46b5756ef92965263112738baea86914da2e95d4aa00609c5931a750540aca'
OLD = ROOT / 'iteration_21/results/analysis/2026-10-17T004327174461_0000/summary.json'
OLD_SHA = '56da11135e920e0ced7ee5173d0bfe064a3802ecaf566d6ba7b6d11b75123823'
REFS = [f'null_{i:04d}' for i in range(999)]
CHECKS = [f'null_{i:04d}' for i in range(999, 1999)]
ALTS = [f'new_r{i:03d}' for i in range(150)]
IDS = REFS + CHECKS + ALTS
QUERIES = CHECKS + ALTS
METHODS = ['level_only', 'known_known', 'background_estimated']
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_json, read_sealed, sha256, canonical_hash, sealed_json, atomic_bytes, utc_now


def require(condition, message):
    if not condition:
        raise ValueError(message)


def classify(value, radius, bank):
    """Literal integer exceedance counting, retaining every tied reference."""
    require(len(bank) == 999 and math.isfinite(value) and
            math.isfinite(radius) and radius >= 1e-6, 'Invalid complete score bank')
    central = sum(t >= value for t, e in bank)
    tied = sum(t == value for t, e in bank)
    guaranteed = sum(t - e >= value + radius for t, e in bank)
    possible = sum(t + e >= value - radius for t, e in bank)
    require(0 <= guaranteed <= central <= possible <= 999, 'Invalid interval counts')
    decision = True if possible <= 49 else False if guaranteed >= 50 else None
    return dict(rank=(central + 1) / 1000,
                rank_sensitivity_range=[(guaranteed + 1) / 1000, (possible + 1) / 1000],
                reject=decision,
                reason='stable_reject' if decision is True else
                       'stable_nonreject' if decision is False else 'ordering_sensitive'), dict(
                exceedances=central, exact_ties=tied, guaranteed_exceedances=guaranteed,
                possible_exceedances=possible)


def cp_by_binomial_tail(k, n):
    """Invert binomial tails, independently of the frozen beta-quantile code."""
    require(type(k) is int and type(n) is int and 0 <= k <= n and n > 0, 'Invalid binomial count')
    lower = 0. if k == 0 else brentq(lambda p: binom.sf(k - 1, n, p) - .025,
                                    0., 1., xtol=2e-14, rtol=1e-14)
    upper = 1. if k == n else brentq(lambda p: binom.cdf(k, n, p) - .025,
                                    0., 1., xtol=2e-14, rtol=1e-14)
    return [lower, upper]


def tally(values):
    n = len(values)
    require(n > 0 and all(x is None or type(x) is bool for x in values), 'Invalid binary/unknown tally')
    k = sum(x is True for x in values); u = sum(x is None for x in values)
    result = dict(requested=n, rejections=k, resolved=n-u, unknown=u,
                  conditional_frequency=None, monte_carlo_se=None,
                  exact_binomial_95_interval=None, accounting_bounds=[k/n, (k+u)/n])
    if not u:
        result.update(conditional_frequency=k/n, monte_carlo_se=math.sqrt(k*(n-k)/n**3),
                      exact_binomial_95_interval=cp_by_binomial_tail(k, n))
    return result


def paired(values, first, second):
    n = len(values); require(n > 0, 'Empty paired cohort')
    table = dict(neither=0, first_only=0, second_only=0, both=0, unknown=0)
    differences = []; lo = []; hi = []
    for a, b in values:
        require(all(x is None or type(x) is bool for x in (a, b)), 'Invalid paired decision')
        lo.append((int(a) if a is not None else 0) - (int(b) if b is not None else 1))
        hi.append((int(a) if a is not None else 1) - (int(b) if b is not None else 0))
        if a is None or b is None:
            table['unknown'] += 1
        else:
            table['both' if a and b else 'first_only' if a else 'second_only' if b else 'neither'] += 1
            differences.append(int(a)-int(b))
    complete = table['unknown'] == 0
    mean = sum(differences)/n if complete else None
    se = (math.sqrt(sum((x-mean)**2 for x in differences)/(n-1)/n)
          if complete and n > 1 else None)
    return dict(requested=n, complete=complete, first_method=first, second_method=second,
                table=table, first_minus_second=mean, descriptive_MCSE=se,
                accounting_bounds=[sum(lo)/n, sum(hi)/n])


def compare(expected, actual, context):
    if isinstance(expected, dict):
        require(set(expected) == set(actual), context + ': keys')
        for k in expected:
            compare(expected[k], actual[k], context + '/' + k)
    elif isinstance(expected, list):
        require(len(expected) == len(actual), context + ': length')
        for k, (a, b) in enumerate(zip(expected, actual)):
            compare(a, b, context + '/' + str(k))
    elif type(expected) is float:
        require(type(actual) in (float, int) and math.isfinite(actual) and
                abs(expected-actual) <= 2e-12, context + ': float')
    else:
        require(type(expected) is type(actual) and expected == actual, context + ': value')


def audit():
    started = time.perf_counter()
    require(sha256(ANALYSIS/'summary.json') == SUMMARY_SHA and sha256(OLD) == OLD_SHA,
            'Accepted source analysis changed')
    saved = read_sealed(ANALYSIS/'summary.json'); manifest = read_sealed(ANALYSIS/'manifest.json')
    plan = read_sealed(AREA/'results/full_calibration/plan.json')
    protocol = read_json(AREA/'configs/full_protocol_frozen.json')
    old = read_sealed(OLD)
    require(saved['plan_id'] == manifest['plan_id'] == plan['plan_id'] and
            saved['source_hashes'] == plan['sources'] and protocol == plan['contract'] and
            saved['config_sha256'] == sha256(AREA/'configs/full_protocol_frozen.json'),
            'Frozen plan/protocol/source identity differs')
    require(all(sha256(ROOT/p) == h for p, h in plan['sources'].items()), 'Changed frozen numerical source')
    require(plan['ids'] == IDS and [e['id'] for e in plan['entries']] == IDS and
            protocol['future_inference'] == dict(reference_ids=REFS, heldout_null_ids=CHECKS, alternative_ids=ALTS),
            'Fixed role/order quota differs')
    require(all(sha256(ANALYSIS/name) == h for name, h in manifest['files'].items()),
            'Published file hash differs')
    signature = canonical_hash({k: saved[k] for k in (
        'plan_id', 'config_sha256', 'source_case_sha256', 'source_baseline_sha256',
        'prior_own_bank_analysis', 'summarizer_sha256')})
    require(signature == saved['analysis_signature'] == manifest['analysis_signature'],
            'Analysis signature differs')
    require(saved['source_case_sha256'] == manifest['source_case_sha256'] and
            saved['source_baseline_sha256'] == manifest['source_baseline_sha256'] ==
            old['source_case_sha256'], 'Case/floor hash maps differ')
    terminal = read_sealed(ANALYSIS/'runner_summary.json')
    ledger = read_sealed(ANALYSIS/'runner_sessions.json')
    require(terminal['states'] == dict.fromkeys(IDS, 'complete') and
            terminal['counts'] == {'complete': 2149} and terminal['terminal_complete'] is True and
            terminal['all_complete'] is True and terminal['sessions_closed'] is True and
            terminal['active'] is False and terminal['active_ids'] == [] and
            all(s['closed'] for s in ledger['sessions']), 'Calibration terminal barrier missing')
    receipts = saved['score_receipts']
    require(len(receipts) == 2149 and [r['id'] for r in receipts] == IDS, 'Score receipt quota/order differs')
    values = {}
    for i, row in enumerate(receipts):
        role = 'null_reference' if i < 999 else 'heldout_null' if i < 1999 else 'alternative'
        require(row['role'] == role and row['case_sha256'] == saved['source_case_sha256'][row['id']] and
                row['baseline_sha256'] == saved['source_baseline_sha256'][row['id']] and
                all(math.isfinite(row[k]) for k in ('statistic16','statistic32','numerical_envelope')) and
                min(row['statistic16'],row['statistic32']) >= -1e-4 and
                abs(row['statistic16']-row['statistic32']) < 1e-4 and
                row['numerical_envelope'] >= 1e-6, 'Invalid receipt/identity/order gate')
        values[row['id']] = (row['statistic16'], row['numerical_envelope'])
    bank = [values[i] for i in REFS]
    accepted = {r['id']: r for r in saved['outcomes']}
    old_by = {r['id']: r for r in old['outcomes']}
    require([r['id'] for r in saved['outcomes']] == QUERIES and
            [r['id'] for r in old['outcomes']] == QUERIES, 'Query publication quota/order differs')
    decisions = {}; details = []
    for i in QUERIES:
        result, counts = classify(*values[i], bank)
        require(result == accepted[i]['level_only'], 'Independent level decision/range differs: ' + i)
        decisions[i] = dict(level_only=result)
        for name in METHODS[1:]:
            require(accepted[i][name] == old_by[i][name], 'Frozen old own-bank decision differs: ' + i)
            decisions[i][name] = old_by[i][name]
        details.append(dict(id=i, **counts, **result))
    methods = {}
    for name in METHODS:
        methods[name] = dict(reference_requested=999, reference_resolved=999, reference_complete=True,
                            heldout_null_size=tally([decisions[i][name]['reject'] for i in CHECKS]),
                            alternative_frequency=tally([decisions[i][name]['reject'] for i in ALTS]))
    contrasts = {}
    for second in METHODS[1:]:
        contrasts['level_only_minus_'+second] = {
            cohort: paired([(decisions[i]['level_only']['reject'], decisions[i][second]['reject'])
                             for i in ids], 'level_only', second)
            for cohort, ids in [('heldout_null_size', CHECKS), ('alternative_frequency', ALTS)]}
    compare(methods, saved['methods'], 'methods')
    compare(contrasts, saved['paired'], 'paired')
    with (ANALYSIS/'outcomes.csv').open(newline='', encoding='utf-8') as stream:
        csv_rows = list(csv.DictReader(stream))
    require(len(csv_rows) == 1150 and [r['id'] for r in csv_rows] == QUERIES, 'CSV quota/order differs')
    for row in csv_rows:
        for name in METHODS:
            d = decisions[row['id']][name]
            require(float(row[name+'_rank']) == d['rank'] and
                    row[name+'_reject'] == ('' if d['reject'] is None else str(d['reject'])) and
                    row[name+'_reason'] == d['reason'], 'CSV decision differs')
    counts = Counter(v[0] for v in bank)
    return dict(schema_version=1, role='C', passed=True, created_utc=utc_now(),
                plan_id=plan['plan_id'], source_hashes=plan['sources'], analysis_signature=signature,
                analysis_path=ANALYSIS.relative_to(ROOT).as_posix(),
                source_bindings={p.relative_to(ROOT).as_posix(): sha256(p) for p in (
                    ANALYSIS/'summary.json', ANALYSIS/'manifest.json', ANALYSIS/'outcomes.csv',
                    AREA/'configs/full_protocol_frozen.json', AREA/'reports/C_calibration_contract.md',
                    OLD, Path(__file__))},
                receipt_count=2149, query_count=1150, every_new_decision_and_range_matches=True,
                every_old_KK_BG_decision_matches_accepted21=True,
                every_tally_CP_and_paired_field_matches=True, publication_csv_matches=True,
                methods=methods, paired=contrasts,
                numerical_rank_diagnostics=dict(reference_count=999, reference_unique_scores=len(counts),
                    reference_zero_scores=counts.get(0.,0), queries_with_exact_reference_ties=sum(r['exact_ties']>0 for r in details),
                    queries_with_nonpoint_sensitivity_ranges=sum(r['rank_sensitivity_range'][0]!=r['rank_sensitivity_range'][1] for r in details),
                    ordering_sensitive_unknown_queries=sum(r['reject'] is None for r in details),
                    envelope_min=min(v[1] for v in values.values()), envelope_max=max(v[1] for v in values.values())),
                scope='Independent rank/tie/envelope-range, binomial-tail CP and paired saved-score arithmetic only; no likelihood evaluation, history fit, CUDA, simulation or new campaign.',
                numerical_radius_derivation_scope='Radii read from accepted2149score receipts; D independently validates full selected-NLL epsilon derivation and raw numerical controls.',
                CP_implementation='Independent binomial upper/lower tail inversion by Brent; not the frozen beta-quantile implementation.',
                max_summary_float_comparison_tolerance=2e-12,
                elapsed_seconds=time.perf_counter()-started,
                query_details=details)


def main():
    result = audit()
    output = AREA/'completion/results/C_calibration_audit.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists(), 'Refusing existing C audit overwrite')
    sealed_json(output, result)
    print(dict(passed=True, receipt_count=result['receipt_count'], query_count=result['query_count'],
               diagnostics=result['numerical_rank_diagnostics'], result_sha256=sha256(output),
               elapsed_seconds=result['elapsed_seconds']))


if __name__ == '__main__':
    main()
