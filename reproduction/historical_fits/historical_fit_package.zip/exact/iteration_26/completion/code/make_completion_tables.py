"""Generate descriptive tables/figure from accepted saved calibration; no fits or rank changes."""
from pathlib import Path
import argparse
import csv
import io
import json
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
AREA=ROOT/'iteration_26/completion'
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sealed_json,sha256,atomic_bytes,utc_now
SOURCE=ROOT/'iteration_26/results/analysis/2026-10-17T125009077299_0000/summary.json'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();out=args.output_dir.resolve()
    if any((out/name).exists() for name in ['method_comparison.csv','paired_comparison.csv','summary.json','calibrated_comparison.png','calibrated_comparison.svg']):
        raise FileExistsError('Refusing existing generated artifacts; choose a new output directory')
    out.mkdir(parents=True,exist_ok=True)
    data=read_sealed(SOURCE)
    order=['known_known','level_only','background_estimated']
    labels=['Level and trend supplied','Level estimated; trend supplied','Level and trend estimated']
    rows=[]
    for name,label in zip(order,labels):
        for cohort in ['heldout_null_size','alternative_frequency']:
            v=data['methods'][name][cohort]
            rows.append(dict(procedure=name,label=label,cohort=cohort,requested=v['requested'],rejections=v['rejections'],unknown=v['unknown'],
                             conditional_frequency=v['conditional_frequency'],nominal_CP95_low=v['exact_binomial_95_interval'][0],
                             nominal_CP95_high=v['exact_binomial_95_interval'][1],descriptive_MCSE=v['monte_carlo_se']))
    stream=io.StringIO(newline='');w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    atomic_bytes(out/'method_comparison.csv',stream.getvalue().encode())
    paired=[]
    for comparison,cohorts in data['paired'].items():
        for cohort,v in cohorts.items():
            paired.append(dict(comparison=comparison,cohort=cohort,requested=v['requested'],**v['table'],
                               frequency_difference=v['first_minus_second'],descriptive_paired_MCSE=v['descriptive_MCSE']))
    stream=io.StringIO(newline='');w=csv.DictWriter(stream,fieldnames=list(paired[0]));w.writeheader();w.writerows(paired)
    atomic_bytes(out/'paired_comparison.csv',stream.getvalue().encode())
    sealed_json(out/'summary.json',dict(created_utc=utc_now(),source_path=SOURCE.relative_to(ROOT).as_posix(),source_sha256=sha256(SOURCE),
                analysis_signature=data['analysis_signature'],plan_id=data['plan_id'],methods=data['methods'],paired=data['paired'],
                full_run_charged_seconds=data['full_run_charged_seconds'],limitations=data['limitations'],
                source_status='Saved frozen calibration output; completion cross-reviews reported separately'))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    fig,axes=plt.subplots(1,2,figsize=(12,5.4),gridspec_kw={'width_ratios':[1,1]})
    x=np.arange(3);colors=['#3b6e9d','#21866b','#bd7530'];ticks=['Level + trend\nsupplied','Level estimated\nTrend supplied','Level + trend\nestimated']
    for ax,cohort,title in zip(axes,['heldout_null_size','alternative_frequency'],['Held-out null rejection','Alternative detection']):
        vals=[data['methods'][m][cohort] for m in order];y=np.array([100*v['conditional_frequency'] for v in vals]);ci=np.array([v['exact_binomial_95_interval'] for v in vals])*100
        ax.bar(x,y,color=colors,width=.6,alpha=.9)
        ax.errorbar(x,y,yerr=np.vstack([y-ci[:,0],ci[:,1]-y]),fmt='none',ecolor='#222222',capsize=5,lw=1.4)
        for xx,yy,v,upper in zip(x,y,vals,ci[:,1]):ax.text(xx,upper+.16 if cohort=='heldout_null_size' else upper+1.5,f"{v['rejections']}/{v['requested']}",ha='center',va='bottom',fontsize=10)
        ax.set_xticks(x,ticks,fontsize=10);ax.set_title(title,fontsize=13,pad=14);ax.set_ylabel('Percent');ax.set_axisbelow(True);ax.grid(axis='y',alpha=.18)
        ax.spines[['top','right']].set_visible(False)
        if cohort=='heldout_null_size':ax.set_ylim(0,8.5);ax.axhline(5,color='#555555',linestyle='--',lw=1,label='Nominal 5%');ax.legend(frameon=False,loc='upper right')
        else:ax.set_ylim(0,110)
    fig.suptitle('Level-only matched-null calibration on the same saved histories',fontsize=15,y=.99)
    fig.text(.5,.015,'Whiskers: nominal conditional 95% binomial intervals. Reused-data exploratory comparison; not selection-adjusted.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.065,1,.95])
    fig.savefig(out/'calibrated_comparison.png',dpi=170)
    fig.savefig(out/'calibrated_comparison.svg')
    plt.close(fig)
    print(json.dumps(dict(tables_written=len(rows),paired_rows=len(paired),source_sha256=sha256(SOURCE),figure=str(out/'calibrated_comparison.png'))))


if __name__=='__main__':main()
