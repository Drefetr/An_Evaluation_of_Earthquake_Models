# Completion status and exact continuation

Full level-only calibration COMPLETE. No scientific job remains running. There is no need to rerun the fit.

- 2,149/2,149 fresh fits complete: 999 null references,1000 held-out null queries,150 alternatives.
- 0 failed/censored/missing fits; 0 numerical-envelope-unknown decisions.
- New level-only: 46/1000 null rejections; 123/150 alternative detections.
- Inherited supplied-background KK: 49/1000 null; 150/150 alternatives.
- Inherited level-plus-trend BG: 44/1000 null; 68/150 alternatives.
- Level versus BG paired alternatives: 62 both, 61 only level, 6 only BG, 21 neither.
- One closed zero-exit owned worker generation; no resume or repair required.
- Charged full parent time 15,610.504871 seconds (4h20m); saved analysis 133.50 seconds before its final manifest write. Post-lock elapsed was not durably logged.
- Accepted analysis signature: 7f1ca18d066eff9064ecad4c9e9a919f8ebeb2a873a923293604c7cb9d82148c.

All current completion reports and evidence are here. The parent iteration 26 STATUS remains its frozen preparation snapshot by design. Source/input/result preservation is checked by the completion verifier and snapshot/manifests.

The single next question is the missing trend-only own-null calibration, which would supply level and estimate trend plus inhibition under the same inherited law. It is proposed only; no configuration, extra simulations or fitting campaign has been launched. A new bounded protocol/resource review should precede it. Confirmatory claims require an appropriately reserved or new evaluation set rather than relabelling this reused cohort.
