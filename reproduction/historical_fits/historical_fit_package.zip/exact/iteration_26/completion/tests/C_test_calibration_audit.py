"""Literal tests of C's independent completion arithmetic; no scientific records."""
from pathlib import Path
import importlib.util
import math
import sys
import unittest
from scipy.stats import binom

sys.dont_write_bytecode = True
path=Path(__file__).resolve().parents[1]/'code/C_recompute_calibration.py'
spec=importlib.util.spec_from_file_location('_C26_independent_completion_literal',path)
c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)


class CompletionArithmeticTests(unittest.TestCase):
    def test_integer_boundary_and_conservative_ties(self):
        for k,decision in [(49,True),(50,False)]:
            out,detail=c.classify(1.,1e-6,[(2.,1e-6)]*k+[(0.,1e-6)]*(999-k))
            self.assertEqual(out['rank'],(1+k)/1000);self.assertIs(out['reject'],decision)
        out,detail=c.classify(0.,1e-6,[(0.,1e-6)]*999)
        self.assertEqual(out['rank'],1.);self.assertEqual(detail['exact_ties'],999)
        self.assertIsNone(out['reject'])

    def test_touching_intervals_include_equality(self):
        out,detail=c.classify(0.,.25,[(.5,.25)]*999)
        self.assertEqual(detail['guaranteed_exceedances'],999)
        self.assertEqual(out['rank_sensitivity_range'],[1.,1.])
        out,detail=c.classify(1.,.1,[(2.,.1)]*49+[(1.,.1)]+[(0.,.1)]*949)
        self.assertEqual(out['rank_sensitivity_range'],[.05,.051]);self.assertIsNone(out['reject'])

    def test_incomplete_nonfinite_radius_and_negative_raw(self):
        with self.assertRaises(ValueError):c.classify(0.,1e-6,[(0.,1e-6)]*998)
        with self.assertRaises(ValueError):c.classify(float('nan'),1e-6,[(0.,1e-6)]*999)
        with self.assertRaises(ValueError):c.classify(0.,0.,[(0.,1e-6)]*999)
        out,detail=c.classify(-1e-7,1e-6,[(0.,1e-6)]*999)
        self.assertEqual(out['rank'],1.)

    def test_cp_closed_endpoints_and_interior_tail_equations(self):
        self.assertAlmostEqual(c.cp_by_binomial_tail(150,150)[0],.025**(1/150),places=12)
        self.assertEqual(c.cp_by_binomial_tail(150,150)[1],1.)
        self.assertEqual(c.cp_by_binomial_tail(0,1000)[0],0.)
        self.assertAlmostEqual(c.cp_by_binomial_tail(0,1000)[1],1-.025**(1/1000),places=12)
        lo,hi=c.cp_by_binomial_tail(46,1000)
        self.assertAlmostEqual(binom.sf(45,1000,lo),.025,places=11)
        self.assertAlmostEqual(binom.cdf(46,1000,hi),.025,places=11)

    def test_fixed_denominator_unknown_and_paired_direction(self):
        tally=c.tally([True,False,None]);self.assertEqual(tally['accounting_bounds'],[1/3,2/3])
        self.assertIsNone(tally['conditional_frequency']);self.assertIsNone(tally['exact_binomial_95_interval'])
        p=c.paired([(True,False),(True,True),(False,False),(None,True)],'level','BG')
        self.assertEqual(p['table'],dict(neither=1,first_only=1,second_only=0,both=1,unknown=1))
        self.assertEqual(p['accounting_bounds'],[0.,.25]);self.assertIsNone(p['first_minus_second'])

    def test_complete_paired_sample_variance(self):
        p=c.paired([(True,False),(True,True),(False,False),(False,False)],'level','BG')
        self.assertEqual(p['first_minus_second'],.25);self.assertEqual(p['descriptive_MCSE'],.25)
        self.assertEqual(p['table']['first_only'],1);self.assertEqual(p['table']['second_only'],0)
        with self.assertRaises(ValueError):c.compare({'n':1},{'n':True},'type')


if __name__=='__main__':
    unittest.main(verbosity=2)
