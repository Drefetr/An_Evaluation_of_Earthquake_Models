"""Read-only source/provenance and manual full-launch gate verifier."""
from pathlib import Path
import json
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sha256
from run_level_calibration import guard,AREA


def main():
    manifest=read_sealed(AREA/'logs/preparation_manifest.json');errors=[]
    for label,records in [('prepared',manifest['artifact_sha256']),('prior',read_sealed(AREA/'logs/prior_preservation_before.json')['artifact_sha256'])]:
        for path,h in records.items():
            if not (ROOT/path).is_file() or sha256(ROOT/path)!=h:errors.append(label+':'+path)
    plan=read_sealed(AREA/'results/full_calibration/plan.json');guard(plan)
    summary=read_sealed(AREA/'results/full_calibration/summary.json')
    print(json.dumps(dict(passed=not errors,errors=errors,prepared_artifacts=len(manifest['artifact_sha256']),
                         preserved_prior_paths=len(read_sealed(AREA/'logs/prior_preservation_before.json')['artifact_sha256']),
                         plan_id=plan['plan_id'],counts=summary['counts'],sessions_closed=summary['sessions_closed'],
                         execution_started=(AREA/'results/full_calibration/execution_started.json').exists(),read_only=True),indent=2))
    return 0 if not errors else 2


if __name__=='__main__':raise SystemExit(main())
