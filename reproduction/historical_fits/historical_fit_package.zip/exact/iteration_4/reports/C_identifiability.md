# C — Statistical identifiability and discrimination audit

Prepared 15 October 2026 by a coordinating-task subagent. This is an internal analytical review, not independent academic refereeing. Write ownership: this report, `configs/experiment_contract.md`, `manuscript_revisions/C_diagnostics.tex`, and later `reviews/C_numerical_review.md`. D owns all shared implementation and tests. Inputs remain unchanged.

## Decision-oriented findings

- **P05 survives with explicit scope:** at exact zero feedback, finite original loading/initial-stress parameters, common independent fresh marks, and fixed triggering/background parameters, every stress kernel gives the same observed marked-event law. This is structural non-identifiability, not an empirical conclusion about a near-zero rounded estimate.
- **P06 survives with a refinement:** the singular limit retains a deterministic kernel-shaped trend. Nonzero q requires rho to diverge; nonzero p also requires initial stress to diverge if p = b X0. Fixed finite X0 forces p to zero. The supplied material does not supply the unrounded estimates or profiles needed to reproduce M03.
- **P07 and P08 survive:** additive inhibition has a background-fraction masking bound, and the proposed predictable score is correct. Background/trigger nuisance fitting can remove much of its signal. Infinite Var(g) does not by itself imply infinite score information when triggering is present.
- **New restricted result:** a finite-horizon Kullback--Leibler bound links this masking to an upper bound on testing power. It is a deliberately conservative sufficient bound, not a power calculation for the pilot or a nonlinear ergodicity theorem. The coordinator's information sufficient condition applies to the rounded exponents despite their infinite raw second moments.
- **E01 is narrowed prospectively:** C approved a six-row exact finite-mixture feasibility pilot before outcomes, with all kernels on its fitted grid, equal background flexibility and a small full-search bootstrap. Nine calibration draws per null example cannot resolve a 5% test. Shared-restriction calibration remains deferred.

## Sources and provenance

The original model is manuscript Chapter 9 equations (9.1)--(9.2), printed pp. 25--26 (PDF positions 26--27); fresh marks and finite modes appear in Definition 9.3/Assumption 9.4, printed p. 27. The likelihood and pre-event conventions are in Chapter 7, printed pp. 20--21. The reported fits and singular trend limit are manuscript Chapter 10, particularly Section 10.3, printed p. 34. These are manuscript-reported findings, not reproduced estimates. Working-note Sections 4--4.1 supply P05/P06; brief Sections 6 and 8 supply P07/P08 and the later experiment proposal. `reports/coordinator_score_information.md` contains a new coordinator derivation audited below. `configs/experiment_contract.md` is a new pre-outcome statistical specification, not executed evidence. Actual numerical review is recorded separately.

## 1. Exact observed-law equality and the physical closure

Let Phi_s be a nonnegative normalized relaxation kernel, A_s(t) = integral_0^t Phi_s(u)du, G_s(t) = sum_{Ti<t} g(Mi)Phi_s(t-Ti), and H_e(t) = sum_{Ti<t} kappa(Mi)h_e(t-Ti). The original physical family is

\[
\lambda(t)=\exp\{a+b[X_0\Phi_s(t)+\rho A_s(t)-G_s(t)]\}+H_e(t).
\]

For b = 0 with X0 and rho finite, this becomes exp(a)+H_e for every history. The common conditional mark law is F and does not depend on the latent state. Consequently the predictable marked-event intensity measure, lambda(t)dt F(dm), and all successive waiting-time/mark conditional laws coincide across choices of Phi_s. Under the usual non-explosive construction this yields equality of the complete observed marked-catalogue laws on every finite horizon, and therefore on the generated infinite-horizon sigma field. The latent stress laws can differ radically while these observed laws coincide. A hypothetical state-dependent mark law would change this conclusion; that is the different Chapter 6 model, not the Chapter 9 setting.

For b > 0 set p = b X0, q = b rho, r = b. Then

\[
\log\mu(t)=a+p\Phi_s(t)+qA_s(t)-rG_s(t).
\]

Permitting r = 0 and q nonzero adds a closure point with deterministic kernel-shaped trend and no event-dependent inhibition. Reaching it requires rho = q/r to diverge. Retaining nonzero p additionally requires X0 = p/r to diverge; with fixed finite X0 one obtains p = 0. Positivity constraints inherited from rho must be preserved (q >= 0 if rho >= 0). Thus exact finite-parameter b = 0 and this singular trend-only closure are different nulls. The displayed rounded b = 0 in the manuscript is insufficient to choose between them. A trend fit can identify aspects of Phi_s through deterministic loading without identifying earthquake-induced stress inhibition or the material equality h_e = -Phi_s'.

## 2. The diagnostic family and the instantaneous bound

To isolate inhibition, the experiment deliberately uses

\[
\lambda_r(t)=\mu(t)e^{-rG_s(t)}+H_e(t),\qquad \mu(t)=e^{B(t;\zeta)},\quad r\geq0.
\]

Its independently specified background must have the same allowed B family across candidates. It is not a reparameterization of the full physical loading law. On a fixed history define lambda0 = mu+H and pB = mu/lambda0. Direct subtraction gives

\[
\delta_r(t)=\frac{\lambda_0(t)-\lambda_r(t)}{\lambda_0(t)}
=p_B(t)[1-e^{-rG_s(t)}]\leq p_B(t).
\]

This bound is sharp as rG grows with pB held fixed. It is an instantaneous comparison on the same history: the r = 0 comparison path is not a counterfactual simulation with a different realized event history. Inhibiting immigrants changes future triggering descendants; the formula does not bound that long-run causal effect. Nor does pB equal 1-n at every time. Under a stationary uninhibited normalized Hawkes model, 1-n is an average immigrant fraction; that identity is not a pointwise statement and cannot simply be imported into the varying-background inhibited family.

There is an additional fixed-lag masking effect. Add a single event with magnitude excess m to an otherwise fixed history, fix a positive lag u with Phi_s(u)>0 and h_e(u)>0, and suppose g(m)=exp(gamma m), kappa(m)=A exp(a_k m). At the null,

\[
p_BG_s\sim \frac{\mu\Phi_s(u)}{Ah_e(u)}e^{(\gamma-a_k)m},
\qquad p_B\sim \frac{\mu}{Ah_e(u)}e^{-a_km}.
\]

For a_k > gamma the single-event contribution to the inhibition score therefore tends to zero at this fixed lag as magnitude tends to infinity, even though its stress drop grows. The rounded exponents satisfy 1.97 > .75 log(10) = 1.72694. This is neither an integrated-future-information statement nor a reason to remove extreme catalogues: recovery time, background level, overlapping events and kernel tails also matter.

## 3. Score, predictable evaluation and nuisance projection

With the common mark density omitted, ell(r) = sum log lambda_r(Ti) - integral_0^T lambda_r(t)dt. Every G(Ti) and H(Ti) excludes event i. At r = 0,

\[
U_s=\ell'(0)
=-\sum_{T_i\leq T}p_B(T_i)G_s(T_i)
 +\int_0^T\mu(t)G_s(t)dt
=\int_0^T f_s(t)\{dN(t)-\lambda_0(t)dt\},
\quad f_s=-p_BG_s.
\]

Pathwise differentiation is legitimate for a fixed finite catalogue, finite marks and the finite-mixture pilot's bounded numerical histories. Martingale expectation or variance identities require integrability separately. If the score is square integrable, its predictable variance is

\[
I_{ss}=E_0\int_0^T \lambda_0f_s^2dt
=E_0\int_0^T\frac{\mu(t)^2G_s(t)^2}{\mu(t)+H_e(t)}dt.
\]

For nuisance parameter zeta, its score integrand is f_zeta = (partial_zeta lambda0)/lambda0. In the pilot these include pB for log intercept, pB(2t/T-1) for slope, and Hunit/lambda0 for n. Trigger-scale changes contribute (partial H)/lambda0. If productivity and the mark law are also estimated, their additional score directions must be included; fixing them in this pilot makes the discrimination problem easier than the manuscript's estimation problem.

Under finite score second moments define the Hilbert inner product <f,h> = E_0 integral lambda0 f h dt. The residual after projecting f_s on the closed span of nuisance integrands is the efficient score integrand. In finite nonsingular notation,

\[
I_{s\mid\zeta}=I_{ss}-I_{s\zeta}I_{\zeta\zeta}^{-1}I_{\zeta s}\leq I_{ss}.
\]

Use the projection, or a generalized inverse with its range condition, when nuisance scores are redundant. Near-zero efficient information means the stress-depletion pattern is nearly explained by fitted background/trigger directions. Smooth slowly varying depletion can confound background trends; post-event depletion can confound triggering scale/productivity. These are quantitative projection statements, not universal proofs of non-identifiability away from r = 0. Information about an independently parameterized stress kernel theta_s is zero at r = 0 because partial_theta_s lambda = -r mu exp(-rG) partial_theta_s G. An O(r^2) information claim away from zero needs a justified uniform moment bound for the relevant derivative kernel.

## 4. Heavy tails: a sufficient finite-information condition

The coordinator's bound is correct with its explicit assumptions. Assume empty history, bounded deterministic mu, n = E kappa < 1, kappa>0 almost surely, E(g^2/kappa)<infinity, and

\[
C_T=\int_0^T\frac{\Phi_s(u)^2}{h_e(u)}du<\infty.
\]

On a nonempty history weighted Cauchy--Schwarz implies

\[
\frac{G_s(t)^2}{\mu(t)+H_e(t)}\leq\frac{G_s(t)^2}{H_e(t)}
\leq \sum_{T_i<t}\frac{g(M_i)^2\Phi_s(t-T_i)^2}{\kappa(M_i)h_e(t-T_i)}.
\]

On the empty history set both sides to zero. Tonelli, the fresh-mark compensator, and domination by the uninhibited Hawkes process of immigration rate mu_sup give, for any r >= 0,

\[
E_r\int_0^T\frac{\mu^2G_s^2}{\mu+H_e}dt
\leq \mu_{\rm sup}^2 E(g^2/\kappa) C_T E_rN(T)
\leq K_T:=\frac{\mu_{\rm sup}^3 E(g^2/\kappa)C_TT}{1-n}<\infty.
\]

Positive finite mixtures have positive h_e on [0,T], so C_T is finite for every fixed T. Exact Mittag--Leffler h_e is positive for u>0 and behaves like a positive multiple of u^(alpha-1) at zero, so its reciprocal causes no finite-horizon endpoint divergence. This says nothing uniform as T tends to infinity or as productivity tends to zero. Under the rounded manuscript transforms, 2gamma-a_k = 1.48387764 < beta = 2.494, so E(g^2/kappa) is finite for A>0 although E(g^2) and E(kappa^2) are infinite. By contrast, with kappa = 0 and a positive Poisson background, E(G_s(t)^2)=infinity for t>0 whenever the kernel is nonzero on a positive-measure portion of (0,t); then the null r-score has infinite variance.

Finite I_ss alone is not a Gaussian score theorem, a differentiability-in-quadratic-mean proof, or boundary likelihood-ratio asymptotics. In particular the pathwise second derivative at zero contains separate terms integral mu G^2 and sum pB(1-pB)G^2. Their expectations may each be infinite even when the martingale-score variance is finite. One must not interchange expectation with differentiation or subtract infinity from infinity to identify expected curvature. This is an extra reason to calibrate the actual fitted procedure rather than invoke a generic information matrix.

## 5. A restricted nonasymptotic testing bound

**Proposition C.1 (finite-horizon visibility bound).** Consider the diagnostic family with the same bounded deterministic mu, g, kappa, stress/trigger kernels and fresh mark law across r >= 0, empty history, nonnegative finite marks, normalized triggering kernel, E kappa = n < 1. Let P_r denote its observed marked-path law on [0,T]. Then

\[
\begin{split}
D_{\rm KL}(P_r\Vert P_0)
&=E_r\int_0^T\lambda_0(t)\{[1-\delta_r(t)]\log[1-\delta_r(t)]+\delta_r(t)\}dt\\
&\leq E_r\int_0^T\frac{\mu(t)^2}{\mu(t)+H_e(t)}\min\{r^2G_s(t)^2,1\}dt
\leq\int_0^T\mu(t)dt.
\end{split}
\]

If the assumptions of Section 4 hold, D_KL(P_r||P_0) <= r^2 K_T. Thus, for any possibly randomized test phi with values in [0,1],

\[
E_r\phi\leq E_0\phi+\min\{1,r\sqrt{K_T/2}\}.
\]

**Proof.** Common mark densities cancel in the path likelihood. Both intensities are positive on finite histories; Hawkes domination supplies finite event counts. More specifically, the stopped likelihood ratio of P_r relative to P_0 is the product of lambda_r/lambda0 over events times exp(integral(lambda0-lambda_r)). Each product factor is at most one, and lambda0-lambda_r <= mu. Thus the local likelihood martingale is bounded by exp(integral_0^T mu), hence is a true uniformly integrable martingale. The non-explosive construction identifies its changed law with P_r. The event-log term is integrable under P_r because lambda_r log(lambda0/lambda_r) <= lambda0-lambda_r <= mu; the integral term obeys the same bound. This justifies the entropy identity after substituting lambda_r = lambda0(1-delta), without subtracting undefined expectations. For 0 <= delta <= 1, f(delta) = (1-delta)log(1-delta)+delta satisfies f(delta) <= delta^2. For example, writing v = 1-delta, the difference delta^2-f(delta) = v(v-1-log v) >= 0, with endpoints understood by continuity. Also 1-exp(-rG) <= min(rG,1). This proves the first bound; mu^2/(mu+H) <= mu proves finiteness without second moments. Section 4 gives the r^2 K_T bound. Pinsker's inequality then bounds total variation, and a [0,1]-valued test's expectation difference is at most total variation. The entropy justification and bound were checked in B's cross-review, communicated 15 October 2026.

Even when E(g^2/kappa) fails, P_r approaches P_0 in total variation as r tends down to zero on each fixed finite horizon. One common dominating marked Hawkes construction contains the events of every fixed-r inhibited construction; consequently G_r <= G_dom. The entropy bound is at most E integral mu(t) min(r^2 G_dom(t)^2,1)dt, which tends to zero by bounded convergence since the dominating path has finitely many finite-valued marks on [0,T]. This supplies no rate and no long-horizon uniformity.

The bound is an upper bound on distinguishability with all nuisance parameters fixed; estimating nuisance cannot manufacture information. It can be numerically very loose. It does not establish a necessary threshold for detectability, does not identify a shared relation, and does not turn the feasibility pilot into a power study. Under comparable mu and H, background masking enters quadratically through mu^2/(mu+H), making the link to the score explicit.

**Proposition C.2 (first-moment kernel discrimination bound).** This is a new coordinator derivation, checked and written here by C. Fix the same bounded deterministic background, normalized nonnegative triggering kernel h_e, mark law, and productivity in two diagnostic models; assume m1 = E g < infinity, n = E kappa < 1 and empty history. For two nonnegative continuous relaxation kernels Phi1, Phi2 on [0,T], with the same fixed r >= 0,

\[
\|P_{r,\Phi_1}-P_{r,\Phi_2}\|_{\rm TV}
\leq \min\left\{1,\frac{r\mu_{\rm sup}^2m_1}{1-n}
\int_0^T(T-u)|\Phi_1(u)-\Phi_2(u)|du\right\}.
\]

In particular compare Phi2 = 0, interpreted as no inhibition rather than a normalized relaxation kernel, to obtain a first-moment O(r) bound between inhibition and the null. Comparing a shared Phi1 with a different stress kernel Phi2 while keeping the triggering kernel fixed gives a genuine nonlinear finite-horizon restriction-discrimination bound. It does not permit changing h_e at the same time without an additional term.

**Proof.** Construct the two processes with a common marked Poisson random measure and stop at the first unmatched event sigma. Before sigma they share every event and mark. The absolute intensity difference is at most r mu_sup sum_{Ti<t} g(Mi)|Phi1(t-Ti)-Phi2(t-Ti)| because x maps to exp(-rx) is r-Lipschitz on x >= 0. Both event sets before sigma are contained in one uninhibited Hawkes process with immigration mu_sup, fresh common marks and kernel h_e. Its mean event density obeys E lambda_dom(s) <= mu_sup/(1-n), by summing the nonnegative renewal series. Fresh-mark compensation and Tonelli therefore bound the expected integrated unmatched-event rate by the displayed double-integral expression. The coupling inequality gives total variation <= P(sigma <= T), bounded by this compensator. This argument uses only first moments and retains all nonlinear inhibition feedback up to first separation. Each [0,1]-valued test's power-minus-size is bounded by the same quantity. Constants may again be very conservative.

**Proposition C.3 (active-inhibition structural identifiability in a restricted marked family).** This is a new coordinator argument checked and written here by C. Let the diagnostic model have empty history, unknown positive continuous deterministic background mu on [0,T], g(q)>0 continuous and known, fresh marks Q with support [0,infinity) and a positive density, and kappa(q)=n f(q) with n>=0 and known positive continuous f(q) tending to infinity, normalized by E f(Q)=1. Assume r >= 0, nonnegative continuous relaxation Phi_s on [0,T] with Phi_s(0)=1, and a nonnegative normalized triggering density h_e that is locally integrable at zero and continuous for u>0. Models are non-explosive with finite mean event counts. Equality of their observed marked laws implies:

1. mu is identical on [0,T];
2. n h_e(u) is identical for every 0<u<T;
3. r is identical, and if r>0 then Phi_s is identical on [0,T].

For the exact three-mode scaled family used in the pilot, n>0 also identifies n and the triggering scale e individually. Its relaxation scale is injective since -Phi_s'(0)=(sum w_j/c_j)/s. Consequently, within that restricted family, r>0 and n>0 make the shared restriction structurally identifiable in the idealized full-law sense. This does not guarantee useful finite-catalogue information.

**Proof.** Before the first event the intensity is mu(t), so its survival law identifies the integrated mu and hence the continuous mu itself. Equality of marked laws then identifies the conditional intensity along histories with exactly one event at s and mark q, and no subsequent event before t. Local integrability of h_e ensures a positive conditional no-further-event survival for each finite q. Positive joint first-event/mark/no-further-event densities give equality for almost every such (s,q,t); continuity of the parameterized functions extends it to s<t and q>=0. Along these histories the hazard is

\[
\mu(t)\exp[-r g(q)\Phi_s(t-s)]+n f(q)h_e(t-s).
\]

Divide by f(q) and let q tend to infinity: the first term tends to zero because it is bounded by mu(t), so n h_e(t-s) is identified. Subtract this identical triggering term from the original hazard. The remaining positive background gives r g(q) Phi_s(u) identical after taking logarithms; divide by known positive g(q). Taking u down to zero and using Phi_s(0)=1 identifies r. If r>0 it identifies Phi_s(u) on the observation window. For the finite-mixture h_e(u)=sum_j w_j(c_j e)^(-1) exp[-u/(c_j e)], its right-hand values at zero satisfy -h_e'(0)/h_e(0) = (sum w_j/c_j^2)/(e sum w_j/c_j). The ratio of derivatives of the identified n h_e therefore identifies e when n>0; its value at zero then identifies n.

If r=0 the stress kernel remains unidentified; if n=0 the triggering scale is unidentified. Arbitrary kernel tails beyond T are not identified by a T-window law. Unknown mark transforms, state-dependent marks, random/unrestricted history-dependent backgrounds, unobserved prehistory, or physical loading constraints are outside this proposition. The proof exploits arbitrarily rare high marks across the entire probability law; it supplies no finite-sample power guarantee. Numerical truncation of marks would remove that particular proof and needs a separate identifiability argument. Near-zero r, the finite-horizon bounds and nuisance projection explain how structural identifiability can coexist with practical invisibility.

## 6. Calibration and what each candidate means

Null r = 0 represents background variation plus triggering; the shared model adds inhibition and imposes a common relaxation shape; separate inhibition adds inhibition without imposing the common shape. A fully multiplicative model exp(-rG)(mu+H) would inhibit all triggering as well and represents a different mechanism; it is not silently substituted. The physical trend-only closure from Section 1 is a separate deterministic-background comparator for an original-parameterization study, not evidence for inhibition.

Testing feedback with sup over stress kernels is nonregular: r >= 0 is on the boundary and theta_s is unidentified under the null. Fixed-kernel one-sided boundary formulas do not calibrate a search over theta_s and nuisance parameters. Davies (1977), Section 1 and abstract, treats the general nuisance-only-under-alternative obstruction; its particular Gaussian-process approximations are not automatically valid for this model. Self and Liang (1987), Section 1, explicitly require differentiability and a positive definite finite information limit and identifiability. Their boundary examples cannot be transferred merely because this model also has a boundary. Primary-source metadata: [Davies, Biometrika 64(2), 247--254, DOI 10.1093/biomet/64.2.247](https://academic.oup.com/biomet/article-abstract/64/2/247/384826); [Self and Liang, JASA 82(398), 605--610, DOI 10.1080/01621459.1987.10478472, article text](https://pages.stat.wisc.edu/~larget/Stat998/Fall2015/Self-Liang-1987.pdf). Retrieved 15 October 2026.

For a developed calibration: fit the entire null, simulate new fixed-window marked catalogues from that fitted null, rerun all null and alternative nuisance fits and stress/trigger kernel searches, and compare the observed global statistic with that complete-procedure bootstrap distribution. Calibration validity in a singular heavy-tailed model is itself a research question; sensitivity over plausible null parameter values and finite-sample simulation assessment are needed. Plug-in bootstrap is a proposed procedure, not a theorem. For the shared restriction, simulate under the fitted shared family and refit both shared and separate searches, including r = 0 possibilities and optimizer boundaries. Close-to-zero r may create another weak-identification problem. Calibrate that separately; failure to reject shared equality does not support it unless meaningful alternatives are demonstrably distinguishable.

The exact approved feasibility design, known nuisance restrictions, resource gate, seeds protocol, fit/predictive outcomes and failure criteria are in `configs/experiment_contract.md`. Its six rows vary three generating families, two mark laws, n and background direction with acknowledged confounding. Nine bootstrap draws on each of two pre-specified null examples give minimum attainable p = .1 and no 5% rejection claim. Neither error-rate certification, interval coverage nor shared-restriction testing is completed by that small calibration. Report descriptive full-window and chronological scores with uncertainty in their limited Monte Carlo context.

## 7. Claim dispositions and next work

| Claim | Provenance | Validation disposition | Remaining condition or missing evidence |
|---|---|---|---|
| P05 | Prior conversational deduction | Analytically confirmed in stated fresh-mark finite-nuisance null | Do not transfer to state-dependent marks or singular trend closure |
| P06 | Prior conversational deduction | Confirmed with p/X0 refinement | Need original estimates/profiles to interpret the actual optimizer |
| P07 | Later conversational deduction | Exact fixed-history identity | Not long-run causal suppression |
| P08 | Later conversational deduction | Score confirmed; finite-information sufficient condition added | Whole-search calibration, nuisance projection, asymptotic regularity unresolved |
| M03 | Manuscript report | Not reproduced | No original code/catalogue/logs/unrounded estimates supplied |
| E01 | Proposed experiment | Prospective statistical contract approved | Execution and independent numerical review recorded separately |
| C01 | New derivation | Restricted finite-horizon KL/testing bound checked by B and A, including genuine likelihood and entropy integrability | No novelty determination; sufficient bounds may be vacuous |
| C02 | New coordinator derivation | First-moment nonlinear kernel-discrimination coupling bound, written/audited by C and checked by A | Constants loose; fixed triggering/background only |
| C03 | New coordinator derivation | Restricted active-inhibition observed-law identifiability proof, written/audited by C; A cross-review required and supplied explicit positivity/integrability assumptions | Rare-mark proof is not practical power; final cross-review report retained separately |

The most useful statistical next step after the bounded pilot is a factorial sensitivity design with background fraction, mark tail and kernel separation independently varied, using validated chronological scores and enough full-procedure calibration draws to assess the intended level. Before any real-data claim, recover the frozen catalogue/original fit artifacts or define a separately timestamped catalogue and reproduce the complete estimator with its background and kernel-search choices.

## 8. Execution closure

The corrected finite-mixture pilot subsequently completed 150/150 catalogues (25 per row) and 18/18 full-procedure bootstrap draws. C's actual numerical cross-review is `reviews/C_numerical_review.md`, with separately executed direct holdout/mean-ODE checks and saved-output audits. Meaningful shared inhibition gives weak median heldout improvement in these settings; deliberately separated kernels yield stronger descriptive full-window differences, with modest or absent additional heldout gain in the finite-control row. This is a bounded synthetic result under known beta, fixed productivity exponent, coarse kernels and incompletely crossed factors. It does not reproduce M03, calibrate a shared-restriction test, establish 5%/80% performance, or negate the corrected active-inhibition structural-identifiability proposition.
