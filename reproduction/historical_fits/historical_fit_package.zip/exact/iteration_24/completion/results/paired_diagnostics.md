| Case | Procedure | Null NLL gain | Alternative NLL gain | Direct GLR change |
|---|---|---:|---:|---:|
| null_0000 | known_known | 0 | 0 | 0 |
| null_0000 | background_estimated | 4.54747e-13 | 1.68257e-11 | 3.30265e-11 |
| null_0841 | known_known | 0 | 0 | 0 |
| null_0841 | background_estimated | 0 | 1.40972e-11 | 2.80203e-11 |
| null_1292 | known_known | 0 | 0 | 0 |
| null_1292 | background_estimated | 2.91038e-11 | 1.94996e-08 | 3.89682e-08 |
| new_r000 | known_known | 0 | 0 | 0 |
| new_r000 | background_estimated | 2.27374e-13 | 1.20508e-11 | 2.38689e-11 |
| new_r076 | known_known | 0 | 7.27596e-12 | 5.68434e-13 |
| new_r076 | background_estimated | 7.27596e-12 | 2.98314e-10 | 5.81526e-10 |
| null_1107 | known_known | 0 | 0 | 0 |
| null_1107 | background_estimated | 0 | 0 | 0 |
| null_1166 | known_known | 0 | 0 | 0 |
| null_1166 | background_estimated | 4.54747e-13 | 4.54747e-13 | 0 |
| new_r100 | known_known | 0 | 2.43745e-10 | 4.83055e-10 |
| new_r100 | background_estimated | 0 | 0 | 0 |
| null_1345 | known_known | 0 | 0 | 0 |
| null_1345 | background_estimated | 0 | 7.07223e-09 | 1.41453e-08 |
| new_r140 | known_known | 0 | 0 | 0 |
| new_r140 | background_estimated | 0 | 2.95586e-11 | 5.8936e-11 |
