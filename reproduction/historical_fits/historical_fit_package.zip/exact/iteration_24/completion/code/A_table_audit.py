"""Cross-check all descriptive table cells against raw saved records; read only."""
from pathlib import Path
import csv
import gc
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_sealed, sha256


def audit():
    run = ROOT / 'iteration_24/results/profile_audit'
    results = ROOT / 'iteration_24/completion/results'
    summary = read_sealed(results / 'summary.json')
    plan = read_sealed(run / 'plan.json')
    assert summary['plan_id'] == plan['plan_id']
    tables = {}
    for name, key in [('paired_diagnostics', lambda r: (r['id'], r['method'])),
                      ('case_summary', lambda r: r['id']),
                      ('solver_records', lambda r: (r['id'], r['label'], r['index'])),
                      ('eta_profiles', lambda r: (r['id'], float(r['eta'])))]:
        with (results / (name + '.csv')).open(newline='', encoding='utf-8') as stream:
            rows = list(csv.DictReader(stream))
        tables[name] = {key(row): row for row in rows}
        assert len(rows) == len(tables[name])
    cells = 0

    def check(actual, expected):
        nonlocal cells
        assert set(actual) == set(expected)
        for key, value in expected.items():
            if isinstance(value, bool):
                assert actual[key] == str(value), key
            elif isinstance(value, int):
                assert int(actual[key]) == value, key
            elif isinstance(value, float):
                assert float(actual[key]) == value, key
            elif value is None:
                assert actual[key] == '', key
            else:
                assert actual[key] == value, key
            cells += 1

    solver_count = profile_count = 0
    for case_id in plan['ids']:
        path = run / 'cases' / (case_id + '.json')
        assert sha256(path) == summary['case_sha256'][case_id]
        with path.open(encoding='utf-8') as stream:
            case = json.load(stream)
        payload = case['payload']
        controls = [c for group in ('controls', 'old_primary_controls', 'old32_controls', 'validation') for c in payload[group]]
        expected_case = dict(id=case_id, status=case['status'], seed=case['seed'], clock_mode=case['clock_mode'],
                             events=payload['evaluations'][0]['amplitude']['n_events'], elapsed_seconds=case['elapsed_seconds'],
                             solver_count=len(payload['search_records']),
                             powell_count=sum(record['label'] == 'background_alternative_Powell' for record in payload['search_records']),
                             value_control_count=len(controls), maximum_value_control_difference=max(c['absolute_difference'] for c in controls),
                             amplitude_evaluations=len(payload['evaluations']), peak_cuda_bytes=payload['cuda_metrics']['peak_allocated_bytes'],
                             case_sha256=sha256(path))
        check(tables['case_summary'][case_id], expected_case)
        for method in payload['methods']:
            old = method['old_selected']
            null_gain = old['null']['nll'] - method['null']['nll']
            alt_gain = old['alternative']['nll'] - method['alternative']['nll']
            shift = method['contrast32']['statistic'] - method['old_contrast32']['statistic']
            expected = dict(id=case_id, method=method['id'], old_null_NLL=old['null']['nll'], new_null_NLL=method['null']['nll'],
                            null_NLL_gain=null_gain, old_alternative_NLL=old['alternative']['nll'], new_alternative_NLL=method['alternative']['nll'],
                            alternative_NLL_gain=alt_gain, old_GLR32=method['old_contrast32']['statistic'], new_GLR32=method['contrast32']['statistic'],
                            GLR_shift32=shift, old_eta=old['alternative']['pars'][3], new_eta=method['alternative']['pars'][3],
                            material_NLL=max(null_gain, alt_gain) >= .001, material_statistic=abs(shift) >= .1)
            for phase in ('null', 'alternative'):
                for index, label in ((0, 'a'), (1, 'd')):
                    expected['old_' + phase + '_' + label] = old[phase]['pars'][index]
                    expected['new_' + phase + '_' + label] = method[phase]['pars'][index]
            check(tables['paired_diagnostics'][(case_id, method['id'])], expected)
            if method['id'] == 'background_estimated':
                for curve in method['eta_profile']:
                    point = curve['selected']
                    check(tables['eta_profiles'][(case_id, curve['eta'])],
                          dict(id=case_id, eta=curve['eta'], NLL=point['nll'], a=point['pars'][0], d=point['pars'][1]))
                    profile_count += 1
        for record in payload['search_records']:
            expected = dict(id=case_id, **{key: record.get(key) for key in ('label', 'index', 'success', 'status', 'nit', 'nfev', 'nll', 'elapsed_seconds')})
            check(tables['solver_records'][(case_id, record['label'], str(record['index']))], expected)
            solver_count += 1
        del case, payload
        gc.collect()
    assert len(tables['paired_diagnostics']) == 20
    assert len(tables['case_summary']) == 10
    assert len(tables['solver_records']) == solver_count == 114
    assert len(tables['eta_profiles']) == profile_count == 110
    failure = read_sealed(results / 'failure_ledger.json')
    assert failure['completed_cases'] == failure['expected_cases'] == 10 and not failure['failures']
    return dict(passed=True, exact_checked_table_cells=cells, paired_rows=20, cases=10, solver_rows=solver_count,
                eta_profile_rows=profile_count,
                artifact_sha256={path.relative_to(ROOT).as_posix(): sha256(path) for path in sorted(results.iterdir()) if path.is_file()})


if __name__ == '__main__':
    print(json.dumps(audit(), indent=2))
