"""Read-only artifact verification of the completed audit; no fit or scoring."""
from pathlib import Path
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_sealed, sha256


def main():
    base = ROOT / 'iteration_24/completion'
    manifest = read_sealed(base / 'logs/completion_manifest.json')
    errors = []
    for path, digest in manifest['artifact_sha256'].items():
        if not (ROOT / path).is_file() or sha256(ROOT / path) != digest:
            errors.append(path)
    initial = read_sealed(ROOT / 'iteration_24/logs/manual_handoff_manifest.json')
    for path, digest in initial['artifact_sha256'].items():
        if not (ROOT / path).is_file() or sha256(ROOT / path) != digest:
            errors.append('prior_handoff:' + path)
    for name in ('A_completion_review', 'C_completion_interpretation', 'D_resource_review'):
        if read_sealed(base / ('reviews/' + name + '.json'))['passed'] is not True:
            errors.append(name)
    saved = read_sealed(ROOT / 'iteration_24/results/profile_audit/summary.json')
    result = read_sealed(base / 'results/summary.json')
    if not saved['all_complete'] or saved['counts'] != {'complete': 10}:
        errors.append('Production run incomplete')
    if result['diagnostic_decision'] != 'no_material_change_found_within_declared_finite_search_on_selected_set':
        errors.append('Completed diagnostic conclusion differs')
    print(json.dumps(dict(passed=not errors, errors=errors,
                         completion_artifacts_checked=len(manifest['artifact_sha256']),
                         prior_handoff_artifacts_checked=len(initial['artifact_sha256']),
                         completed_cases=result['completed_cases'],
                         maximum_phase_NLL_gain=result['maximum_phase_NLL_gain'],
                         maximum_absolute_GLR_shift32=result['maximum_absolute_GLR_shift32'],
                         scope='Saved evidence, source/review bindings and completion status only.',
                         read_only=True, new_scientific_computation=False),indent=2))
    return 0 if not errors else 2


if __name__ == '__main__':
    raise SystemExit(main())
