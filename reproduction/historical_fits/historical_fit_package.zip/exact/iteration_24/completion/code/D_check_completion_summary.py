"""Read-only independent resource/count cross-check of completion aggregation."""
from pathlib import Path
import csv
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_sealed, sha256


def main():
    area = ROOT / 'iteration_24/completion'
    result = read_sealed(area / 'results/summary.json')
    failure = read_sealed(area / 'results/failure_ledger.json')
    review = read_sealed(area / 'reviews/D_resource_review.json')
    rows = list(csv.DictReader((area / 'results/case_summary.csv').open(newline='', encoding='utf-8')))
    assert result['plan_id'] == review['plan_id']
    assert result['completed_cases'] == failure['completed_cases'] == failure['expected_cases'] == len(rows) == 10
    assert result['failures'] == failure['failures'] == []
    assert result['production_summary_all_complete'] is True
    budget = review['budget']
    resource = result['resource']
    expected = dict(inner_recorded_seconds=budget['inner_checkpoint_charge_seconds'],
                    outer_measured_continuation_seconds=budget['continuation_measured_wall_seconds'],
                    outer_closure_allowance_seconds=1., historical_prefix_plus_tail_reservation_seconds=320.9282113001682,
                    corrected_reservation_charge_seconds=budget['corrected_cumulative_debit_seconds'],
                    historical_exact_full_wall_unknown=True, all_sessions_closed=True,
                    all_outer_exits_zero=True, outer_censored_sessions=0)
    assert resource == expected
    assert result['input_summary_sha256'] == sha256(ROOT / 'iteration_24/results/profile_audit/summary.json')
    assert result['input_inner_ledger_sha256'] == sha256(ROOT / 'iteration_24/results/profile_audit/sessions.json')
    assert result['input_outer_ledger_sha256'] == sha256(ROOT / 'iteration_24/results/profile_audit/budget_supervisor/sessions.json')
    counts = dict(method_history_pairs=0, required_solver_records=0, powell_starts=0, value_controls=0, eta_profile_points=0)
    case_rows = {row['id']: row for row in rows}
    assert len(case_rows) == 10
    for independent in review['cases']:
        identifier = independent['id']
        path = ROOT / f'iteration_24/results/profile_audit/cases/{identifier}.json'
        case = read_sealed(path)
        p = case['payload']
        assert result['case_sha256'][identifier] == case_rows[identifier]['case_sha256'] == independent['case_sha256'] == sha256(path)
        assert float(case_rows[identifier]['elapsed_seconds']) == independent['recorded_case_wall_seconds']
        assert case_rows[identifier]['status'] == 'complete'
        counts['method_history_pairs'] += len(p['methods'])
        counts['required_solver_records'] += len(p['search_records'])
        counts['powell_starts'] += sum(s['label'] == 'background_alternative_Powell' for s in p['search_records'])
        counts['value_controls'] += sum(len(p[group]) for group in ('controls', 'old_primary_controls', 'old32_controls', 'validation'))
        counts['eta_profile_points'] += sum(len(m.get('eta_profile', [])) for m in p['methods'])
    assert all(result[k] == value for k, value in counts.items())
    assert result['script_sha256'] == sha256(area / 'code/summarize_completed.py')
    assert result['protocol_sha256'] == sha256(area / 'configs/saved_analysis_protocol.json')
    print(json.dumps(dict(passed=True, counts=counts, resource_fields_checked=len(expected),
                          original_case_hashes_checked=10, failures=[],
                          inputs_sha256={p.relative_to(ROOT).as_posix(): sha256(p) for p in
                                         [area / 'results/summary.json', area / 'results/failure_ledger.json',
                                          area / 'results/case_summary.csv', area / 'code/summarize_completed.py',
                                          Path(__file__)]},
                          read_only=True, scientific_fit_launched=False, gpu_initialized=False), indent=2))


if __name__ == '__main__':
    main()
