"""Independent read-only audit of saved metadata; no scientific evaluation.

Imports only standard library and the immutable checkpoint I/O helper. The
production complete-payload guard is AST-isolated from all scientific imports.
"""
from pathlib import Path
import ast
import collections
import gc
import json
import math
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import canonical_hash, read_json, read_sealed, sha256


class Numbers:
    @staticmethod
    def finfo(_):
        return type('FloatInfo', (), {'eps': sys.float_info.epsilon})()

    @staticmethod
    def linspace(lo, hi, count):
        result = [lo + i * ((hi - lo) / (count - 1)) for i in range(count)]
        result[-1] = hi
        return result


def isolated_production_guard():
    source = ROOT / 'iteration_24/code/profile_optimizer.py'
    nodes = []
    for node in ast.parse(source.read_text()).body:
        if isinstance(node, ast.FunctionDef) and node.name in ('_best', 'validate_result'):
            nodes.append(node)
        elif isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id in ('SEARCH_SPEC', 'TOL', 'METHODS')
                for target in node.targets):
            nodes.append(node)
    scope = {'math': math, 'np': Numbers, 'clean': lambda value: value}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), scope)
    return scope['validate_result']


def local_brackets(xs, ys):
    return [[xs[i - 1], xs[i + 1]] for i in range(1, len(xs) - 1)
            if ys[i] <= ys[i - 1] and ys[i] <= ys[i + 1]
            and (ys[i] < ys[i - 1] or ys[i] < ys[i + 1])]


def audit():
    run = ROOT / 'iteration_24/results/profile_audit'
    plan = read_sealed(run / 'plan.json')
    keys = ['config_path', 'config_sha256', 'contract', 'sources', 'ids', 'entries', 'baselines', 'law']
    assert canonical_hash({key: plan[key] for key in keys}) == plan['plan_id']
    assert sha256(ROOT / plan['config_path']) == plan['config_sha256']
    assert read_json(ROOT / plan['config_path']) == plan['contract']
    assert all(sha256(ROOT / path) == digest and sha256(run / 'source_snapshots' / path) == digest
               for path, digest in plan['sources'].items())
    assert all(sha256(ROOT / ref['path']) == ref['sha256'] for ref in plan['contract']['authorities'])
    assert plan['law'] == read_json(ROOT / 'iteration_21/configs/staged_full_frozen.json')['law']
    inv = read_sealed(ROOT / 'iteration_17/results/inventory_20261016T120350054217Z.json')
    inventory = {entry['id']: entry for entry in inv['entries']}
    declared = {entry['id']: entry for entry in plan['contract']['cases']}
    assert set(path.stem for path in (run / 'cases').glob('*.json')) == set(plan['ids'])
    assert [entry['id'] for entry in plan['entries']] == plan['ids']
    guard = isolated_production_guard()
    fit = plan['law']['alternative_generating_fit']
    screen = plan['contract']['diagnostic_screens']
    rows = []
    hashes = {}
    for entry in plan['entries']:
        case_id = entry['id']
        assert entry == inventory[case_id]
        assert all(sha256(ROOT / ref['path']) == ref['sha256'] for ref in entry['files'].values())
        path = run / 'cases' / (case_id + '.json')
        hashes[case_id] = sha256(path)
        case = read_sealed(path)
        payload = case['payload']
        baseline_ref = plan['baselines'][case_id]
        assert sha256(ROOT / baseline_ref['path']) == baseline_ref['sha256']
        baseline = read_sealed(ROOT / baseline_ref['path'])
        old_methods = {method['id']: method for method in baseline['payload']['methods']}
        assert case['plan_id'] == plan['plan_id'] and case['id'] == case_id
        assert case['seed'] == entry['seed'] and case['clock_mode'] == entry['clock_mode']
        assert case['catalogue_sha256'] == entry['files']['catalogue.npz']['sha256']
        assert case['inventory_entry_sha256'] == canonical_hash(entry)
        assert case['baseline_sha256'] == baseline_ref['sha256']
        assert case['status'] == 'complete' and case['error'] is None
        assert guard(payload, plan['contract']) is True
        assert case['elapsed_seconds'] <= plan['contract']['resources']['per_case_wall_seconds'][case_id]
        assert payload['feature_metadata']['clock_mode'] == case['clock_mode']
        metrics = payload['cuda_metrics']
        assert metrics['dtype'] == 'float64'
        assert all(metrics[key] is False for key in ('allow_tf32', 'mixed_precision', 'fast_math_requested'))
        assert metrics['peak_allocated_bytes'] <= 2 ** 30 and metrics['chunk_nodes'] == 32768
        assert payload['scalar_reduction_chunk_nodes'] == 2 ** 20
        assert not payload['evaluation_errors']

        def check_point(point):
            a, d, n, eta = point['pars']
            assert all(math.isfinite(value) for value in (a, d, n, eta, point['nll']))
            assert -12 <= a <= 0 and -2 <= d <= 2 and 0 <= eta <= 3
            assert n == fit['pars'][2] and point['trigger'] == fit['trigger'] and point['ratio'] == fit['ratio']
            assert point['success'] is True

        roots = payload['evaluations']
        coordinates = {}
        boundaries = collections.Counter()
        max_residual = max_bracket = max_monotonicity = 0.
        max_iterations = 0
        for index, point in enumerate(roots):
            check_point(point)
            assert point['evaluation_id'] == index
            coordinates[(point['pars'][1], point['pars'][3])] = point
            amplitude = point['amplitude']
            trace = amplitude['root_evaluations']
            lo, hi = amplitude['F_A_lower'], amplitude['F_A_upper']
            assert amplitude['root_converged'] is True and 0 <= amplitude['iterations'] <= 100
            assert amplitude['n_events'] == declared[case_id]['n_events']
            assert amplitude['a'] == point['pars'][0]
            assert math.isclose(amplitude['A'], math.exp(amplitude['a']), rel_tol=1e-15)
            assert math.isfinite(point['J']) and point['J'] > 0
            assert all(math.isfinite(item[key]) for item in trace for key in ('a', 'F_A'))
            assert all(-12 <= item['a'] <= 0 for item in trace)
            assert trace[0] == {'a': -12., 'F_A': lo} and trace[1] == {'a': 0., 'F_A': hi}
            assert trace[-1] == {'a': amplitude['a'], 'F_A': amplitude['F_A_at_solution']}
            ordered = sorted(trace, key=lambda item: item['a'])
            for left, right in zip(ordered, ordered[1:]):
                violation = left['F_A'] - right['F_A']
                max_monotonicity = max(max_monotonicity, violation)
                assert violation <= 1e-10 * max(1., abs(left['F_A']), abs(right['F_A']))
            boundary = amplitude['boundary']
            if boundary is None:
                assert lo < 0 < hi and amplitude['iterations'] > 0
                if amplitude['F_A_at_solution'] != 0:
                    width = min(item['a'] for item in trace if item['F_A'] > 0) - max(item['a'] for item in trace if item['F_A'] < 0)
                    assert 0 <= width <= 2.01e-12 + sys.float_info.epsilon * 4 * abs(amplitude['a'])
                    max_bracket = max(max_bracket, width)
            elif boundary == 'lower':
                assert lo >= 0 and amplitude['a'] == -12 and amplitude['iterations'] == 0
            elif boundary == 'upper':
                assert hi <= 0 and amplitude['a'] == 0 and amplitude['iterations'] == 0
            else:
                raise AssertionError('Unknown amplitude boundary')
            boundaries[str(boundary)] += 1
            if boundary is None:
                max_residual = max(max_residual, abs(amplitude['F_A_at_solution']))
            max_iterations = max(max_iterations, amplitude['iterations'])
        assert len(coordinates) == len(roots)
        assert payload['profile_requests'] == len(roots) + payload['profile_cache_hits']
        methods = {method['id']: method for method in payload['methods']}
        kk, bg = methods['known_known'], methods['background_estimated']
        d_grid = Numbers.linspace(-2., 2., 17)
        assert payload['stages'][0]['local_brackets'] == local_brackets(Numbers.linspace(0., 3., 17), [point['nll'] for point in kk['candidates'][2:19]])
        assert payload['stages'][1]['local_brackets'] == local_brackets(d_grid, [coordinates[(d, 0.)]['nll'] for d in d_grid])
        for index, curve in enumerate(bg['eta_profile']):
            for d in d_grid:
                assert (d, curve['eta']) in coordinates
            if index:
                assert curve['search']['local_brackets'] == local_brackets(d_grid, [coordinates[(d, curve['eta'])]['nll'] for d in d_grid])
        method_rows = []
        for mid, method in methods.items():
            for phase in ('null', 'alternative'):
                old = method['old_selected'][phase]
                assert all(old[key] == old_methods[mid][phase][key] for key in ('pars', 'trigger', 'ratio'))
                assert abs(old['nll'] - old_methods[mid][phase]['nll']) < 1e-4
                assert method[phase]['nll'] <= old['nll'] + 1e-8
                assert abs(method['gains'][phase + '_NLL'] - (old['nll'] - method[phase]['nll'])) <= 1e-10
            assert abs(method['old_contrast16']['statistic'] - old_methods[mid]['contrast16']['statistic']) == method['gates']['old_direct_saved_delta'] < 1e-4
            for point in method['candidates'] + method.get('null_candidates', []):
                check_point(point)
                if 'evaluation_id' in point:
                    assert point == roots[point['evaluation_id']]
            gains = method['gains']
            material_nll = any(gains[phase + '_NLL'] >= screen['material_phase_NLL_improvement'] for phase in ('null', 'alternative'))
            material_stat = max(abs(gains['direct_GLR_shift16']), abs(gains['direct_GLR_shift32'])) >= screen['material_absolute_direct_GLR_change']
            method_rows.append(dict(method=mid, **gains, material_NLL=material_nll, material_statistic=material_stat,
                                    new_direct_order_delta=method['gates']['direct_order_delta'],
                                    old_direct_order_delta=method['gates']['old_direct_order_delta']))
        row = dict(id=case_id, clock_mode=case['clock_mode'], n_events=declared[case_id]['n_events'],
                   elapsed_seconds=case['elapsed_seconds'], roots=len(roots), root_boundary_counts=dict(boundaries),
                   max_root_iterations=max_iterations, max_absolute_root_residual=max_residual,
                   max_terminal_sign_bracket_width=max_bracket, max_monotonicity_violation=max_monotonicity,
                   solvers=len(payload['search_records']), failed_solvers=sum(not record['success'] for record in payload['search_records']),
                   powell_nfev=[record['nfev'] for record in payload['search_records'] if record['label'] == 'background_alternative_Powell'],
                   max_original_CUDA16_control_delta=max(record['absolute_difference'] for record in payload['controls']),
                   max_old_primary_delta=max(record['absolute_difference'] for record in payload['old_primary_controls']),
                   max_new_CPU32_delta=max(record['absolute_difference'] for record in payload['validation']),
                   max_old_CPU32_delta=max(record['absolute_difference'] for record in payload['old32_controls']),
                   max_old_CPU32_saved_delta=max(record['saved_absolute_difference'] for record in payload['old32_controls']),
                   peak_GPU_allocated_bytes=metrics['peak_allocated_bytes'], methods=method_rows)
        rows.append(row)
        print('AUDITED ' + case_id, file=sys.stderr, flush=True)
        del case, payload, roots, coordinates, methods, kk, bg, baseline, old_methods
        gc.collect()
    assert declared['null_1292']['n_events'] == 30276
    assert next(row for row in rows if row['id'] == 'null_0841')['clock_mode'] == 'paired_clock'
    summary = read_sealed(run / 'summary.json')
    assert summary['all_complete'] and summary['counts'] == {'complete': 10} and summary['sessions_closed']
    assert all(summary['states'][case_id] == 'complete' for case_id in plan['ids']) and not summary['active_ids']
    manifest = ROOT / 'iteration_24/logs/manual_handoff_manifest.json'
    return dict(passed=True, plan_id=plan['plan_id'], source_hashes=plan['sources'], case_sha256=hashes,
                scientific_likelihood_evaluations=0, GPU_initializations=0,
                pure_production_guard_cases=10, exact_ten_cases=True,
                material_NLL_screen=screen['material_phase_NLL_improvement'],
                material_statistic_screen=screen['material_absolute_direct_GLR_change'],
                handoff_manifest_sha256=sha256(manifest), rows=rows)


if __name__ == '__main__':
    print(json.dumps(audit(), indent=2, allow_nan=False))
