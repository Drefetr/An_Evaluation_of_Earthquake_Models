"""Read-only audit of existing run artifacts; writes only new D completion review."""
from pathlib import Path
from datetime import datetime
import collections
import json
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_24/code'))
import budgeted_continue as supervisor
from checkpoint_io import canonical_hash, read_sealed, sealed_json, sha256, utc_now

RUN = ROOT / 'iteration_24/results/profile_audit'
DEST = ROOT / 'iteration_24/completion/reviews'


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def main():
    authority = supervisor.load_authority()
    supervisor.validate_sources(authority)
    policy, plan = authority['policy'], authority['plan']
    base = RUN / 'budget_supervisor'
    ledger = supervisor.load_ledger(authority, base)
    view = supervisor.status(authority, base)
    archive = base / 'original_inner_sessions.json'
    require(sha256(archive) == policy['original_sessions_sha256'], 'Original session archive bytes differ')
    original = read_sealed(archive)
    inner = read_sealed(RUN / 'sessions.json')
    summary = read_sealed(RUN / 'summary.json')
    gate = read_sealed(RUN / 'gates/first_case_review.json')
    require(inner['plan_id'] == summary['plan_id'] == gate['plan_id'] == plan['plan_id'], 'Plan lineage differs')
    require(gate['passed'] is True and gate['reviewers'] == ['A', 'C'], 'Missing original A/C gate')
    require(len(original['sessions']) == 1 and len(inner['sessions']) == 2 and len(ledger['sessions']) == 1,
            'Unexpected number of recorded sessions')
    require(inner['sessions'][0] == original['sessions'][0], 'Original first-session record was replaced')
    require(all(s['closed'] and s['worker_exitcode'] == 0 for s in inner['sessions']), 'Inner session not cleanly closed')
    outer = ledger['sessions'][0]
    require(outer['closed'] and outer['worker_exitcode'] == 0 and outer['reason'] == 'child_returned' and
            outer['censored'] is False and outer['error'] is None, 'Outer continuation did not close successfully')
    require(outer['closure_allowance_seconds'] == 1. and
            outer['elapsed_seconds'] == outer['measured_elapsed_seconds'] + 1., 'Closure allowance differs')
    require(ledger['initial_debit_seconds'] == policy['initial_inner_elapsed_seconds'] + 60., 'Historical debit differs')
    require(outer['reserved_remaining_seconds'] == 3600. - ledger['initial_debit_seconds'], 'Reserved remaining differs')
    require(outer['launch_cutoff_seconds_from_session_start'] == outer['reserved_remaining_seconds'] - 15.,
            'Outer cutoff differs')
    require(outer['measured_elapsed_seconds'] < outer['launch_cutoff_seconds_from_session_start'], 'Cutoff exceeded')
    total = ledger['initial_debit_seconds'] + outer['elapsed_seconds']
    require(total == view['durable_charged_seconds'] < 3600., 'Cumulative corrected debit differs')
    require(summary['charged_seconds'] == sum(s['elapsed_seconds'] for s in inner['sessions']), 'Inner sum differs')
    require(summary['sessions_closed'] and summary['all_complete'] and summary['counts'] == {'complete': 10} and
            summary['reason'] == 'complete' and summary['active_ids'] == [], 'Run summary not complete')

    identities = []
    life = supervisor.lifetime()
    for scope, session in [('outer_continuation', outer)] + [('inner_' + str(i), s) for i, s in enumerate(inner['sessions'])]:
        old = session['worker_identity']
        current = life.process_identity(old['pid'])
        require(current != old, 'Owned process creation token is still live: ' + scope)
        identities.append(dict(scope=scope, recorded_identity=old, current_identity=current, matched_live=False))

    attempts = RUN / 'attempts'
    starts = {p.name[:-len('.started.json')]: read_sealed(p) for p in attempts.glob('*.started.json')}
    finishes = {p.name[:-len('.finished.json')]: read_sealed(p) for p in attempts.glob('*.finished.json')}
    require(len(starts) == len(finishes) == 10 and starts.keys() == finishes.keys(), 'Missing or additional recorded attempts')
    require(len(list(attempts.iterdir())) == 20, 'Additional attempt artifacts')
    require(collections.Counter(v['id'] for v in starts.values()) == collections.Counter(plan['ids']), 'Repeat or missing case attempts')
    cases = {p.stem: p for p in (RUN / 'cases').iterdir()}
    require(set(cases) == set(plan['ids']) and all(p.suffix == '.json' for p in cases.values()), 'Additional/missing case artifacts')
    snapshots = RUN / 'source_snapshots'
    for name, digest in plan['sources'].items():
        require(sha256(snapshots / name) == digest, 'Original source snapshot differs: ' + name)
    rows = []
    partial_attempts = set()
    for entry in plan['entries']:
        id = entry['id']
        path = cases[id]
        case = read_sealed(path)
        aid = case['attempt_id']
        start, finish = starts[aid], finishes[aid]
        expected_session = inner['sessions'][0 if id == 'null_0000' else 1]['session_id']
        require(aid == expected_session + '_' + id, 'Attempt/session lineage differs: ' + id)
        identity = dict(plan_id=plan['plan_id'], id=id, seed=entry['seed'], clock_mode=entry['clock_mode'],
                        inventory_entry_sha256=canonical_hash(entry),
                        catalogue_sha256=entry['files']['catalogue.npz']['sha256'],
                        baseline_sha256=plan['baselines'][id]['sha256'])
        require(all(case[k] == start[k] == value for k, value in identity.items()), 'Case/start identity differs: ' + id)
        require(case['status'] == finish['status'] == 'complete' and case['error'] is None and
                finish['plan_id'] == plan['plan_id'] and finish['id'] == id and
                finish['case_sha256'] == sha256(path), 'Finished case binding differs: ' + id)
        cap = plan['contract']['resources']['per_case_wall_seconds'][id]
        parent_interval = (datetime.fromisoformat(case['completed_utc']) - datetime.fromisoformat(start['started_utc'])).total_seconds()
        require(0 <= case['elapsed_seconds'] <= cap and 0 <= parent_interval <= cap, 'Per-case cap exceeded: ' + id)
        partial_dir = RUN / 'partials' / id / aid
        partials = list(partial_dir.glob('*.json'))
        require(len(partials) == case['partial_records'], 'Partial checkpoint count differs: ' + id)
        partial_attempts.add(partial_dir)
        for p in partials:
            v = read_sealed(p)
            require(v['attempt_id'] == aid and v['id'] == id and v['plan_id'] == plan['plan_id'], 'Unbound partial')
        rows.append(dict(id=id, attempt_id=aid, status='complete', case_sha256=sha256(path),
                         recorded_case_wall_seconds=case['elapsed_seconds'],
                         parent_start_to_case_commit_seconds=parent_interval, cap_seconds=cap,
                         partial_records=len(partials)))
    actual_partial_attempts = {p.parent for p in (RUN / 'partials').rglob('*.json')}
    require(actual_partial_attempts == partial_attempts, 'Extra/orphan recorded partial attempt')

    verification = []
    for name in ['iteration_24/code/verify_handoff.py', 'iteration_23/code/verify_delivery.py']:
        completed = subprocess.run([sys.executable, '-B', str(ROOT / name)], cwd=ROOT, capture_output=True, text=True)
        require(completed.returncode == 0, 'Read-only verifier failed: ' + name + ': ' + completed.stderr)
        value = json.loads(completed.stdout)
        require(value['passed'] is True and value['read_only'] is True, 'Verifier result differs')
        verification.append(dict(path=name, exitcode=completed.returncode, result=value))

    paths = ['iteration_24/configs/budget_supervisor_frozen.json', 'iteration_24/logs/budget_supervisor_freeze.json',
             'iteration_24/logs/manual_handoff_manifest.json', 'iteration_24/results/profile_audit/plan.json',
             'iteration_24/results/profile_audit/summary.json', 'iteration_24/results/profile_audit/sessions.json',
             'iteration_24/results/profile_audit/budget_supervisor/sessions.json',
             'iteration_24/results/profile_audit/budget_supervisor/original_inner_sessions.json',
             'iteration_24/results/profile_audit/gates/first_case_review.json',
             Path(__file__).relative_to(ROOT).as_posix()]
    value = dict(role='D', review_utc=utc_now(), passed=True, plan_id=plan['plan_id'],
                 scope='Recorded resource/provenance completion review; no scientific fitting, scoring or GPU work',
                 scientific_fit_launched=False, gpu_initialized=False,
                 original_static_handoff_artifacts=70, original_handoff_manifest_unchanged=True,
                 source_snapshots_checked=len(plan['sources']), supervisor_freeze_sources_checked=len(authority['freeze']['sources']),
                 completed_cases=10, recorded_started_attempts=10, recorded_finished_attempts=10,
                 additional_recorded_attempts=0, recorded_failed_or_censored_cases=0,
                 inner_session_count=2, outer_continuation_session_count=1, all_sessions_closed=True,
                 original_first_case_sha256=policy['first_case_sha256'], original_session_archive_sha256=sha256(archive),
                 budget=dict(total_policy_seconds=3600., historical_inner_measurement_seconds=policy['initial_inner_elapsed_seconds'],
                             historical_tail_reservation_seconds=60., continuation_measured_wall_seconds=outer['measured_elapsed_seconds'],
                             final_write_operational_allowance_seconds=1., corrected_cumulative_debit_seconds=total,
                             nominal_unused_policy_seconds=3600. - total, inner_checkpoint_charge_seconds=summary['charged_seconds'],
                             scope='Parent wall accounting; historical tail and final write allowances are operational reservations, not measurements or proved latency bounds; not GPU-seconds',
                             unused_budget_authorizes_new_campaign=False),
                 process_death_checks=identities, cases=rows, verification=verification,
                 evidence_sha256={p: sha256(ROOT / p) for p in paths},
                 absence_claim_scope='No additional, repeated, failed, censored or orphan attempt is present in this recorded audit tree; this is not a claim about unrecorded machine-wide history')
    DEST.mkdir(parents=True, exist_ok=True)
    output = DEST / 'D_resource_review.json'
    require(not output.exists(), 'Refusing to overwrite D completion review')
    sealed_json(output, value)
    print(json.dumps(dict(passed=True, corrected_cumulative_debit_seconds=total,
                          nominal_unused_policy_seconds=3600. - total, cases=10, attempts=10,
                          process_identities_checked=len(identities), review_sha256=sha256(output)), indent=2))


if __name__ == '__main__':
    main()
