"""Aggregate saved audit records. No fitting, history evaluation or CUDA calls."""
from pathlib import Path
import argparse
import csv
import gc
import json
import math
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_sealed, sealed_json, sha256, utc_now


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    began = time.perf_counter()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'iteration_24/completion/results')
    args = parser.parse_args()
    out = args.output_dir.resolve()
    if not out.is_relative_to(ROOT / 'iteration_24/completion') or out.exists():
        raise ValueError('Choose a new output directory within iteration_24/completion')
    protocol_path = ROOT / 'iteration_24/completion/configs/saved_analysis_protocol.json'
    protocol = read_sealed(protocol_path)
    run = ROOT / 'iteration_24/results/profile_audit'
    plan = read_sealed(run / 'plan.json')
    assert plan['plan_id'] == protocol['plan_id']
    assert sha256(run / 'plan.json') == protocol['plan_sha256']
    for path, digest in plan['sources'].items():
        assert sha256(ROOT / path) == digest, path
    screens = protocol['screens']
    phase_threshold = screens['material_phase_NLL_improvement']
    stat_threshold = screens['material_absolute_direct_GLR_change']
    paired, cases, solvers, curves, failures = [], [], [], [], []
    for identifier in plan['ids']:
        path = run / f'cases/{identifier}.json'
        assert sha256(path) == protocol['case_sha256'][identifier]
        case = read_sealed(path)
        assert case['plan_id'] == plan['plan_id'] and case['id'] == identifier
        if case['status'] != 'complete':
            failures.append(dict(id=identifier, status=case['status'], error=case.get('error')))
            continue
        payload = case['payload']
        controls = [c for group in ('controls', 'old_primary_controls', 'old32_controls', 'validation') for c in payload[group]]
        assert len(controls) == 24 and all(c['passed'] for c in controls)
        assert payload['complete'] and payload['all_mandated_solvers_successful']
        assert all(s['success'] for s in payload['search_records'])
        cases.append(dict(id=identifier, status=case['status'], seed=case['seed'],
                          clock_mode=case['clock_mode'],
                          events=payload['evaluations'][0]['amplitude']['n_events'],
                          elapsed_seconds=case['elapsed_seconds'],
                          solver_count=len(payload['search_records']),
                          powell_count=sum(s['label'] == 'background_alternative_Powell' for s in payload['search_records']),
                          value_control_count=len(controls),
                          maximum_value_control_difference=max(c['absolute_difference'] for c in controls),
                          amplitude_evaluations=len(payload['evaluations']),
                          peak_cuda_bytes=payload['cuda_metrics']['peak_allocated_bytes'],
                          case_sha256=sha256(path)))
        for s in payload['search_records']:
            solvers.append(dict(id=identifier, **{k:s.get(k) for k in ('label','index','success','status','nit','nfev','nll','elapsed_seconds')}))
        for m in payload['methods']:
            assert m['complete']
            old, gains = m['old_selected'], m['gains']
            null_gain = old['null']['nll'] - m['null']['nll']
            alt_gain = old['alternative']['nll'] - m['alternative']['nll']
            shift = m['contrast32']['statistic'] - m['old_contrast32']['statistic']
            assert abs(null_gain-gains['null_NLL']) < 1e-10
            assert abs(alt_gain-gains['alternative_NLL']) < 1e-10
            assert abs(shift-gains['direct_GLR_shift32']) < 1e-10
            assert null_gain >= -1e-8 and alt_gain >= -1e-8
            assert all(math.isfinite(v) for v in (null_gain,alt_gain,shift))
            row = dict(id=identifier, method=m['id'],
                       old_null_NLL=old['null']['nll'], new_null_NLL=m['null']['nll'],
                       null_NLL_gain=null_gain,
                       old_alternative_NLL=old['alternative']['nll'],
                       new_alternative_NLL=m['alternative']['nll'], alternative_NLL_gain=alt_gain,
                       old_GLR32=m['old_contrast32']['statistic'], new_GLR32=m['contrast32']['statistic'],
                       GLR_shift32=shift, old_eta=old['alternative']['pars'][3],
                       new_eta=m['alternative']['pars'][3],
                       material_NLL=max(null_gain,alt_gain) >= phase_threshold,
                       material_statistic=abs(shift) >= stat_threshold)
            for phase in ('null','alternative'):
                for index, name in ((0,'a'),(1,'d')):
                    row[f'old_{phase}_{name}'] = old[phase]['pars'][index]
                    row[f'new_{phase}_{name}'] = m[phase]['pars'][index]
            paired.append(row)
            if m['id'] == 'background_estimated':
                for point in m['eta_profile']:
                    p = point['selected']
                    curves.append(dict(id=identifier,eta=point['eta'],NLL=p['nll'],a=p['pars'][0],d=p['pars'][1]))
        del case, payload
        gc.collect()
    complete = len(cases) == len(plan['ids']) and len(paired) == 2*len(plan['ids']) and not failures
    any_stat = any(r['material_statistic'] for r in paired)
    any_nll = any(r['material_NLL'] for r in paired)
    decision = ('incomplete' if not complete else 'statistic_sensitive' if any_stat
                else 'likelihood_sensitive_only' if any_nll
                else 'no_material_change_found_within_declared_finite_search_on_selected_set')
    inner = read_sealed(run / 'sessions.json')
    outer = read_sealed(run / 'budget_supervisor/sessions.json')
    primary = read_sealed(run / 'summary.json')
    resource = dict(inner_recorded_seconds=sum(s['elapsed_seconds'] for s in inner['sessions']),
                    outer_measured_continuation_seconds=sum(s['measured_elapsed_seconds'] for s in outer['sessions']),
                    outer_closure_allowance_seconds=sum(s.get('closure_allowance_seconds',0) for s in outer['sessions']),
                    historical_prefix_plus_tail_reservation_seconds=outer['initial_debit_seconds'],
                    corrected_reservation_charge_seconds=outer['initial_debit_seconds']+sum(s['elapsed_seconds'] for s in outer['sessions']),
                    historical_exact_full_wall_unknown=True,
                    all_sessions_closed=all(s['closed'] for s in inner['sessions']+outer['sessions']),
                    all_outer_exits_zero=all(s['worker_exitcode']==0 for s in outer['sessions']),
                    outer_censored_sessions=sum(s['censored'] for s in outer['sessions']))
    result = dict(created_utc=utc_now(), provenance_kind='descriptive_aggregation_of_executed_saved_history_fits',
                  validation_status='aggregation_assertions_passed; separate reviews required',
                  protocol_sha256=sha256(protocol_path), script_sha256=sha256(Path(__file__)),
                  plan_id=plan['plan_id'], case_sha256=protocol['case_sha256'],
                  input_summary_sha256=sha256(run/'summary.json'),
                  input_inner_ledger_sha256=sha256(run/'sessions.json'),
                  input_outer_ledger_sha256=sha256(run/'budget_supervisor/sessions.json'),
                  completed_cases=len(cases), method_history_pairs=len(paired),
                  required_solver_records=len(solvers), powell_starts=sum(c['powell_count'] for c in cases),
                  value_controls=sum(c['value_control_count'] for c in cases),
                  eta_profile_points=len(curves),
                  maximum_value_control_difference=max(c['maximum_value_control_difference'] for c in cases),
                  maximum_phase_NLL_gain=max(max(r['null_NLL_gain'],r['alternative_NLL_gain']) for r in paired),
                  maximum_absolute_GLR_shift32=max(abs(r['GLR_shift32']) for r in paired),
                  material_NLL_pairs=sum(r['material_NLL'] for r in paired),
                  material_statistic_pairs=sum(r['material_statistic'] for r in paired),
                  screens=screens, diagnostic_decision=decision,
                  production_summary_all_complete=primary['all_complete'], resource=resource,
                  failures=failures, no_new_fits_scores_or_power=True,
                  selection_is_purposive=True, elapsed_analysis_seconds=time.perf_counter()-began)
    out.mkdir(parents=True)
    for name, rows in (('paired_diagnostics',paired),('case_summary',cases),('solver_records',solvers),('eta_profiles',curves)):
        write_csv(out/(name+'.csv'),rows)
    sealed_json(out/'summary.json',result)
    sealed_json(out/'failure_ledger.json',dict(completed_cases=len(cases),expected_cases=10,failures=failures,
                                              qualifier='This completed iteration24 run only; earlier iteration23 failures remain unchanged.'))
    lines = ['| Case | Procedure | Null NLL gain | Alternative NLL gain | Direct GLR change |',
             '|---|---|---:|---:|---:|']
    for r in paired:
        lines.append(f"| {r['id']} | {r['method']} | {r['null_NLL_gain']:.6g} | {r['alternative_NLL_gain']:.6g} | {r['GLR_shift32']:.6g} |")
    (out/'paired_diagnostics.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('completed_cases','method_history_pairs','required_solver_records','powell_starts','value_controls','maximum_phase_NLL_gain','maximum_absolute_GLR_shift32','diagnostic_decision')}))


if __name__ == '__main__':
    main()
