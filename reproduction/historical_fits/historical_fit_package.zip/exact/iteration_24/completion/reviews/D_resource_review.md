# D resource and provenance completion review

**PASS for the recorded completed iteration 24 audit.** This review read saved artifacts and queried process identities. It performed no fit, history scoring, simulation, or GPU initialization. All new D artifacts are inside `iteration_24/completion`; no earlier source, review, status document, manifest, scientific case, or ledger was edited.

The independent sealed evidence is `D_resource_review.json` (SHA256 `183565d23182859f0f854b72d75fb8e08c4a0ea0bea968ee184be13db5f45fff`). Its producer is `completion/code/D_resource_review.py`, SHA256 `8e9dd339b074f980ebeb68c05c58e018cd93d4cfdb4f3d50de4370b3b1b61b9e`.

The recorded audit has exactly 10 complete cases, 10 started attempts and 10 finished attempts: one attempt per frozen case, with matching case hashes in the finished records. The first attempt belongs to the original first-case session and the other nine belong to the single continuation session. All partial-checkpoint directories belong to those same ten attempts; each recorded partial count and seal matches. No additional, repeated, failed, censored, or orphan attempt appears in this audit tree. This establishes the contents of the recorded audit, not an absence claim about unrecorded machine-wide history.

Both inner sessions and the one outer continuation session are closed with exit code zero. The outer session is uncensored, has reason `child_returned`, and records no error. The pinned lifetime helper returned no live matching process for all three recorded PID/creation-token identities: original inner worker PID 38288, continuation inner worker PID 25148, and outer-owned wrapper PID 35328. All ten case durations, and independently their parent attempt-start to case-commit timestamp intervals, are below their frozen per-case caps: 600 seconds each except `null_1292`, whose cap is 1200 seconds.

| Resource item | Seconds | Interpretation |
|---|---:|---|
| Original inner first-session measurement | 260.9282113001682 | Historical inner checkpoint accounting |
| Historical tail reservation | 60 | Operational reservation, not measured or proved upper bound |
| Original outer debit | 320.9282113001682 | Sum of the preceding two items |
| Continuation outer measured wall | 1505.2737544998527 | Includes preflight, execution, owned-child cleanup and postflight verification |
| Final ledger-write allowance | 1 | Explicit operational allowance, not measured latency or proved bound |
| Corrected cumulative reservation charge | **1827.2019658000208** | Authoritative continuation policy debit |
| Nominal unused part of the 3600-second policy | **1772.7980341999792** | Unused allowance; no authorization for another campaign |
| Unchanged inner summary charge | 1740.347389700124 | Inner checkpoint scope; does not include the full outer scope |

The outer continuation's initial remaining reservation was `3279.071788699832` seconds and its launch/execution cutoff was `3264.071788699832` seconds from the session invocation, retaining the frozen 15-second cleanup reserve. Its measured duration was below that cutoff. These figures are **parent wall accounting, not GPU-seconds**. The exact full historical first-session wall remains unknown because its final tail was not measured by the original inner ledger. The 60-second historical reservation and 1-second final-write allowance do not turn that unknown into an exact measured total or a demonstrated timing bound.

Provenance checks passed for all 13 original plan source snapshots and all 17 supervisor-freeze source entries. The original plan ID is `77301cd2d805f1f5e347cc39fb7ae4e5490915f0deeaf1325a1d4028229ee3f7`; the original first-case SHA256 is still `4a29c7f0998a5dfb81e12f526e929c3fea6574ecd1638b7d33bb9be4d3e92329`. The exact archived original inner-session bytes still hash to `ed1b1c46ea2092bfc8dedb7ee488882eda54bbc5f56b968d0e6609094b625ad6`, and the original session record is unchanged within the expanded two-session inner ledger. Policy, plan, config, source-freeze, first-case A/C gate and case/attempt/catalogue/baseline identities all match their recorded bindings.

Read-only validation commands actually run:

```powershell
python -B iteration_24/code/verify_handoff.py
python -B iteration_23/code/verify_delivery.py
python -B iteration_24/completion/code/D_resource_review.py
python -B iteration_24/completion/code/D_check_completion_summary.py
```

The original handoff verifier passed **70 static artifacts**, the original A/C gate, and the live ten-case completion state. The iteration 23 verifier passed **195 delivery artifacts and 155 prior pins**; its historical `scientific_study_complete=false` remains as recorded. Neither static manifest was extended or rewritten for this completion evidence.

The separate read-only completion-summary cross-check passed all nine resource fields, all ten saved case hash/elapsed-time rows and the empty failure ledger. Independent counting of the saved payload metadata matched the aggregation's **20 method/history pairs, 114 solver records, 48 Powell starts, 240 value controls and 110 eta-profile points**. This count check does not repeat the scientific numerical validation delegated to the other completion reviewers.

Reviewed completion aggregation pins:

* `completion/results/summary.json`: `62042bf903ba658888e474af5407bb71b8599739c85d83571ee4f6a5cece30ac`.
* `completion/results/failure_ledger.json`: `c2429551f1196b025ea068d3c8e1fb6c629de0334b087b0b2340cd5638c20e65`.
* `completion/results/case_summary.csv`: `e4f1edf7bb9cec2b45d1b8a3c329c8a5d52a006c89e4a67d50284ee9c0a5ba9d`.
* `completion/code/summarize_completed.py`: `f984a1e9e25ce2b1bd8a9ed03f532a2c254aec132cfc61fa56519af0429b63ac`.
* `completion/code/D_check_completion_summary.py`: `f6ed1887c4e1c27a6d4ca5e34845916530d8155377c174269efed45286c6b6dd`.

The completion failure ledger applies to this completed iteration 24 run. It does not erase earlier iteration 23 failures. Completion of this bounded diagnostic and its unused resource allowance do not authorize additional scientific work, recalibration, power estimates, or a new campaign.
