# Completed larger-limit optimization audit

All ten frozen diagnostic histories completed, with no failed or censored case. The larger value-only profile searches found no material improvement over the original iteration21 fits. The largest phase NLL improvement was 1.94995664e-08, and the largest absolute CPU32 direct-GLR change was 3.89681745e-08, against the predeclared numerical screens .001 and .1. Both order16 and order32 statistics pass the screen in A's separate raw audit. This resolves the earlier inability to complete the selected-set audit; it does not certify global maxima or all 2,149 historical fits.

## What actually ran

The user's manual continuation finished the remaining nine histories after the reviewed first case. All 20 procedure-history pairs completed; all 114 mandated scalar/Powell records, 48 Powell starts, 240 numerical value controls and 110 saved eta-profile points are present. Maximum value-control discrepancy was 2.91038305e-11, below the frozen 1e-4 numerical gates. The six null and four alternative histories were selected purposively from earlier warnings and diagnostics. No case was replaced. This is not a representative ten-history power sample.

The 30,276-event null_1292 extreme, paired-clock null_0841, prior numerical fallback cases, large-gradient warnings and near-boundary new_r140 were retained. Original iteration21 points remained eligible. The new search conditionally profiles background amplitude, uses grids and value-only Powell searches over trend and inhibition, and retains the strict requirement that every mandated solver succeed. Ordinary/extreme case limits were 600/1200 seconds, with 100,000 evaluations and 2,000 iterations allowed per Powell start. Earlier failed iteration23 attempts remain failed in their own records.

Actual A review independently checked raw root traces, isolated pure production validation, scalar brackets, solver/candidate arithmetic, source and baseline bindings, and every saved table cell. C reviewed interpretation and independently checked descriptive arithmetic and selected raw points. D reviewed process closure, resource accounting and preservation. These are parallel project reviews, not statistically independent academic refereeing. See `reviews/` for their exact execution scopes and limitations.

## Paired outcomes

Gains are old minus new NLL on a common backend; the old coordinates and law remain those of the original eligible iteration21 fits. Rescored old values can differ slightly from their saved primary values (at most about 2.91e-11 in the checked controls). Direct-statistic changes are new minus old at the CPU32 selected-point convention. They are numerical diagnostics, not p-values or new detections.

| Case | Procedure | Null NLL gain | Alternative NLL gain | Direct GLR change |
|---|---|---:|---:|---:|
| null_0000 | known_known | 0 | 0 | 0 |
| null_0000 | background_estimated | 4.54747e-13 | 1.68257e-11 | 3.30265e-11 |
| null_0841 | known_known | 0 | 0 | 0 |
| null_0841 | background_estimated | 0 | 1.40972e-11 | 2.80203e-11 |
| null_1292 | known_known | 0 | 0 | 0 |
| null_1292 | background_estimated | 2.91038e-11 | 1.94996e-08 | 3.89682e-08 |
| new_r000 | known_known | 0 | 0 | 0 |
| new_r000 | background_estimated | 2.27374e-13 | 1.20508e-11 | 2.38689e-11 |
| new_r076 | known_known | 0 | 7.27596e-12 | 5.68434e-13 |
| new_r076 | background_estimated | 7.27596e-12 | 2.98314e-10 | 5.81526e-10 |
| null_1107 | known_known | 0 | 0 | 0 |
| null_1107 | background_estimated | 0 | 0 | 0 |
| null_1166 | known_known | 0 | 0 | 0 |
| null_1166 | background_estimated | 4.54747e-13 | 4.54747e-13 | 0 |
| new_r100 | known_known | 0 | 2.43745e-10 | 4.83055e-10 |
| new_r100 | background_estimated | 0 | 0 | 0 |
| null_1345 | known_known | 0 | 0 | 0 |
| null_1345 | background_estimated | 0 | 7.07223e-09 | 1.41453e-08 |
| new_r140 | known_known | 0 | 0 | 0 |
| new_r140 | background_estimated | 0 | 2.95586e-11 | 5.8936e-11 |

No procedure-history pair crossed either material screen. The largest NLL and statistic changes occurred in null_1292 with estimated background. Known-background results were also effectively unchanged. A separately checked both saved quadrature orders; the largest order16 change is approximately 3.896818157e-8, with no material-screen crossing.

The CPU32 selected-point checks use the same pinned history geometry. They do not independently reconstruct every search-point history, validate every eta-curve integral against another history implementation, or prove a universal quadrature bound. A's new independent metadata review checks the saved traces and arithmetic; it does not rerun likelihood integration. Earlier literal geometry validations remain earlier evidence. Solver success and conditional-amplitude curvature do not establish joint convexity or global optimality.

## Consequence for the research question

The earlier calibrated study detected 150/150 alternative histories with nuisance parameters supplied and eta estimated, versus 68/150 (45.3%) when background intercept and trend were also estimated. Its held-out null counts were 49/1000 and 44/1000, using separate matched null banks. Those remain the immutable results of the earlier procedures; this audit does not recalculate their power, ranks or size. The historical 57/150 (38%) fuller-nuisance procedure is a different comparison and cannot be decomposed additively using these counts. Source: `iteration_22/reports/research_report.md`, accepted iteration21 analysis linked there.

A distinct optimization algorithm, with exact conditional amplitude profiling up to numerical tolerance and much more search time, reproduced the selected likelihoods and contrasts on all ten deliberately difficult histories. This weakens an explanation based on inadequate stopping limits or the earlier optimizer on this set. It supports proceeding to isolate statistical overlap between inhibition and background flexibility. It does not prove that optimization is irrelevant elsewhere, that the best possible nuisance-aware test must lose this much power, or that background confounding is the unique cause of the historical contrast.

The present intensity remains the independently specified-background diagnostic, exp(a+d*(2t/T-1))*exp(-eta*G(t))+n*H(t). Branching/productivity, beta and the stress/trigger kernels are supplied. This differs from the original physical loading model. Fixed history, full compensator, random counts, pre-event evaluation and the authoritative time representations are preserved. The transformed marks have finite first but infinite second moments; no Fisher/Wilks approximation is invoked. Numerical likelihood robustness is separate from physical stress mechanism identification, geological covariates, equality of kernels, ensemble information or first-moment ergodicity. No new NZ catalogue result follows.

## Resources and preservation

The continuation's measured outer wall was 1505.273754 seconds (25 minutes 5 seconds), including preflight, child execution, cleanup and verification. Its exit was zero; all sessions closed and none was censored. It is parent wall, not GPU compute time. The corrected reservation ledger totals 1827.201966 seconds, including the recorded first-session prefix plus a 60-second historical-tail reservation and a one-second closure allowance. These reservations are not measured or proved latency bounds; exact first-invocation full wall remains unavailable. The inner ledger alone is not authoritative for that corrected total.

The original 70-artifact handoff passes verification. Earlier iteration23 preservation and its 195-artifact/155-prior-pin verifier pass. Initial README/STATUS remain an immutable handoff snapshot; this completion area supplies the current status. Sources, original fits, prior failure records and inputs are unchanged. No new simulation, catalogue download, bootstrap or calibration was launched.

## Single most valuable next step

Prepare a separately bounded background-level versus time-trend pilot on these same ten histories. Add the two intermediate procedures (a estimated with d supplied, and d estimated with a supplied) to the existing both-supplied and both-estimated benchmarks. Infer eta consistently; retain the law, kernels, beta, trigger parameters, clocks, bounds and strict numerical gates. Freeze an explicit compute allowance and failure policy before refitting. Compare pathwise null/alternative likelihood gains and direct-statistic contraction without treating the effects as additive shares. This pilot would identify where the finite-history contraction occurs; it would not estimate power. Any later detection comparison needs its own separately declared matched-null calculation for each altered procedure. This is a proposed next experiment, not an automatic launch authorized by unused audit budget.

## Reproduction and evidence

Saved input plan: `77301cd2d805f1f5e347cc39fb7ae4e5490915f0deeaf1325a1d4028229ee3f7`. New aggregation protocol: `configs/saved_analysis_protocol.json`. Per-case source hashes, all paired rows, solver records, profiles, failure ledger and resource scope are saved in `results/`. Completion review decisions and their precise limitations are in `reviews/`. No PDF or integrated original thesis was produced; `manuscript/replacement.tex` is explicitly replacement text.

Read-only completed-handoff check from the project root:

```powershell
python -B iteration_24/code/verify_handoff.py
```

Reproduce descriptive tables into a new directory (the script refuses overwrites):

```powershell
python -B iteration_24/completion/code/summarize_completed.py --output-dir iteration_24/completion/reproduction_01
```

A's standalone raw-metadata audit is `completion/code/A_metadata_audit.py`; it performs no likelihood, fitting or GPU evaluation. Do not run a resume command to analyze this completed run. The final completion manifest binds the exact saved cases, ledgers, code, outputs and reviews.
