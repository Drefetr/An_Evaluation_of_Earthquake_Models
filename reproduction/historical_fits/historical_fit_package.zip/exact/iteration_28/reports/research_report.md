# Iteration 28: spatial and magnitude/source heterogeneity

The audit narrows the explanation of the earlier predictive failure. The first period's loss is a regional event-intensity deficit partly offset by a favorable compensator contribution. Negative event components occur in every occupied geographic cell, both native ML and Mw groups, and all declared magnitude/depth groups. They are not confined to one coarse location or label. Replacing archived magnitude values barely changes the model comparison and leaves every fold's sign unchanged. These observations do not identify a physical cause or prove that catalogue heterogeneity is harmless.

## Frozen scope and what ran

All 612 test events were joined to the archived 913-event primary catalogue and the exact iteration 27 saved predictions. The focus on fold_50 was selected because its loss was already known. The data, periods and recipes had been inspected before; freezing this follow-up makes it reproducible, not confirmatory. The original manuscript code and frozen catalogue remain unavailable; these are independently reconstructed results on the separately archived GeoNet snapshot, with a 1960 origin and 2026-10-15 exclusive end.

Before new grouped outcomes, A/C reviewed two frozen protocols, 42 sources and 30 input hashes. All 90 fixed-parameter evaluations completed: 72 actual temporal-bin scores and 18 magnitude-value sensitivity scores, using orders 16/32. There were no new fitted models, optimizations, scientific simulations or catalogue downloads. All 45 order-pair controls and 18 additivity controls passed; maximum absolute order change 2.13162821e-14, maximum additivity error 1.13686838e-13, below the strict 1e-4 gate. That gate is numerical, not a significance or materiality threshold.

## Where the full temporal loss occurs

For each pair of models, write

\[E=\sum_i\log(\lambda_A(T_i)/\lambda_B(T_i)),\qquad C=\Lambda_B-\Lambda_A,\qquad\Delta\ell=E+C.\]

Marks are common between candidates within each comparison and cancel. Intensities are predictable: the current event's mark does not enter its own pre-event intensity. Histories and all quiet intervals are retained. The compensator is realized integrated intensity along the updating observed history; it is not automatically the future expected count conditional only on the origin.

| Period | Event component E | Regional compensator C | Full score E+C |
|---|---|---|---|
| fold_50 | -33.715205 | +17.197647 | -16.517557 |
| fold_65 | -1.785927 | +1.710650 | -0.075277 |
| fold_80 | -4.430836 | +3.400812 | -1.030025 |

In fold_50, shared inhibition has integrated intensity 115.871595 versus 133.069242 for ML triggering, against 203 observed events. Its lower integrated intensity contributes +17.197647 to the score contrast, while event log-intensity ratios contribute -33.715205. The net is -16.517557. These are paired differences between separately fitted recipes; they do not isolate eta alone from their different nuisance values. No naive Poisson count test is implied.

Four equal-duration bins were fixed for every test period. Each bin was actually integrated with complete preceding history; no event-count allocation or bin refitting was used. Dates in this table are displayed to the day; exact fractional-day boundaries are in the raw scores.

| Bin | UTC dates (end exclusive) | Events | Event E | Compensator C | Full score |
|---|---|---|---|---|---|
| 1 | 1993-05-24 to 1995-11-24 | 130 | -2.891244 | +2.464270 | -0.426975 |
| 2 | 1995-11-24 to 1998-05-27 | 37 | -16.875378 | +7.143815 | -9.731563 |
| 3 | 1998-05-27 to 2000-11-27 | 17 | -8.696131 | +4.642115 | -4.054016 |
| 4 | 2000-11-27 to 2003-05-31 | 19 | -5.252451 | +2.947447 | -2.305004 |

The second bin, approximately late 1995 to mid 1998, has the largest full-score loss, followed by the third. The first bin has many events but little net loss. This is a useful localization, not identification of an earthquake sequence, fault or geologic cause. The full 12-bin results for both contrasts are in the saved CSVs and [temporal figure](../results/publication/temporal_components.png).

## Spatial and mark heterogeneity

The temporal model provides one regional compensator. It does not supply a cell- or magnitude-specific compensator, so the next tables contain **event terms only**. Add the one global C above to the sum for any one marginal classification to recover the full regional contrast. Never add different marginal tables together or describe a cell sum as a fraction of the full predictive loss. The cells have unequal areas and no spatial exposure or completeness model; counts are not spatial rates.

| Cell | Latitude | Longitude | Events | Event sum E | Mean event E | n<5 |
|---|---|---|---|---|---|---|
| lat0_lon0 | -48.5 to -43.5 | 165 to 170 | 40 | -11.240056 | -0.281001 | False |
| lat0_lon1 | -48.5 to -43.5 | 170 to 175 | 3 | -1.267174 | -0.422391 | True |
| lat0_lon2 | -48.5 to -43.5 | 175 to 180 | 0 | +0.000000 | unavailable | True |
| lat1_lon0 | -43.5 to -38.5 | 165 to 170 | 0 | +0.000000 | unavailable | True |
| lat1_lon1 | -43.5 to -38.5 | 170 to 175 | 28 | -9.061725 | -0.323633 | False |
| lat1_lon2 | -43.5 to -38.5 | 175 to 180 | 9 | -2.594521 | -0.288280 | False |
| lat2_lon0 | -38.5 to -33.5 | 165 to 170 | 0 | +0.000000 | unavailable | True |
| lat2_lon1 | -38.5 to -33.5 | 170 to 175 | 0 | +0.000000 | unavailable | True |
| lat2_lon2 | -38.5 to -33.5 | 175 to 180 | 123 | -9.551729 | -0.077656 | False |

All five occupied cells have negative event sums. Per-event penalties differ, but timing and location are confounded, sparse cells are flagged and no geographic significance test was performed. The intensity used here depends on the regional temporal history, not on event coordinates. These patterns therefore support examining spatial structure without identifying local stress transfer. See [the all-event maps](../results/publication/event_component_maps.png); they contain no fault or geology layer.

| Classification | Category | Events | Event sum E | n<5 |
|---|---|---|---|---|
| magnitude_band | M5_5.5 | 166 | -28.744451 | False |
| magnitude_band | M5.5_6 | 28 | -2.591890 | False |
| magnitude_band | M6_6.5 | 4 | -1.738086 | True |
| magnitude_band | M6.5_plus | 5 | -0.640778 | False |
| depth_band | depth_le10 | 31 | -10.177861 | False |
| depth_band | depth_10_20 | 140 | -12.994545 | False |
| depth_band | depth_20_40 | 32 | -10.542798 | False |
| native_label | M | 0 | +0.000000 | True |
| native_label | ML | 162 | -24.635054 | False |
| native_label | MLv | 0 | +0.000000 | True |
| native_label | MS | 0 | +0.000000 | True |
| native_label | Mw | 41 | -9.080150 | False |
| native_label | Mw(mB) | 0 | +0.000000 | True |
| native_label | mB | 0 | +0.000000 | True |

ML and Mw both have negative event components in the main period; neither a switch to a new native label nor one magnitude category alone accounts for all event penalties. Most events are in the lowest magnitude bin, so raw sums must be read alongside counts. Grouping by the current event's magnitude is descriptive association: in this model that mark affects subsequent history, not the intensity at its own occurrence. The groups overlap across classifications and are not independent replications.

Training/test composition was compared within each fold using unsmoothed total variation, 0.5 times the sum of absolute category-proportion differences. This is a descriptive distance with no p-value or causal interpretation.

| Period | Spatial TV | Magnitude TV | Depth TV | Native-label TV |
|---|---|---|---|---|
| fold_50 | 0.225341 | 0.031733 | 0.141368 | 0.050521 |
| fold_65 | 0.521697 | 0.072555 | 0.186278 | 0.417972 |
| fold_80 | 0.255571 | 0.109531 | 0.252650 | 0.964812 |

The largest native-label composition change occurs in the last period, whose inhibition score loss is much smaller than the first. This weakens a simple explanation that the known modern label transition alone caused the dominant 1993-2003 failure. It does not rule out legacy scale differences, observation changes, spatial mixing or omitted parents. Native label M is a network summary, not simply a moment-tensor Mw; labels must not be silently homogenized. Verified primary documentation and limitations are in [A's source audit](A_source_audit.md). The [composition plot](../results/publication/composition.png) shows all declared native labels and magnitude bins.

## Source interfaces: actual differences and a controlled value sensitivity

These are two archived interfaces to the same underlying GeoNet catalogue, not independent physical catalogues. Exact-ID comparison retains 913 common events and one FDSN-only event, 2025p672513. Across 1684 common raw IDs, the audit found 0 changed local filter reason/decision lists. The unmatched event has no retained primary raw row; its absence does not establish which server predicate or revision excluded it. The archived WFS server request used M>=5; FDSN requested 4.9 and then applied the declared local M>=5 filter. Neither archive is declared ground truth.

| Field | Nonzero numeric differences /913 | 95th percentile absolute difference | Maximum absolute difference |
|---|---|---|---|
| time_utc | 270 | 0.00085000 | 1.097041 |
| magnitude | 241 | 4.00E-9 | 0.164143665 |
| depth | 79 | 2.09960E-10 | 7.0 |
| latitude | 34 | 0E-7 | 0.05014419 |
| longitude | 34 | 0E-7 | 0.0846100 |

Timestamp differences are seconds; magnitude differences use native units, depth uses km, coordinates use degrees. Quantiles include all 913 pairs including zeros and use the frozen linear-interpolation rule. Many discrepancies are tiny decimal differences, while maxima identify larger interface differences. The maximum magnitude discrepancy was already recorded in iteration 5 metadata; it is not a new discovery. Raw per-event values remain available. Lexical rounding tags are based on processed CSV literals, including padded timestamp zeros, and must not be interpreted as counts of substantive revisions or differences beyond original instrument/source precision. No independent re-extraction of the archived QuakeML was performed.

The one prospectively selected sensitivity branch replaced magnitudes/excess for the same 913 IDs throughout the entire history. Primary times, coordinates, depth, labels, training beta and every selected parameter/kernel/ratio stayed fixed. The extra FDSN event was not added. This is a counterfactual mixed-interface history, not a retrained FDSN fit or a physical magnitude-scale conversion.

| Contrast | Primary total | Alternate-magnitude total | Signed change | Sign reversals |
|---|---|---|---|---|
| shared_minus_ml | -17.622859365 | -17.617975447 | +0.004883918 | [] |
| omori_minus_ml | +12.458120886 | +12.441651231 | -0.016469655 | [] |

| Period | Contrast | Primary | Alternate magnitudes | Change |
|---|---|---|---|---|
| fold_50 | shared_minus_ml | -16.517557453 | -16.517557453 | +0.000000000 |
| fold_50 | omori_minus_ml | +3.106623109 | +3.106623109 | +0.000000000 |
| fold_65 | shared_minus_ml | -0.075277291 | -0.075277291 | -0.000000000 |
| fold_65 | omori_minus_ml | +2.837707721 | +2.837707722 | +0.000000001 |
| fold_80 | shared_minus_ml | -1.030024621 | -1.025140704 | +0.004883918 |
| fold_80 | omori_minus_ml | +6.513790056 | +6.497320400 | -0.016469656 |

The negative shared-inhibition comparison survives this value replacement, including the dominant first period. This particular archived magnitude-value discrepancy does not account for the earlier failure within the frozen recipe. That is narrower than ruling out magnitude-scale heterogeneity, timing/location differences, changed completeness or measurement error. Shared source history and native labels persist across both interfaces.

## Review, provenance and decision

Source code, rules, inputs, full rows and failures are retained under this new immutable area. The [numerical raw result](../results/numerical_audit/result.json), [exact source comparison](../results/A_source_comparison.json), [publication summary](../results/publication/summary.json) and [frozen inventory](../logs/source_inventory.json) separate prior authorities from newly executed evidence. The source branch verified all 171 files in the prior iteration 27 manifest; no older input/result was repaired. Three actual collaborating reviewers cross-check the final evidence; this is not independent academic refereeing.

Owned numerical execution charged 68.081039/600 seconds; source execution charged 6.617628/60 seconds; publication charged 11.010644/60 seconds. Each includes the explicit 1-second operational closure allowance, not a proved filesystem/scheduler bound. Numerical work used one native CPU thread and no GPU. The separate synthetic preparation benchmark passed 90 evaluations in 63.235514 seconds, with 18 synthetic reference setup evaluations separately recorded. A 7 source tests, C 8 design tests and D 8 numerical tests have their own receipts; their overlapping checks should not be summed as independent evidence. All three PNGs were rendered and visually inspected. No PDF or reconstructed original thesis was produced.

The next useful question is whether a spatially local history and a comparably flexible background improve prediction relative to the regional pooling used here. A proper test needs an explicit spatial conditional intensity and its regional/spatial compensators, not relabeling these event components as local rates. That would be a separately bounded design with matched alternatives and training-only choices. This audit does not justify a large sample-size campaign or establish physical absence of inhibition. First-moment stability, infinite-memory results and sufficient-data questions remain separate prior research strands.

Exact commands and read-only verification are in [reproduction.md](reproduction.md). No interrupted work remains in this audit: 90/90 evaluations, 913/913 source matches and all planned rows completed. The three unfinished iteration 27 horizon cases remain untouched and outside this task.
