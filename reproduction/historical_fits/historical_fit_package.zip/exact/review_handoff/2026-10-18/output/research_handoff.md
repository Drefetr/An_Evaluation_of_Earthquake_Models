# Viscoelastic point-process research: advising review handoff

Prepared 18 October 2026, New Zealand. Evidence through iteration 28.

**Assessment:** no conclusive empirical identification of physical stress-dependent inhibition, or of a shared physical stress/triggering memory, has been achieved. Several restricted mathematical conclusions and controlled numerical findings are positive and substantive. We have narrowed particular explanations and reduced the priority of some follow-ups; we have not ruled out whole physical mechanisms or demonstrated that the catalogue can never be informative.

This is a synthesis for review, not a new scientific experiment. Earlier authorities remain unchanged. Three actual collaborating agents checked the mathematical, inferential and execution synthesis; their reviews are project cross-checks, not independent academic refereeing. The original manuscript's frozen catalogue, fitting code, run logs and LaTeX source remain unavailable. All newer catalogue fits are independent reconstructions.

## 1. What changed since the previous handoff

The earlier handoff, through iteration 16, emphasized a fitted detector's 38% conditional detection frequency at the stronger synthetic inhibition setting. The subsequent work changes its interpretation substantially: **these stipulated observation laws were readily distinguishable when their nuisance values were supplied**. The weak fitted detector is therefore not evidence of an intrinsic information limit for that pair of laws over that horizon. [P16, O19]

The controlled component studies then found substantial detection loss when background level and trend were estimated, even with triggering, beta and both kernels supplied. More generous optimization on ten deliberately difficult histories barely changed the fitted values. Estimating background level alone retained 82% detection after its own null calibration, whereas estimating level and trend retained 45.3%. This is real progress in locating procedure sensitivity, though it does not uniquely attribute that loss to a physical or statistical cause. [BG22, OPT24, ABL25, CAL26]

The latest observed-catalogue comparison gives useful negative predictive evidence: the shared-inhibition recipe loses to triggering alone in each of three disjoint test periods. A stronger Omori triggering recipe does better. The latest spatial/mark/source audit localizes the largest loss in time and shows that one archived magnitude-value discrepancy has almost no effect. It does not fit a spatial model or identify geology. [OBS27, HET28]

| Question | Current answer |
|---|---|
| Have we established physical inhibition in NZ? | No. Neither its presence nor its absence is established. |
| Have we established shared physical memory? | No. Feedback detection and equality of physical kernels are separate questions. |
| Is there a positive theoretical contribution? | Yes, under explicit finite-mode, finite-horizon or auxiliary-system assumptions. |
| Is 38% detection an intrinsic observation-law limit? | No such inference is supported; the known-law test detected all 150 saved alternatives in this experiment. |
| Do the current inhibited recipes improve observed prediction? | No, in the declared exploratory comparisons. This is a negative result about recipes, not a physical exclusion. |
| Have we proved that there are too few events? | No. There is no validated sufficient-event-count calculation for the observed composite problem. |
| Have we exhausted worthwhile research? | No. We have made several repetitions and numerical explanations less attractive, while spatial/background adequacy and observation assumptions remain unresolved. |

## 2. The original paper, data and model boundaries

The original 40-page manuscript is dated 14 October 2026. Its printed page number is one less than its PDF page position. Chapters 3 and 7-11 and Appendix A define the model, theorem and reported earthquake analysis. Chapter 10 reports 1,682 downloaded entries, 1,603 earthquake-typed entries and 913 selected shallow events. The unavailable historical implementation must not be inferred from the supplied iteration-3 numerical checking script. [S1, REV17]

The reconstructed primary snapshot was downloaded from GeoNet WFS on 15 October 2026 at 08:29:36-40 UTC. It selects M>=5, depth<=40 km excluding sentinel -9, longitude 165-180 and latitude -48.5 to -33.5, from 1960-01-01 inclusive to 2026-10-15 exclusive. It contains 913 unique eligible events over 24,394 days. Negative depths other than the sentinel were retained. Exact queries, archived responses and exclusion ledgers are in iteration 5. Matching the old count does not recover the old event list. [D5, HET28]

The primary CSV SHA256 is `feacccb7581d1c4c33f88874cd6b198c41639da6930a7fc35e46f910a594fb3e`. The archived FDSN interface has 914 selections, all 913 primary IDs plus `2025p672513`. These are interfaces/snapshots of one provider, not independent physical catalogues. No new download occurred in this handoff or in iterations 27-28.

The manuscript reports a 24,393-day horizon and beta about 2.494 with its half-bin Aki convention. The reconstructed continuous exponential-mark estimate is 2.849401764894274; the manuscript's adjustment applied to these same new values gives 2.494071218330174. This reconciles an estimator convention, not the missing historical sample. Changing beta also changes productivity normalization and the interpretation of branching. [REV17]

The physical manuscript combines loading-convolution stress, marked depletion and triggering. Its unrestricted empirical optimum has negative b; its constrained b>=0 fit approaches a singular small-b/large-loading limit. The repaired positive nondecreasing-link stability theorem does not cover that negative-b fit. A rounded b=0 in a table is not proof of a finite-parameter no-feedback optimum. [S1, M4, I4]

The new empirical and synthetic diagnostic instead uses an independently specified background:

$$
\lambda_\eta(t)=B(t)e^{-\eta G_s(t)}+nH_e(t),\qquad B(t)=\exp\{a+d(2t/T-1)\}.
$$

G is marked stress memory; H is normalized marked triggering; both use strictly earlier events. A fresh current mark affects subsequent intensity, not its own pre-event intensity. Eta is a diagnostic inhibition coefficient, not the original physical b. The numerical ML kernels are normalized positive finite spectral mixtures, not the exact infinite-memory law. New results about this diagnostic must not be silently transferred to the physical loading model.

Completeness, native magnitude-scale homogeneity, missing M<5/deep/outside-region parents, prehistory and national spatial pooling remain substantive assumptions. A 1964-onward M5+ sample would not extend a sample already beginning in 1960. A lower threshold or another region requires a new observation/completeness assessment and matched recalibration; no validated such campaign has completed.

<!-- pagebreak -->

## 3. Mathematical conclusions that survived review

The source-level audit found no blocking error in the scoped principal mathematics it examined. This is neither a general theorem certification nor a novelty determination. The following are positive restricted results, not physical empirical conclusions. Detailed assumptions and exact source locations are supplied by the mathematical synthesis and cited source drafts. [REV17, A-MATH]

| Result | Supported conclusion | Essential boundary |
|---|---|---|
| Finite-mode first-moment theorem | Construction/non-explosion, unique invariant law, first moments, stationary balances and convergence in the stated weighted Wasserstein-like cost. | Finite positive modes, upper-bounded stress, fresh marks, finite mean stress drop, mean productivity n<1, appropriate positive nondecreasing half-line-Lipschitz link and the stated coupling conditions. Not total-variation mixing or a nonstationary-background theorem. |
| Heavy-tail stationary moments | Corresponding stationary quadratic stress/excitation moments actually diverge when their jump transforms have infinite second moments and stationary event rate is positive. | Does not refute a finite-variance theorem under its own stronger assumptions. First-moment ergodicity can coexist with infinite variance. |
| Finite-horizon kernel approximation | A quantitative bound with strengthened uniform Lipschitz control; qualitative convergence can be recovered by release localization under local control. | No interchange of stationary and infinite-mode limits; no constants uniform as the slowest mode tends to zero. |
| Exact-memory counterexamples | Characteristic-function arguments establish non-tightness in no-feedback/no-triggering compensated-Poisson submodels: unit drops at alpha<=1/2; Pareto index q in (1,2) at alpha*q<=1. | Not instability of active nonlinear inhibition. Latent stress non-tightness need not make the no-feedback observed catalogue ill-defined. |
| Excitation-inclusive linear response | Positive integrable auxiliary response, integral 1/chi and a polynomial tail, with a weak-feedback crossover result. | Constant-mark frozen-slope auxiliary system; nonlinear stress-band/tightness control remains unproved. |
| Identifiability | At zero feedback a separately varied stress kernel disappears when diagnostic background and triggering are fixed, or physical loading/initial stress remain finite. Positive-feedback full-law identification is available under strong specified assumptions. | Known transforms, positive deterministic background, empty history and unbounded mark support in the positive result; no stable finite-catalogue verification guarantee, and unobserved-lag tails remain unidentified without continuation assumptions. |
| Visibility and weighted score | On the same fixed history at the same time, additive inhibition cannot remove more than the background fraction of total intensity. Appropriate weighted scores can have finite second moments despite infinite raw transformed-mark variance. | No blanket Fisher/Wilks theory, boundary chi-square calibration or universal event-count formula. |
| Positive-eta finite-horizon response | Square-integrable inhibition score and a derivative identity for fixed complete-data tests/functionals. | Fixed nuisance law, positive eta, finite horizon and domination assumptions; not uniform at eta=0 or stationary/infinite-history theory. |
| Background amplitude profiling | Exact conditional score balance and profile derivatives; interior log-amplitude curvature is positive at the balanced root. | Finite-path likelihood calculus, active-boundary qualifications, no global joint-convexity or ensemble-information claim. |

The positive-eta score bound is E(S_eta^2)<=4A/(e^2 eta^2), where A is integrated deterministic background. The power derivative for a fixed everywhere-defined rejection rule is a score covariance of unrestricted sign. A fixed rule may internally fit parameters; what matters is that the entire algorithm and all data outcomes are defined. This result does not justify an adaptively changed or incomplete procedure. [R15]

The auxiliary response transform is `[s+(1-n)*tau^(-alpha)*s^(1-alpha)+chi]^(-1)`. Its positivity and integrability are mathematically useful but do not settle nonlinear exact-memory ergodicity. At an interior conditional amplitude optimum, integrated background equals the sum of fitted background event shares. These shares are likelihood weights, not identified physical parent assignments or a stationary conservation law. [L4, AMP23]

The literature/contribution audit identifies prior marked ML triggering and hybrid correcting/triggering models. Remaining equation-level equivalence and inaccessible-full-text questions prevent a novelty certificate. The manuscript already acknowledged the heavy-tail second-moment problem and absence of a proved exact-ML ergodicity theorem; these limitations must not be advertised as newly discovered. [N4, REV17]

## 4. Observed-catalogue evidence

### Initial reconstruction and calibration

The first independent reconstruction gave a very small inhibition gain in sample and worse chronological test scores. The observed feedback statistic was 0.7036472; the separate-versus-shared-scale statistic was 0.0829952. The completed fitted-law calibration retained 1,999 null cases per restriction, 3,998 total. Corrected ranks were 0.365 and 0.263, respectively; neither restriction was rejected at 5% by that procedure. These are conditional ranks, not probabilities that either null is true, and non-rejection does not establish shared memory. [D5, B12]

The supplied compact source review recomputed ten saved-parameter scores, reaggregated all 3,998 calibration-statistic rows into the two observed ranks, and reproduced all 300 power decisions, but lacked individual histories and complete fits. Its 82 selected passing tests and file hashes do not constitute full historical reproduction. Later project stages located and used raw saved histories for their own declared comparisons; that does not retroactively expand the earlier review's scope. [REV17]

### Three-period predictive comparison

Iteration 27 fitted training prefixes with 301, 504 and 659 events, then scored disjoint test blocks with 203, 155 and 254 events. The common training beta is a mark-only plug-in, not a joint marked-intensity MLE. Full marked scores retain event counts, quiet exposure, complete compensators and updating strictly prior test history. All 477 planned records, 411 optimizer start lineages and 30 selected numerical controls completed. [OBS27]

| Test score contrast | 1993-2003 | 2003-2013 | 2013-2026 | Total |
|---|---:|---:|---:|---:|
| Shared inhibition minus ML triggering | -16.517557 | -0.075277 | -1.030025 | -17.622859 |
| Omori triggering minus ML triggering | +3.106623 | +2.837708 | +6.513790 | +12.458121 |

Exact boundaries are in the frozen protocol. The period labels above are rounded. Shared inhibition's nonnegative training gains were +2.731009, +0.302486 and +0.143866; an exact null floor makes a nonnegative training gain partly built into fitting. Its test ordering is therefore more informative than the sign of the training improvement.

These are exploratory, reused-period recipe comparisons. Continuous Omori refinement and the finite ML kernel grid do not have identical flexibility. The result favors the declared Omori recipe predictively; it does not identify a physical triggering law, fairly rank all equally flexible families or isolate eta while holding nuisance values identical. Residual diagnostics also show changing calibration across periods, so a winning candidate is not thereby an adequate physical model.

### Spatial, magnitude and source audit

In the first test period, shared-minus-ML event log-intensity terms sum to -33.715205; the regional compensator contribution is +17.197647, giving -16.517557 overall. Four fixed equal-duration bins reproduce the full integral. All four contrasts are negative; late 1995 to mid 1998 has the largest bin loss, -9.731563. [HET28]

All five occupied coarse spatial cells and both nonempty native ML/Mw groups have negative event terms. Location and time are confounded; cells have unequal areas and no spatial exposure model. Marginal group tables reuse events. There is one regional compensator, so these are not local likelihoods, local rates or causal fractions of loss. Current magnitude grouping is descriptive; the current mark does not cause its own predictable intensity.

The source comparison retains 913 matched IDs and the FDSN-only event separately. It found no changed local filtering decisions among 1,684 common raw IDs. The maximum magnitude difference, 0.164143665, was already known from iteration-5 metadata. Replacing only matched archived magnitude values throughout the history, keeping clocks, beta and all fitted recipes fixed, changes the shared-minus-ML total from -17.622859 to -17.617975, with no fold sign reversal. This particular mixed-interface sensitivity does not explain the predictive loss. It does not rule out legacy magnitude scales, timing/location changes, incompleteness or measurement error.

<!-- pagebreak -->

## 5. Synthetic discrimination: positive procedural findings

The latest paired simulation study used eta=0.2839974288868791 and eta=0.4885010300470942. Mean achieved fixed-history intensity suppression was 14.159% and 19.360%, respectively. Counts remained random; this is not a controlled percentage reduction in long-run earthquake counts. All 300 full-fit cases in 150 fresh pairs completed, separately from the planning pilot. [P16]

The original fuller fitted detector detected 49/150 (32.7%) and 57/150 (38.0%). The adjusted-minus-original paired difference was 5.33 percentage points with descriptive paired Monte Carlo SE 4.71 points. This did not establish the planning pilot's apparent large improvement. More replications of the same procedure could refine this frequency but would not resolve why sensitivity was lost.

### Known laws versus estimation

The oracle used the same observed marked histories under both fully specified intensities, the complete compensator difference, fixed mark law and its own null calibration. The completed CUDA evaluation accepted all 2,149 histories: 999 null references, 1,000 disjoint held-out null checks and 150 stronger-setting alternatives. No count conditioning or removal of extreme histories was introduced. [O19]

| Procedure | Alternative detections | Held-out null rejections | Nominal conditional exact 95% detection interval |
|---|---:|---:|---|
| Known-law likelihood ratio | 150/150 (100%) | 50/1000 (5.0%) | 97.57-100% |
| Eta estimated; nuisance supplied | 150/150 (100%) | 49/1000 (4.9%) | 97.57-100% |
| Level estimated; trend supplied | 123/150 (82.0%) | 46/1000 (4.6%) | 74.9-87.8% |
| Level and trend estimated | 68/150 (45.3%) | 44/1000 (4.4%) | 37.2-53.7% |
| Earlier fuller fitted detector | 57/150 (38.0%) | 50/1000 (5.0%) | 30.21-46.28% |

The original iteration-16 decisions used 1,999 references and rank `(1+count(Dref>=D))/2000`. Iterations 19, 21 and 26 use each procedure's own 999 references and rank `(1+count(Dref>=D))/1000`, with 1,000 separate null queries. The historical fuller-detector row above is its iteration-19 recalibration; its 57/150 count happens to remain unchanged after that reference split. It is not an independent repeat of the iteration-16 result.

Each procedure uses its own matched null calculation; oracle critical values are never substituted for fitted-test critical values. The first four rows supply triggering, beta and both kernels. The last row additionally estimates/searches them under its own earlier recipe. Consequently the rows do not form an additive causal decomposition. Similar realized null rates do not prove exactly equal population size or uniform calibration over the composite null. [O19, BG22, CAL26]

The numerical frequencies and intervals condition on realized reference banks and the specified generating law. They omit bank construction, generating-parameter uncertainty and adaptive procedure selection. The null queries were held out of threshold construction, not held untouched throughout the research history. The ideal conservative add-one rank theorem requires exchangeability of the entire selection-plus-scoring rule; that condition is not proved retrospectively for this adaptively selected study, with ID-specific clock/repair provenance retained. Newly freezing code does not make the comparisons confirmatory. There is a substantial zero atom in the level-only reference statistics (604/999 exactly zero), so ties and the declared add-one rank convention are material. All 1,150 level-only decisions remained resolved under the declared empirical numerical envelopes; these are sensitivity controls, not rigorous integration-error bounds.

The supplied-background versus estimated-background contrast establishes a strong difference between these procedures at this law. It supports looking for estimation/test loss rather than declaring the two laws intrinsically indistinguishable. Neyman-Pearson optimality applies only to the exact calibrated simple-law test for that pair, not to arbitrary mechanisms or plug-in composite tests. A finite 150/150 frequency is neither certainty nor a rigorous numerical upper bound on possible power.

### What the ablations did and did not explain

On two previously frozen reference histories, nuisance projection onto only a,d,n retained 10.82% and 3.26% of the raw eta squared-score norms. This is pre-existing finite-path evidence of overlap, not ensemble Fisher information or a demonstrated explanation of 38% power. [G13]

An initial component benchmark stopped on an extreme history. A staged implementation subsequently completed the supplied-nuisance and estimated-background study. Then a distinct profile/Powell robustness audit gave no material improvement on ten deliberately difficult histories: the largest phase NLL improvement was 1.95e-8 and largest direct-statistic change about 3.90e-8. This weakens inadequate solver time as an explanation on that selected set. It does not prove global optimization or validate every historical fit. [OPT24]

The ten-history raw-statistic pilot showed larger level-only than trend-only contraction on its four alternative paths. It did not estimate power. The full level-only calibration then retained 82% detection, substantially above the 45.3% level-plus-trend result. Thus a large raw-statistic contraction cannot be read as an equal-size power loss without recalibrating the null. The missing trend-only matched-null cell and interactions prevent assigning the loss uniquely to trend. Level-only and level-plus-trend had 61 versus six discordant alternative detections; neither rule uniformly dominated pathwise. [ABL25, CAL26]

## 6. What can reasonably be deprioritized

These are conditional research decisions, not universal exclusions.

| Avenue or explanation | What the work now supports |
|---|---|
| Treating 38% as an intrinsic shortage of information | Unsupported for the stipulated simple-law pair; the supplied-law result is strongly positive. The observed-data composite problem remains open. |
| Merely increasing optimizer limits across all cases | Low priority after the selected difficult-set robustness audit; no global guarantee follows. |
| More Monte Carlo replications of the same 38% procedure | Would improve precision, not explain sensitivity loss or improve model adequacy. |
| Explaining loss by the tested archived magnitude values | Low priority within the fixed-recipe sensitivity; broader observation heterogeneity remains open. |
| Interpreting larger raw LR as better calibrated detection | Invalid without method-specific null calibration; the level-only follow-up directly illustrates this. |
| Using 913 events as a universal 5% precision guarantee | Invalid: effect definition, dependence, nuisance overlap, calibration and observation law determine information. |
| Using non-rejection to validate shared memory | Unsupported, especially with an unidentified stress kernel under zero feedback. |
| Treating CUDA speed or numerical agreement as physical evidence | Unsupported. They make controlled studies practical and validate finite computations. |
| Launching a large horizon/lower-threshold/multi-region campaign now | Not justified by these results alone; first specify the observational target and adequate competing models. |

It is reasonable to conclude: **we have no conclusive empirical evidence for the proposed physical mechanism, and we have learned enough to avoid several uninformative repetitions.** It is not reasonable to conclude that nothing positive was established, that spatial/geological mechanisms have been ruled out, or that more suitable data and models cannot help.

## 7. Completion, preservation and continuation

The initial 3,998-row calibration and 300-row paired study completed after earlier recovery stages. Iteration 19's 2,149-history oracle evaluation completed. The staged background comparison completed both procedures on all 2,149 histories. Iteration 24's ten-history robustness audit, iteration 25's bounded ablation and iteration 26's 2,149 fresh level-only fits completed. Their earlier preparation/status files are historical; completion reports govern the current conclusion.

Iteration 27's observed five-family analysis completed. Its separately budgeted horizon feasibility pilot closed with 27 of 30 planned horizon-prefix cases complete, two pending and one resource-limited. Each case compares null and alternative fits. Whole-pilot acceptance is false. Five null paths per horizon cannot calibrate a 5% add-one test; no horizon power or sufficient-N estimate exists. Those three cases were not resumed in iteration 28 or this handoff. They must remain explicit, not converted into non-rejections. [OBS27]

Iteration 28 completed all 90 fixed-parameter evaluations, 45 order pairs, 18 additivity checks and 913 source matches, without new fitting, simulation or downloads. All three scoped completion reviews and the final read-only verifier passed. Its manifest covers 71 files and rechecks all 171 iteration-27 manifest files unchanged. Its source/input closure has 72 unique pins. No new scientific work is launched by this handoff.

The portable review bundle intentionally omits most per-case histories, full optimizer trees, large runtime logs, dependency environments and caches. It is suitable for source/summary/selected-code review, not full historical regeneration. The exact archive inventory, hashes, exclusions and canonical project paths are provided separately. Run scripts in the packet are evidence; do not launch resume or scientific campaigns merely to review it.

From the authorized full project, current read-only verification is:

```powershell
python -B iteration_28/code/verify_completion.py
python -B iteration_27/code/verify_completion.py
```

These commands verify evidence bindings and selected source-join arithmetic; they do not repeat likelihood evaluation, fits or simulations. Earlier stages' individual verification commands and source authorities are listed in the execution/provenance synthesis. Reproduction commands that generate new tables must target fresh output paths. Do not overwrite a sealed authority.

## 8. Questions for the advising agent

1. Is the defensible contribution now a restricted first-moment/identifiability analysis plus negative predictive evidence and controlled nuisance-sensitivity results, rather than a claimed empirical discovery of shared physical memory?
2. Do the mathematical source assumptions justify every theorem wording, especially finite versus infinite memory, known transforms, positive eta and fixed complete-data tests? Which unresolved literature equivalence questions must still be checked?
3. Do the conditional calibration and selected-set optimizer qualifications adequately limit the component-study interpretation? Does any language still imply an intrinsic information bound or a causal decomposition?
4. Does the observed predictive loss and spatial/mark audit warrant a minimal spatial conditional-intensity comparison with comparable background flexibility, or should the manuscript stop at the restricted negative result?
5. Would the remaining trend-only calibrated cell change that decision enough to justify its cost? It is not automatically the best next experiment merely because it is the missing cell.
6. What minimum observation/completeness and competing-model requirements should be satisfied before collecting a larger/lower-threshold or multi-region corpus?

The immediate next action is this advising review. If research continues, the most useful substantive target is a minimal, explicitly spatial predictive comparison with matched background flexibility and proper spatial compensators, under a separately bounded protocol. A well-supported negative conclusion and a narrower manuscript are acceptable outcomes; no positive physical result should be forced.

## Evidence key and reading order

Paths below are relative to the full project root and are preserved in the portable packet when selected. The machine-readable source register records exact hashes; a citation is evidence of what a source supports, not certification of all of its history.

| Key | Source / exact scope |
|---|---|
| S1 | `inputs/manuscript_v2.pdf`; Chapters 3,7,9-11 and Appendix A; original reported results only. |
| REV17 | `AUDIT_REPORT.md`; Sections 1-6; `saved_results_checks.json`; compact source review through iteration 16. |
| M4 | `iteration_4/reports/A_finite_mode_audit.md`; Sections 1-6 and `iteration_4/manuscript_revisions/A_theorems.tex`. |
| L4 | `iteration_4/reports/B_memory_response.md`; `iteration_4/manuscript_revisions/B_propositions.tex`; no-feedback and auxiliary results. |
| I4 | `iteration_4/reports/C_identifiability.md`; `iteration_4/reviews/A_statistical_math_review.md`. |
| N4 | `iteration_4/reports/E_literature.md`, `iteration_4/reports/literature_matrix.csv` and `iteration_4/sources/references_verified.bib`; equation-level novelty limitations. |
| D5 | `iteration_5/reports/research_report.md`; `iteration_5/data/processed/catalogue_metadata.json`; reconstructed fits and data. |
| B12 | `iteration_12/results/aggregate/2026-10-16T061247128773_0000/summary.json`; completed 3,998 calibration rows and lineage. |
| G13 | `iteration_13/reports/reference_score_geometry.md`; saved matrices and conditional projection. |
| R15 | `iteration_15/reports/power_response_corollary.md`; positive-eta response and fixed complete-data-test scope. |
| P16 | `iteration_16/reports/research_report.md`; final 150-pair study, not its preparation/planning pilot. |
| O19 | `iteration_19/reports/completed_evaluation.md`; accepted oracle analysis and exact procedure comparisons. |
| BG22 | `iteration_22/reports/research_report.md`; accepted iteration-21 analysis, not its earlier feasibility-only report. |
| AMP23 | `iteration_23/reports/background_balance_corollary.md`; conditional finite-history calculus. |
| OPT24 | `iteration_24/completion/reports/research_report.md`; completed selected-ten optimizer audit. |
| ABL25 | `iteration_25/completion/reports/research_report.md`; raw-statistic pilot, not calibrated power. |
| CAL26 | `iteration_26/completion/reports/research_report.md`; full matched-null level-only calibration. |
| OBS27 | `iteration_27/reports/research_report.md`; observed complete comparison and incomplete horizon pilot. |
| HET28 | `iteration_28/reports/research_report.md`; temporal decomposition and descriptive spatial/mark/source audit. |
| A-MATH | `review_handoff/2026-10-18/reviews/A_mathematical_synthesis.md`; current source-section/assumption audit. |

Read this synthesis first, then REV17 and the three current reviewer syntheses. For the changed interpretation, prioritize O19, BG22, CAL26, OBS27 and HET28. Consult original derivations and machine-readable summaries before accepting a central claim. The earlier 16-iteration handoff remains historical and must not be read as the current endpoint.
