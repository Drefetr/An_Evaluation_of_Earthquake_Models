# Positive-eta response of a fixed complete-data test

Under the assumptions of the [positive-eta response proposition](positive_eta_response.md), or its [finite-horizon kernel extension](finite_horizon_kernel_extension.md), let `I(history)` be a fixed bounded measurable rejection indicator in `{0,1}`, defined on every admissible complete-data history. The null reference bank, fitting/selection rule, threshold, and any auxiliary randomization law are fixed independently of the true generating inhibition u. Estimated nuisance parameters and nonsmooth model selection are permitted: they are part of the fixed measurable mapping from data to I. The rule must also specify its decisions for empty or degenerate histories. Then `p(u)=E_u I` is C1 for `u>0`, and

`p'(u)=E_u[I*S_u]=Cov_u(I,S_u)`.

There is no direct fixed-history derivative term, because I does not take the true u as an input. The covariance has no proved sign: stronger inhibition does not, by this argument, guarantee greater detection probability. This is an exact restricted response statement under the specified generating family, not evidence that the currently observed power increases or decreases.

**Proof.** On a compact positive interval `[a,b]`, the preceding reports give `L_u=dP_u/dP_0`, `partial_u L_u=L_u*S_u`, `E_u S_u=0`, and `E_u S_u^2<=4*A/(e^2*u^2)`, where `A=integral_0^T B(t)dt`. Differentiating the finite likelihood product gives the integrable envelope

`|partial_u(L_u*I)| <= exp(A)*(A+N)/(ea)`.

Here `E_0 N<=A/(1-n)`, and the path derivative is continuous in u. Dominated convergence proves C1 and the derivative identity; no derivative of I with respect to the data is taken. Cauchy-Schwarz then gives

`|p'(u)| <= 2*sqrt(A*p(u)*(1-p(u)))/(eu) <= sqrt(A)/(eu)`.

Also `E_u[(I*S_u)^2]<=4*A/(e^2*u^2)`, so this response integrand has finite variance at every positive u even when the raw stress-mark second moment is infinite. The bounds are not uniform at u=0 and imply no null-boundary asymptotics, efficiency theorem, or useful numerical precision by themselves.

The actual numerical workflow retains capped, failed, or otherwise unresolved decisions as **unknown**. They are not zeros for I, and complete-case conditioning does not estimate the p defined here. Applying the corollary requires a fully specified complete-data rule and valid evaluation of its generating-law score. It could motivate a separately declared gradient diagnostic using a single fitted decision per simulated draw, together with a score calculation; no algorithm, variance improvement, or compute saving has been demonstrated or implemented. Fixed external randomization can be included by augmenting the path space with a u-independent auxiliary variable. This note inspects no power outcome, changes no experiment, and makes no novelty claim.
