# Mechanism, refinement and focused power comparison

The correction increased the **synthetic inhibition coefficient**, with nuisance parameters, mark law, kernels and observation horizon fixed. For the current-horizon 20% setting eta changed from 0.2839974288868791 to 0.4885010300470942. Fresh prior validation moved its average fixed-history suppression from 14.235% to 19.123%, with MCSE 0.467 percentage points for the latter. Those are calibration results, not evidence of a newly discovered NZ effect. The current study measures whether the corrected generator is easier for the existing test to detect.

Authoritative terminal analysis: `iteration_15/results/analysis/2026-10-16T083404035350_0000/summary.json`, SHA256 `36536a408db356124458ed008af008a05979bd466427adf6a96b78d2e1434bb4`. **50/50 main cases validated**; the two independent timing cases are excluded. The fixed balanced allocation is 25 fresh pairs, using the same seed within each pair and independent assignments across pairs.

## Actual detection comparison

| Generating setting | Detections/planned | Conditional estimate | Exact 95% arm interval | Unknown |
|---|---:|---:|---|---:|
| Original | 6/25 | 24.0% | [9.4%, 45.1%] | 0 |
| Adjusted | 11/25 | 44.0% | [24.4%, 65.1%] | 0 |

![Conditional arm intervals and paired decisions](figures/power_comparison.png)

Paired outcomes: neither=12, original only=2, adjusted only=7, both=4, unknown=0. The observed adjusted-minus-original detection difference is **20.00 percentage points**; its descriptive paired MCSE is **11.55 percentage points**. Possible-completion accounting bounds are [0.2, 0.2]. They are not confidence intervals. Separate arm intervals are not an interval for the paired difference. No McNemar, Wilks or normal-confidence conclusion is attached to this small pilot.

Both arms use the same **1,999 matched known-null reference statistics** and full estimator. The statistic is twice the null-minus-separate-stress-scale fitted NLL difference. A decision rejects when `(1+count(Dref>=Douter))/2000 <= .05`, retaining ties. This is known-law screening conditional on the saved bank, not the power of the full per-catalogue fitted-null bootstrap. Arm intervals omit uncertainty in the common reference bank, generating-law choice and calibrated eta. Iteration 13's primary bank had 39 references; comparing its old eight-draw percentage directly with this study would mix test-rule and generator changes.

## Signal and event availability

| Setting | Mean achieved suppression, validated cases | Mean complete-simulation count | Complete-count range |
|---|---:|---:|---|
| Original | 14.0% | 583.52 | 449–1663 |
| Adjusted | 20.4% | 456.48 | 387–539 |

Counts remain random over fixed horizons. Means are withheld for incomplete full samples, and prefix counts remain separately in the saved outcomes. Heavy-tailed amplitudes do not justify finite count variance or Gaussian count intervals. Larger imposed inhibition changes the number and arrangement of events as well as their intensity contrast. Background, triggering and kernel parameters are re-estimated equally in the fitted candidates. No direct conversion from a stronger contrast to a power multiplier or catalogue-size saving is warranted.

## What resolved the calibration mismatch

The diagnostic intensity is `lambda_eta=B*exp(-eta*G)+n*H`. Eta suppresses its background component. For one fixed history the total fractional contrast is `pB0*(1-exp(-eta*G))`, with `pB0=B/(B+nH)`. It increases and saturates; the triggering contribution bounds how much total intensity can be removed. Calibrating this average on one uninhibited reference path did not hold it fixed after inhibition changed future events and event-time weighting.

The correction used a separate simulation grid of achieved catalogue means, adjacent interpolation, and then fresh independent validation. It changed no observed-catalogue fit or physical loading coefficient. The mathematical review now makes the changing-history contribution explicit: under stated finite-horizon common-mark assumptions, at positive eta

`d E_eta[F_eta]/d eta = E_eta[partial_eta F_eta] + Cov_eta(F_eta,S_eta)`.

The direct term is nonnegative; no sign for the path-law covariance is established. The score second moment is bounded by `4*A/(e^2*eta^2)`, where A is integrated background. This remains a restricted positive-eta result, not a boundary inference, stationary ergodicity, full Fisher-information or power theorem. The exact likelihood/response derivation and its explicit empty-catalogue convention are in `positive_eta_response.md`, separately reviewed in `../reviews/C_positive_eta_response_review.md`.

The separately reviewed `finite_horizon_kernel_extension.md` weakens the bounded-trigger assumption to a normalized integrable density, including a singularity at zero, with bounded finite-window stress loading. An explicit shared survival/density example is `phi(t)=1/(1+t^alpha)` and `h(t)=alpha*t^(alpha-1)/(1+t^alpha)^2`, for alpha between zero and one. It has long stress memory and singular triggering yet a valid finite-horizon construction and response identity. This establishes neither stationarity nor equivalence to a Mittag–Leffler kernel, and does not change the finite-mixture numerical experiment.

For a fixed, everywhere-defined complete-data rejection rule I, the reviewed corollary gives `p'(eta)=Cov_eta(I,S_eta)`. There is no positive direct-effect term because the decision rule does not see the true generating eta. Its sign is unrestricted. This supports a future score-based power-sensitivity diagnostic, without a numerical or efficiency prediction. Actual resource failures remain unknown outcomes rather than zero indicators; no complete-case shortcut is justified. See `power_response_corollary.md`.

## Useful further refinement

The next refinement should follow detection performance under the validated settings. Repeatedly nudging eta until a 25-run mean reads exactly 20% can chase Monte Carlo variability; the prior 19.123% already met the frozen one-percentage-point practical tolerance. Tighter effect calibration requires more independent precision and a new validation batch. A fixed-history Newton step omits the history-distribution response term.

Robust mechanism discrimination additionally needs comparable background flexibility, altered stress/triggering scales, an Omori-type triggering benchmark, and both raw-moment conditions for a finite-variance mark control. Those contrasts are unexecuted here. The same is true of catalogue completeness, missing prehistory and spatial/geological alternatives. A stronger synthetic effect alone establishes none of those distinctions.

## Numerical review and executed scope

Every validated new catalogue retains the complete 234-record/162-start estimator, beta refitting, original declared failure-only recovery tiers, finite/nesting gates and selected CPU32 checks. The numerical procedure was compared to the earlier bank, whose 1,999 sources and gates passed a new law/authority audit. Completed generation, full-fit and validation stages are retained; failed/capped cases are never silently replaced or treated as nonrejections. Any unresolved draw withholds complete-data frequencies and retains the original denominator and pairwise accounting bounds.

The predeclared fixed generating-point audit scored 50 catalogues in 36.490s, with exit status 0. It found 0 better-point witnesses in 100 comparisons; the minimum candidate-minus-selected NLL gap was 0.268255. It uses each dataset's refitted beta and no new optimizer or simulated catalogue; two preselected candidates received independent CPU32 checks. All saved case files remained byte-identical. This excludes this specific missed-fit witness and cannot certify a global optimum. It changes no primary fits or rejection decisions. Full authority: `results/generating_point_audit.json`, SHA256 `5fee0a65a91579e0f2240f6577a835176f6333140e3322f05e1d243830deaaa5`.

Recorded main execution charge is 890.952s, with 32.608s independent timing, 36.490s separate fixed-point scoring and a remaining-main cap of 2247.392s. Their sum is 960.050s against the 2,400s allowance; code development, proof and review time are separate. No larger study or nested bootstrap is launched. Environment, exact sources, seeds, allocation and logs are saved with the plans. These are project review tracks, not independent academic refereeing.

The assumption/claim boundary is detailed in `mechanism_and_refinement.md` and `source_inventory.md`. The original thesis source is unavailable; proposed LaTeX additions are explicitly uncompiled fragments. No thesis PDF is reconstructed. Reproduction and continuation commands are in `../README.md`.
