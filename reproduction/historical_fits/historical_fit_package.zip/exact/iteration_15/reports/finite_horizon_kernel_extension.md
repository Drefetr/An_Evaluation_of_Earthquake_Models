# Finite-horizon extension to unbounded trigger densities

**Decision.** Boundedness of the triggering density h can be removed from the assumptions of [the reviewed positive-eta response proposition](positive_eta_response.md). The conclusions extend to the class defined below, including densities singular near zero. The stress loading remains bounded on each finite window. This analytical extension changes no simulator, approximation, data convention, or running experiment. No numerical work or study outcome was used.

## Assumptions and distinction between the two kernels

Fix T<infinity, empty initial history, and a deterministic measurable background B, nonnegative and finite almost everywhere, with `A=integral_0^T B(t)dt<infinity`. The trigger delay law has a nonnegative Borel density h on strictly positive finite delays:

`integral_0^infinity h(s)ds=1`, with h finite almost everywhere.

It need not be bounded at zero or elsewhere. Changing its values on a Lebesgue-null set does not change the delay law. The stress loading phi is nonnegative, measurable and bounded on `[0,T]`; it need not have finite integral over the infinite half-line. It may be a survival function rather than a density. h and phi need not come from the same family or time scale.

Each event receives a common fresh joint mark `(kappa,g)` independent of the past, with `kappa,g` nonnegative and finite almost surely, `E[kappa]=1`, and `0<=n<1`. Dependence between kappa and g within a mark is allowed. No moment of g is required. The family is

`lambda_u(t)=B(t)*exp(-u*G(t))+n*H(t)`, `u>=0`,

where `H(t)=sum_{t_i<t} kappa_i*h(t-t_i)` and `G(t)=sum_{t_i<t} g_i*phi(t-t_i)`. Every nuisance parameter and the mark law stay fixed as u varies. These assumptions do not include atoms at zero delay, explosive/supercritical branching, infinite amplitudes, or an infinite prehistory.

## 1. A finite dominating process

Construct the noninhibitory process P_0 by Poisson clusters. Immigrants in `[0,T]` form a Poisson process with mean measure `B(t)dt`, so their number is Poisson(A) and finite almost surely. Conditional on a parent's mark, its offspring form a Poisson process at positive delays with intensity `n*kappa*h(s)ds`. Its total offspring count is mixed Poisson with mean `n*E[kappa]=n`.

For one immigrant let Z_j be the size of generation j, with Z_0=1. Fresh marks imply `E[Z_j]=n^j`. Therefore the expected **entire** progeny, including descendants born after T, is

`E[sum_{j>=0} Z_j]=sum_{j>=0} n^j=1/(1-n)`.

Finite expectation implies finite total progeny almost surely. Consequently the finite number of immigrants produces finitely many events altogether, and

`E_0 N(T)<=A/(1-n)`.

This requires no offspring variance or finite mean delay. Delays are strictly positive and absolutely continuous. Conditional on a finite genealogy and its marks, distinct birth times cannot coincide: their difference contains an uncancelled continuous delay or continuous immigrant time. Thus the process is simple. Finite total progeny already excludes a finite-time accumulation, regardless of the density's size near zero.

The construction up to T uses only immigrants before T. Its usual unlabelled predictable intensity follows by adding the immigrant and offspring Poisson compensators: `lambda_0=B+nH`. Directly on every finite path,

`integral_0^T H(t)dt = sum_i kappa_i*integral_0^(T-t_i) h(s)ds <= sum_i kappa_i < infinity`.

Thus the compensator is absolutely continuous and finite even though its density can be unbounded.

## 2. Why the intensity is finite at actual events

For a finite path, h is finite for almost every age, so H and lambda_0 are finite for almost every time. Choose predictable versions of these shot sums; Borel functions of positive ages after stopping times admit such versions. The predictable exceptional set on which lambda_0 is infinite has zero Lebesgue measure pathwise and therefore zero compensator measure. The compensation identity implies that the event count on this set is zero almost surely. Likewise no event occurs where lambda_0=0. One may set the density to a finite value on its exceptional set when writing this argument; the compensator is unchanged.

There is also a direct construction check: absolute continuity of positive delays makes every nonzero age between distinct nodes absolutely continuous, conditional on its finite genealogy. It therefore avoids the null set where h is infinite; birth times similarly avoid the null set where B is infinite. These observations justify finite, positive likelihood factors at actual events rather than merely asserting that the density is finite almost everywhere.

## 3. Existence of the inhibited law and its likelihood

Use the noninhibitory Hawkes history as a candidate process. At a candidate event, accept with probability

`[B*exp(-u*G_accepted)+n*H_accepted]/[B+n*H_reference]`.

The probability lies in `[0,1]` because h and kappa are nonnegative and the accepted history is a subhistory of the reference history. Acceptance depends on the pre-event history, not the candidate's new mark, so accepted events retain the common fresh joint mark law. This constructs a simple nonexplosive P_u with intensity lambda_u. Its event count is bounded by that of the reference construction. No ordering between two different positive-u accepted histories is asserted.

For the likelihood ratio, **lambda_0 is evaluated on the same realized path as lambda_u**; it is not the larger intensity of the rejected-candidate history. Finite-path conditional hazards, with identical conditional mark laws, give

`L_u=dP_u/dP_0=exp(integral(lambda_0-lambda_u)dt)*product_i lambda_u(t_i)/lambda_0(t_i)`.

The integrated intensities are finite by the preceding pathwise bound. G is finite and bounded on each finite path because phi is bounded and all retained g_i are finite. Hence every ratio at an actual P_0 event is positive and at most one, and

`0<L_u<=exp(A)`.

As in the earlier proof, event-count localization and the bounded likelihood martingale justify normalization and remove the stopping. None of these steps uses `sup h<infinity`.

## 4. Which response conclusions carry over

On a fixed finite path H has no u derivative. Thus the earlier score remains

`S_u=-integral [G*b_u/lambda_u]*(dN-lambda_u dt)`, `b_u=B*exp(-uG)`.

At positive u its bracket is bounded by

`integral (G*b_u)^2/lambda_u dt <= integral B*G^2*exp(-uG)dt <= 4*A/(e^2*u^2)`.

The pointwise inequality holds almost everywhere, with the zero-intensity convention. Actual event evaluations are justified above. Therefore S_u is square integrable, has zero mean, and satisfies the same second-moment bound as before.

For the zero-extended event-mean functional F_u from the reviewed proposition, `0<=partial_u F_u<=1/(eu)` still holds. The likelihood-product derivative bound on any compact `[a,b]` with a>0 is unchanged:

`|partial_u(L_u*F_u)| <= exp(A)*(A+N+1)/(ea)`.

It is integrable under P_0 by the cluster count bound. Dominated convergence therefore gives C1 dependence at positive u and the exact response identity

`m(b)-m(a)=integral_a^b {E_u[partial_u F_u]+Cov_u(F_u,S_u)}du`,

where `m(u)=E_u F_u`. The covariance has no proved sign. The previous positive-u response bounds and explicit empty-catalogue convention also carry over: `P_u(N=0)=exp(-A)` for this empty-history model. This extension establishes neither population monotonicity nor regular null-boundary asymptotics.

## Examples and limits of named-family claims

A concrete shared survival/density pair is

`phi_alpha(t)=1/(1+t^alpha)`,

`h_alpha(t)=alpha*t^(alpha-1)/(1+t^alpha)^2=-phi_alpha'(t)`, `t>0`, `0<alpha<1`.

Here h is positive, finite at every strictly positive t, and singular near zero. Since phi(0)=1 and phi tends to zero, `integral_0^infinity h=1`. The survival is bounded by one and behaves as `t^(-alpha)` at long times, so its half-line integral diverges. This is an explicit alternative kernel, not a Mittag-Leffler identity. It demonstrates that shared long memory and a singular triggering density fit the finite-horizon proof without a stationary-prehistory assertion.

For an Omori example with c>0 and p>1, the normalized density is `(p-1)*c^(p-1)*(t+c)^(-p)`. Its bounded survival `(c/(t+c))^(p-1)` has infinite integral when `1<p<=2`, again permitted on a finite horizon. An unnormalized power law, p<=1 in this shifted-density form, or a singular zero-offset specification is not justified by the family name.

A proposed exact Mittag-Leffler trigger is covered only after its particular definition is shown to be a nonnegative normalized absolutely continuous density on positive delays, finite almost everywhere, and its chosen stress loading is bounded on finite windows. A label or near-zero asymptotic alone does not establish those requirements. This report proves the conditional extension rather than claiming every Mittag-Leffler parameterization qualifies. It also does not identify the current finite-mixture numerical surrogate with an exact special-function law.

Nothing here establishes stationarity, infinite-prehistory stress summability, all-parameter score moments, likelihood-ratio asymptotics, computational efficiency, or a power/sample-size formula. The standard cluster and compensation arguments are supplied to document the extension; no novelty claim is made. The previously reviewed response report remains unchanged.
