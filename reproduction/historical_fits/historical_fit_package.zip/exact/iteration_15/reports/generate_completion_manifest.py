"""Inventory new evidence and recheck earlier file equality; not proof certification."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT / "iteration_15"
sys.path.insert(0, str(ROOT / "iteration_6/code"))
from checkpoint_io import read_json, read_sealed, sealed_json, sha256


def main():
    old_path = ROOT / "iteration_14/results/completion_manifest.json"
    old = read_sealed(old_path)
    older_path = ROOT / "iteration_13/results/completion_manifest.json"
    assert sha256(older_path) == old["previous_manifest_sha256"]
    older = read_sealed(older_path)
    earlier = []
    for manifest in (older, old):
        checks = [dict(path=f["path"], passed=sha256(ROOT/f["path"]) == f["sha256"])
                  for f in manifest["files"]]
        assert all(c["passed"] for c in checks), "Earlier artifact changed"
        earlier.extend(checks)
    supplied = read_json(ROOT / "SOURCE_MANIFEST.json")
    inputs = [dict(path=f["path"], passed=sha256(ROOT/f["path"]) == f["sha256"])
              for f in supplied["files"] if f["path"].startswith("inputs/")]
    assert len(inputs) == 7 and all(c["passed"] for c in inputs)
    summary_path = AREA / "results/analysis/2026-10-16T083404035350_0000/summary.json"
    assert sha256(summary_path) == "36536a408db356124458ed008af008a05979bd466427adf6a96b78d2e1434bb4"
    summary = read_sealed(summary_path)
    assert summary["all_planned_validated"] and summary["validated"] == 50
    assert summary["R"] == 25 and summary["B"] == 1999
    assert summary["paired"]["table"]["unknown"] == 0
    for name in ("C_final_power_review.json", "C_supplementary_review.json"):
        assert read_sealed(AREA / "reviews" / name)["passed"]
    read_sealed(AREA / "results/generating_point_audit.json")
    target = AREA / "results/completion_manifest.json"
    files = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=sha256(p))
             for p in sorted(AREA.rglob("*")) if p.is_file() and p != target
             and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts
             and p.suffix not in (".pyc", ".lock", ".tmp")]
    sealed_json(target, dict(created_utc=datetime.now(timezone.utc).isoformat(),
        provenance_scope="File equality and saved execution counts; not proof certification",
        previous_manifest_sha256=sha256(old_path), earlier_files=earlier,
        earlier_iteration_13_14_unchanged=True, original_inputs=inputs,
        authoritative_summary=summary_path.relative_to(ROOT).as_posix(),
        summary_sha256=sha256(summary_path), validated_main_cases=50,
        completed_pairs=25, unknown_main_cases=0, timing_cases_excluded=2,
        scientific_execution_charge_seconds=960.0504035,
        larger_study_launched=False, files=files, file_count=len(files),
        exclusions=["this manifest", "__pycache__", ".pytest_cache", "pyc/lock/tmp"]))
    print(f"Recorded {len(files)} new files; {len(earlier)} earlier files and seven supplied inputs unchanged.")


if __name__ == "__main__":
    main()
