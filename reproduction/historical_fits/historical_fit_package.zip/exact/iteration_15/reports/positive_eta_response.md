# A restricted finite-horizon response identity at positive inhibition

**Decision.** The proposed likelihood-response identity is valid under the explicit assumptions below. It separates the nonnegative direct effect of eta on a fixed history from a history-reweighting term of unrestricted sign. It supplies neither a population monotonicity theorem nor an efficiency or detection-power claim. This is an analytical diagnostic for a known generating law; no simulation, fitting, or iteration 15 outcome was inspected for this report.

## Scope and assumptions

Fix a finite horizon T, empty initial history, and a deterministic nonnegative background B with `A=integral_0^T B(t)dt<infinity`. Assume B is finite almost everywhere. Hold every nuisance parameter and the fresh mark law fixed as u varies. Marks are drawn independently of the past at each event from that common law.

On a realized marked history define the predictable pre-event sums

`H(t)=sum_{t_i<t} kappa_i*h(t-t_i)` and `G(t)=sum_{t_i<t} g_i*phi(t-t_i)`,

with nonnegative, almost surely finite mark amplitudes, `E[kappa]=1`, and `0<=n<1`. Take nonnegative kernels h and phi bounded on the finite window, with `integral_0^infinity h=1`. The project's finite positive exponential mixtures satisfy these kernel conditions. No finite first or second moment of g is needed for this particular positive-u result. No stationary or random prehistory is included.

The intensity family and reference law are

`lambda_u(t)=b_u(t)+n*H(t)`, `b_u(t)=B(t)*exp(-u*G(t))`, `u>=0`,

and `P_0` is the noninhibitory Hawkes law `lambda_0=B+nH`. Its subcritical cluster construction gives `E_0 N(T)<=A/(1-n)` and nonexplosion. The inhibited process is also nonexplosive: use the reference Hawkes proposal history, noting that an accepted subhistory has no larger H, and its intensity is at most `B+nH_reference`. This domination compares each inhibited law with P_0; it is not a monotone coupling between two positive inhibition parameters.

At actual event times lambda_0 is positive almost surely. Assign ratio 1 where both intensities vanish; this convention affects no event or compensator contribution.

## 1. Likelihood domination

The common fresh mark law cancels from the finite-path conditional hazard density. Thus

`L_u = dP_u/dP_0 = exp(integral_0^T (lambda_0-lambda_u)dt) * product_{i=1}^{N(T)} lambda_u(t_i)/lambda_0(t_i)`.

Every product factor is in `(0,1]` on the finite-path support, and

`0 <= integral (lambda_0-lambda_u)dt = integral B*(1-exp(-uG))dt <= A`.

Consequently `0<L_u<=exp(A)`. One rigorous construction is to stop at finite event counts and use the conditional-hazard likelihood. Equivalently, its counting-process exponential is a local martingale bounded by `exp(A)` at every stopped time, hence uniformly integrable and a true density martingale. The induced law has intensity lambda_u and the same conditional mark law. Nonexplosion removes the localization. The likelihood bound alone is not a claim about derivatives at u=0.

## 2. Score and its second moment for u>0

For a fixed finite path, differentiating the product and integrated intensity gives

`S_u = partial_u log L_u = integral_0^T G*b_u dt - sum_i G(t_i)*b_u(t_i)/lambda_u(t_i)`

`    = -integral_0^T [G*b_u/lambda_u]*(dN-lambda_u dt)`.

Its predictable bracket under P_u satisfies

`integral (G*b_u)^2/lambda_u dt <= integral G^2*b_u dt`

`    = integral B*G^2*exp(-uG)dt <= 4*A/(e^2*u^2)`.

The last inequality uses `sup_{z>=0} z^2*exp(-uz)=4/(e^2*u^2)`. At zero intensity take the integrand as zero. Localization and the stochastic-integral isometry therefore give a square-integrable martingale score:

`E_u S_u=0`, `E_u S_u^2 <= 4*A/(e^2*u^2)`.

This does not require raw `E[g^2]` to be finite. It applies at positive u and is not uniform as u decreases to zero. It is separate from the earlier [positive-excitation weighted-moment bound at the null](../../iteration_13/reports/restricted_score_bound.md), and establishes no all-direction information matrix, boundary likelihood-ratio law, or central limit theorem.

## 3. A bounded event-mean functional

For N>0 set

`F_u=(1/N)*sum_i pB0_i*(1-exp(-u*G_i))`, with `pB0_i=B(t_i)/(B(t_i)+nH(t_i))`.

**For this proposition only, define F_u=0 when N=0.** Iteration 14 instead retained an undefined empty-catalogue event mean with unknown `[0,1]` accounting. This analytical extension does not change its data convention.

On every fixed finite history, `0<=F_u<=1`, and

`D_u := partial_u F_u=(1/N)*sum_i pB0_i*G_i*exp(-uG_i)`

with D_u=0 on empty paths. Since `sup_{z>=0} z*exp(-uz)=1/(eu)`,

`0<=D_u<=1/(eu)`.

Both F and its path derivative hold the event configuration and nuisance parameters fixed. Their population averages below are taken under a changing path law.

## 4. Exact finite-difference response

Write `m(u)=E_u F_u=E_0[L_u F_u]`. On any compact `[a,b]` with `0<a<b`, pathwise differentiation gives

`partial_u(L_u F_u)=L_u*(D_u+F_u*S_u)`.

The necessary integral exchange is justified, rather than inferred from a formal score rule:

`E_0 |partial_u(L_u F_u)| <= E_u D_u + E_u |S_u|`

`    <= (1+2*sqrt(A))/(eu) <= (1+2*sqrt(A))/(ea)`.

This is jointly integrable in u and the reference path law. Pathwise fundamental calculus followed by Fubini proves the exact identity

`m(b)-m(a) = integral_a^b E_u[D_u+F_u*S_u]du`.

In particular m is locally absolutely continuous on `(0,infinity)`, with the displayed integrand as its derivative almost everywhere. Because `E_u S_u=0`, the reweighting term is `Cov_u(F_u,S_u)`. The direct term is nonnegative; the covariance has no proved sign. Therefore the fixed-history monotonicity result cannot be promoted to monotonicity of m.

Under the stated finite-mean reference count assumption, one can strengthen the regularity to **C1 on `(0,infinity)`**. To see the domination explicitly, put `q_i(u)=lambda_u(t_i)/lambda_0(t_i)` and `I_u=integral B*(1-exp(-uG))`. On `[a,b]`, `|q_i'|<=1/(ea)` and `|I_u'|<=A/(ea)`. Direct differentiation of `exp(I_u)*product q_i`, without dividing by q_i, yields

`|partial_u(L_u F_u)| <= exp(A)*(A+N+1)/(ea)`.

This is integrable under P_0 because `E_0 N<infinity`. The path derivative is continuous in u (bounded finite-path kernels and dominated background integration). Dominated convergence gives a continuous expectation derivative at every positive u. This stronger statement uses the finite-mean domination argument; the preceding Fubini identity already suffices for the response interpretation.

A conservative consequence, using `Var(F_u)<=1/4`, is

`|Cov_u(F_u,S_u)| <= sqrt(A)/(eu)`,

`|m'(u)| <= (1+sqrt(A))/(eu)`.

These bounds can be numerically loose. They are existence/control results, not a fitted sensitivity estimate. The random response integrand `D_u+F_u*S_u` has finite second moment at each positive u, with L2 norm at most `(1+2*sqrt(A))/(eu)`. This can motivate a separately specified response-calibration diagnostic; it does not establish that such a Monte Carlo estimator is efficient or cheaper than direct simulation.

## 5. Empty-catalogue convention

With empty initial history, before the first event G=H=0 and the hazard is B for every u. Hence

`P_u(N=0)=exp(-A)` exactly, independent of u.

Any fixed constant extension c in `[0,1]` on the empty path changes m by `c*exp(-A)` and leaves its response derivative unchanged. If `A>0`, the conditional-on-nonempty mean is `m(u)/(1-exp(-A))` and its derivative has that same constant rescaling. Allowing an unspecified bounded extension gives a mean interval of width `exp(-A)`. These theoretical statements explain the convention; they do not authorize replacing an unknown recorded metric by zero. If A=0, the process is empty and the conditional mean is undefined, while the zero-extended functional and response are identically zero.

## Consequence for refinement

The model has two response mechanisms: eta directly suppresses the background on a fixed history, while the changed path law reallocates events and history weights. The identity accounts for both. It explains why calibrating one fixed reference history can miss the generated-catalogue mean, and why a fixed-history Newton step omits part of the population response. It does not prove the response is positive, that an exact target is attainable or unique, or that stronger alternatives are easier for a nuisance-adjusted test to detect.

The proposition concerns the specified known-law diagnostic with fixed B, mark law, kernels and nuisance parameters. It does not differentiate an estimator that refits those quantities, transfer to a physical causal rate reduction, repair finite arithmetic overflow, validate the original manuscript, or change the currently running experiment. No claim of literature novelty is made.
