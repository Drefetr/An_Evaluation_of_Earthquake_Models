# Mechanism of the recalibration and useful next refinements

The improvement from iteration 13 to 14 is **closer calibration of a synthetic effect**, obtained by increasing the inhibition parameter eta. It is not a new fit to New Zealand earthquakes, a change to the physical model, or demonstrated improvement in detection power. Keep the independently validated eta candidates fixed and measure their detection performance before another round of tuning.

## What changed exactly

In every old/new pair in [the frozen iteration 14 configuration](../../iteration_14/configs/validation.json), the complete generating-fit dictionaries are equal after removing `pars[3]`. The shared values remain

`a=-4.162108473051707`, `d=0.23211265877958467`, `n=0.5017751599706763`, `beta=2.849401764894274`, and productivity ratio `r=0.7`. Both kernels retain the same finite-mixture Mittag-Leffler specification: `tau=1`, `alpha=0.5`, `p=1.3`, spectral step `0.4`, tail bound `1e-8`. The horizon stays fixed within each old/new comparison. Only eta changes:

| Horizon, days | Target | Original eta | Validated candidate eta |
|---|---:|---:|---:|
|24,394|5%|0.048869242662405894|0.07012853326350502|
|24,394|10%|0.10858867487917685|0.1696512773183481|
|24,394|20%|0.2839974288868791|0.4885010300470942|
|73,182|5%|0.039249214542677394|0.0413037479279677|
|73,182|10%|0.08394931883863642|0.0962916529923892|
|73,182|20%|0.19642640446192255|0.277965319669969|

The fit dictionaries retain historical optimizer fields, including the old `nll`; those are inherited metadata, not a newly evaluated likelihood at the modified eta. The generating parameters above must not be interpreted as a new empirical optimum. Their original nuisance parameters came from the earlier fitted null law; adding eta specifies synthetic alternatives.

## Why eta changes the effect

For the history just before time t, write

`B(t)=exp(a+d*(2t/T-1))`, `H(t)=sum_i kappa_i*h_trigger(t-t_i)`, and `G(t)=sum_i g_i*phi_stress(t-t_i)`,

where `kappa_i=(1-r)*exp(r*beta*Q_i)` and `g_i=exp(gamma*(Q_i-1))`, with `gamma=0.75*log(10)`. The model intensity is

`lambda_eta(t)=B(t)*exp(-eta*G(t))+n*H(t)`.

Thus inhibition multiplies the background component. It leaves the triggering component unchanged **conditional on the same history**. Relative to the eta=0 intensity evaluated on that history, the fractional total-intensity contrast is

`f_eta(t)=[B(t)/(B(t)+n*H(t))]*[1-exp(-eta*G(t))]`.

This is exactly the quantity averaged by [the implemented fixed-history metric](../../iteration_13/code/power_engine.py), first over each catalogue's event times, then equally over catalogues. It is bounded by the background fraction `pB=B/(B+nH)`. A 20% total-intensity contrast can require substantially more than 20% background suppression when triggering contributes much of the intensity. Eta has no universal percentage-rate interpretation.

For one fixed finite history with N>0 and fixed nuisance parameters,

`F_N'(eta)=(1/N)*sum_i pB_i*G_i*exp(-eta*G_i) >= 0`,

`F_N''(eta)=-(1/N)*sum_i pB_i*G_i^2*exp(-eta*G_i) <= 0`.

The contrast therefore increases and saturates on that history. If `q=eta_new/eta_old>=1`, concavity of `1-exp(-z)` gives `F_old <= F_new <= q*F_old`. This finite-path statement needs no population second-moment assumption. It does **not** compare effects on two different generated histories.

Increasing eta changes accepted events, subsequent stress and triggering, random N, and which histories/event times receive weight. Equal catalogue means also differ from pooled-event means when N is informative. That is why solving for 5/10/20% on one reference history did not guarantee those means after generating inhibited catalogues. The interpolation supplement estimated this changed-history relationship and iteration 14 checked the candidates on fresh independent pairs. No monotonicity theorem for the resulting population catalogue-mean effect has been established. Empty-catalogue event means remain undefined, with explicit unknown accounting, rather than a hidden zero convention.

## What fresh validation actually established

The [saved iteration 14 summary](../../iteration_14/results/validation/summary.json) contains 25 complete old/new pairs per setting. Its descriptive results are:

| Horizon | Target | Old mean | New mean | New-mean MCSE, pp | Paired gain, pp |
|---|---:|---:|---:|---:|---:|
|T|5%|3.600%|4.949%|0.073|1.350|
|T|10%|6.928%|9.604%|0.336|2.677|
|T|20%|14.235%|19.123%|0.467|4.889|
|3T|5%|4.831%|5.062%|0.049|0.231|
|3T|10%|9.070%|10.065%|0.085|0.995|
|3T|20%|16.272%|19.671%|0.260|3.399|

All meet the predeclared descriptive screen: within one percentage point of target and MCSE at most half a percentage point. This screen is not a 95% equivalence test. The gains are larger by design because the alternatives were strengthened; these percentages are not likelihood-ratio evidence of inhibition in the observed catalogue. No significance claim or detection-power gain follows from them alone.

Counts changed too. At T/20%, the old/new mean counts are 560.40/492.36; at 3T/20%, 1577.24/1425.92. Conversely, the small 3T/5% contrast has observed means 2062.96/2071.08. These are descriptive random-count outcomes under common random numbers, not event matching, pathwise count ordering, or a causal earthquake-count reduction. They illustrate why multiplying an eta or effect ratio cannot predict the amount of information available to the test.

## Refinements in useful order

1. **Measure power under the validated alternatives.** Preserve the same full estimator, nuisance fitting, null calibration, and failure ledger in the fresh focused comparison. A known generating law permits simulation checks; it does not make fitted nuisance parameters known. The new paired study can measure a conditional, design-specific detection difference with uncertainty. It cannot establish a general sample-size law from one background, mark law, horizon and kernel specification.
2. **Separate signal size from nuisance overlap.** Intercept, trend, branching and kernel changes can imitate some intensity variation. The earlier [two-path score geometry](../../iteration_13/reports/reference_score_geometry.md) describes this overlap but is not expected Fisher information or a power forecast. A diagnostic with independently specified/known B would test a different, restricted information problem; it must be labelled separately from the actual test that estimates B. Neither establishes that the model's latent B is a measured physical background rate.
3. **Use structured controls after the focused comparison.** Separate stress and triggering time scales, and an Omori triggering benchmark, can test sensitivity to the shared-kernel choice. Finite-variance mark controls require both `beta>2*gamma` for stress and `r<0.5` for productivity; changing only one does not make both raw variances finite. Recalibrate the target effect in each changed law and report count/exposure differences rather than confounding these changes with an asserted estimator improvement.
4. **Increase precision before fine eta tuning.** The T/20% mean is 19.1234%, with MCSE 0.4668 percentage points. Its 0.8766-point deficit is about 1.88 rough MCSEs; that ratio is a scale comparison, not a normal confidence test. The candidate already passes the frozen practical screen. Repeatedly nudging eta until this particular sample reads 20.000% risks chasing Monte Carlo noise and forfeits an independent check. More calibration replications, with a predeclared tolerance and separate validation, would be more informative if tighter alignment becomes necessary.

A formal conditional-history Newton suggestion would be `eta_next=eta+(target-F_N(eta))/F_N'(eta)` when the derivative is positive. That is only a same-history calculation: it omits the derivative of the generated-history distribution and cannot certify a population-calibrated eta. No such update was computed or executed here.

## Assumption and claim map

| Claim | Required conditioning or evidence | Boundary of the claim |
|---|---|---|
|Eta suppresses intensity and F is increasing/concave|Same history, same B/H/G and averaging weights|No changed-history population ordering|
|Candidates align with nominal effects|Fresh 25-pair iteration 14 simulation validation|Descriptive mean calibration under this DGP, not empirical NZ evidence|
|Stronger alternatives improve detection|New full-fit, calibrated rejection experiment|Not established by larger F alone|
|Finite raw mark variances|Both stress and productivity thresholds above|Not assumed for the original law|
|A restricted eta score has finite second moment|Positive excitation and the weighted-moment/kernel assumptions in the [restricted bound](../../iteration_13/reports/restricted_score_bound.md)|No Wilks law, all-direction Fisher result, or automatic power formula|
|Known-background diagnostic is easier to identify|Independently specified B, explicitly restricted estimation|Not a replacement for estimated-background test performance|

This report runs no simulation or fitting and changes no previous input, bank, or calibration. Original manuscript code/data remain unavailable; the results belong to the documented independent reconstruction. Authority read here: iteration 14 configuration SHA256 `b83fdcfbd7028f6cbc167b8496b38433fb3508ac0e027ee52ff869bc7bde0f50`; final reuse-summary SHA256 `90ffebb67d76599f66c9cd1eecaeeaec106aeba56ccb43a944056828bf4e4239`. The exact interpolation origin is [iteration 13's achieved-effect supplement](../../iteration_13/results/achieved_effect_calibration/20261016T073220937353Z/summary.json); the prospective distinctions were recorded in [iteration 14's expected-gain analysis](../../iteration_14/reports/expected_gain_analysis.md). The new iteration 15 power outcomes were not inspected.
