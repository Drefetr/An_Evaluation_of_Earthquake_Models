# Provenance, assumptions and validation map

Earlier inputs and iterations are read-only. Source provenance is not proof certification.

| Source | Provenance | Validation and use |
|---|---|---|
| `iteration_14/configs/validation.json`, final validation summary | Fresh earlier 150-pair synthetic validation | Exact original/adjusted eta and unchanged generating law; not a new empirical fit |
| `iteration_15/configs/design.json` | New prospective focused design | 25 main pair seeds and two independent benchmark seeds, checked disjoint from 4,585 recorded earlier seeds |
| `iteration_15/reports/statistical_design.md` | New pre-outcome statistical contract | Fixed timing allocation, common null reference, paired uncertainty and failure rules |
| `iteration_15/results/benchmark/` | Two new timing-only full searches | All gates passed; excluded from power denominators; cost-only allocation selected R25 |
| `iteration_15/results/allocation.json`, `configs/pilot.json` | New pre-outcome allocation | 50 main full-fit cases; 2,247.392s main cap after 32.608s benchmark charge and 120s reserve |
| `iteration_15/code/power_engine.py`, `power_runner.py` | Adaptation of the earlier independent reconstruction | Scientific fitting/likelihood/validation functions identical to iteration13; pair/cache/authority guards adapted and tested |
| `iteration_12/code/stable_history.py`, precise/paired clock helpers and earlier numerical sources | Previously reconstructed numerical implementation | Exact pinned sources and original prescribed starts, recovery semantics, paired times and CPU32 checks retained |
| `iteration_12/results/aggregate/2026-10-16T061247128773_0000/` | Earlier completed synthetic bank | All1,999 short null cases checked under new C reuse audit; no new null fitting |
| `iteration_15/reviews/C_null_bank_review.json` | New provenance/law/numerical-equivalence audit | 476,678,943 referenced bytes rehashed; validation statistics, CPU32 gates and prior full-estimator semantic authorities checked |
| `iteration_15/reports/positive_eta_response.md` | Newly derived restricted proposition | Separately reviewed likelihood domination, score moment bound and response identity; no literature-novelty claim |
| `iteration_15/code/power_summary.py` | New terminal-only statistical aggregation | A/C source checks use synthetic fixtures; actual numerical outputs require a separate terminal audit |

The mathematical derivation holds nuisance parameters fixed and assumes a finite horizon, empty history, common fresh mark law and a dominating noninhibitory construction. The estimation experiment refits background, triggering, mark and kernel parameters as prescribed. These are different information problems. The diagnostic independently specified background must remain distinguished from interpretation of physical loading, stationary infinite prehistory and empirical geology/completeness effects.

No original manuscript code, frozen historical catalogue or thesis source has been recovered. This study does not extend the observed catalogue, lower its magnitude threshold or introduce spatial/geological data. Environmental versions and actual execution authorities are saved with the run evidence; no system-wide changes or paid resources are used.

## Completed evidence

All 50 main cases and both excluded timing cases passed the prescribed numerical validation. The terminal analysis is `results/analysis/2026-10-16T083404035350_0000/summary.json`, SHA256 `36536a408db356124458ed008af008a05979bd466427adf6a96b78d2e1434bb4`. C's separate actual-output audit checked all 11,700 canonical records, 8,100 prescribed starts, matched reference statistics, exact ranks and paired summaries. The maximum selected CPU32 discrepancy was 7.28e-12. A predeclared supplementary audit found no better-point witness among 100 comparisons; this does not establish global optimality.

The original and adjusted arms rejected in 6/25 and 11/25 cases respectively. These are executed conditional screening frequencies. The 20-percentage-point difference has descriptive paired MCSE 11.55 points, and remains imprecise. The positive-eta response result, integrable-trigger extension and fixed-test power-response corollary have separate mathematical review; none asserts population monotonicity, full boundary likelihood asymptotics or a literature novelty result.

The final completion manifest inventories new files, rechecks earlier iteration-13/14 inventories and checks all seven supplied input hashes. File equality establishes provenance, not scientific correctness. The disabled future precision template contains no executed cases.
