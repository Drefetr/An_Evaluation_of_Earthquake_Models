"""Render the terminal paired power comparison from one saved analysis."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import argparse, math
import numpy as np
ROOT=Path(__file__).resolve().parents[2];AREA=ROOT/"iteration_15"
sys.path.insert(0,str(ROOT/"iteration_6/code"))
from checkpoint_io import read_sealed, atomic_bytes, sha256


def write(path,text):atomic_bytes(path,text.encode("utf-8"))
def pct(x):return "withheld" if x is None else f"{100*x:.1f}%"
def num(x):return "withheld" if x is None else f"{x:.2f}"


def main():
    p=argparse.ArgumentParser();p.add_argument("analysis",type=Path);args=p.parse_args()
    source=args.analysis/"summary.json";s=read_sealed(source)
    allocation=read_sealed(AREA/"results/allocation.json")
    runner=read_sealed(AREA/"results/pilot/summary.json")
    rows=[];descriptive=[]
    for arm,label in (("old","Original"),("new","Adjusted")):
        a=s["arms"][arm];ci=a["exact_binomial_95_interval"]
        interval=f"[{pct(ci[0])}, {pct(ci[1])}]" if ci else "withheld"
        rows.append(f"| {label} | {a['rejections']}/{a['requested']} | {pct(a['conditional_power'])} | {interval} | {a['unknown']} |")
        cases=[c for c in s["outcomes"] if c["arm"]==arm]
        counts=[c["n_events"] for c in cases if c["simulation_complete"]]
        count_mean=float(np.mean(counts)) if len(counts)==s["R"] else None
        effect=[c["realized_effect"]["mean_event_fixed_history_total_suppression"] for c in cases if c["realized_effect"] is not None]
        effect_mean=float(np.mean(effect)) if len(effect)==s["R"] else None
        descriptive.append(f"| {label} | {pct(effect_mean)} | {num(count_mean)} | {min(counts) if counts else 'unknown'}–{max(counts) if counts else 'unknown'} |")
    pair=s["paired"];table=pair["table"]
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    fig,axes=plt.subplots(1,2,figsize=(9.6,4.4),layout="constrained")
    for x,arm,color in ((0,"old","#205c8a"),(1,"new","#b84e2c")):
        a=s["arms"][arm];value=a["conditional_power"];ci=a["exact_binomial_95_interval"]
        if value is not None and ci is not None:
            axes[0].errorbar([x],[value],yerr=np.array([[value-ci[0]],[ci[1]-value]]),fmt="o",color=color,capsize=5,markersize=7)
            axes[0].annotate(f"{a['rejections']}/{a['requested']}",(x,value),xytext=(12,0),textcoords="offset points",va="center")
    axes[0].set(xticks=[0,1],xticklabels=["Original eta","Adjusted eta"],xlim=(-.5,1.6),ylim=(-.02,1.02),ylabel="Conditional detection frequency",title="Arm estimates and exact 95% intervals")
    axes[0].yaxis.set_major_formatter(PercentFormatter(1));axes[0].grid(axis="y",alpha=.2)
    axes[0].spines[["top","right"]].set_visible(False)
    matrix=np.array([[table['neither'],table['new_only']],[table['old_only'],table['both']]])
    axes[1].imshow(matrix,cmap="Blues",vmin=0,vmax=max(1,int(matrix.max())))
    for (i,j),value in np.ndenumerate(matrix):
        axes[1].text(j,i,str(value),ha="center",va="center",fontsize=17,color="white" if value>matrix.max()/2 else "#17364d")
    axes[1].set(xticks=[0,1],xticklabels=["No","Yes"],yticks=[0,1],yticklabels=["No","Yes"],xlabel="Adjusted setting rejects",ylabel="Original setting rejects",title=f"Paired decisions; unknown={table['unknown']}")
    fig.suptitle(f"Fresh focused comparison: {s['R']} pairs, fixed null bank B=1,999\nIntervals condition on this bank and do not include its uncertainty",fontsize=11)
    folder=AREA/"reports/figures";folder.mkdir(parents=True,exist_ok=True)
    fig.savefig(folder/"power_comparison.png",dpi=170);fig.savefig(folder/"power_comparison.svg");plt.close(fig)
    witness_path=AREA/"results/generating_point_audit.json"
    witness_seconds=0.
    witness_text="The predeclared fixed generating-point witness check is deferred or not yet terminal; it is not a completed result in this rendering."
    if witness_path.exists():
        w=read_sealed(witness_path)
        witness_seconds=w['parent_execution']['parent_elapsed_seconds']
        witness_text=f"The predeclared fixed generating-point audit scored {len(w['rows'])} catalogues in {witness_seconds:.3f}s, with exit status {w['parent_execution']['exitcode']}. It found {w['witness_count']} better-point witnesses in {w['comparison_count']} comparisons; the minimum candidate-minus-selected NLL gap was {w['minimum_gap']:.6f}. It uses each dataset's refitted beta and no new optimizer or simulated catalogue; two preselected candidates received independent CPU32 checks. All saved case files remained byte-identical. This excludes this specific missed-fit witness and cannot certify a global optimum. It changes no primary fits or rejection decisions. Full authority: `results/generating_point_audit.json`, SHA256 `{sha256(witness_path)}`."
    report=f"""# Mechanism, refinement and focused power comparison

The correction increased the **synthetic inhibition coefficient**, with nuisance parameters, mark law, kernels and observation horizon fixed. For the current-horizon 20% setting eta changed from 0.2839974288868791 to 0.4885010300470942. Fresh prior validation moved its average fixed-history suppression from 14.235% to 19.123%, with MCSE 0.467 percentage points for the latter. Those are calibration results, not evidence of a newly discovered NZ effect. The current study measures whether the corrected generator is easier for the existing test to detect.

Authoritative terminal analysis: `{source.resolve().relative_to(ROOT).as_posix()}`, SHA256 `{sha256(source)}`. **{s['validated']}/{s['requested']} main cases validated**; the two independent timing cases are excluded. The fixed balanced allocation is {s['R']} fresh pairs, using the same seed within each pair and independent assignments across pairs.

## Actual detection comparison

| Generating setting | Detections/planned | Conditional estimate | Exact 95% arm interval | Unknown |
|---|---:|---:|---|---:|
{chr(10).join(rows)}

![Conditional arm intervals and paired decisions](figures/power_comparison.png)

Paired outcomes: neither={table['neither']}, original only={table['old_only']}, adjusted only={table['new_only']}, both={table['both']}, unknown={table['unknown']}. The observed adjusted-minus-original detection difference is **{num(100*pair['mean_gain'] if pair['mean_gain'] is not None else None)} percentage points**; its descriptive paired MCSE is **{num(100*pair['MCSE'] if pair['MCSE'] is not None else None)} percentage points**. Possible-completion accounting bounds are {pair['accounting_bounds']}. They are not confidence intervals. Separate arm intervals are not an interval for the paired difference. No McNemar, Wilks or normal-confidence conclusion is attached to this small pilot.

Both arms use the same **1,999 matched known-null reference statistics** and full estimator. The statistic is twice the null-minus-separate-stress-scale fitted NLL difference. A decision rejects when `(1+count(Dref>=Douter))/2000 <= .05`, retaining ties. This is known-law screening conditional on the saved bank, not the power of the full per-catalogue fitted-null bootstrap. Arm intervals omit uncertainty in the common reference bank, generating-law choice and calibrated eta. Iteration 13's primary bank had 39 references; comparing its old eight-draw percentage directly with this study would mix test-rule and generator changes.

## Signal and event availability

| Setting | Mean achieved suppression, validated cases | Mean complete-simulation count | Complete-count range |
|---|---:|---:|---|
{chr(10).join(descriptive)}

Counts remain random over fixed horizons. Means are withheld for incomplete full samples, and prefix counts remain separately in the saved outcomes. Heavy-tailed amplitudes do not justify finite count variance or Gaussian count intervals. Larger imposed inhibition changes the number and arrangement of events as well as their intensity contrast. Background, triggering and kernel parameters are re-estimated equally in the fitted candidates. No direct conversion from a stronger contrast to a power multiplier or catalogue-size saving is warranted.

## What resolved the calibration mismatch

The diagnostic intensity is `lambda_eta=B*exp(-eta*G)+n*H`. Eta suppresses its background component. For one fixed history the total fractional contrast is `pB0*(1-exp(-eta*G))`, with `pB0=B/(B+nH)`. It increases and saturates; the triggering contribution bounds how much total intensity can be removed. Calibrating this average on one uninhibited reference path did not hold it fixed after inhibition changed future events and event-time weighting.

The correction used a separate simulation grid of achieved catalogue means, adjacent interpolation, and then fresh independent validation. It changed no observed-catalogue fit or physical loading coefficient. The mathematical review now makes the changing-history contribution explicit: under stated finite-horizon common-mark assumptions, at positive eta

`d E_eta[F_eta]/d eta = E_eta[partial_eta F_eta] + Cov_eta(F_eta,S_eta)`.

The direct term is nonnegative; no sign for the path-law covariance is established. The score second moment is bounded by `4*A/(e^2*eta^2)`, where A is integrated background. This remains a restricted positive-eta result, not a boundary inference, stationary ergodicity, full Fisher-information or power theorem. The exact likelihood/response derivation and its explicit empty-catalogue convention are in `positive_eta_response.md`, separately reviewed in `../reviews/C_positive_eta_response_review.md`.

The separately reviewed `finite_horizon_kernel_extension.md` weakens the bounded-trigger assumption to a normalized integrable density, including a singularity at zero, with bounded finite-window stress loading. An explicit shared survival/density example is `phi(t)=1/(1+t^alpha)` and `h(t)=alpha*t^(alpha-1)/(1+t^alpha)^2`, for alpha between zero and one. It has long stress memory and singular triggering yet a valid finite-horizon construction and response identity. This establishes neither stationarity nor equivalence to a Mittag–Leffler kernel, and does not change the finite-mixture numerical experiment.

For a fixed, everywhere-defined complete-data rejection rule I, the reviewed corollary gives `p'(eta)=Cov_eta(I,S_eta)`. There is no positive direct-effect term because the decision rule does not see the true generating eta. Its sign is unrestricted. This supports a future score-based power-sensitivity diagnostic, without a numerical or efficiency prediction. Actual resource failures remain unknown outcomes rather than zero indicators; no complete-case shortcut is justified. See `power_response_corollary.md`.

## Useful further refinement

The next refinement should follow detection performance under the validated settings. Repeatedly nudging eta until a 25-run mean reads exactly 20% can chase Monte Carlo variability; the prior 19.123% already met the frozen one-percentage-point practical tolerance. Tighter effect calibration requires more independent precision and a new validation batch. A fixed-history Newton step omits the history-distribution response term.

Robust mechanism discrimination additionally needs comparable background flexibility, altered stress/triggering scales, an Omori-type triggering benchmark, and both raw-moment conditions for a finite-variance mark control. Those contrasts are unexecuted here. The same is true of catalogue completeness, missing prehistory and spatial/geological alternatives. A stronger synthetic effect alone establishes none of those distinctions.

## Numerical review and executed scope

Every validated new catalogue retains the complete 234-record/162-start estimator, beta refitting, original declared failure-only recovery tiers, finite/nesting gates and selected CPU32 checks. The numerical procedure was compared to the earlier bank, whose 1,999 sources and gates passed a new law/authority audit. Completed generation, full-fit and validation stages are retained; failed/capped cases are never silently replaced or treated as nonrejections. Any unresolved draw withholds complete-data frequencies and retains the original denominator and pairwise accounting bounds.

{witness_text}

Recorded main execution charge is {runner['work_seconds_charged']:.3f}s, with {allocation['benchmark_charged_seconds']:.3f}s independent timing, {witness_seconds:.3f}s separate fixed-point scoring and a remaining-main cap of {allocation['remaining_main_cap_seconds']:.3f}s. Their sum is {runner['work_seconds_charged']+allocation['benchmark_charged_seconds']+witness_seconds:.3f}s against the 2,400s allowance; code development, proof and review time are separate. No larger study or nested bootstrap is launched. Environment, exact sources, seeds, allocation and logs are saved with the plans. These are project review tracks, not independent academic refereeing.

The assumption/claim boundary is detailed in `mechanism_and_refinement.md` and `source_inventory.md`. The original thesis source is unavailable; proposed LaTeX additions are explicitly uncompiled fragments. No thesis PDF is reconstructed. Reproduction and continuation commands are in `../README.md`.
"""
    write(AREA/"reports/research_report.md",report)
    write(AREA/"STATUS.md",f"""# Focused comparison: {'complete' if s['all_planned_validated'] else 'terminal with unresolved cases'}

{s['validated']}/{s['requested']} main cases validated, {s['R']} pairs, B1999 fixed-reference rule. Original detections {s['arms']['old']['rejections']}/{s['R']}; adjusted {s['arms']['new']['rejections']}/{s['R']}. Paired gain {num(100*pair['mean_gain'] if pair['mean_gain'] is not None else None)} percentage points; unknown pairs {table['unknown']}.

These are conditional known-law screening frequencies with pilot uncertainty. No full fitted-null-bootstrap power, physical effect discovery, 80% power certification or universal sample-size saving is established.

Report: [reports/research_report.md](reports/research_report.md).
Authoritative analysis: `{source.resolve().relative_to(AREA).as_posix()}`.
""")
    print("Rendered "+str(source))


if __name__=="__main__":main()
