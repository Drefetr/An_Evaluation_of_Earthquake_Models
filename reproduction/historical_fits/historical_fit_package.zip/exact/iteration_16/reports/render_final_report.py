"""Render completed evidence without changing any frozen scientific source."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import argparse, json, statistics
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT/"iteration_16"
sys.path.insert(0, str(ROOT/"iteration_6/code"))
from checkpoint_io import read_sealed, atomic_bytes, sha256


def write(path, text):
    atomic_bytes(path, text.encode("utf-8"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("analysis", type=Path)
    args = parser.parse_args()
    source = args.analysis/"summary.json"
    s = read_sealed(source)
    review = read_sealed(AREA/"reviews/C_final_power_review.json")
    assert review["passed"] and s["all_planned_validated"] and s["validated"] == 300
    assert s["R"] == 150 and not s["planning_pilot_pooled"]
    runner = read_sealed(AREA/"results/precision/summary.json")
    prior = read_sealed(ROOT/"iteration_15/results/analysis/2026-10-16T083404035350_0000/summary.json")
    rows, descriptors = [], []
    for arm, label in (("old", "Original"), ("new", "Adjusted")):
        a = s["arms"][arm]
        ci = a["exact_binomial_95_interval"]
        rows.append(f"| {label} | {a['rejections']}/150 | {100*a['conditional_power']:.1f}% | [{100*ci[0]:.1f}%, {100*ci[1]:.1f}%] | {a['unknown']} |")
        cases = [c for c in s["outcomes"] if c["arm"] == arm]
        assert len(cases) == 150 and all(c["simulation_complete"] for c in cases)
        counts = [c["n_events"] for c in cases]
        effects = [c["realized_effect"]["mean_event_fixed_history_total_suppression"] for c in cases]
        descriptors.append(f"| {label} | {100*statistics.mean(effects):.3f}% | {statistics.mean(counts):.2f} | {statistics.median(counts):.1f} | {min(counts)} to {max(counts)} |")
    pair = s["paired"]; table = pair["table"]
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from matplotlib.ticker import PercentFormatter
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.4), layout="constrained")
    for x, arm, color in ((0, "old", "#205c8a"), (1, "new", "#b84e2c")):
        a = s["arms"][arm]; value = a["conditional_power"]; ci = a["exact_binomial_95_interval"]
        axes[0].errorbar([x], [value], yerr=np.array([[value-ci[0]], [ci[1]-value]]),
            fmt="o", color=color, capsize=5, markersize=7)
        axes[0].annotate(f"{a['rejections']}/150", (x, value), xytext=(12, 0), textcoords="offset points", va="center")
    axes[0].set(xticks=[0, 1], xticklabels=["Original eta", "Adjusted eta"], xlim=(-.5, 1.6),
        ylim=(-.02, 1.02), ylabel="Conditional detection frequency", title="Estimates and exact 95% arm intervals")
    axes[0].yaxis.set_major_formatter(PercentFormatter(1)); axes[0].grid(axis="y", alpha=.2)
    axes[0].spines[["top", "right"]].set_visible(False)
    matrix = np.array([[table["neither"], table["new_only"]], [table["old_only"], table["both"]]])
    axes[1].imshow(matrix, cmap="Blues", vmin=0, vmax=matrix.max())
    for (i, j), value in np.ndenumerate(matrix):
        axes[1].text(j, i, str(value), ha="center", va="center", fontsize=17,
            color="white" if value > matrix.max()/2 else "#17364d")
    axes[1].set(xticks=[0, 1], xticklabels=["No", "Yes"], yticks=[0, 1], yticklabels=["No", "Yes"],
        xlabel="Adjusted setting rejects", ylabel="Original setting rejects", title="Paired decisions; no unknowns")
    fig.suptitle("150 fresh pairs | fixed null bank B=1,999\nIntervals condition on the saved bank; planning pilot excluded", fontsize=11)
    folder = AREA/"reports/figures"; folder.mkdir(parents=True, exist_ok=True)
    fig.savefig(folder/"power_precision.png", dpi=170)
    fig.savefig(folder/"power_precision.svg"); plt.close(fig)
    report = f"""# Completed fresh paired detection study

All **300/300 main cases validated**, in **{runner['work_seconds_charged']/60:.2f} minutes** of recorded scientific-session wall time. One closed session completed the fixed 150 fresh pairs, without unresolved cases or planning-pilot pooling. The larger experiment estimates a much smaller detection gain than the initial pilot. It does not establish a clear improvement in detection performance, and it establishes no effect in the observed NZ catalogue.

Authoritative analysis: `{source.resolve().relative_to(ROOT).as_posix()}`, SHA256 `{sha256(source)}`. The separate actual-output audit is `reviews/C_final_power_review.json`. It reconstructed all 300 case chains, 70,200 canonical fit records, 48,600 prescribed starts, selected winners, mark-rate refits, likelihood statistics, reference ranks and paired summaries. Numerical audits are project reviews, not independent academic refereeing or global-optimum certificates.

## Detection results

| Generating setting | Detections | Conditional frequency | Exact 95% arm interval | Unknown |
|---|---:|---:|---|---:|
{chr(10).join(rows)}

![Conditional detection and paired outcomes](figures/power_precision.png)

The adjusted-minus-original difference is **{100*pair['mean_gain']:.3f} percentage points**, with descriptive paired Monte Carlo standard error **{100*pair['MCSE']:.3f} points**. Paired outcomes are neither={table['neither']}, original-only={table['old_only']}, adjusted-only={table['new_only']}, both={table['both']}. Thus the adjusted setting gained 29 detections and lost 21 relative to its paired original setting. No pathwise ordering was imposed or established.

The paired MCSE met the approximate 4.7-point planning forecast. Precision improved, while the observed gain fell from the planning pilot's {100*prior['paired']['mean_gain']:.1f} points (MCSE {100*prior['paired']['MCSE']:.2f}) to {100*pair['mean_gain']:.2f} points. The earlier 25 pairs remain separate: they are neither pooled nor used to extend this fixed sample. This comparison concerns observed estimates, not a formal test that the two experiments have different population effects. No post-outcome McNemar, normal confidence interval for the gain, equivalence test or Wilks conclusion has been added. Arm intervals are not a confidence interval for the paired difference.

## What changed in the generating law

Only the generating inhibition coefficient differs, eta=0.2839974288868791 versus 0.4885010300470942. Both use the same finite shared stress/triggering kernel approximation, nuisance law, heavy-tailed mark transformation, empty history and 24,394-day horizon. A fixed horizon produces random event counts; stronger inhibition also changes subsequent histories.

| Setting | Mean achieved fixed-history suppression | Mean catalogue count | Median count | Count range |
|---|---:|---:|---:|---|
{chr(10).join(descriptors)}

These are descriptive catalogue-weighted suppression means and empirical count summaries. No finite raw mark/count variance, Gaussian count interval or count-to-power conversion is assumed. The suppression measure compares total intensity with the event history and other generating parameters held fixed; it is not the long-run count reduction. Selected nuisance-fit descriptors are separately labelled exploratory in `reviews/A_final_interpretation.md`.

Extreme realizations remain included. Pair 076 has 449 original-setting events and 6,553 adjusted-setting events, despite the typical adjusted count being smaller. Across the 150 pairs, counts decreased in 143, were equal in one and increased in six. Achieved suppression increased in 147 pairs and decreased in three. These are realized comparisons, not population monotonicity assertions or grounds to exclude any pair.

## Scope and interpretation

Each decision compares the fitted noninhibitory model with the separate-stress-scale inhibitory model using `D=2*(NLL_MLnull-NLL_MLseparateScale)`. All 1,999 matched earlier null statistics are retained. The exact conservative rank is `(1+count(Dref>=Douter))/2000`, rejecting at or below .05, with ties retained. The candidates share the same baseline intercept/trend and branching nuisance parameterization and bounds; the inhibitory alternative adds a history-dependent term and stress-kernel search.

The frequencies and exact arm intervals condition on this fixed reference bank and these generating parameters. They omit bank uncertainty, uncertainty in the fitted generating law, and selection/calibration of eta. This is not the power of a complete per-catalogue fitted-null bootstrap. A Bernoulli detection indicator is bounded, so its Monte Carlo variance calculation does not require finite variance of raw earthquake marks. The heavy-tailed process still precludes silently importing raw-moment assumptions elsewhere.

The new result supports a useful restricted negative finding: even with genuine inhibition at the adjusted level, this routine misses most catalogues under the specified scenario. It does not support 80% detection performance. It also does not prove no improvement, no inhibition, failure of the proposed physics, or identifiability of a shared stress/triggering kernel. The current primary statistic tests feedback against no feedback; it does not itself distinguish shared memory from a different stress kernel.

The mathematical positive-eta response identity from iteration 15 remains relevant: changing eta changes both direct fixed-history suppression and the distribution of histories. For a fixed rejection rule, power response is a score covariance with unrestricted sign. Neither that formula nor the present descriptive nuisance shifts proves why a particular case changed its decision.

## Numerical evidence and next action

All cases passed the frozen full-estimator and selected independent CPU32 gates. Nineteen primary optimizer failures in seven cases were retained and recovered through the predeclared failure-only procedures (18 F9/CPU maxls40, one Powell/n=0-face route). They are not unresolved failed catalogues. The largest selected CPU32 discrepancy is about 1.04e-11, below the frozen 1e-4 tolerance. Detailed source, recovery, resource and log checks are in `reviews/D_final_execution_review.json` and the separate C audit. These checks do not prove global optimality. The saved parent transcript contains 299 worker exits at zero and creation of the analysis snapshot. The first case's parent events are absent, but its worker log and sealed generation/fit/validation chain establish its completed stages. Its parent exit and the final launcher exit are not directly captured in the transcript and are not invented here.

Saved selected-fit summaries suggest an exploratory background/trend tradeoff. The true background intercept and trend are about -4.162 and .232. Under the noninhibitory candidate, the median fitted intercept is about -4.467 (original) or -4.597 (adjusted), and the median trend is .0325 or -.0467. Under the separate-stress alternative, the corresponding medians are -3.945/-4.009 and .373/.339; branching medians remain near .50. The separate-scale fit selects stress scale 10 in 70/150 original and 80/150 adjusted cases, although the generating scale is 1. These post-outcome descriptors do not establish a confounding mechanism, a likelihood ridge, unbiasedness, or kernel identifiability. Eta estimates on different selected scales cannot be read directly as coefficient bias. See A's separate saved-fit audit for the full parameter and metric provenance.

The most valuable next step is a narrowly specified study of nuisance-parameter confounding: compare known versus estimated background/triggering parameters with matched null calibration, beginning with the saved-fit diagnostics. That addresses whether background and triggering flexibility absorb the inhibitory signal. Merely increasing the replication count would narrow uncertainty around this same limited-sensitivity setup. A longer-horizon or lower-threshold catalogue requires its own recalibration and power design, and shared-kernel discrimination requires additional generating alternatives. None of those new fits, simulations, catalogue downloads or expanded campaigns was launched during this review.

Re-render this report from the project root:

```powershell
python -B iteration_16/reports/render_final_report.py iteration_16/results/analysis/2026-10-16T103144428080_0000
```

The earlier input files, frozen scientific code/protocol, accepted simulations and primary analysis remain unchanged. No revised thesis PDF is produced. The targeted LaTeX addition is an explicitly uncompiled replacement fragment.
"""
    write(AREA/"reports/research_report.md", report)
    write(AREA/"STATUS.md", f"""# Completed and audited

300/300 cases validated; 150 fresh pairs; no unknowns. Original detections 49/150 (32.7%), adjusted 57/150 (38.0%). Paired gain {100*pair['mean_gain']:.3f} percentage points, descriptive MCSE {100*pair['MCSE']:.3f} points. Recorded execution {runner['work_seconds_charged']/60:.2f} minutes. The earlier 25 planning pairs are excluded.

This conditional fixed-bank result does not establish a clear gain, 80% detection performance, a physical NZ effect or shared-kernel identification. Full report: [reports/research_report.md](reports/research_report.md).

Authoritative analysis: `{source.resolve().relative_to(AREA).as_posix()}`. No additional scientific runs were launched in the final review.
""")
    print("Rendered " + str(source))


if __name__ == "__main__":
    main()
