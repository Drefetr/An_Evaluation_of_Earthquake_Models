# Targeted manuscript change

`manuscript_revisions/power_precision_results.tex` is a new uncompiled replacement fragment, not recovered thesis source. No PDF is produced and no original manuscript file is changed.

Use it in the synthetic identifiability/power discussion. Replace any forecast treating the iteration-15 20-percentage-point pilot gain as established performance with the fresh fixed-150-pair estimate: 5.33 percentage points, descriptive paired MCSE 4.71 points. Preserve the earlier pilot as planning evidence, separately labelled and not pooled. Add the exact conditional arm intervals and fixed-bank limitation. Do not convert this result into a shared-kernel test, an observed NZ effect, a universal catalogue-size requirement, or an argument that inhibition is absent.

The corresponding numerical evidence and provenance are in the saved analysis, C actual-output audit and D execution review. No literature novelty claim or stationary theorem is introduced.
