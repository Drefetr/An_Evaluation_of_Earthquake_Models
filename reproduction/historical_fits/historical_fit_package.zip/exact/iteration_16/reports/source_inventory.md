# Final evidence and provenance map

| Evidence | Provenance | Validation and limit |
|---|---|---|
| Original `inputs/` | Supplied manuscript and iteration-3 historical material | Read-only hashes checked; not a reproduction of original thesis analysis |
| `iteration_15/` | Earlier independent reconstruction and 25-pair planning pilot | Preserved; planning outcomes not pooled into this cohort |
| `configs/design.json`, `configs/precision.json`, `results/allocation.json` | New prospective fixed-150-pair design | Exact fresh seeds, unchanged laws and fixed four-hour cap bound before outcomes |
| `results/precision/plan.json` and snapshots | Frozen wrapper/numerical/protocol authorities | All recorded source pins match at completion |
| `results/precision/cases/` | User-executed 300 synthetic generation/fit/validation chains | All validated; 1,800 saved case files preserved through read-only audits |
| `results/analysis/2026-10-16T103144428080_0000/` | Launcher-created terminal statistical analysis | Exact ranks, frequencies, conditional arm intervals and paired MCSE reconstructed by C |
| `reviews/C_null_bank_review.json` | Current audit of 1,999 previously executed null references | Full byte/identity/gate audit; fixed known-law calibration rather than complete fitted-null-bootstrap power |
| `reviews/C_final_power_review.json` | Separate actual-output statistical audit | 300 chains, 70,200 fit records and 48,600 starts checked; no new fit or score |
| `reviews/D_final_execution_review.json` | Separate execution/numerical/source audit | Declared recovery lineages and 900 CPU32 gates passed; telemetry gaps explicitly retained |
| `reviews/A_final_interpretation.json` | Separate saved-fit descriptive review | Actual effects/counts/nuisance selections, with extreme realizations retained; exploratory interpretation only |
| `reports/research_report.md` and figures | New rendering of saved evidence | Tables generated from analysis; PNG visually inspected; no PDF produced |
| `manuscript_revisions/power_precision_results.tex` | New uncompiled replacement fragment | Not recovered original LaTeX and not an integrated thesis revision |

Fresh seeds, empty history, pre-event intensity, untruncated marks, the finite positive kernel substitution, background parameterization and normalization are inherited explicitly from the frozen protocol. This was not a new empirical NZ fit or catalogue augmentation. No original frozen historical catalogue or original fitting implementation was recovered by this run. All computational science remains labelled as an independent reconstruction. Project agent reviews do not constitute independent academic refereeing.
