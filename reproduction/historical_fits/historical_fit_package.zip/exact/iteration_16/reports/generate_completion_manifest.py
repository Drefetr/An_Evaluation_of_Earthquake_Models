"""Final byte-provenance inventory, separate from scientific audit conclusions."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT/"iteration_16"
sys.path.insert(0, str(ROOT/"iteration_6/code"))
from checkpoint_io import read_json, read_sealed, sealed_json, sha256


def main():
    old_path = ROOT/"iteration_15/results/completion_manifest.json"
    old = read_sealed(old_path)
    assert all(sha256(ROOT/f["path"]) == f["sha256"] for f in old["files"])
    inputs = [f for f in read_json(ROOT/"SOURCE_MANIFEST.json")["files"] if f["path"].startswith("inputs/")]
    assert len(inputs) == 7 and all(sha256(ROOT/f["path"]) == f["sha256"] for f in inputs)
    plan = read_sealed(AREA/"results/precision/plan.json")
    frozen = dict(plan["sources"], **plan["protocol_sources"])
    assert all(sha256(ROOT/p) == d for p, d in frozen.items())
    summary_path = AREA/"results/analysis/2026-10-16T103144428080_0000/summary.json"
    assert sha256(summary_path) == "ec93b8df8777d94520e099569394ba9464d3029e34d3f6bd6543754deb319294"
    summary = read_sealed(summary_path)
    assert summary["all_planned_validated"] and summary["validated"] == 300 and summary["R"] == 150
    for name in ("C_final_power_review.json", "D_final_execution_review.json"):
        review = read_json(AREA/"reviews"/name)
        if "record_sha256" in review:
            read_sealed(AREA/"reviews"/name)
        assert review["passed"]
    assert (AREA/"reviews/A_final_interpretation.md").exists()
    target = AREA/"reviews/root_completion_manifest.json"
    files = [dict(path=p.relative_to(ROOT).as_posix(), bytes=p.stat().st_size, sha256=sha256(p))
             for p in sorted(AREA.rglob("*")) if p.is_file() and p != target
             and "__pycache__" not in p.parts and ".pytest_cache" not in p.parts
             and p.suffix not in (".pyc", ".lock", ".tmp")]
    sealed_json(target, dict(created_utc=datetime.now(timezone.utc).isoformat(),
        scope="Final file equality/provenance inventory; not proof, global optimum or power certification",
        earlier_manifest_sha256=sha256(old_path), previous_iteration15_files_unchanged=len(old["files"]),
        original_inputs_unchanged=7, frozen_source_and_protocol_hashes=frozen,
        authoritative_summary=summary_path.relative_to(ROOT).as_posix(), summary_sha256=sha256(summary_path),
        validated_cases=300, pairs=150, unknown_cases=0, new_scientific_work_during_final_review=False,
        files=files, file_count=len(files), exclusions=["this manifest", "__pycache__", ".pytest_cache", "pyc/lock/tmp"]))
    print(f"Recorded {len(files)} files; 300 cases complete; {len(old['files'])} earlier files and seven original inputs unchanged.")


if __name__ == "__main__":
    main()
