"""Fixed-horizon power-pilot stages; completed-stage checkpoints only.

All numerical science is imported read-only from iteration 12/5. An incomplete
or failed planned case remains in the denominator ledger; no seed replacement.
"""
from pathlib import Path
import os
for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_name]='1'
import sys
sys.dont_write_bytecode=True
import gc,json,math,time
ROOT=Path(__file__).resolve().parents[2]
AREA=ROOT/'iteration_16'
for _folder in ('iteration_6/code','iteration_12/code','iteration_5/code','iteration_5_performance/gpu'):
    sys.path.insert(0,str(ROOT/_folder))
from checkpoint_io import (atomic_npz,atomic_bytes,atomic_json,read_json,read_sealed,sealed_json,
                           sha256,canonical_hash,utc_now)

STABLE_SHA='f2ed43402c17203c900642b584db591638fbd27474c9669bffa4a43379bdaa30'
SOURCE_NAMES=('iteration_16/code/power_engine.py','iteration_16/code/power_runner.py',
 'iteration_12/code/stable_history.py','iteration_12/code/paired_history.py',
 'iteration_12/code/clock_simulator.py','iteration_9/code/numerical_fit.py',
 'iteration_5/code/empirical_process.py','iteration_5/code/kernels.py',
 'iteration_5_performance/gpu/cuda_history.py','iteration_5_performance/cpu/numexpr_objective.py',
 'iteration_6/code/checkpoint_io.py')
DEFAULT_LIMITS=dict(global_work_seconds=14400.,simulation_seconds=120.,fit_seconds=900.,
 validation_seconds=600.,child_seconds=1650.,max_events=100000,max_proposals=5000000,
 fit_history_estimate_mib=24576.,validation_history_estimate_mib=26000.)
MODELS=('ml_null','ml_shared','ml_separate_scale')
TERMINAL=('validated','simulation_censored','fit_failed','gate_failed','resource_limited','error','time_cap')


def validate_config(config):
    """Validate identities/design only, with no GPU import or random draws."""
    if config.get('schema_version')!=1:raise ValueError('Unsupported power configuration')
    if config.get('maxiter',100)!=100 or config.get('ratios',[.4,.7,.8])!=[.4,.7,.8]:
        raise ValueError('The full frozen estimator must retain maxiter100/ratios')
    settings=config['settings'];draws=config['draws'];ids=set();settings_by={}
    for s in settings:
        if s['id'] in settings_by:raise ValueError('Duplicate setting ID')
        if any(not math.isfinite(float(s[k])) or s[k]<=0 for k in ('horizon','beta')):raise ValueError('Invalid horizon/beta')
        fit=s['generating_fit'];p=fit['pars'];stress=fit.get('stress')
        if len(p)!=(4 if stress else 3) or not all(math.isfinite(float(x)) for x in p):raise ValueError('Invalid DGP pars')
        if not (-12<=p[0]<=0 and -2<=p[1]<=2 and 0<=p[2]<1 and 0<=fit['ratio']<1):raise ValueError('DGP outside declared family')
        if stress and not 0<=p[3]<=3:raise ValueError('DGP eta outside fitted box')
        if fit['trigger']['kind'] not in ('exp','ml') or stress and stress['kind'] not in ('exp','ml'):raise ValueError('Mixture DGP required')
        settings_by[s['id']]=s
    seed_groups={};pair_groups={}
    for c in draws:
        if c['id'] in ids:raise ValueError('Duplicate planned ID')
        if c['setting_id'] not in settings_by:raise ValueError('Unknown case setting')
        if not isinstance(c['seed'],int) or isinstance(c['seed'],bool) or not 0<=c['seed']<2**64:raise ValueError('Invalid uint64 seed')
        if not isinstance(c['replication'],int) or c['replication']<0:raise ValueError('Invalid replication')
        if c['phase'] not in ('benchmark','reference','alternative','nested'):raise ValueError('Unknown phase')
        if any(x in c['id'] for x in ('/','\\','..')):raise ValueError('Unsafe case ID')
        if c.get('arm') not in ('old','new') or not c.get('pair_id'):raise ValueError('Explicit arm/pair identity required')
        ids.add(c['id']);seed_groups.setdefault(c['seed'],[]).append(c)
        pair_groups.setdefault(c['pair_id'],[]).append(c)
    for group in seed_groups.values():
        if len(group)==1:
            if group[0]['phase']!='benchmark':raise ValueError('A paired pilot seed must occur exactly twice')
        elif not (len(group)==2 and {c['arm'] for c in group}=={'old','new'} and
                  len({c['pair_id'] for c in group})==1 and len({c['replication'] for c in group})==1 and
                  all(c['phase']=='alternative' for c in group)):
            raise ValueError('Duplicate seed is permitted only for its exact old/new CRN pair')
    for group in pair_groups.values():
        if any(c['phase']=='alternative' for c in group) and not (len(group)==2 and
            {c['arm'] for c in group}=={'old','new'} and len({c['seed'] for c in group})==1):
            raise ValueError('Every pilot pair must contain its two fixed-seed arms exactly once')
    limits=dict(DEFAULT_LIMITS,**config.get('limits',{}))
    if any(not math.isfinite(float(v)) or v<=0 for v in limits.values()):raise ValueError('Positive finite limits required')
    if any(not isinstance(limits[k],int) for k in ('max_events','max_proposals')):raise ValueError('Integer guards required')
    return settings_by,limits


def prepare(config_path,run):
    config_path=Path(config_path).resolve();run=Path(run).resolve()
    if not run.is_relative_to(AREA/'results'):raise ValueError('Run directory must remain inside iteration16/results')
    config=read_json(config_path);_,limits=validate_config(config)
    if sha256(ROOT/'iteration_12/code/stable_history.py')!=STABLE_SHA:raise ValueError('Reviewed stable fitter differs')
    sources={n:sha256(ROOT/n) for n in SOURCE_NAMES}
    authority=dict(schema_version=1,config=config,config_path=str(config_path.relative_to(ROOT)),
        config_sha256=sha256(config_path),sources=sources,limits=limits)
    # The protocol/config must pre-exist every simulation. Optional evidence is
    # bound here as well, without making the runner invent statistical rules.
    authority['protocol_sources']={n:sha256(ROOT/n) for n in config.get('protocol_sources',[])}
    plan=dict(authority,plan_id=canonical_hash(authority))
    run.mkdir(parents=True,exist_ok=True);path=run/'plan.json'
    if path.exists():
        old=read_sealed(path)
        if ({k:old[k] for k in authority}!=authority or canonical_hash({k:old[k] for k in authority})!=plan['plan_id'] or
                old['plan_id']!=plan['plan_id']):raise ValueError('Run configuration/source/protocol/stored authority changed')
        return old
    sealed_json(path,dict(plan,created_utc=utc_now()))
    for name in sources:atomic_bytes(run/'source_snapshots'/name,(ROOT/name).read_bytes())
    atomic_bytes(run/'config.json',config_path.read_bytes())
    return read_sealed(path)


def identity(plan,case):
    return dict(plan_id=plan['plan_id'],**{k:case[k] for k in ('id','setting_id','role','replication','seed','phase','pair_id','arm')})


def verify(record,plan,case):
    if any(record.get(k)!=v for k,v in identity(plan,case).items()):raise ValueError('Artifact identity differs')


def case_path(run,case):return Path(run)/'cases'/case['id']
def setting_for(plan,case):return next(s for s in plan['config']['settings'] if s['id']==case['setting_id'])


def event(path,stage,status,**extra):
    record=dict(id=path.name,stage=stage,status=status,utc=utc_now(),perf_counter=time.perf_counter(),**extra)
    sealed_json(path/'progress.json',record)
    print(json.dumps(record,allow_nan=False),flush=True)


def retained(path,plan,case,status,stage,**extra):
    record=dict(**identity(plan,case),status=status,stage=stage,complete=False,updated_utc=utc_now(),**extra)
    sealed_json(path/'outcome.json',record);event(path,stage,status)
    return record


def load_simulation(plan,case,run):
    import numpy as np
    from clock_simulator import canonical,prefix_digest
    path=case_path(run,case);saved=read_sealed(path/'simulation.json');verify(saved,plan,case)
    if saved['catalogue_sha256']!=sha256(path/'catalogue.npz') or saved['state_sha256']!=sha256(path/'simulation_state.json'):
        raise ValueError('Simulation file hash differs')
    state=read_json(path/'simulation_state.json');payload=dict(state);seal=payload.pop('state_sha256')
    if canonical(payload)!=seal:raise ValueError('Simulation state seal differs')
    with np.load(path/'catalogue.npz',allow_pickle=False) as data:arrays={k:data[k] for k in data.files}
    if prefix_digest(arrays)!=state['prefix_sha256'] or len(arrays['times'])!=state['event_count']:raise ValueError('Simulation prefix differs')
    s=setting_for(plan,case)
    expected=canonical(dict(seed=case['seed'],horizon=float(s['horizon']),beta=float(s['beta']),fit=s['generating_fit']))
    if state['input_sha256']!=expected or state['source_sha256']!=plan['sources']['iteration_12/code/clock_simulator.py']:
        raise ValueError('Generating law/source differs')
    if bool(saved['complete'])!=bool(state['complete']) or saved['reason']!=state['reason']:
        raise ValueError('Generation completion metadata differs from precise state')
    return saved,arrays,state


def simulate_stage(plan,case,run,simulator=None):
    from clock_simulator import simulate_fitted,ARRAY_KEYS
    path=case_path(run,case);path.mkdir(parents=True,exist_ok=True)
    if (path/'simulation.json').exists():return load_simulation(plan,case,run)[0]
    s=setting_for(plan,case);lim=plan['limits'];event(path,'simulation','started');began=time.perf_counter()
    result=(simulator or simulate_fitted)(case['seed'],s['horizon'],s['beta'],s['generating_fit'],
        max_events=lim['max_events'],max_proposals=lim['max_proposals'],seconds=lim['simulation_seconds'])
    # Atomic NPZ refuses to replace a differing orphan left between commits.
    atomic_npz(path/'catalogue.npz',**{k:result[k] for k in ARRAY_KEYS})
    state=result['checkpoint_state'];state_path=path/'simulation_state.json'
    if state_path.exists() and read_json(state_path)!=state:raise ValueError('Orphan simulation state differs')
    if not state_path.exists():atomic_json(state_path,dict(state))
    value=dict(**identity(plan,case),stage='simulation',complete=bool(result['complete']),
        n_events=len(result['times']),reason=result['reason'],proposals=result['proposals'],
        requires_precise_likelihood=result['requires_precise_likelihood'],
        catalogue_sha256=sha256(path/'catalogue.npz'),state_sha256=sha256(state_path),
        elapsed_seconds=time.perf_counter()-began,updated_utc=utc_now())
    sealed_json(path/'simulation.json',value);event(path,'simulation','committed',complete=value['complete'],n_events=value['n_events'])
    return value


def history_estimate(arrays,horizon,order,paired):
    """Exact frozen-constructor panel count, before allocating history arrays."""
    import numpy as np
    from paired_history import difference
    t=arrays['times'];n=len(t);offset=np.geomspace(1e-6,1e5,23)
    offset=np.sort(np.r_[offset,np.sqrt(offset[:-1]*offset[1:])])
    gaps=np.r_[arrays['event_gaps'],difference(horizon,0.,t[-1],arrays['times_lo'][-1])] if paired else np.diff(np.r_[0.,t,horizon])
    nodes=sum(1+int(np.count_nonzero(offset<gap)) for gap in gaps)*order
    return dict(estimate_mib=float((24*n*n+nodes*8*35)/2**20),quadrature_nodes=nodes,quadrature_order=order,n_events=n)


def fixed_history_metrics(arrays,setting):
    """DGP event-time suppression holding that observed history fixed, not causal."""
    import numpy as np
    from empirical_process import unit_productivity,GAMMA,G6
    from kernels import KernelSpec
    fit=setting['generating_fit'];a,d,n=fit['pars'][:3];stress=fit.get('stress');eta=fit['pars'][3] if stress else 0.
    def history(amplitudes,kernel,derivative=False):
        w,r=kernel.mixture;state=np.zeros(len(r));answer=np.empty(len(arrays['times']))
        for j,(gap,amp) in enumerate(zip(arrays['event_gaps'],amplitudes)):
            state*=np.exp(-r*gap);answer[j]=state@(w*r if derivative else w);state+=amp
        return answer
    he=history(unit_productivity(arrays['excess'],setting['beta'],fit['ratio']),KernelSpec(**fit['trigger']),True)
    ge=history(np.exp(GAMMA*arrays['excess'])/G6,KernelSpec(**stress)) if stress else np.zeros(len(he))
    logb=a+d*(2*arrays['times']/setting['horizon']-1)
    logh=np.full_like(he,-np.inf);np.log(he,out=logh,where=he>0)
    logtrigger=math.log(n)+logh if n>0 else np.full_like(he,-np.inf)
    pb=np.exp(logb-np.logaddexp(logb,logtrigger))
    suppression=pb*(-np.expm1(-eta*ge))
    return dict(mean_event_background_fraction=float(pb.mean()),mean_event_fixed_history_total_suppression=float(suppression.mean()),
        median_event_fixed_history_total_suppression=float(np.median(suppression)),eta=float(eta),
        stress_second_moment_finite=bool(setting['beta']>2*GAMMA),productivity_second_moment_finite=bool(fit['ratio']<.5),
        scope='DGP parameters and realized event history held fixed; not coupled causal event-count reduction')


def fit_stage(plan,case,run,history_classes=None,fitter=None):
    import numpy as np
    from threadpoolctl import threadpool_limits
    path=case_path(run,case);sim,arrays,state=load_simulation(plan,case,run)
    final=path/'fit.json'
    if final.exists():
        saved=read_sealed(final);verify(saved,plan,case)
        if saved['catalogue_sha256']!=sim['catalogue_sha256']:raise ValueError('Saved fit catalogue differs')
        return saved
    if not sim['complete']:return retained(path,plan,case,'simulation_censored','simulation',reason=sim['reason'])
    if len(arrays['times'])<2 or np.any(arrays['excess']<0) or not np.isfinite(arrays['excess']).all() or arrays['excess'].mean()<=0:
        return retained(path,plan,case,'fit_failed','fit',reason='Insufficient/invalid realized events, no replacement')
    s=setting_for(plan,case);paired=bool(sim['requires_precise_likelihood']);estimate=history_estimate(arrays,s['horizon'],16,paired)
    lim=plan['limits'];allowance=lim['fit_history_estimate_mib']
    if estimate['estimate_mib']>allowance:return retained(path,plan,case,'resource_limited','fit',**estimate,limit_mib=allowance)
    from paired_history import PairedHistory,cuda_history_class
    from empirical_process import EmpiricalHistory
    from stable_history import fit_with_recovery
    torch=None
    if history_classes is None:
        import torch
        from cuda_history import CUDAHistory
        history_classes=(cuda_history_class() if paired else CUDAHistory,PairedHistory if paired else EmpiricalHistory)
    gpu,cpu=history_classes;extra=dict(times_lo=arrays['times_lo'],event_gaps=arrays['event_gaps']) if paired else {}
    def cpu_factory(*args,**kwargs):return cpu(*args,**kwargs,**extra)
    beta=float(1/arrays['excess'].mean());event(path,'fit','started',n_events=len(arrays['times']),paired=paired);began=time.perf_counter()
    with threadpool_limits(limits=1):
        if torch is not None:torch.set_num_threads(1);torch.cuda.init();torch.cuda.reset_peak_memory_stats()
        h=gpu(arrays['times'],arrays['excess'],beta,s['horizon'],s['horizon'],order=16,memory_limit_mb=allowance,**extra)
        fit=(fitter or fit_with_recovery)(h,maxiter=100,ratios=(.4,.7,.8),include_omori=False,deadline=began+lim['fit_seconds'],
            history_factory=cpu_factory if paired else None)
        if torch is not None:torch.cuda.synchronize()
        whole=bool(fit['complete'] and fit['resource_grid_complete'] and len(fit['subfits'])==234 and sum(r['origin']=='optimizer' for r in fit['subfits'])==162)
        value=dict(**identity(plan,case),catalogue_sha256=sim['catalogue_sha256'],fit=fit,complete=whole,
            beta_refitted=beta,paired_likelihood=paired,elapsed_seconds=time.perf_counter()-began,
            history_estimate=estimate,peak_cuda_allocated_bytes=torch.cuda.max_memory_allocated() if torch is not None else None,
            dgp_fixed_history_metrics=fixed_history_metrics(arrays,s),updated_utc=utc_now())
        sealed_json(final if whole else path/'fit_incomplete.json',value)
        del h;gc.collect()
        if torch is not None:torch.cuda.synchronize();torch.cuda.empty_cache()
    event(path,'fit','committed' if whole else 'incomplete',whole_grid=whole,all_converged=fit['all_optimizations_converged'])
    if not whole or not fit['all_optimizations_converged']:
        retained(path,plan,case,'fit_failed','fit',reason='Incomplete grid or failed prescribed optimizer',fit_complete=whole)
    return value


def validation_stage(plan,case,run,history_class=None,scorer=None):
    import numpy as np
    from threadpoolctl import threadpool_limits
    from empirical_process import EmpiricalHistory,score_fit
    from paired_history import PairedHistory
    path=case_path(run,case);sim,arrays,state=load_simulation(plan,case,run);saved=read_sealed(path/'fit.json');verify(saved,plan,case)
    final=path/'validation.json';fit_sha=sha256(path/'fit.json')
    if final.exists():
        result=read_sealed(final);verify(result,plan,case)
        if result['fit_sha256']!=fit_sha:raise ValueError('Saved validation fit differs')
        return result
    if saved['catalogue_sha256']!=sim['catalogue_sha256']:raise ValueError('Validation catalogue differs')
    f=saved['fit'];s=setting_for(plan,case);paired=saved['paired_likelihood'];lim=plan['limits']
    estimate=history_estimate(arrays,s['horizon'],32,paired);allowance=lim['validation_history_estimate_mib']
    if estimate['estimate_mib']>allowance:return retained(path,plan,case,'resource_limited','validation',**estimate,limit_mib=allowance,fit_sha256=fit_sha)
    beta=float(1/arrays['excess'].mean())
    if beta!=saved['beta_refitted']:raise ValueError('Validation beta differs')
    extra=dict(times_lo=arrays['times_lo'],event_gaps=arrays['event_gaps']) if paired else {}
    cls=history_class or (PairedHistory if paired else EmpiricalHistory)
    event(path,'validation','started');began=time.perf_counter();deltas={}
    with threadpool_limits(limits=1):
        h=cls(arrays['times'],arrays['excess'],beta,s['horizon'],s['horizon'],order=32,memory_limit_mb=allowance,**extra)
        for model in MODELS:
            if time.perf_counter()-began>lim['validation_seconds']:raise TimeoutError('CPU32 validation deadline')
            deltas[model]=float((scorer or score_fit)(h,f['best'][model])+f['best'][model]['nll'])
            print(json.dumps(dict(id=case['id'],event='CPU32_model_finished',model=model,delta=deltas[model])),flush=True)
    best=f['best'];stats=dict(feedback=2*(best['ml_null']['nll']-best['ml_separate_scale']['nll']),sharing=2*(best['ml_shared']['nll']-best['ml_separate_scale']['nll']))
    finite_records=all(r['nll'] is not None and math.isfinite(r['nll']) and all(math.isfinite(x) for x in r['pars']) for r in f['subfits'])
    passed=bool(f['complete'] and f['resource_grid_complete'] and f['all_optimizations_converged'] and len(f['subfits'])==234 and
        sum(r['origin']=='optimizer' for r in f['subfits'])==162 and finite_records and
        np.isfinite(list(deltas.values())).all() and np.isfinite(list(stats.values())).all() and
        max(abs(v) for v in deltas.values())<1e-4 and min(stats.values())>=-1e-7 and time.perf_counter()-began<=lim['validation_seconds'])
    result=dict(**identity(plan,case),complete=True,passed=passed,fit_sha256=fit_sha,catalogue_sha256=sim['catalogue_sha256'],
        statistics=stats,deltas=deltas,beta_refitted=beta,elapsed_seconds=time.perf_counter()-began,history_estimate=estimate,updated_utc=utc_now())
    sealed_json(final,result);event(path,'validation','committed',passed=passed)
    if not passed:retained(path,plan,case,'gate_failed','validation',fit_sha256=fit_sha)
    return result


def state_for(plan,case,run):
    path=case_path(run,case)
    if (path/'outcome.json').exists():
        value=read_sealed(path/'outcome.json');verify(value,plan,case);return value['status']
    if (path/'validation.json').exists():
        value=read_sealed(path/'validation.json');verify(value,plan,case)
        if value['fit_sha256']!=sha256(path/'fit.json'):raise ValueError('Validation authority differs')
        fitted=read_sealed(path/'fit.json');verify(fitted,plan,case)
        sim=read_sealed(path/'simulation.json');verify(sim,plan,case)
        if not (value['catalogue_sha256']==fitted['catalogue_sha256']==sim['catalogue_sha256']==sha256(path/'catalogue.npz')):
            raise ValueError('Saved stage catalogue authority differs')
        if value.get('passed'):
            f=fitted['fit']
            valid=(value.get('complete') and fitted.get('complete') and f['complete'] and f['resource_grid_complete'] and
                f['all_optimizations_converged'] and len(f['subfits'])==234 and sum(r['origin']=='optimizer' for r in f['subfits'])==162 and
                all(r['success'] and r['nll'] is not None and math.isfinite(r['nll']) and all(math.isfinite(x) for x in r['pars']) for r in f['subfits']) and
                len(value['deltas'])==3 and set(value['deltas'])==set(MODELS) and all(math.isfinite(x) and abs(x)<1e-4 for x in value['deltas'].values()) and
                set(value['statistics'])=={'feedback','sharing'} and all(math.isfinite(x) and x>=-1e-7 for x in value['statistics'].values()))
            if not valid:raise ValueError('Invalid cached passed validation/full estimator gate')
        return 'validated' if value['passed'] else 'gate_failed'
    if (path/'fit.json').exists():return 'fit_complete'
    if (path/'simulation.json').exists():
        value=read_sealed(path/'simulation.json');verify(value,plan,case)
        return 'simulation_complete' if value['complete'] else 'simulation_censored'
    return 'pending'
