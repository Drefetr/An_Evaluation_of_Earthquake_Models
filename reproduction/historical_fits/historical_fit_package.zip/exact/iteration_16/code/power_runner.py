"""Guarded sequential-GPU paired precision runner; no periodic scientific checkpoints."""
from pathlib import Path
import sys,os,argparse,json,time,traceback,multiprocessing as mp
sys.dont_write_bytecode=True
from power_engine import (ROOT,AREA,prepare,case_path,identity,event,retained,simulate_stage,
                         fit_stage,validation_stage,state_for,TERMINAL,read_sealed,
                         sealed_json,utc_now,sha256)
from checkpoint_io import ChildJob,RunLock


def worker(plan,case,run,ready=None):
    # No work or checkpoint writes before parent-owned Job assignment. A child
    # orphaned in that short window exits instead of beginning a generation.
    if ready is not None:
        began=time.perf_counter()
        while not ready.wait(.1):
            parent=mp.parent_process()
            if parent is None or not parent.is_alive() or time.perf_counter()-began>15.:return
    log=Path(run)/'logs'/(case['id']+'.log');log.parent.mkdir(parents=True,exist_ok=True)
    stream=log.open('a',encoding='utf-8',buffering=1);sys.stdout=stream;sys.stderr=stream
    path=case_path(run,case);path.mkdir(parents=True,exist_ok=True)
    try:
        sim=simulate_stage(plan,case,run)
        if not sim['complete']:
            retained(path,plan,case,'simulation_censored','simulation',reason=sim['reason']);return
        fit_stage(plan,case,run)
        if not (path/'outcome.json').exists():validation_stage(plan,case,run)
    except TimeoutError as exc:
        traceback.print_exc();retained(path,plan,case,'time_cap','worker',error=str(exc))
    except BaseException as exc:
        traceback.print_exc();retained(path,plan,case,'error','worker',error=f'{type(exc).__name__}: {exc}')
        raise
    finally:stream.flush()


def sessions_read(run):
    path=Path(run)/'sessions.json'
    return read_sealed(path)['sessions'] if path.exists() else []


def recover_unclean(sessions,cap):
    """No heartbeat: reserve a whole unfinished child cap once, not downtime."""
    for s in sessions:
        if not s.get('closed'):
            s['elapsed_seconds']+=cap if s.get('active_case_id') else 0.
            s.update(closed=True,reason='unclean_upper_bound',reserved_upper_bound_seconds=cap if s.get('active_case_id') else 0.)
    return sessions


def save_sessions(run,sessions):sealed_json(Path(run)/'sessions.json',dict(sessions=sessions,updated_utc=utc_now()))


def summary(plan,run,states,sessions,reason):
    counts={s:sum(v==s for v in states.values()) for s in sorted(set(states.values()))}
    record=dict(plan_id=plan['plan_id'],updated_utc=utc_now(),reason=reason,total_planned=len(states),counts=counts,
        completed_terminal=sum(counts.get(s,0) for s in TERMINAL),
        completed_validated=counts.get('validated',0),unresolved_terminal=sum(counts.get(s,0) for s in TERMINAL if s!='validated'),
        all_planned_validated=bool(states and all(s=='validated' for s in states.values())),
        work_seconds_charged=sum(s['elapsed_seconds'] for s in sessions),
        work_scope='Cumulative parent wall in owned execution sessions; unclean active case conservatively reserves full child cap; no UTC downtime treated as compute',
        active_ids=[s['active_case_id'] for s in sessions if not s.get('closed') and s.get('active_case_id')])
    sealed_json(Path(run)/'summary.json',record);return record


def run_cases(plan,run,phase='all',case_id=None,stop_after=None):
    run=Path(run);lim=plan['limits'];draws=plan['config']['draws']
    if case_id is not None and not any(c['id']==case_id for c in draws):raise ValueError('Unplanned case ID')
    selected=[c for c in draws if (phase=='all' or c['phase']==phase) and (case_id is None or c['id']==case_id)]
    if not selected:raise ValueError('No cases selected')
    with RunLock(run/'runner.lock'):
        # One initial reconciliation; in-loop only the just-finished case is read.
        states={c['id']:state_for(plan,c,run) for c in draws}
        sessions=recover_unclean(sessions_read(run),lim['child_seconds']);save_sessions(run,sessions)
        started=time.perf_counter();previous=sum(s['elapsed_seconds'] for s in sessions)
        s=dict(started_utc=utc_now(),elapsed_seconds=0.,active_case_id=None,closed=False,phase=phase,selected_case_id=case_id)
        sessions.append(s);save_sessions(run,sessions);summary(plan,run,states,sessions,'active')
        count=0;reason='selected_complete';fatal=False
        try:
            for case in selected:
                if states[case['id']] in TERMINAL:continue
                if (run/'STOP').exists():reason='stop_requested';break
                if previous+time.perf_counter()-started>=lim['global_work_seconds']:reason='global_budget';break
                s.update(active_case_id=case['id'],elapsed_seconds=time.perf_counter()-started);save_sessions(run,sessions)
                context=mp.get_context('spawn');ready=context.Event()
                child=context.Process(target=worker,args=(plan,case,str(run),ready))
                job=ChildJob();case_began=time.perf_counter();cap_reason=None
                try:
                    child.start();job.assign(child);ready.set()
                    print(json.dumps(dict(id=case['id'],event='started',pid=child.pid,phase=case['phase'],
                        completed_overall=sum(v in TERMINAL for v in states.values()),planned_overall=len(states),
                        validated_overall=sum(v=='validated' for v in states.values()))),flush=True)
                    while child.is_alive():
                        child.join(.5);now=time.perf_counter()
                        if now-case_began>lim['child_seconds']:cap_reason='child_wall_cap';break
                        if previous+now-started>lim['global_work_seconds']:cap_reason='global_budget';break
                        try:p=read_sealed(case_path(run,case)/'progress.json')
                        except (FileNotFoundError,PermissionError):continue
                        cap=lim.get(p['stage']+'_seconds')
                        if p['status']=='started' and p['perf_counter']>=case_began and cap and now-p['perf_counter']>cap:
                            cap_reason=p['stage']+'_wall_cap';break
                    if cap_reason:
                        child.terminate();child.join(10)
                        retained(case_path(run,case),plan,case,'time_cap','parent',reason=cap_reason)
                    elif child.exitcode!=0:
                        fatal=True
                        if not (case_path(run,case)/'outcome.json').exists():
                            retained(case_path(run,case),plan,case,'error','parent',reason='Unexpected worker exit',exitcode=child.exitcode)
                finally:
                    job.close()
                    if child.is_alive():child.terminate();child.join(10)
                states[case['id']]=state_for(plan,case,run);count+=1
                s.update(active_case_id=None,elapsed_seconds=time.perf_counter()-started);save_sessions(run,sessions)
                progress=summary(plan,run,states,sessions,'active')
                print(json.dumps(dict(id=case['id'],event='finished',status=states[case['id']],worker_exitcode=child.exitcode,
                    elapsed_seconds=time.perf_counter()-case_began,completed_overall=progress['completed_terminal'],
                    planned_overall=progress['total_planned'],validated_overall=progress['completed_validated'])),flush=True)
                if fatal:reason='unexpected_worker_failure';break
                if cap_reason=='global_budget':reason='global_budget';break
                if stop_after is not None and count>=stop_after:reason='stop_after';break
        except BaseException as exc:
            reason='parent_exception:'+type(exc).__name__
            raise
        finally:
            s.update(active_case_id=None,elapsed_seconds=time.perf_counter()-started,closed=True,reason=reason,ended_utc=utc_now());save_sessions(run,sessions)
            final=summary(plan,run,states,sessions,reason)
            sealed_json(run/'case_index.json',dict(plan_id=plan['plan_id'],states=states,updated_utc=utc_now()))
        if fatal:return 2
        if reason in ('global_budget','unexpected_worker_failure'):return 2
        if reason in ('stop_requested','stop_after'):return 0
        return 0 if all(states[c['id']]=='validated' for c in selected) else 2


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',default=str(AREA/'configs/precision.json'))
    parser.add_argument('--run-dir',default=str(AREA/'results/precision'));parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--resume',action='store_true');parser.add_argument('--status',action='store_true')
    parser.add_argument('--phase',choices=('all','benchmark','reference','alternative','nested'),default='all')
    parser.add_argument('--case');parser.add_argument('--stop-after',type=int)
    args=parser.parse_args();run=Path(args.run_dir).resolve()
    if not run.is_relative_to(AREA/'results'):raise ValueError('Run must remain under iteration16/results')
    if args.status:
        if (run/'summary.json').exists():status=read_sealed(run/'summary.json')
        elif (run/'plan.json').exists():
            saved_plan=read_sealed(run/'plan.json');planned=len(saved_plan['config']['draws'])
            status=dict(prepared=True,active=False,plan_id=saved_plan['plan_id'],total_planned=planned,
                completed_terminal=0,completed_validated=0,pending=planned,counts=dict(pending=planned),
                all_planned_validated=False,active_ids=[],work_seconds_charged=0.)
        else:status=dict(prepared=False,active=False,total_planned=0,completed_validated=0,pending=0)
        print(json.dumps(status,indent=2));return 0
    if args.stop_after is not None and args.stop_after<=0:raise ValueError('Positive stop-after required')
    plan=prepare(args.config,run)
    if args.prepare_only:print(json.dumps(dict(prepared=True,plan_id=plan['plan_id'],planned=len(plan['config']['draws']),scientific_work_launched=False)));return 0
    if not args.resume:raise ValueError('Explicit --resume required to execute prepared precision run')
    return run_cases(plan,run,args.phase,args.case,args.stop_after)


if __name__=='__main__':raise SystemExit(main())
