"""Freeze/check the new 150-pair cohort. Never simulate, fit or choose outcomes."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import argparse, copy, csv, hashlib, json, re, subprocess
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT / "iteration_16"
sys.path.insert(0, str(ROOT / "iteration_6/code"))
from checkpoint_io import atomic_json, read_json, read_sealed, sealed_json, sha256

R = 150
WORK_SECONDS = 14400.0


def prior_seeds():
    folders = sorted(p for p in ROOT.glob("iteration_*") if p.is_dir() and p != AREA)
    result = subprocess.run(["rg", "--no-heading", "--no-filename", "--glob", "*.json",
        "-o", r'"seed"\s*:\s*[0-9]+', *map(str, folders)],
        capture_output=True, text=True, timeout=60)
    if result.returncode not in (0, 1) or result.stderr:
        raise ValueError("Prior JSON seed scan failed: " + result.stderr)
    seeds = {int(x) for x in re.findall(r"\d+", result.stdout)}
    csv_fields = 0
    for folder in folders:
        for path in folder.rglob("*.csv"):
            with path.open(encoding="utf-8-sig", newline="") as stream:
                rows = csv.DictReader(stream)
                keys = [k for k in (rows.fieldnames or []) if k.strip().lower() == "seed"]
                for row in rows if keys else ():
                    for key in keys:
                        value = (row.get(key) or "").strip()
                        if value.isdecimal():
                            seeds.add(int(value)); csv_fields += 1
    return seeds, csv_fields


def expected_draws():
    pairs, draws = [], []
    for rep in range(R):
        seed = int(np.random.SeedSequence([20261016, 16, 800, rep]).generate_state(1, dtype=np.uint64)[0])
        pair_id = f"pair_{rep:03d}"
        pairs.append(dict(id=pair_id, replication=rep, seed=seed))
        for arm in ("old", "new"):
            draws.append(dict(id=f"{arm}_r{rep:03d}", setting_id=arm, role="alternative",
                phase="alternative", arm=arm, pair_id=pair_id, replication=rep, seed=seed))
    return pairs, draws


def freeze():
    paths = [AREA/"configs/design.json", AREA/"configs/precision.json", AREA/"results/allocation.json"]
    if any(p.exists() for p in paths):
        raise FileExistsError("Preserve existing design/config/allocation; use --check")
    previous, csv_fields = prior_seeds()
    pairs, draws = expected_draws()
    fresh = {p["seed"] for p in pairs}
    if len(fresh) != R or fresh & previous:
        raise ValueError("New pair streams duplicate/overlap prior seeds")
    source = ROOT/"iteration_15/configs/design.json"
    old_design = read_json(source)
    design = dict(schema_version=1, settings=copy.deepcopy(old_design["settings"]), pairs=pairs, draws=draws,
        source_input=copy.deepcopy(old_design["source_input"]),
        planning_design=dict(path=source.relative_to(ROOT).as_posix(), sha256=sha256(source)),
        seed_audit=dict(prior_unique=len(previous), prior_csv_fields=csv_fields, new_unique=R,
            overlap=0, intentional_pair_reuse=True,
            prior_set_sha256=hashlib.sha256(json.dumps(sorted(previous), separators=(",", ":")).encode()).hexdigest()),
        design=dict(fixed_R=R, total_scientific_budget_seconds=WORK_SECONDS,
            no_nested_bootstrap=True, no_automatic_500=True, planning_pilot_not_pooled=True,
            primary_null_B=1999, reject_if_rank_le=.05, ties=">=",
            estimand="Known-law fixed-reference conditional screening frequencies; not fitted-null-bootstrap power"))
    atomic_json(paths[0], design)
    config = copy.deepcopy(read_json(ROOT/"iteration_15/configs/pilot.json"))
    config.update(settings=design["settings"], draws=draws,
        purpose="Fixed 150 NEW pairs; no planning-pilot pooling or outcome-dependent extension",
        protocol_sources=[
            "iteration_16/configs/design.json", "iteration_16/reports/statistical_design.md",
            "iteration_16/code/prepare_precision.py", "iteration_16/code/preflight.py",
            "iteration_16/code/power_summary.py", "iteration_16/run_precision.ps1",
            "iteration_16/results/allocation.json", "iteration_16/reviews/C_null_bank_review.json",
            "iteration_16/environment.json", old_design["source_input"]["path"]])
    config["limits"]["global_work_seconds"] = WORK_SECONDS
    atomic_json(paths[1], config)
    sealed_json(paths[2], dict(R=R, mode="fixed_fresh_precision", design_sha256=sha256(paths[0]),
        global_work_seconds=WORK_SECONDS, planning_pilot_not_pooled=True))
    return check()


def check():
    design = read_json(AREA/"configs/design.json")
    config = read_json(AREA/"configs/precision.json")
    allocation = read_sealed(AREA/"results/allocation.json")
    pairs, draws = expected_draws()
    old = read_json(ROOT/"iteration_15/configs/pilot.json")
    if not (design["pairs"] == pairs and design["draws"] == config["draws"] == draws
            and design["settings"] == config["settings"] == old["settings"]):
        raise ValueError("Frozen generating law or pair identities changed")
    expected_limits = dict(old["limits"], global_work_seconds=WORK_SECONDS)
    if config["limits"] != expected_limits or config["maxiter"] != 100 or config["ratios"] != [.4,.7,.8]:
        raise ValueError("Frozen estimator/resource contract changed")
    if not (allocation["R"] == R and allocation["mode"] == "fixed_fresh_precision"
            and allocation["design_sha256"] == sha256(AREA/"configs/design.json")
            and allocation["global_work_seconds"] == WORK_SECONDS
            and allocation["planning_pilot_not_pooled"] is True):
        raise ValueError("Frozen allocation changed")
    for key in ("source_input", "planning_design"):
        item = design[key]
        if sha256(ROOT/item["path"]) != item["sha256"]:
            raise ValueError("Source/planning design changed")
    if not (design["design"]["fixed_R"] == R and design["design"]["planning_pilot_not_pooled"]
            and design["seed_audit"]["new_unique"] == R and design["seed_audit"]["overlap"] == 0):
        raise ValueError("Prospective cohort metadata changed")
    return dict(prepared=True, pairs=R, cases=2*R, work_cap_seconds=WORK_SECONDS,
        scientific_work_launched=False, config_sha256=sha256(AREA/"configs/precision.json"),
        seed_audit=design["seed_audit"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.freeze and args.check:
        parser.error("Choose --freeze or --check")
    print(json.dumps(freeze() if args.freeze else check(), indent=2))
