"""Terminal-only fixed150-pair known-law summary; no simulation or fitting.

Authority/fit checks adapt iteration 13's separately reviewed summary. The full
reference bank remains read-only. No outcome-dependent selection is permitted.
"""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import argparse, csv, io, math, importlib.util
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT/"iteration_16"
sys.path.insert(0, str(ROOT/"iteration_6/code"))
from checkpoint_io import read_json, read_sealed, sealed_json, sha256, canonical_hash, atomic_bytes, utc_now
_ENGINE = None
SCIENTIFIC_SOURCES = {
    "iteration_16/code/power_engine.py", "iteration_16/code/power_runner.py",
    "iteration_12/code/stable_history.py", "iteration_12/code/paired_history.py",
    "iteration_12/code/clock_simulator.py", "iteration_9/code/numerical_fit.py",
    "iteration_5/code/empirical_process.py", "iteration_5/code/kernels.py",
    "iteration_5_performance/gpu/cuda_history.py", "iteration_5_performance/cpu/numexpr_objective.py",
    "iteration_6/code/checkpoint_io.py",
}


def require(value, message):
    if not value: raise ValueError(message)


def previous_summary():
    spec = importlib.util.spec_from_file_location("previous_power_summary", ROOT/"iteration_13/code/power_summary.py")
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def rank(value, references):
    if len(references) != 1999: return None
    require(math.isfinite(value) and all(math.isfinite(x) for x in references), "Nonfinite statistic")
    return (1+sum(x >= value for x in references))/2000


def paired_summary(pairs):
    require(bool(pairs), "Empty pair set")
    table = dict(neither=0, old_only=0, new_only=0, both=0, unknown=0)
    delta, bounds = [], []
    for old, new in pairs:
        require(all(v is None or type(v) is bool for v in (old,new)), "Invalid paired decision")
        bounds.append([(int(new) if new is not None else 0)-(int(old) if old is not None else 1),
                       (int(new) if new is not None else 1)-(int(old) if old is not None else 0)])
        if old is None or new is None:
            table["unknown"] += 1; continue
        table["both" if old and new else "old_only" if old else "new_only" if new else "neither"] += 1
        delta.append(int(new)-int(old))
    n = len(pairs)
    complete = not table["unknown"]
    return dict(requested=n, complete=complete, table=table,
        mean_gain=float(np.mean(delta)) if complete else None,
        MCSE=float(np.std(delta,ddof=1)/math.sqrt(n)) if complete and n>1 else None,
        accounting_bounds=[sum(v[i] for v in bounds)/n for i in (0,1)],
        scope="Paired conditional screening-frequency difference; descriptive MCSE, no confidence interval")


def checked_case(run, case, plan):
    global _ENGINE
    if _ENGINE is None:
        spec=importlib.util.spec_from_file_location("iteration16_checked_engine",AREA/"code/power_engine.py")
        _ENGINE=importlib.util.module_from_spec(spec);spec.loader.exec_module(_ENGINE)
    state_for,load_simulation,verify=_ENGINE.state_for,_ENGINE.load_simulation,_ENGINE.verify
    path=run/"cases"/case["id"]; status=state_for(plan,case,run)
    result=dict(**case,status=status,statistics=None,n_events=None,simulation_complete=None,realized_effect=None)
    if (path/"simulation.json").exists():
        sim=read_sealed(path/"simulation.json")
        verify(sim,plan,case)
        result.update(n_events=sim["n_events"],simulation_complete=sim["complete"])
    if status!="validated":return result
    sim,arrays,state=load_simulation(plan,case,run)
    require(sim["complete"] and state["complete"] and state["pending_accept"] is None,"Validated incomplete generation")
    fit=read_sealed(path/"fit.json"); val=read_sealed(path/"validation.json")
    verify(fit,plan,case);verify(val,plan,case)
    require(val["complete"] and val["passed"] and val["fit_sha256"]==sha256(path/"fit.json"),"Validation authority differs")
    require(fit["catalogue_sha256"]==val["catalogue_sha256"]==sim["catalogue_sha256"],"Catalogue chain differs")
    f=fit["fit"];records=f["subfits"];starts=[r for r in records if r["origin"]=="optimizer"]
    require(f["complete"] and f["resource_grid_complete"] and f["all_optimizations_converged"],"Full estimator incomplete")
    require(len(records)==234 and len(starts)==162 and all(r["success"] for r in records),"Grid/start acceptance differs")
    best={}
    for r in records:
        require(r["nll"] is not None and math.isfinite(r["nll"]) and all(math.isfinite(x) for x in r["pars"]),"Nonfinite fit record")
        bounds=[(-12.,0.),(-2.,2.),(0.,.98)]+([(0.,3.)] if r.get("stress") else [])
        require(len(r["pars"])==len(bounds) and all(lo<=v<=hi for v,(lo,hi) in zip(r["pars"],bounds)) and
                r["ratio"] in (.4,.7,.8),"Fit outside fixed parameter/grid domain")
        if r["success"] and (r["model"] not in best or r["nll"]<best[r["model"]]["nll"]):best[r["model"]]=r
    require(best==f["best"],"Selected winner differs")
    q=arrays["excess"]
    require(len(q)>=2 and np.isfinite(q).all() and (q>=0).all() and q.mean()>0 and
            np.isfinite(arrays["event_gaps"]).all() and (arrays["event_gaps"]>0).all(),"Invalid accepted marks/gaps")
    beta=float(1/q.mean())
    require(beta==fit["beta_refitted"]==val["beta_refitted"],"Refitted mark rate differs")
    stats=dict(feedback=2*(best["ml_null"]["nll"]-best["ml_separate_scale"]["nll"]),
               sharing=2*(best["ml_shared"]["nll"]-best["ml_separate_scale"]["nll"]))
    require(stats==val["statistics"] and all(math.isfinite(v) and v>=-1e-7 for v in stats.values()),"Likelihood statistic differs")
    require(set(val["deltas"])=={"ml_null","ml_shared","ml_separate_scale"} and
            all(math.isfinite(v) and abs(v)<1e-4 for v in val["deltas"].values()),"CPU32 gate differs")
    result.update(statistics=stats,n_events=len(arrays["times"]),realized_effect=fit["dgp_fixed_history_metrics"],
        best_parameters={k:dict(pars=v["pars"],ratio=v["ratio"],trigger=v["trigger"],stress=v.get("stress")) for k,v in best.items()},
        maximum_CPU32_delta=max(abs(v) for v in val["deltas"].values()),fit_sha256=sha256(path/"fit.json"),
        validation_sha256=sha256(path/"validation.json"),catalogue_sha256=sim["catalogue_sha256"])
    return result


def validate_authority(plan, allocation, design, actual):
    keys=("schema_version","config","config_path","config_sha256","sources","limits","protocol_sources")
    require(canonical_hash({k:plan[k] for k in keys})==plan["plan_id"],"Stored plan authority differs")
    require(plan["config"]==actual and plan["config_sha256"]==sha256(AREA/"configs/precision.json"),"Config authority differs")
    R=allocation["R"]
    require(type(R) is int and R==150 and allocation["mode"]=="fixed_fresh_precision" and
            allocation["planning_pilot_not_pooled"] is True,"Fixed150 fresh allocation differs")
    require(design["design"]["fixed_R"]==150 and design["design"]["total_scientific_budget_seconds"]==14400. and
            design["design"]["no_nested_bootstrap"] is True and design["design"]["no_automatic_500"] is True,
            "Fixed precision design differs")
    require(design["schema_version"]==1 and design["design"]["planning_pilot_not_pooled"] is True and
            design["design"]["primary_null_B"]==1999 and design["design"]["reject_if_rank_le"]==.05 and
            design["design"]["ties"]==">=","Test rule or planning-pilot exclusion differs")
    require(actual["settings"]==design["settings"],"Generating settings changed")
    expected=design["draws"]
    require(len(expected)==300 and len({c["id"] for c in expected})==300 and actual["draws"]==expected,
            "Fresh pair identity/order/quota changed")
    require(actual["schema_version"]==1 and actual["maxiter"]==100 and actual["ratios"]==[.4,.7,.8],
            "Estimator configuration differs")
    require(set(plan["sources"])==SCIENTIFIC_SOURCES and
            set(plan["protocol_sources"])==set(actual["protocol_sources"]),"Pinned source inventory differs")
    for name,digest in plan["sources"].items():require(sha256(ROOT/name)==digest,"Pinned numerical source changed")
    for name,digest in plan["protocol_sources"].items():require(sha256(ROOT/name)==digest,"Pinned design source changed")
    require(allocation["design_sha256"]==sha256(AREA/"configs/design.json"),"Allocation authority differs")
    require(plan["limits"]["global_work_seconds"]==allocation["global_work_seconds"]==14400.,"Fixed session budget differs")
    fixed_caps=dict(simulation_seconds=120.,fit_seconds=900.,validation_seconds=600.,child_seconds=1550.,
                    max_events=100000,max_proposals=5000000,fit_history_estimate_mib=24576.,validation_history_estimate_mib=26000.)
    require(all(plan["limits"][k]==v for k,v in fixed_caps.items()),"Scientific stage/resource caps differ")
    require(actual["limits"]==plan["limits"],"Configured and effective resource limits differ")
    planning=ROOT/design["planning_design"]["path"]
    require(sha256(planning)==design["planning_design"]["sha256"] and
            design["settings"]==read_json(planning)["settings"],"Planning settings authority changed")
    source=ROOT/design["source_input"]["path"]
    require(sha256(source)==design["source_input"]["sha256"],"Validated generating-law source changed")
    cell=next(c for c in read_json(source)["cells"] if c["id"]=="h1_e20")
    expected_settings=[dict(id=arm,horizon=24394.,beta=cell["beta"],generating_fit=cell[arm+"_fit"]) for arm in ("old","new")]
    require(design["settings"]==expected_settings,"Exact old/new laws differ")
    require(len(design["pairs"])==150 and len({c["id"] for c in design["pairs"]})==150,
            "Fixed pair authority quota differs")
    seeds=set()
    for r in range(R):
        pair=[c for c in expected if c["replication"]==r]
        seed=int(np.random.SeedSequence([20261016,16,800,r]).generate_state(1,dtype=np.uint64)[0])
        seeds.add(seed)
        require(design["pairs"][r]==dict(id=f"pair_{r:03d}",replication=r,seed=seed),"Fixed pair authority differs")
        require(len(pair)==2 and {c["arm"] for c in pair}=={"old","new"} and
                all(c["seed"]==seed and c["pair_id"]==f"pair_{r:03d}" and c["id"]==f"{c['arm']}_r{r:03d}" and
                    c["setting_id"]==c["arm"] and c["role"]=="alternative" and c["phase"]=="alternative" for c in pair),"Fixed pair/seed identity differs")
    require(len(seeds)==150 and len({c["seed"] for c in expected})==150,"Independent pair seed collision")
    return R


def collect(run):
    run=Path(run).resolve()
    require(run.is_relative_to(AREA/"results"),"Run must remain inside iteration16/results")
    old=previous_summary()
    plan=read_sealed(run/"plan.json");allocation=read_sealed(AREA/"results/allocation.json")
    design=read_json(AREA/"configs/design.json");actual=read_json(AREA/"configs/precision.json")
    R=validate_authority(plan,allocation,design,actual)
    summary=read_sealed(run/"summary.json");sessions=read_sealed(run/"sessions.json")
    old.require_terminal(summary,sessions,None,plan)
    index=read_sealed(run/"case_index.json")
    old.require_terminal(summary,sessions,index,plan)
    require(summary["total_planned"]==2*R,"Wrong planned total")
    review_path=AREA/"reviews/C_null_bank_review.json";review=read_sealed(review_path)
    require(review["complete"] and review["matched"] and review["validated_null_count"]==1999,"New bank-match audit incomplete")
    require(review["design_sha256"]==sha256(AREA/"configs/design.json"),"Bank audit design differs")
    require(review["precision_config_sha256"]==sha256(AREA/"configs/precision.json"),"Bank audit fixed config differs")
    require(review["statistical_contract_sha256"]==sha256(AREA/"reports/statistical_design.md"),"Bank audit contract differs")
    require(set(plan["sources"]).issubset(review["current_sources"]) and
            all(review["current_sources"][name]==digest for name,digest in plan["sources"].items()),"Bank audit omits or changes numerical sources")
    for name,digest in review["current_sources"].items():require(sha256(ROOT/name)==digest,"Bank audit numerical source differs")
    protocol=read_json(ROOT/"iteration_13/configs/power_protocol.json")
    bank,bank_authorities=old.baseline_bank(protocol)
    require(bank_authorities["summary_sha256"]==review["aggregate_summary"]["sha256"] and
            bank_authorities["manifest_sha256"]==review["aggregate_cases"]["sha256"] and
            bank_authorities["reuse_review_sha256"]==review["previous_review"]["sha256"],"Audited bank authorities differ")
    references=[c["statistics"]["feedback"] for c in bank]
    require(not ({c["seed"] for c in actual["draws"]}&{c["seed"] for c in bank}),"New/reference seed overlap")
    outcomes=[checked_case(run,c,plan) for c in actual["draws"]]
    require({c["id"]:c["status"] for c in outcomes}==index["states"],"Actual case states differ from terminal index")
    decisions={}
    for c in outcomes:
        p=rank(c["statistics"]["feedback"],references) if c["status"]=="validated" else None
        c.update(rank=p,reject=p<=.05 if p is not None else None)
        decisions[c["id"]]=c["reject"]
    arms={arm:old.decision_summary([c["reject"] for c in outcomes if c["arm"]==arm]) for arm in ("old","new")}
    pairs=[(decisions[f"old_r{r:03d}"],decisions[f"new_r{r:03d}"]) for r in range(R)]
    return dict(created_utc=utc_now(),plan_id=plan["plan_id"],R=R,B=1999,requested=2*R,
        validated=sum(c["status"]=="validated" for c in outcomes),all_planned_validated=all(c["status"]=="validated" for c in outcomes),
        arms=arms,paired=paired_summary(pairs),outcomes=outcomes,
        reference_authorities=bank_authorities,new_bank_review_sha256=sha256(review_path),
        allocation_sha256=sha256(AREA/"results/allocation.json"),runner_summary_sha256=sha256(run/"summary.json"),
        sources=dict(summarizer_sha256=sha256(Path(__file__)),plan_sha256=sha256(run/"plan.json"),
                     design_sha256=sha256(AREA/"configs/design.json"),precision_config_sha256=sha256(AREA/"configs/precision.json")),
        planning_pilot_pooled=False,
        estimand="Known-generating-law fixed-reference conditional screening frequencies, not per-catalogue fitted-null bootstrap power",
        interval_scope="Arm Clopper-Pearson intervals condition on fixed reference bank; paired MCSE is descriptive, not a gain interval")


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--run-dir",type=Path,default=AREA/"results/precision");args=parser.parse_args()
    run=args.run_dir.resolve()
    require(run.is_relative_to(AREA/"results"),"Run must remain inside iteration16/results")
    result=collect(run)
    out=AREA/"results/analysis"/utc_now().replace(":","").replace(".","").replace("+","_")
    out.mkdir(parents=True,exist_ok=False);sealed_json(out/"summary.json",result)
    stream=io.StringIO(newline="");fields=["id","pair_id","arm","seed","status","n_events","feedback","rank","reject"]
    writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
    for c in result["outcomes"]:
        writer.writerow({k:c.get(k) for k in fields if k!="feedback"}|dict(feedback=c["statistics"]["feedback"] if c["statistics"] else None))
    atomic_bytes(out/"outcomes.csv",stream.getvalue().encode())
    print(str(out))
    return 0 if result["all_planned_validated"] else 2


if __name__=="__main__":raise SystemExit(main())
