"""Validate the frozen launch and CUDA, without generating or fitting data."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
import importlib.metadata as metadata, json
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT/"iteration_16"
sys.path.insert(0, str(AREA/"code"))
from prepare_precision import check
from power_engine import prepare, read_json, read_sealed, sha256


def main():
    result = check()
    env = read_json(AREA/"environment.json")
    if Path(sys.executable).resolve() != Path(env["python_executable"]).resolve():
        raise ValueError("Use the recorded Python executable")
    for name, version in env["packages"].items():
        if metadata.version(name) != version:
            raise ValueError("Recorded dependency differs: " + name)
    review = read_sealed(AREA/"reviews/C_null_bank_review.json")
    if not (review["complete"] and review["matched"] and review["validated_null_count"] == 1999):
        raise ValueError("Reference-bank preflight audit is incomplete")
    if review["design_sha256"] != sha256(AREA/"configs/design.json"):
        raise ValueError("Reference-bank design authority changed")
    if review["statistical_contract_sha256"] != sha256(AREA/"reports/statistical_design.md"):
        raise ValueError("Reference-bank statistical contract changed")
    for name, digest in review["current_sources"].items():
        if sha256(ROOT/name) != digest:
            raise ValueError("Audited source changed: " + name)
    from power_summary import previous_summary, validate_authority
    bank, authorities = previous_summary().baseline_bank(
        read_json(ROOT/"iteration_13/configs/power_protocol.json"))
    if not (len(bank) == 1999
            and authorities["summary_sha256"] == review["aggregate_summary"]["sha256"]
            and authorities["manifest_sha256"] == review["aggregate_cases"]["sha256"]
            and authorities["reuse_review_sha256"] == review["previous_review"]["sha256"]):
        raise ValueError("Reference-bank authority chain changed")
    run = AREA/"results/precision"
    if (run/"STOP").exists():
        raise ValueError("STOP marker exists; remove it deliberately before resuming")
    plan = prepare(AREA/"configs/precision.json", run)
    validate_authority(plan, read_sealed(AREA/"results/allocation.json"),
        read_json(AREA/"configs/design.json"), read_json(AREA/"configs/precision.json"))
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable in the recorded Python environment")
    # Exercise the CUDA runtime, rather than merely importing torch.
    probe = torch.ones(2, device="cuda", dtype=torch.float64)
    if float(probe.sum().item()) != 2.0:
        raise RuntimeError("CUDA arithmetic check failed")
    result.update(plan_id=plan["plan_id"], cuda_device=torch.cuda.get_device_name(0),
        cuda_runtime=torch.version.cuda, python_executable=sys.executable,
        no_simulation_or_fitting=True)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
