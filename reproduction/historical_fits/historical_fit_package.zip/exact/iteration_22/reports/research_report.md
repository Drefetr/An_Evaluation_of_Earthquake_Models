# Completed staged comparison: where sensitivity is lost

All three completion reviews passed: full provenance/lifecycle (A), independent calibration/outcome reaggregation (C), and numerical/optimizer execution metadata (D).

The new finding is a large loss associated with estimating the background in the frozen diagnostic test. With triggering, the mark law and stress kernel supplied, estimating inhibition strength retained 150/150 detections. Also estimating background intercept and trend reduced this to 68/150 (45.3%). This identifies a contrast between two computational procedures. It does not establish an intrinsic information limit for all nuisance-aware tests or a physical inhibition mechanism in earthquake data.

## Actual execution and numerical evidence

All 2,149 histories completed both methods: 999 null references, 1,000 held-out null checks and 150 alternatives. There are 4,298 validated method-history pairs and 12,894 resolved prescribed starts. No history was replaced, omitted, censored or imported from the five-case profile. Authoritative clocks were preserved, including paired precision for null_0841 and the projected-clock 30,276-event null_1292 extreme. Existing simulations were refitted; no new catalogue or simulation was generated.

The single measured parent session took 13,604.4555 seconds (3 hours 46 minutes 44 seconds), within the eight-hour cap. Calibration and analysis took a further 351.69 seconds. Worker, fitting stage, analysis stage and launcher exited zero. The owned worker is absent. Closed-session reason="active" is the previously documented cosmetic ledger label; the final summary says complete and all closure flags agree.

All 8,596 selected CPU32 objective gates, 4,298 direct-contrast order checks and 6,447 witnesses passed. Maximum objective discrepancy was 2.9104e-11; maximum direct-order discrepancy was 1.4211e-13, against 1e-4 gates. There were 12,892 primary-CUDA acceptances and two CPU40 recoveries (null_1107 and null_1166 background alternative start zero); the original failures remain in the lineage. Peak allocated Torch memory was 147.63 MiB. Shared CPU32 feature construction, counted once per history, took 9,355.06 seconds (2.60 hours). Parent wall is not GPU compute time.

These controls do not prove universal quadrature bounds or global maxima. Most background starts used the permitted relative-objective stopping condition. Across optimizer-selected background points, median projected-gradient norm was about 7.07e-6, 99th percentile 3.61e-4 and maximum .03068; many exceed the nominal 2e-6 gradient tolerance. This is allowed by the frozen recipe and retained as an optimization qualification, without post-outcome repairs.

## Calibrated result

| Procedure | Alternative detections | Conditional exact 95% interval | Held-out null rejections | Conditional exact 95% interval |
|---|---:|---:|---:|---:|
| Known law (oracle) | 150/150 (100.0%) | 97.57 to 100.00% | 50/1,000 (5.0%) | 3.73 to 6.54% |
| Estimate inhibition only | 150/150 (100.0%) | 97.57 to 100.00% | 49/1,000 (4.9%) | 3.65 to 6.43% |
| Estimate inhibition + background | 68/150 (45.3%) | 37.20 to 53.66% | 44/1,000 (4.4%) | 3.21 to 5.86% |

Each procedure used its own complete bank of 999 null references, add-one ranks, >= ties and the frozen numerical-sensitivity envelopes. All 1,150 query histories and all 3,450 decisions are resolved. C independently reconstructed the calibrations from saved statistics and reproduced the CSV, conditional intervals and paired summaries. No chi-squared/Wilks or finite mark-score Fisher approximation was used.

The known-nuisance versus background-estimated alternative table is 68 detected by both, 82 detected only with nuisance supplied, and zero reverse-only or neither cases. The paired difference is 54.67 percentage points, descriptive Monte Carlo SE 4.08 percentage points. Estimating eta alone caused no observed loss at this setting; 150/150 does not prove equivalence or certain future detection. Its exact interval remains 97.57 to 100%.

Marginal null frequencies are 4.9% and 4.4%, with overlapping conditional intervals. This does not establish equal population size or an exactly equal-size comparison. Intervals condition on realized reference banks and the supplied generating law, omit their uncertainty, and are not selection-adjusted confirmation after earlier inspection of these histories.

![Matched-null procedure comparison](procedure_comparison.png)

Figure bars show conditional exact binomial intervals. The standard-tool PNG/SVG was visually inspected.

## Saved-likelihood accounting

This is a post-outcome descriptive analysis of all 150 alternatives; no new test, threshold or refit was introduced. Write KK for supplied nuisance and BG for estimated background. At the common saved CUDA16 convention, define

$$
g_0=\mathrm{NLL}_{KK,0}-\mathrm{NLL}_{BG,0},\qquad
 g_1=\mathrm{NLL}_{KK,1}-\mathrm{NLL}_{BG,1}.
$$

If \(e_m\) is a method's saved direct-minus-subtraction control, then

$$
D_{KK}-D_{BG}=2(g_0-g_1)+e_{KK}-e_{BG}.
$$

The maximum identity residual is 1.08e-11; the applicable control is the sum of the two absolute direct-subtraction errors. On every alternative path, extra background flexibility improved the selected null likelihood more than the selected alternative likelihood. Median null NLL gain was 28.665, versus .862 for the alternative. The median within-history GLR decrease was 54.251. Separately, median GLRs were 58.890 and 3.626; medians of differences need not equal differences of medians.

The procedures' own 50th-largest point-reference GLRs were about 3.000 and 4.321. These are descriptive order summaries, not replacement rules. The contrast therefore involves contraction of the fitted statistic as well as different calibration; it is not merely a threshold shift. The separately calibrated oracle is on signed log-LR scale, so its numeric cutpoint must not be pooled with these GLRs.

Extra background flexibility lets the selected no-inhibition model fit alternative-generated histories much better. This is fitted-likelihood accounting, not measurement of tectonic background or proof of information loss for ideal global profile likelihood. Eta estimates generally do not vanish: their medians are about .494 with nuisance supplied and .620 with background estimated. The lower, less-rising fitted null background is not an observed physical loading law.

## Scope and relation to the original research

The independently specified-background diagnostic intensity is

$$
\lambda_\eta(t)=\exp\{a+d(2t/T-1)\}\exp\{-\eta G(t)\}+nH(t).
$$

The fixed generating law has eta=.4885010300470942, a=-4.162108473051707, d=.23211265877958467, n=.5017751599706763, productivity ratio=.7, beta=2.849401764894274 and horizon T=24394 days. Both kernels use the pinned normalized 195-mode alpha=.5, tau=1 mixture. Mark transforms have finite first but infinite second moments. Full marked histories, pre-event intensities, empty prehistory, full compensators and random counts were retained; catalogues were not conditioned to 913 events.

This is not reproduction of the unavailable original frozen code/catalogue or original physical loading model. It neither compares shared versus different stress/triggering kernels nor includes spatial fault/geological covariates. Finite-mode first-moment stability, exact infinite-memory questions and physical mechanism identification remain separate. Earlier two-path score overlap remains prior finite-path evidence, not a new discovery or quantified cause of this contrast.

The historical fuller detector detected 57/150 (38%). It shares 55 detections with the new BG procedure; 13 are BG-only and two historical-only. This optional context is descriptive. Differences in beta/stress knowledge, triggering estimation, search, constraints and calibration prevent assigning the remaining 11 cases to triggering alone. Nor is 82/93 an explained fraction of the earlier gap: these procedures do not yield an additive decomposition.

## Next step and evidence

The single most valuable next bounded step is an independent optimization/profile robustness audit on a predeclared small diagnostic set, before an intercept-versus-trend ablation. Keep the same likelihood, bounds, histories and primary results; report better candidates separately. An altered scientific fitting procedure needs its own matched-null calibration. Alternative-only repairs cannot reuse the current bank. No such refits or new simulations were launched here.

Accepted authority: `iteration_21/results/analysis/2026-10-17T004327174461_0000`, summary SHA256 `56da11135e920e0ced7ee5173d0bfe064a3802ecaf566d6ba7b6d11b75123823`, analysis signature `bf66d9555b78ff56d1780e2fab5d3b2d49fa266051f85d85976ab3414bc90ee8`. Run plan: `0599c1c2447283992ccee3eed6a80fbd9ba40845e7866310e823c72df0cfa79e`.

New iteration_22 artifacts include `comparison_table.csv`, `procedure_comparison.png/.svg`, `results/completion_summary.json` and `results/statistic_decomposition.csv/.json`. A integrity/lifecycle, C statistics/decomposition and D numerical/optimizer reviews preserve detailed evidence and limits. Agent reviews are collaborative software/research checks, not independent academic refereeing or novelty certification.

Reproduce descriptive outputs into a fresh area from the project directory:

```powershell
python -B iteration_22/code/render_completion.py --output-dir iteration_22/reproduction_01
python -B iteration_22/code/statistic_decomposition.py --output-dir iteration_22/reproduction_01
python -B iteration_22/code/write_report.py --output-dir iteration_22/reproduction_01
```

Choose a new output directory if it already exists. These commands read saved summaries/fits and write reports; they do not evaluate history likelihoods, fit, simulate, resume production or republish the accepted analysis. Standalone A/C/D audit scripts record their execution scopes. Preserve sealed delivery artifacts when repeating output-producing reviews.
