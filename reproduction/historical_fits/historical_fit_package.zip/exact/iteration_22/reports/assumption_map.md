# Scope and assumption map

| Item | What this completed comparison holds fixed | Limit |
|---|---|---|
| Generating law | Pinned finite-mixture diagnostic law, eta=0.4885010300470942, T=24394 days | One supplied alternative, not all inhibition strengths |
| Background | exp(a+d(2t/T-1)); supplied in KK, fitted in BG | Independent specified-background diagnostic, not original physical loading |
| Triggering | n, productivity ratio, normalized trigger kernel supplied | Trigger estimation and kernel search not isolated |
| Stress | Supplied shared 195-mode finite mixture | Shared versus different kernels not tested |
| Mark law | Fixed beta=2.849401764894274, fresh marks; finite first/infinite second transformed moments | No finite Fisher or Wilks assumption |
| Observation | Complete fixed-horizon marked histories, pre-event intensities, full compensator and random counts | Empty prehistory and frozen clock conventions retained |
| Numerical method | Unchanged two-start/four-start frozen fitting recipe and fallback ladder | Finite-start success does not certify global optima |
| Calibration | Own 999-null reference bank per procedure, exact ties and numerical envelopes | Reported intervals condition on banks/law and omit development-selection adjustment |
| Validation | 1000 held-out null histories and 150 paired alternatives, no missing cases | Achieved frequencies do not prove exact population size or 100% future power |
| New analysis | Saved-point likelihood decomposition on all 150 alternatives | Post-outcome descriptive accounting; no new fit or new scientific test |
| Mathematics | Earlier finite-mode first-moment and memory results unchanged | No nonlinear infinite-memory/stability theorem inferred from numerical tests |
| Physical interpretation | None newly established by this synthetic comparison | Original frozen code/catalogue absent; no new earthquake fit or geology inference |
