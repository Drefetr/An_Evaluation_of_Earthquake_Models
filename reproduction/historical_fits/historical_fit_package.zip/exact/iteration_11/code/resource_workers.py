"""Unchanged scientific jobs with exact, typed constructor-estimate preflight.

Only the dedicated preflight exception is a retained resource-limit outcome.
Unexpected MemoryError, CUDA OOM, scorer or optimizer errors remain failures.
"""
from pathlib import Path
import sys
import hashlib
import importlib.util
import types
import numpy as np
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'iteration_7/code'))
import completion_workers as original
from checkpoint_io import read_sealed,sealed_json,sha256,utc_now

spec=importlib.util.spec_from_file_location('frozen_numerical9_resource11',ROOT/'iteration_9/code/numerical_fit.py')
numerics=importlib.util.module_from_spec(spec);spec.loader.exec_module(numerics)
_fit=original.fit_job;_validate=original.validate_job
BASE_GUARD_MB=800.;FIT_GUARD_MB=1600.;VALIDATION_GUARD_MB=3200.
EXPECTED_EMPIRICAL_SHA256='9d8bc923cc87eba586bd0dee721245be73f2bbf623c90e00e138a18198d45ea0'
EXECUTION_POLICY=dict(fit_history_estimate_limit_mb=1600.,validation_history_estimate_limit_mb=3200.,
    original_history_estimate_limit_mb=800.,fitting_quadrature_order=16,validation_quadrature_order=32,
    fit_recipe='unchanged_iteration9',per_case_memory_guard_outcome='resource_limited',
    other_resource_and_statistical_limits='unchanged')


class ResourceEstimateExceeded(MemoryError):
    def __init__(self,estimate_mb,limit_mb,quadrature_order,n_events,quadrature_nodes):
        self.estimate_mb=float(estimate_mb);self.limit_mb=float(limit_mb)
        self.quadrature_order=int(quadrature_order);self.n_events=int(n_events);self.quadrature_nodes=int(quadrature_nodes)
        super().__init__(f'Exact frozen history estimate {estimate_mb:.6f}MiB exceeds {limit_mb:.6f}MiB')


def history_estimate(times,excess,beta,end,coordinate_horizon=24394.,start=0.,order=16):
    """Count exactly the frozen constructor's nodes without allocating histories."""
    if hashlib.sha256(Path(numerics.ep.__file__).read_bytes()).hexdigest()!=EXPECTED_EMPIRICAL_SHA256:
        raise RuntimeError('Frozen EmpiricalHistory source differs')
    times=np.asarray(times,dtype=float);excess=np.asarray(excess,dtype=float)
    if times.shape!=excess.shape or times.ndim!=1 or np.any(np.diff(times)<=0) or np.any(times<0):
        raise ValueError('strictly ordered nonnegative one-dimensional event times required')
    if not np.isfinite(times).all() or not np.isfinite(excess).all():raise ValueError('nonfinite catalogue arrays')
    if np.any(excess<0) or not 0<=start<end or coordinate_horizon<=0:raise ValueError('invalid marks/window/horizon')
    times=times[times<end];n=len(times);order=int(order)
    if order<=0:raise ValueError('positive quadrature order required')
    offsets=np.geomspace(1e-6,1e5,23)
    offsets=np.sort(np.r_[offsets,np.sqrt(offsets[:-1]*offsets[1:])])
    boundaries=np.r_[start,times[(times>start)&(times<end)],end]
    panels=sum(1+int(np.count_nonzero(offsets<b-a)) for a,b in zip(boundaries[:-1],boundaries[1:]))
    nodes=panels*order
    return dict(estimate_mb=float((24*n**2+nodes*8*35)/(1024**2)),quadrature_order=order,n_events=n,quadrature_nodes=nodes)


def preflight_guard(*args,limit_mb,**kwargs):
    estimate=history_estimate(*args,**kwargs)
    if estimate['estimate_mb']>limit_mb:raise ResourceEstimateExceeded(limit_mb=limit_mb,**estimate)
    return estimate


def resource_history_class(base_class,order,limit_mb):
    class ResourceHistory(base_class):
        def __init__(self,*args,**kwargs):
            if kwargs.get('order')!=order or kwargs.get('memory_limit_mb')!=BASE_GUARD_MB:
                raise ValueError('Original history order/base guard differs')
            original_kwargs=dict(kwargs);original_kwargs.pop('memory_limit_mb')
            preflight_guard(*args,limit_mb=limit_mb,**original_kwargs)
            super().__init__(*args,**dict(kwargs,memory_limit_mb=limit_mb))
    return ResourceHistory


def _amendment(plan):
    amendment=plan['_execution_amendment']
    if amendment['execution_policy']!=EXECUTION_POLICY:raise ValueError('Reviewed resource execution policy differs')
    return amendment


def _inputs(plan,case,run,validation=False):
    path=Path(run)/'runs'/case['id'];sim=read_sealed(path/'simulation.json');original.verify_identity(sim,plan,case)
    if sha256(path/'catalogue.npz')!=sim['catalogue_sha256']:raise ValueError('Catalogue checksum differs')
    fitted=None
    if validation:
        fitted=read_sealed(path/'fit.json');original.verify_identity(fitted,plan,case)
        if fitted['catalogue_sha256']!=sim['catalogue_sha256']:raise ValueError('Fit catalogue differs')
    return path,sim,fitted


def _arrays(path):
    with np.load(path/'catalogue.npz',allow_pickle=False) as saved:times=saved['times'];excess=saved['excess']
    if len(times)<2 or not np.isfinite(times).all() or not np.isfinite(excess).all() or np.any(np.diff(times)<=0) or np.any(excess<0) or excess.mean()<=0:
        raise ValueError('Invalid saved catalogue arrays')
    return times,excess,float(1/excess.mean())


def _resource_outcome(plan,case,path,sim,stage,attempt,exc):
    amendment=_amendment(plan)
    value=dict(**original.identity(plan,case),stage=stage,catalogue_sha256=sim['catalogue_sha256'],
        estimate_mb=exc.estimate_mb,limit_mb=exc.limit_mb,quadrature_order=exc.quadrature_order,
        n_events=exc.n_events,quadrature_nodes=exc.quadrature_nodes,attempt=attempt,updated_utc=utc_now(),
        complete=False,category='estimated_history_memory',resource_limited=True,
        execution_provenance=dict(amendment_id=amendment['amendment_id'],base_plan_id=plan['plan_id']))
    if stage=='validation':value['fit_sha256']=sha256(path/'fit.json')
    sealed_json(path/'resource_limit.json',value)
    return read_sealed(path/'resource_limit.json')


def _existing_resource(path,plan,case,sim,stage):
    final=path/'resource_limit.json'
    if not final.exists():return None
    value=read_sealed(final);original.verify_identity(value,plan,case)
    if value['stage']!=stage or value['catalogue_sha256']!=sim['catalogue_sha256']:
        raise ValueError('Existing resource outcome inputs/stage differ')
    if stage=='validation' and value['fit_sha256']!=sha256(path/'fit.json'):raise ValueError('Resource fit checksum differs')
    if value.get('execution_provenance')!=dict(amendment_id=_amendment(plan)['amendment_id'],base_plan_id=plan['plan_id']):
        raise ValueError('Existing resource outcome provenance differs')
    return value


def fit_job(plan,case,run,attempt,stop=None,history_class=None,fitter=None):
    amendment=_amendment(plan);path,sim,_=_inputs(plan,case,run)
    if (path/'fit.json').exists():return _fit(plan,case,run,attempt,stop,history_class,fitter)
    retained=_existing_resource(path,plan,case,sim,'fit')
    if retained is not None:return retained
    if original.cancelled(stop):return original.interrupted()
    if not sim['complete']:raise ValueError('Cannot fit censored simulation')
    times,excess,beta=_arrays(path);config=plan['config']
    # Catch ONLY this exact pure preflight, never errors from a factory/solver.
    try:preflight_guard(times,excess,beta,config['horizon'],config['coordinate_horizon'],order=16,limit_mb=FIT_GUARD_MB)
    except ResourceEstimateExceeded as exc:return _resource_outcome(plan,case,path,sim,'fit',attempt,exc)
    if history_class is None:
        sys.path.insert(0,str(ROOT/'iteration_5_performance/gpu'))
        from cuda_history import CUDAHistory as history_class
    def amended_fitter(history,**options):
        result=(fitter or numerics.fit_with_recovery)(history,**options)
        result['execution_provenance']=dict(amendment_id=amendment['amendment_id'],base_plan_id=plan['plan_id'],
            catalogue_sha256=sim['catalogue_sha256'],quadrature_order=16,history_estimate_limit_mb=FIT_GUARD_MB,
            policy='Unchanged iteration9 numerical estimator; constructor resource-estimate policy only')
        return result
    return _fit(plan,case,run,attempt,stop,resource_history_class(history_class,16,FIT_GUARD_MB),amended_fitter)


def validate_job(plan,case,run,stop,attempt,history_class=None,scorer=None):
    amendment=_amendment(plan);path,sim,fitted=_inputs(plan,case,run,True)
    if (path/'validation.json').exists():
        return _validate(plan,case,run,stop,attempt,history_class,scorer)
    retained=_existing_resource(path,plan,case,sim,'validation')
    if retained is not None:return retained
    if original.cancelled(stop):return original.interrupted()
    times,excess,beta=_arrays(path);config=plan['config']
    if beta!=fitted['beta_refitted']:raise ValueError('Validation beta differs')
    try:preflight_guard(times,excess,beta,config['horizon'],config['coordinate_horizon'],order=32,limit_mb=VALIDATION_GUARD_MB)
    except ResourceEstimateExceeded as exc:return _resource_outcome(plan,case,path,sim,'validation',attempt,exc)
    base=history_class or numerics.ep.EmpiricalHistory
    def writer(target,value,*args,**kwargs):
        value=dict(value,execution_provenance=dict(amendment_id=amendment['amendment_id'],base_plan_id=plan['plan_id'],
            catalogue_sha256=value['catalogue_sha256'],fit_sha256=value['fit_sha256'],quadrature_order=32,
            history_estimate_limit_mb=VALIDATION_GUARD_MB,scope='Constructor estimate allowance only; unchanged original CPU32 scorer/strict gate'))
        sealed_json(target,value,*args,**kwargs)
    cloned=types.FunctionType(_validate.__code__,dict(_validate.__globals__,sealed_json=writer),
        name=_validate.__name__,argdefs=_validate.__defaults__,closure=_validate.__closure__)
    value=cloned(plan,case,run,stop,attempt,resource_history_class(base,32,VALIDATION_GUARD_MB),scorer or numerics.ep.score_fit)
    return value if value.get('interrupted') else read_sealed(path/'validation.json')


def cpu_main(*args,**kwargs):
    previous=original.validate_job;original.validate_job=validate_job
    try:return original.cpu_main(*args,**kwargs)
    finally:original.validate_job=previous


def gpu_main(*args,**kwargs):
    previous=original.fit_job;original.fit_job=fit_job
    try:return original.gpu_main(*args,**kwargs)
    finally:original.fit_job=previous
