"""Amended production recovery; original seeds and completed stages preserved.

Preparation and --status launch no simulation, optimizer or GPU worker. Uses
the sealed iteration7 workers unchanged. No production duration is promised.
"""
from __future__ import annotations
import os
for _name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[_name]='1'
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import argparse
from collections import Counter
import heapq
import importlib.metadata
import importlib.util
import json
import math
import multiprocessing as mp
import platform
import queue
import re
import time
import uuid

AREA=Path(__file__).resolve().parents[1];PROJECT=AREA.parent
sys.path.insert(0,str(PROJECT/'iteration_7/code'))
_spec=importlib.util.spec_from_file_location('readonly_completion7',PROJECT/'iteration_7/code/pipeline.py')
_base=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_base)
from resource_workers import cpu_main,gpu_main
from checkpoint_io import atomic_json,atomic_bytes,read_json,read_sealed,sha256,canonical_hash,utc_now,RunLock,ChildJob
from resource_manifest import attach_execution_amendment,verify_case_provenance,resource_state

def state_for(plan,case,run):
    state=_base.state_for(plan,case,run)
    if (Path(run)/'runs'/case['id']/'resource_limit.json').exists():
        return verify_case_provenance(resource_state(state,plan,case,run),plan,case,run)
    if state['status']=='failed' and state.get('failed_stage')=='fit':
        value=read_sealed(Path(run)/'runs'/case['id']/'fit_error.json')
        fit=value.get('fit',{});skipped=fit.get('skipped_alternative_grids',[])
        # This one typed numerical failure is retained. Memory, integrity,
        # unexpected exceptions and unfinished resource-limited grids stay fatal.
        if (value.get('error')=='Original search did not complete all234records/162starts'
                and fit.get('resource_grid_complete') and skipped
                and all(row.get('reason')=='no_converged_matching_null' for row in skipped)):
            provenance=fit.get('execution_provenance',{})
            if (provenance.get('amendment_id')!=plan['_execution_amendment']['amendment_id']
                    or provenance.get('base_plan_id')!=plan['plan_id']
                    or provenance.get('catalogue_sha256')!=value.get('catalogue_sha256')):
                raise ValueError('Incomplete numerical search lacks amended provenance')
            simulation=read_sealed(Path(run)/'runs'/case['id']/'simulation.json')
            _base.verify_identity(simulation,plan,case)
            if (simulation['catalogue_sha256']!=value['catalogue_sha256']
                    or sha256(Path(run)/'runs'/case['id']/'catalogue.npz')!=value['catalogue_sha256']):
                raise ValueError('Incomplete numerical search belongs to different catalogue bytes')
            state.update(status='fit_failed',reason='unresolved_matching_null_optimization')
    return verify_case_provenance(state,plan,case,run)
def terminal(value):return value['status']=='resource_limited' or _base.terminal(value)
event=_base.event
repair_journal=_base.repair_journal
prior_work=_base.prior_work
reserve_unclean_sessions=_base.reserve_unclean_sessions
FATAL_STATUSES=('failed',)  # Unexpected stage/integrity/hardware errors still halt.
TERMINAL_FAILURE_STATUSES=('failed','simulation_censored','fit_failed','validation_failed','resource_limited')
# Declared fit_failed/validation_failed/censored cases remain terminal and
# withhold affected role inference, but do not prevent other fixed IDs running.


def validate_config(config):
    b=config.get('desired_draws_per_role');draws=config['draws']
    if not isinstance(b,int) or isinstance(b,bool) or b<1:raise ValueError('desired_draws_per_role must be a positive integer')
    if len(draws)!=2*b or len({r['id'] for r in draws})!=2*b or len({r['seed'] for r in draws})!=2*b:raise ValueError('Wrong quota or duplicate ID/seed')
    if any(not re.fullmatch(r'(null|shared)_\d{4,}',r['id']) or not r['id'].startswith(r['role']+'_') for r in draws):raise ValueError('Unsafe/mismatched ID')
    if any(draws[2*i]['role']!='null' or draws[2*i+1]['role']!='shared' for i in range(b)):raise ValueError('Expected fixed interleaved null/shared order')
    if config.get('checkpoint_policy')!='completed_stages_only' or config['include_omori'] or config['maxiter']!=100 or config['ratios']!=[.4,.7,.8] or config['quadrature_order']!=16:
        raise ValueError('Completion policy or frozen estimator differs')
    limits=config['limits']
    if limits['maximum_simulation_prefetch']<1 or limits['maximum_validation_queue_backlog']<1:raise ValueError('Backlog limits must be positive')
    return b


def prepare(config_path,run):
    raise ValueError('Use prepare_recovery.py to migrate the existing bank once, then --resume')


def load_plan(run):
    plan=read_json(Path(run)/'plan.json');payload=dict(plan);payload.pop('plan_id')
    if canonical_hash(payload)!=plan['plan_id'] or plan.get('checkpoint_policy')!='completed_stages_only':raise ValueError('Wrong/damaged plan')
    validate_config(plan['config'])
    for name,digest in plan['source_hashes'].items():
        if sha256(PROJECT/name)!=digest:raise ValueError('Source changed: '+name)
    for name,version in plan['environment'].items():
        if importlib.metadata.version(name)!=version:raise ValueError('Dependency changed: '+name)
    if plan['python']['version']!=sys.version:raise ValueError('Python runtime changed')
    return attach_execution_amendment(run,plan)


class StateCache:
    """One initial reconciliation, then single-case reads and cached queues."""
    def __init__(self,plan,run,loader=None):
        self.plan=plan;self.run=Path(run);self.loader=loader or state_for
        self.cases={r['id']:r for r in plan['config']['draws']};self.order=list(self.cases)
        self.position={key:i for i,key in enumerate(self.order)};self.by_id={};self.counts=Counter();self.validated_by_role=Counter()
        self.ready={key:[] for key in ('planned','simulated','fitted')};self.last_validated=None
        for identifier in self.order:self._replace(identifier,self.loader(plan,self.cases[identifier],self.run))

    def _replace(self,identifier,value):
        old=self.by_id.get(identifier)
        if old:
            self.counts[old['status']]-=1
            if old['status']=='validated':self.validated_by_role[old['role']]-=1
        self.by_id[identifier]=value;self.counts[value['status']]+=1
        if value['status']=='validated':self.validated_by_role[value['role']]+=1;self.last_validated=identifier
        if value['status'] in self.ready:heapq.heappush(self.ready[value['status']],(self.position[identifier],identifier))

    def update(self,identifier):
        self._replace(identifier,self.loader(self.plan,self.cases[identifier],self.run))
        return self.by_id[identifier]

    def pop_ready(self,status,excluded=()):
        heap=self.ready[status]
        while heap:
            _,identifier=heapq.heappop(heap)
            if self.by_id[identifier]['status']==status and identifier not in excluded:return identifier
        return None

    @property
    def validated(self):return self.counts['validated']
    @property
    def terminal_count(self):return self.validated+sum(self.counts[key] for key in TERMINAL_FAILURE_STATUSES)
    @property
    def has_failure(self):return any(self.counts[key] for key in FATAL_STATUSES)
    def ordered(self):return [self.by_id[identifier] for identifier in self.order]
    def compact_counts(self):return {key:value for key,value in self.counts.items() if value}


def simulation_capacity(cache,cpu_pending,prefetch):
    return max(0,prefetch-cache.counts['simulated']-sum(stage=='simulation' for stage in cpu_pending.values()))


def aggregate(plan,values):
    b=plan['config']['desired_draws_per_role'];answer={}
    identity=lambda value:tuple(value.get(key) for key in ('id','role','replication','seed'))
    for role,key in (('null','feedback'),('shared','sharing')):
        group=[r for r in values if r['role']==role];good=[r for r in group if r['status']=='validated'];observed=plan['config']['observed'][key]
        planned=[r for r in plan['config']['draws'] if r['role']==role]
        valid=(len(group)==len(good)==b and len({r['id'] for r in good})==b and len({r['seed'] for r in good})==b and
               len(planned)==b and {identity(r) for r in good}=={identity(r) for r in planned} and
               math.isfinite(observed) and all(math.isfinite(r.get('statistics',{}).get(key,float('nan'))) for r in good))
        result=dict(completed=len(good),requested=b,observed=observed,exceedances=None,rank=None,
                    exceedance_probability=None,monte_carlo_se=None,exact_binomial_95_interval=None,
                    scope='All planned role draws required; conditional Monte Carlo uncertainty only, not model uncertainty, bootstrap-validity or power certification; no old pooling')
        if valid:
            from scipy.stats import beta
            k=sum(r['statistics'][key]>=observed for r in good);q=k/b
            result.update(exceedances=k,rank=(1+k)/(b+1),exceedance_probability=q,monte_carlo_se=math.sqrt(q*(1-q)/b),
                exact_binomial_95_interval=[0. if k==0 else float(beta.ppf(.025,k,b-k+1)),1. if k==b else float(beta.ppf(.975,k+1,b-k))])
        answer[role]=result
    return answer


def run_campaign(run,plan,cache,pause_after=None):
    ctx=mp.get_context('spawn');barrier=ctx.Event();stop=ctx.Event();cpu_tasks=ctx.Queue();gpu_tasks=ctx.Queue();messages=ctx.Queue()
    session=uuid.uuid4().hex;session_path=Path(run)/'sessions'/(session+'.json');began=time.perf_counter();began_utc=utc_now()
    consumed=prior_work(run);limits=plan['config']['limits'];remaining=limits['global_work_seconds']-consumed
    if remaining<=0:raise RuntimeError('Budget exhausted including conservative unclean reservations')
    deadline=began+remaining;job=ChildJob();processes=[];cpu_pending={};gpu_pending=None;attempt_started={};reason='complete';last_completion=None
    def session_record(status):
        active=[dict(id=identifier,stage=stage) for identifier,stage in cpu_pending.items()]
        if gpu_pending:active.append(dict(id=gpu_pending,stage='fit'))
        return dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],session_id=session,pid=os.getpid(),status=status,started_utc=began_utc,updated_utc=utc_now(),elapsed_seconds=time.perf_counter()-began,
            recorded_prior_work_seconds=consumed,allocated_remaining_seconds=remaining,in_flight=active,worker_pids=[p.pid for p in processes])
    def progress(stage_event,status='running'):
        record=session_record(status);atomic_json(session_path,record,False)
        compact=dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],plan_id=plan['plan_id'],status=status,event=stage_event,updated_utc=record['updated_utc'],session_id=session,
            requested=len(cache.order),counts=cache.compact_counts(),validated_by_role=dict(cache.validated_by_role),
            active_ids=record['in_flight'],last_completion=last_completion,last_validated=cache.last_validated,
            session_elapsed_seconds=record['elapsed_seconds'],recorded_prior_work_seconds=consumed,
            timing_scope='Last saved stage event, not a timed heartbeat or a real-time completion estimate')
        atomic_json(Path(run)/'progress.json',compact,False);print(json.dumps(compact),flush=True)
    def drain_messages():
        nonlocal gpu_pending,reason,last_completion
        while True:
            try:message=messages.get_nowait()
            except queue.Empty:break
            event(run,message)
            if message['event'] in ('finished','error','interrupted'):
                identifier=message['id']
                if message.get('stage')=='fit':gpu_pending=None
                else:cpu_pending.pop(identifier,None)
                value=cache.update(identifier)  # Exactly one finished ID, never all3998.
                if message.get('stage')=='simulation' or terminal(value):attempt_started.pop(identifier,None)
                last_completion=dict(id=identifier,stage=message.get('stage'),status=value['status'],utc=message.get('utc'))
            if message['event']=='fatal':reason='worker_startup_failure';stop.set()
            progress(message['event']+'_'+str(message.get('stage')))
    atomic_json(session_path,session_record('starting'),False);event(run,dict(event='session_started',session_id=session,pid=os.getpid()))
    try:
        for index in range(2):
            child=ctx.Process(target=cpu_main,args=(index,plan,str(run),cpu_tasks,messages,barrier,stop));child.start();processes.append(child);job.assign(child)
        child=ctx.Process(target=gpu_main,args=(plan,str(run),gpu_tasks,messages,barrier,stop));child.start();processes.append(child);job.assign(child)
        atomic_json(Path(run)/'lock_owner.json',dict(session_id=session,pid=os.getpid(),worker_pids=[p.pid for p in processes],utc=utc_now()),False)
        barrier.set();progress('session_start')
        while True:
            drain_messages();now=time.perf_counter()
            if cache.has_failure:reason='stage_failure';stop.set()
            if cache.terminal_count==len(cache.order):
                reason='complete' if cache.validated==len(cache.order) else 'completed_with_unresolved_cases';break
            if (Path(run)/'STOP').exists():reason='stop_file_requested';stop.set()
            if pause_after is not None and cache.validated>=pause_after:reason='requested_pause';stop.set()
            if now>=deadline:reason='global_work_cap';stop.set()
            if any(now-t>cap for identifier,(t,cap) in attempt_started.items() if not terminal(cache.by_id[identifier])):reason='attempt_work_cap';stop.set()
            if any(not p.is_alive() for p in processes):reason='worker_exit';stop.set()
            if stop.is_set():break
            while len(cpu_pending)<2:
                identifier=cache.pop_ready('fitted',cpu_pending);stage='validation'
                if identifier is None:
                    if simulation_capacity(cache,cpu_pending,limits['maximum_simulation_prefetch'])<=0:break
                    identifier=cache.pop_ready('planned',cpu_pending);stage='simulation'
                if identifier is None:break
                attempt=dict(attempt_id=uuid.uuid4().hex,session_id=session,dispatched_utc=utc_now());cpu_pending[identifier]=stage
                attempt_started.setdefault(identifier,(now,limits['simulation_seconds'] if stage=='simulation' else limits['fit_and_validation_attempt_wall_seconds']))
                event(run,dict(event='dispatched',stage=stage,id=identifier,**attempt));progress('dispatched_'+stage)
                cpu_tasks.put(dict(stage=stage,case=cache.cases[identifier],**attempt))
            # counts['fitted'] includes CPU validation queued/running, so the
            # configured backlog bounds the whole unvalidated fitted bank.
            if gpu_pending is None and cache.counts['fitted']<limits['maximum_validation_queue_backlog']:
                identifier=cache.pop_ready('simulated')
                if identifier is not None:
                    gpu_pending=identifier;attempt=dict(attempt_id=uuid.uuid4().hex,session_id=session,dispatched_utc=utc_now())
                    attempt_started[identifier]=(now,limits['fit_and_validation_attempt_wall_seconds'])
                    event(run,dict(event='dispatched',stage='fit',id=identifier,**attempt));progress('dispatched_fit')
                    gpu_tasks.put(dict(case=cache.cases[identifier],**attempt))
            time.sleep(.1)  # Message/stop checks only; no timer writes.
    except KeyboardInterrupt:reason='keyboard_interrupt';stop.set()
    except Exception:reason='runner_exception';stop.set();raise
    finally:
        before_drain=time.perf_counter()-began;stop.set();pause_write_error=None
        try:progress('graceful_pause',reason)
        except Exception as exc:pause_write_error=f'{type(exc).__name__}: {exc}'
        for _ in range(2):cpu_tasks.put(None)
        gpu_tasks.put(None)
        until=min([time.perf_counter()+35,deadline]+[t+cap for t,cap in attempt_started.values()])
        for child in processes:child.join(timeout=max(0,until-time.perf_counter()))
        job.close()
        for child in processes:
            if child.is_alive():child.terminate()
            child.join(timeout=3)
        drain_messages();work=time.perf_counter()-began;cleanup=time.perf_counter()
        # If a committed completion message was lost during process death,
        # reconcile only the at-most-three formerly active IDs.
        for identifier in set(cpu_pending)|({gpu_pending} if gpu_pending else set()):cache.update(identifier)
        for channel in (cpu_tasks,gpu_tasks,messages):channel.cancel_join_thread();channel.close()
        record=session_record(reason);record.update(work_seconds=work,work_before_drain_seconds=before_drain,graceful_drain_work_seconds=work-before_drain,
            cleanup_seconds=time.perf_counter()-cleanup,worker_exitcodes=[p.exitcode for p in processes],work_accounting_scope='Measured session work; prior unclean reservations labelled separately')
        if pause_write_error:record['graceful_pause_metadata_error']=pause_write_error
        atomic_json(session_path,record,False)
        index=Path(run)/'case_index.json';values=cache.ordered()  # Full index once, at session end only.
        atomic_json(index,dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],plan_id=plan['plan_id'],updated_utc=utc_now(),states=values),False)
        summary=dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],plan_id=plan['plan_id'],updated_utc=utc_now(),status=reason,last_session=record,recorded_total_session_seconds=prior_work(run),
            requested=len(values),validated=cache.validated,counts=cache.compact_counts(),validated_by_role=dict(cache.validated_by_role),
            ranks=aggregate(plan,values),case_index='case_index.json',case_index_sha256=sha256(index),checkpoint_policy='completed_stages_only')
        atomic_json(Path(run)/'summary.json',summary,False);atomic_json(Path(run)/'progress.json',summary,False)
        event(run,dict(event='session_ended',session_id=session,reason=reason,validated=cache.validated))
    if cache.validated==len(cache.order):return 0
    if reason in ('stop_file_requested','requested_pause','keyboard_interrupt'):return 130
    if reason in ('global_work_cap','attempt_work_cap'):return 3
    return 2


def compact_status(run):
    """Read only the small saved counter record; no plan, fits or GPU import."""
    path=Path(run)/'progress.json'
    return read_json(path) if path.exists() else dict(status='not_prepared',run_dir=str(run),scientific_work_launched=False)


def finalize_terminal(run,plan,cache):
    """Repair final metadata after the last stage committed before parent death.

    This performs no simulation, optimization, validation or worker startup.
    Previously unclean sessions must already have their conservative reservation.
    """
    if cache.terminal_count!=len(cache.order):raise ValueError('Final metadata requires all planned IDs terminal')
    began=time.perf_counter();run=Path(run);values=cache.ordered();index=run/'case_index.json'
    atomic_json(index,dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],plan_id=plan['plan_id'],updated_utc=utc_now(),states=values),False)
    sessions=[read_json(path) for path in (run/'sessions').glob('*.json')]
    last=max(sessions,key=lambda value:value.get('started_utc','')) if sessions else None
    summary=dict(execution_amendment_id=plan['_execution_amendment']['amendment_id'],plan_id=plan['plan_id'],updated_utc=utc_now(),status='complete' if cache.validated==len(values) else 'completed_with_unresolved_cases',
        last_session=last,recorded_total_session_seconds=prior_work(run),requested=len(values),validated=cache.validated,
        counts=cache.compact_counts(),validated_by_role=dict(cache.validated_by_role),ranks=aggregate(plan,values),
        case_index='case_index.json',case_index_sha256=sha256(index),checkpoint_policy='completed_stages_only',
        metadata_reconciled_without_workers=True,metadata_finalization_seconds=time.perf_counter()-began)
    atomic_json(run/'summary.json',summary,False);atomic_json(run/'progress.json',summary,False)
    event(run,dict(event='terminal_metadata_reconciled',validated=cache.validated,requested=len(values),scientific_work_launched=False))
    return 0 if cache.validated==len(values) else 2


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,default=PROJECT/'iteration_8/configs/production.json')
    parser.add_argument('--run-dir',type=Path,default=AREA/'results/full_bootstrap');parser.add_argument('--resume',action='store_true')
    parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--status',action='store_true');parser.add_argument('--pause-after-validated',type=int)
    args=parser.parse_args();run=args.run_dir.resolve()
    if not run.is_relative_to(AREA.resolve()):raise ValueError('Recovery runner writes only inside iteration11')
    if args.status:print(json.dumps(compact_status(run),indent=2));return 0
    plan=load_plan(run) if args.resume else prepare(args.config.resolve(),run)
    with RunLock(run/'runner.lock'):
        repair_journal(run)
        if args.prepare_only:print(json.dumps(dict(prepared=str(run),plan_id=plan['plan_id'],scientific_work_launched=False)));return 0
        cache=StateCache(plan,run)
        reserve_unclean_sessions(run,plan)
        if cache.terminal_count==len(cache.order):
            print(json.dumps(dict(already_terminal=True,counts=cache.compact_counts(),validated=cache.validated,requested=len(cache.order))))
            return finalize_terminal(run,plan,cache)
        if cache.has_failure:print(json.dumps(dict(status='retained_failure_halts_resume',counts=cache.compact_counts())));return 2
        if (run/'STOP').exists():print(json.dumps(dict(status='stop_file_present',incomplete=True)));return 130
        return run_campaign(run,plan,cache,args.pause_after_validated)


if __name__=='__main__':raise SystemExit(main())
