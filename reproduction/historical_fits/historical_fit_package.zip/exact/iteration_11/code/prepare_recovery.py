"""Copy the stopped10 bank once; archive only the failed fit-error marker."""
from pathlib import Path
import sys
import shutil
import importlib.util
import json
sys.dont_write_bytecode=True
AREA=Path(__file__).resolve().parents[1];ROOT=AREA.parent
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import RunLock,read_json,atomic_json,atomic_bytes,sha256,canonical_hash,utc_now

def archive(path,destination,run):
    if not path.resolve().is_relative_to(run.resolve()) or not destination.resolve().is_relative_to(run.resolve()):
        raise ValueError('Archive path escaped new bank')
    destination.parent.mkdir(parents=True,exist_ok=True);path.rename(destination)

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--run-dir',type=Path,default=AREA/'results/full_bootstrap');args=parser.parse_args()
    run=args.run_dir.resolve();base=(ROOT/'iteration_10/results/full_bootstrap').resolve()
    if not run.is_relative_to(AREA.resolve()) or run==AREA.resolve() or run.exists():raise ValueError('Choose a new subdirectory of iteration11; existing banks use --resume')
    manifest_path=AREA/'reviews/A_stopped10_manifest.json';baseline=read_json(manifest_path)
    supplement_path=AREA/'reviews/A_runtime_authority_supplement.json'
    for entry in read_json(supplement_path)['files']:
        if sha256(ROOT/entry['path'])!=entry['sha256']:raise ValueError('Supplement authority changed')
    for entry in baseline['files']:
        if sha256(ROOT/entry['path'])!=entry['sha256']:raise ValueError('Stopped10 baseline changed: '+entry['path'])
    with RunLock(base/'runner.lock'):
        for entry in baseline['files']:
            path=ROOT/entry['path']
            if path.resolve()==base/'runner.lock':continue
            if sha256(path)!=entry['sha256']:raise ValueError('Stopped10 baseline changed while locked')
        shutil.copytree(base,run,copy_function=shutil.copy2,ignore=shutil.ignore_patterns('runner.lock'))
        atomic_bytes(run/'runner.lock',b'0')
        copied=[]
        for entry in baseline['files']:
            source=ROOT/entry['path']
            if source.resolve().is_relative_to(base):
                relative=source.resolve().relative_to(base)
                if sha256(run/relative)!=entry['sha256']:raise ValueError('Copied authority differs: '+str(relative))
                copied.append(dict(path=str(relative),sha256=entry['sha256']))
    from resource_manifest import POLICY
    plan=read_json(run/'plan.json');old=read_json(run/'execution_amendment.json')
    fits={p.parent.name:sha256(p) for p in (run/'runs').glob('*/fit.json')}
    validations={p.parent.name:sha256(p) for p in (run/'runs').glob('*/validation.json')}
    if len(fits)!=2603 or len(validations)!=2598:raise ValueError('Stopped bank changed; preserve copied bank for inspection')
    error=run/'runs/shared_1302/fit_error.json';error_hash=sha256(error)
    error_archive=error.parent/'prior_attempts/iteration10_fit_error.json';archive(error,error_archive,run)
    prior_path=run/'resource_prior_control_records/iteration10_execution_amendment.json'
    archive(run/'execution_amendment.json',prior_path,run)
    for name in ('summary.json','case_index.json','progress.json','lock_owner.json'):
        path=run/name
        if path.exists():archive(path,run/'resource_prior_control_records'/name,run)
    sources={str(p.relative_to(ROOT)):sha256(p) for p in sorted((AREA/'code').glob('*.py'))}
    sources[str((AREA/'run_recovery.ps1').relative_to(ROOT))]=sha256(AREA/'run_recovery.ps1')
    snapshot='resource_recovery_source_snapshots'
    for name in sources:atomic_bytes(run/snapshot/name,(ROOT/name).read_bytes())
    prior_work=sum(read_json(p)['work_seconds'] for p in (run/'sessions').glob('*.json'))
    amendment=dict(created_utc=utc_now(),base_plan_id=plan['plan_id'],base_plan_file_sha256=sha256(run/'plan.json'),
        base_inventory=str(manifest_path.relative_to(ROOT)),base_inventory_sha256=sha256(manifest_path),
        authority_supplement=dict(path=str(supplement_path.relative_to(ROOT)),sha256=sha256(supplement_path)),
        predecessor_execution=dict(path=str(prior_path.relative_to(run)),file_sha256=sha256(prior_path),amendment_id=old['amendment_id']),
        recovery_source_hashes=sources,recovery_source_snapshot_root=snapshot,
        reused_case_fit_sha256=fits,reused_validation_sha256=validations,copied_original_files=copied,
        existing_work_seconds=prior_work,reset_cases=[dict(id='shared_1302',stage='fit',archived_path=str(error_archive.relative_to(run)),original_error_sha256=error_hash)],
        execution_policy=dict(POLICY),
        mathematical_basis='Identical panels Q32=2Q16; E32=2E16-24*N^2/2^20<3200MiB whenever order16 E16<=1600MiB. Exact typed per-case preflight guards, not measured peak/RAM reservations.',
        scientific_invariants='All3998 IDs/seeds, saved catalogues/fit bytes, model/grid/starts/numerical recipe, CPU32 scorer/strict gates and fixed1999-per-role inference rule unchanged',
        unresolved_policy='Four derivative-overflow fits and two simulation censors remain unresolved. Typed exact history-estimate caps retain resource_limited outcomes and other fixed IDs continue. Never replace/count unresolved valid; affected-role inference withheld and finalnonzero. Actual allocation/hardware/integrity and unexpected errors still stop.')
    amendment['amendment_id']=canonical_hash(amendment);atomic_json(run/'execution_amendment.json',amendment,False)
    spec=importlib.util.spec_from_file_location('resource_recovery11',AREA/'code/pipeline.py')
    recovery=importlib.util.module_from_spec(spec);spec.loader.exec_module(recovery)
    amended=recovery.load_plan(run);cache=recovery.StateCache(amended,run)
    if cache.has_failure:raise ValueError('An unexpected fatal state remains after the single fit-error archive')
    atomic_json(run/'progress.json',dict(status='resource_recovery_prepared',plan_id=plan['plan_id'],execution_amendment_id=amendment['amendment_id'],
        counts=cache.compact_counts(),validated_by_role=dict(cache.validated_by_role),requested=3998,
        recorded_prior_work_seconds=prior_work,active_ids=[],updated_utc=utc_now()),False)
    recovery.event(run,dict(event='resource_execution_amendment_prepared',amendment_id=amendment['amendment_id'],scientific_work_launched=False))
    print(json.dumps(dict(amendment_id=amendment['amendment_id'],counts=cache.compact_counts(),carried_work_seconds=prior_work,scientific_work_launched=False)))

if __name__=='__main__':main()
