"""Only shared1302 full search and CPU32 check, externally bounded180seconds."""
from pathlib import Path
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='1'
import sys
sys.dont_write_bytecode=True
import argparse
import importlib.util
import json
import subprocess
import time
import uuid
AREA=Path(__file__).resolve().parents[1];ROOT=AREA.parent
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import RunLock,ChildJob,read_json,atomic_json,sha256,utc_now

def module():
    spec=importlib.util.spec_from_file_location('bounded_resource11',AREA/'code/pipeline.py')
    result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result

def worker(run,session):
    if sys.stdin.buffer.read(1)!=b'1':return 4
    recovery=module();plan=recovery.load_plan(run);case=next(c for c in plan['config']['draws'] if c['id']=='shared_1302')
    from resource_workers import fit_job,validate_job
    import multiprocessing as mp
    import torch
    torch.set_num_threads(1);stop=mp.get_context('spawn').Event()
    attempt=dict(attempt_id=uuid.uuid4().hex,session_id=session,dispatched_utc=utc_now())
    path=run/'runs'/case['id'];catalogue_hash=sha256(path/'catalogue.npz')
    fitted=fit_job(plan,case,run,attempt,stop)
    validation=validate_job(plan,case,run,stop,attempt) if not fitted.get('resource_limited') else None
    state=recovery.state_for(plan,case,run)
    result=dict(utc=utc_now(),case=case['id'],state=state,fit_complete=fitted.get('fit',{}).get('complete',False),
        all_optimizations_converged=fitted.get('fit',{}).get('all_optimizations_converged',False),
        CPU32_passed=bool(validation and validation.get('passed')),CPU32_deltas=validation.get('deltas') if validation else None,
        statistics=validation.get('statistics') if validation else None,record_count=len(fitted.get('fit',{}).get('subfits',[])),
        optimizer_starts=sum(r['origin']=='optimizer' for r in fitted.get('fit',{}).get('subfits',[])),
        catalogue_unchanged=sha256(path/'catalogue.npz')==catalogue_hash,
        fit_sha256=sha256(path/'fit.json') if (path/'fit.json').exists() else None,
        validation_sha256=sha256(path/'validation.json') if (path/'validation.json').exists() else None,
        amendment_id=plan['_execution_amendment']['amendment_id'],
        scope='Same saved4639-event catalogue; one full unchanged234/162 search plus unchanged CPU32 checks; no simulation')
    atomic_json(AREA/'reports/repaired_case_result.json',result,False);print(json.dumps(result),flush=True)
    return 0 if state['status']=='validated' else 2

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--worker',action='store_true');parser.add_argument('--session',default='')
    parser.add_argument('--seconds',type=float,default=180);args=parser.parse_args();run=AREA/'results/full_bootstrap'
    if args.worker:return worker(run,args.session)
    if not 0<args.seconds<=180:raise ValueError('Bound at most180seconds')
    recovery=module();session='resource_repair_'+uuid.uuid4().hex
    with RunLock(run/'runner.lock'):
        plan=recovery.load_plan(run);case=next(c for c in plan['config']['draws'] if c['id']=='shared_1302')
        if recovery.state_for(plan,case,run)['status']!='simulated':raise ValueError('Only the saved reset catalogue may run')
        began=time.perf_counter();session_path=run/'sessions'/(session+'.json');log=AREA/'logs'/('worker_'+session+'.log')
        log.parent.mkdir(exist_ok=True);record=dict(session_id=session,status='bounded_resource_repair_running',started_utc=utc_now(),updated_utc=utc_now(),
            execution_amendment_id=plan['_execution_amendment']['amendment_id'],recorded_prior_work_seconds=recovery.prior_work(run),
            elapsed_seconds=0.,in_flight=[dict(id=case['id'],stage='fit_and_validation')],worker_log=str(log.relative_to(ROOT)))
        atomic_json(session_path,record,False);job=ChildJob();code=1;timed_out=False
        try:
            with log.open('x',encoding='utf-8') as handle:
                child=subprocess.Popen([sys.executable,'-B',str(Path(__file__)),'--worker','--session',session],stdin=subprocess.PIPE,stdout=handle,stderr=subprocess.STDOUT)
                job.assign(child);child.stdin.write(b'1');child.stdin.flush();child.stdin.close()
                try:code=child.wait(timeout=args.seconds)
                except subprocess.TimeoutExpired:timed_out=True;child.kill();child.wait();code=3
        finally:job.close()
        work=time.perf_counter()-began;record.update(status='bounded_resource_repair_complete' if code==0 else 'bounded_resource_repair_stopped',
            updated_utc=utc_now(),work_seconds=work,elapsed_seconds=work,worker_exitcode=code,timed_out=timed_out,in_flight=[])
        atomic_json(session_path,record,False);cache=recovery.StateCache(plan,run)
        atomic_json(run/'progress.json',dict(status='ready_to_resume' if code==0 else 'bounded_resource_repair_stopped',
            plan_id=plan['plan_id'],execution_amendment_id=plan['_execution_amendment']['amendment_id'],requested=3998,
            counts=cache.compact_counts(),validated_by_role=dict(cache.validated_by_role),active_ids=[],
            recorded_prior_work_seconds=recovery.prior_work(run),updated_utc=utc_now()),False)
        print(json.dumps(dict(exitcode=code,work_seconds=work,counts=cache.compact_counts(),total_charged_work_seconds=recovery.prior_work(run))),flush=True)
        return code

if __name__=='__main__':raise SystemExit(main())
