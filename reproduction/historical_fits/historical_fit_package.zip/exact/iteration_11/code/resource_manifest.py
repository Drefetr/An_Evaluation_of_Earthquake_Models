"""Source-bound resource amendment and independently verified retained outcomes."""
from pathlib import Path
import sys
import importlib.util
import types
import math
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_json,read_sealed,sha256,canonical_hash

POLICY={'fit_history_estimate_limit_mb':1600.0,'validation_history_estimate_limit_mb':3200.0,
    'original_history_estimate_limit_mb':800.0,'fitting_quadrature_order':16,'validation_quadrature_order':32,
    'fit_recipe':'unchanged_iteration9','per_case_memory_guard_outcome':'resource_limited',
    'other_resource_and_statistical_limits':'unchanged'}

def attach_execution_amendment(run,plan):
    run=Path(run);current=run/'execution_amendment.json';amend=read_json(current);payload=dict(amend);identity=payload.pop('amendment_id')
    if canonical_hash(payload)!=identity or amend['base_plan_id']!=plan['plan_id'] or sha256(run/'plan.json')!=amend['base_plan_file_sha256']:
        raise ValueError('Resource amendment/base plan identity differs')
    authority=amend['predecessor_execution'];prior_path=run/authority['path']
    if not prior_path.resolve().is_relative_to(run.resolve()) or sha256(prior_path)!=authority['file_sha256']:
        raise ValueError('Predecessor authority changed')
    prior=read_json(prior_path)
    if prior['amendment_id']!=authority['amendment_id']:raise ValueError('Predecessor identity differs')
    # Verify the exact prior10 loader with a private authority reader. Every
    # other path, source snapshot, old9 chain and imported authority stays real.
    spec=importlib.util.spec_from_file_location('frozen_manifest10',ROOT/'iteration_10/code/memory_manifest.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    def prior_reader(path):return prior if Path(path).resolve()==current.resolve() else read_json(path)
    original=helper.attach_execution_amendment
    cloned=types.FunctionType(original.__code__,dict(original.__globals__,read_json=prior_reader),
        name=original.__name__,argdefs=original.__defaults__,closure=original.__closure__)
    cloned(run,plan)
    for name,digest in prior['recovery_source_hashes'].items():
        if sha256(ROOT/name)!=digest:raise ValueError('Frozen iteration10 source changed')
    inventory=ROOT/amend['base_inventory']
    if not inventory.resolve().is_relative_to(ROOT.resolve()) or sha256(inventory)!=amend['base_inventory_sha256']:
        raise ValueError('Stopped10 inventory changed')
    baseline=read_json(inventory);old_run=(ROOT/baseline['run_directory']).resolve()
    supplement=amend['authority_supplement'];supplement_path=ROOT/supplement['path']
    if not supplement_path.resolve().is_relative_to(ROOT.resolve()) or sha256(supplement_path)!=supplement['sha256']:
        raise ValueError('Transitive authority supplement changed')
    for entry in read_json(supplement_path)['files']:
        if not (ROOT/entry['path']).resolve().is_relative_to(ROOT.resolve()) or sha256(ROOT/entry['path'])!=entry['sha256']:
            raise ValueError('Transitive authority file changed')
    for filename,key in (('fit.json','reused_case_fit_sha256'),('validation.json','reused_validation_sha256')):
        expected={Path(e['path']).parent.name:e['sha256'] for e in baseline['files']
            if Path(e['path']).name==filename and (ROOT/e['path']).parent.parent.resolve()==old_run/'runs'}
        if amend[key]!=expected:raise ValueError('Complete imported authority map differs')
    snapshot=run/amend['recovery_source_snapshot_root']
    if not snapshot.resolve().is_relative_to(run.resolve()):raise ValueError('Snapshot path escaped bank')
    for name,digest in amend['recovery_source_hashes'].items():
        if not (ROOT/name).resolve().is_relative_to(ROOT.resolve()) or sha256(ROOT/name)!=digest or sha256(snapshot/name)!=digest:
            raise ValueError('Current resource source/snapshot changed')
    reset=amend['reset_cases']
    if len(reset)!=1 or reset[0]['id']!='shared_1302' or reset[0]['stage']!='fit':raise ValueError('Wrong recovery reset')
    original_error=next(e['sha256'] for e in baseline['files'] if (ROOT/e['path']).resolve()==old_run/'runs/shared_1302/fit_error.json')
    archived=run/reset[0]['archived_path']
    if not archived.resolve().is_relative_to(run.resolve()) or sha256(archived)!=original_error or reset[0]['original_error_sha256']!=original_error:
        raise ValueError('Original fit error archive changed')
    if amend['execution_policy']!=POLICY:raise ValueError('Reviewed resource policy differs')
    plan=dict(plan);plan['_execution_amendment']=amend;return plan

def verify_case_provenance(state,plan,case,run):
    amend=plan['_execution_amendment'];path=Path(run)/'runs'/case['id']
    for filename,key in (('fit.json','reused_case_fit_sha256'),('validation.json','reused_validation_sha256')):
        original=amend[key].get(case['id'])
        if original and (not (path/filename).exists() or sha256(path/filename)!=original):raise ValueError('Imported authority missing/changed: '+case['id'])
    fit_path=path/'fit.json'
    if fit_path.exists() and case['id'] not in amend['reused_case_fit_sha256']:
        value=read_sealed(fit_path);p=value['fit'].get('execution_provenance',{})
        expected=dict(amendment_id=amend['amendment_id'],base_plan_id=plan['plan_id'],catalogue_sha256=value['catalogue_sha256'],
            quadrature_order=16,history_estimate_limit_mb=1600.0)
        if any(p.get(k)!=v for k,v in expected.items()):raise ValueError('New fit lacks resource provenance')
    validation_path=path/'validation.json'
    if validation_path.exists() and case['id'] not in amend['reused_validation_sha256']:
        value=read_sealed(validation_path);p=value.get('execution_provenance',{})
        expected=dict(amendment_id=amend['amendment_id'],base_plan_id=plan['plan_id'],catalogue_sha256=value['catalogue_sha256'],
            fit_sha256=value['fit_sha256'],quadrature_order=32,history_estimate_limit_mb=3200.0)
        if any(p.get(k)!=v for k,v in expected.items()):raise ValueError('New validation lacks resource provenance')
    return state

def resource_state(state,plan,case,run):
    import numpy as np
    path=Path(run)/'runs'/case['id'];value=read_sealed(path/'resource_limit.json');amend=plan['_execution_amendment']
    stage=value.get('stage');order,limit=(16,1600.) if stage=='fit' else (32,3200.) if stage=='validation' else (None,None)
    if order is None or state['status']!=('simulated' if stage=='fit' else 'fitted'):
        raise ValueError('Resource marker contradicts scientific stage')
    expected=dict(plan_id=plan['plan_id'],**{k:case[k] for k in ('id','role','replication','seed')})
    if any(value.get(k)!=v for k,v in expected.items()) or value.get('complete') is not False or value.get('resource_limited') is not True or value.get('category')!='estimated_history_memory':
        raise ValueError('Resource marker identity/category differs')
    p=value.get('execution_provenance',{})
    if p.get('amendment_id')!=amend['amendment_id'] or p.get('base_plan_id')!=plan['plan_id']:
        raise ValueError('Resource marker lacks current provenance')
    simulation=read_sealed(path/'simulation.json');catalogue=path/'catalogue.npz'
    if not simulation['complete'] or sha256(catalogue)!=simulation['catalogue_sha256'] or value.get('catalogue_sha256')!=simulation['catalogue_sha256']:
        raise ValueError('Resource marker catalogue differs or censored')
    if stage=='validation' and value.get('fit_sha256')!=sha256(path/'fit.json'):raise ValueError('Resource marker fit differs')
    with np.load(catalogue,allow_pickle=False) as data:
        times=np.asarray(data['times'],dtype=float);excess=np.asarray(data['excess'],dtype=float)
    if (times.ndim!=1 or times.shape!=excess.shape or len(times)<2 or simulation['n_events']!=len(times)
            or not np.isfinite(excess).all() or np.any(excess<0) or not np.isfinite(excess.mean()) or excess.mean()<=0):
        raise ValueError('Invalid resource catalogue marks/count')
    end=plan['config']['horizon'];times=times[times<end]
    if not np.isfinite(times).all() or np.any(times<0) or np.any(np.diff(times)<=0):raise ValueError('Invalid resource catalogue')
    offsets=np.geomspace(1e-6,1e5,23);offsets=np.sort(np.r_[offsets,np.sqrt(offsets[:-1]*offsets[1:])])
    boundaries=np.r_[0.,times[(times>0)&(times<end)],end]
    panels=sum(1+int(np.count_nonzero(offsets<b-a)) for a,b in zip(boundaries[:-1],boundaries[1:]))
    nodes=panels*order;estimate=(24*len(times)**2+280*nodes)/(1024**2)
    if (value.get('n_events')!=len(times) or value.get('quadrature_nodes')!=nodes or value.get('quadrature_order')!=order
            or value.get('limit_mb')!=limit or not math.isfinite(value.get('estimate_mb',float('nan')))
            or not math.isclose(value['estimate_mb'],estimate,rel_tol=0,abs_tol=1e-9) or estimate<=limit):
        raise ValueError('Resource marker does not reproduce an exceeded active guard')
    return dict(state,status='resource_limited',failed_stage=stage,reason='estimated_history_memory',estimate_mb=estimate,limit_mb=limit)
