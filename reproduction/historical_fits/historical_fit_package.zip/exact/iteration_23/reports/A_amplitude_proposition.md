# Conditional amplitude profiling for the frozen finite-history likelihood

This is a finite-observation optimization result for the independently specified background diagnostic. It does not assert global optimization in trend/inhibition, finite population Fisher information, stationarity, or a physical loading interpretation. No saved history was fitted or scored for this derivation.

Fix the observed marked history, supplied beta, triggering/stress features and their original clock convention. Write `A=exp(a)`, with `L=exp(-12)` and `U=1`; fix `d` and `eta` in their declared boxes. At pre-event times let

\[
q_i=\exp\{d x_i-\eta G_i\},\qquad c_i=nH_i,
\quad J=\int_0^T\exp\{d x(t)-\eta G(t)\}\,dt.
\]

Assume a finite history, finite `d,eta,G_i,x_i`, `c_i>=0`, finite trigger compensator `K`, and `0<J<infinity`. The actual finite-history model has `q_i>0`. These are pathwise conditions, not assumptions about ensemble second moments. For `eta>=0`, bounded `x`, finite nonnegative stress almost everywhere and `T>0`, the integrand is positive almost everywhere and bounded above, giving finite positive `J`. Empty prehistory and an initial quiet interval also give an explicit positive contribution.

The **ground** negative log likelihood, including the full-window triggering compensator, is

\[
F(A;d,\eta)=A J+nK-\sum_{i=1}^N\log(Aq_i+c_i).
\]

The marked likelihood adds `-N log(beta)+beta sum(Q_i)`, which is constant in these fitted coordinates. Keeping the observed history fixed while optimizing is not conditioning the generative process to a fixed count. Neither the full horizon nor the first event may be discarded.

On `[L,U]`, each event intensity is positive. Ordinary finite-sum differentiation gives

\[
F_A=J-\sum_i\frac{q_i}{Aq_i+c_i},\qquad
F_{AA}=\sum_i\left(\frac{q_i}{Aq_i+c_i}\right)^2.
\]

For `N>=1`, this curvature is strictly positive. Thus continuity on the compact interval gives a **unique conditional amplitude minimizer**, with the exhaustive rules

1. If `F_A(L)>=0`, the minimizer is `L`.
2. Otherwise, if `F_A(U)<=0`, it is `U`.
3. Otherwise the unique interior root of the continuous strictly increasing `F_A` is the minimizer.

Endpoint equality is included. With no events, `F(A)=AJ+nK` is strictly increasing when `J>0`, so the unique minimizer is `L`. In the more general nonnegative-`q` algebra, strictness requires at least one positive event `q`; a simultaneous `q_i=c_i=0` makes the likelihood invalid. A numerically zero `J` or lost positive `q` is not evidence that the physical objective is flat: it must be resolved stably or retained as a numerical failure/degeneracy.

## Log-amplitude root and numerical representation

For `a=log(A)`, put `p_i=Aq_i/(Aq_i+c_i)`. The log-amplitude score is

\[
g(a)=F_a=A F_A=A J-\sum_i p_i,
\quad g'(a)=A J-\sum_i p_i(1-p_i).
\]

`g` has the same signs and unique root as `F_A` because `A>0`, but **`g` is not generally monotone**. For example, `q=(1,1)`, `c=(0,.001)`, `J=2`, at `A=.0001`,

\[
g'(a)=.0002-\frac{.0001\cdot.001}{(.0011)^2}<0.
\]

The corresponding amplitude root is nevertheless unique and interior, about `.99950025`. The first `c=0` is consistent with an empty-history first event; a positive second triggering contribution is permitted. Brent's method on `a` is valid with the endpoint sign bracket because it needs continuity, not monotonicity of `g`. Monotone-root language applies to `F_A`, not automatically to `g` or the outer profile surface.

Avoid forming an underflowed `q` or `c` and then dividing. With `logq` and `logc`, evaluate `loglambda=logaddexp(a+logq,logc)` and background responsibility from their difference. If `c_i=0` and finite `logq_i`, retain **`p_i=1`** and `loglambda=a+logq_i` even when `exp(logq_i)` underflows. If both physical components are mathematically positive but their exponentials underflow, their finite logs still contain the relevant mixture ratio. Invalid/nonfinite required log intensities must not be replaced by a floor, omitted event, clipped mark/stress, or zero score. Finite precision can make negligible responsibilities underflow; that is an approximation to qualify and compare, not a changed likelihood law.

## Matching the frozen numerical target

The result also holds exactly for a **positive-weight discretized** `J`: the dependence on `A` is still linear. For the pinned implementation, `eta=0` uses the analytic full-horizon background integral at `a=0`. At positive `eta`, `J` consists of the analytic initial quiet interval plus the original positive quadrature terms. Preserve the supplied triggering compensator `nK`, full horizon, pre-event intensities, original time geometry and separate mark constant. Factoring an exponential can change last-bit rounding; comparison with the original objective and CPU32 gates remains necessary. A root tolerance and finite residual are numerical controls, not an exact-arithmetic claim.

The conditional minimizer reduces the search to `min_(d,eta) F(A*(d,eta);d,eta)`. Convexity in `A` alone gives no joint-convexity or global-minimum certificate for that remaining two-dimensional problem. A finite grid, Powell search or improved candidate establishes only the declared numerical search result. A coarse-grid agreement is not proof that all other points are worse; quadrature order agreement at selected points is not a rigorous integration bound. Any material improvement over saved candidates belongs to this predeclared robustness diagnostic, without silently replacing the accepted primary results or borrowing their old null threshold for an altered fitting procedure.

Evidence anchors: `iteration_20/code/restricted_history.py` (ground objective, analytic quiet/full-horizon integrals and separate mark constant); `iteration_21/code/staged_fit.py` (bounds, eligible subsets, starts and saved candidate validation); `iteration_22/reports/research_report.md` and `iteration_22/reviews/C_statistics_report_review.md` (finite-search qualification and prospective diagnostic purpose). This derivation introduces no novelty or original-fit reproduction claim.
