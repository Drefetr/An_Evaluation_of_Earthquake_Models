# Conditional background balance and profile derivatives

This is a new finite-history deduction, written after the bounded optimizer stopped. It introduces no further saved-history likelihood evaluation, fit or statistical test. It builds on A's conditional-amplitude proposition and is not a novelty or population-information claim.

Fix the history, triggering law and trend d. Let the conditional amplitude optimum be interior. With A=exp(a), q_i=exp(d*x_i-eta*G_i), c_i=n*H_i and p_i=A*q_i/(A*q_i+c_i), its exact score balance is

\[
 A J=\sum_i p_i,\qquad
 J=\int_0^T e^{d x(t)-\eta G(t)}\,dt.
\]

Thus the fitted integrated background intensity equals the sum of event-wise background mixture weights. This is a likelihood identity on one history, not a stationary balance law or an assumed causal parent assignment. At a box endpoint, retain the appropriate one-sided score inequality instead. No event or empty interval is removed.

At an interior optimum, the curvature in log amplitude simplifies to

\[
 F_{aa}=A J-\sum_i p_i(1-p_i)=\sum_i p_i^2>0.
\]

This identity applies at the optimum; it does not make the log-amplitude score globally monotone. For a nonempty empty-prehistory catalogue with positive supplied background, the first event has c_1=0 and p_1=1, so the curvature is at least one in these coordinates. This is finite-path curvature, not ensemble Fisher information.

Write

\[
 J_x=\int_0^T x(t)e^{d x(t)-\eta G(t)}\,dt,
 \qquad J_G=\int_0^T G(t)e^{d x(t)-\eta G(t)}\,dt.
\]

On an interval where the unique conditional amplitude remains interior, implicit differentiation gives, at fixed d,

\[
 \frac{\partial a_*}{\partial\eta}
 =\frac{A J_G-\sum_i G_i p_i(1-p_i)}{\sum_i p_i^2}.
\]

The formula alone supplies no sign theorem for all physical histories. Observed increases of fitted a along an eta curve are path-specific; a curve that also re-estimates d is not this fixed-d derivative. In particular, the saved null_0000 curve reaches the declared upper trend bound, which must remain visible.

For the amplitude-profiled objective V(d,eta)=F(A_*(d,eta),d,eta), the envelope derivatives in an interior-amplitude region are

\[
 V_d=A J_x-\sum_i x_i p_i,
 \qquad
 V_\eta=-A J_G+\sum_i G_i p_i.
\]

The amplitude-score chain term vanishes. At a neighborhood with a fixed active amplitude endpoint the same expressions are the partial derivatives with that endpoint fixed. Active-set transitions need separate one-sided treatment; these formulas do not authorize a smooth global-Hessian claim.

For a finite history with bounded finite-mode stress on a compact observation window, these differentiations are justified by bounded domination. The same algebra holds for positive quadrature weights. It needs no second ensemble moment. Empty histories select the lower amplitude endpoint and do not satisfy the asserted interior balance. Nonrepresentable stresses or log intensities remain numerical failures, not floors or clipped marks.

The utility is concrete: these formulas offer a separately testable gradient for the remaining two-dimensional profile search, potentially avoiding the slow Powell starts seen in the saved audit. They do not prove that any gradient method finds a global minimum or explain the earlier population power contrast. The scalar helper and finite-difference fixtures use synthetic finite sums only; no further catalogue was scored.

The helper evaluates these expressions at an accepted approximate interior root and returns its balance residual. Away from an exact root, the actual log-amplitude curvature is `sum(p_i^2) + balance_residual`; the returned `sum(p_i^2)` is the balanced-root expression, not an exact equality with curvature at an arbitrary numerical point. Nonfinite or negative balance tolerances are rejected. A GPU profile-gradient optimizer using these moments remains unimplemented and untested on the saved catalogues.
