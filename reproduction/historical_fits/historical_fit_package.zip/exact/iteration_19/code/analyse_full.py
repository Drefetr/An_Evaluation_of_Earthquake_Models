"""Terminal saved-result analysis adapter. Never evaluates a history or fits data."""
from pathlib import Path
import argparse,csv,importlib.util,io,math,sys
from collections import Counter
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];AREA=ROOT/'iteration_19'
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import RunLock,read_json,read_sealed,sha256,canonical_hash,sealed_json,atomic_bytes,utc_now

PURE_PATH='iteration_17/code/analyse_oracle_v1_1.py'
PURE_SHA='5d6a987185484295fbc172f81783ebff80f10459e695a130efe53005c19d612d'
PROTOCOL_SHA='dc3369af795b8116cea5a1d4603f365affe5111b0100639da1090af7e88cd754'
INVENTORY_SHA='2d7ef9883147fa1d6bed60b007eecf5dd5b97ff16a4f11cfb75625be29fdad60'
CUDA_SHA='be7ff7938596c0f5c3bc40962986e2ae511a0a9c1b05bc1d8d7b99008fa86505'
CONFIG_SHA='51e79769b121446a00e883db270da65efe3f656cd0d0d4c771e211c76311a8dd'
PLAN_KEYS=('schema_version','config_path','config_sha256','config','sources','protocol','ids','entries','imports','law_sha256')
SOURCES={'iteration_19/code/run_full_cuda.py','iteration_19/code/analyse_full.py','iteration_18/code/cuda_oracle.py',
         'iteration_19/run_full_evaluation.ps1','iteration_17/code/analyse_oracle_v1_1.py',
         'iteration_18/code/benchmark_cuda.py','iteration_17/code/oracle_likelihood.py',
         'iteration_5/code/kernels.py','iteration_6/code/checkpoint_io.py'}
IMPORTED_IDS=['null_0000','null_0841','null_1292','new_r000','new_r076']
EXPECTED_ALL=[f'null_{r:04d}' for r in range(1999)]+[f'new_r{r:03d}' for r in range(150)]
TERMINAL={'complete','refinement_failed','time_cap','error'}


def require(condition,message):
    if not condition:raise ValueError(message)


def pure():
    require(sha256(ROOT/PURE_PATH)==PURE_SHA,'Sealed statistical implementation changed')
    name='_iteration17_pure_statistics'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/PURE_PATH)
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name]


def validate_terminal(plan,terminal,sessions,index):
    """Check full cohort metadata before loading any score values."""
    require(terminal['plan_id']==index['plan_id']==plan['plan_id'] and terminal['sessions_closed'] is True and
            terminal['active'] is False and terminal['active_ids']==[] and
            not terminal.get('paused',False) and sessions and
            all(s['closed'] is True and not s.get('active_ids') and s.get('active_attempt') is None and
                s['stage']=='closed' for s in sessions),'Active or paused run; analysis refused')
    states=index['states']
    require(set(states)==set(EXPECTED_ALL) and len(states)==2149 and terminal['total_planned']==2149 and
            dict(Counter(states.values()))==terminal['counts'],'Terminal cohort/counts differ')
    require(all(v in TERMINAL for v in states.values()) and terminal['terminal_complete'] is True,
            'Pending or selected-prefix run; analysis refused')
    require(terminal['all_primary_complete']==all(v=='complete' for v in states.values()),'Completion flag differs')
    require(terminal['charged_seconds']==sum(s['elapsed_seconds'] for s in sessions),'Session charge differs')
    return states


def validate_cuda_payload(record,entry,plan):
    """No GPU work: inspect saved identities, refinement and device metadata."""
    result=pure().load_oracle(record,entry,plan['plan_id'])
    require(record['law_sha256']==canonical_hash(plan['protocol']['phase1']['law']),'Compiled law identity differs')
    if result is None:
        require(record.get('payload') is None or record['status']=='refinement_failed','Unaccepted error payload')
        return None
    p=record['payload'];values=p['evaluations'];selected=p['selected_order']
    require(p['catalogue_cache_reused'] is False and p['preparation_shared_across_orders'] is True,
            'Unexpected catalogue cache or event-preparation convention')
    require(set(values)==({'16','32','64'} if selected==64 else {'16','32'}),'Unprescribed quadrature evaluations')
    for key,v in values.items():
        require(v['order']==int(key) and v['n_events']==entry['n_events'] and v['clock_mode']==entry['clock_mode'] and
                v['eta']==.4885010300470942 and v['beta_fixed']==2.849401764894274,'Saved evaluation law differs')
        require(all(math.isfinite(v[k]) for k in ('log_lr','event_log_ratio_sum','compensator_reduction','nll0','nll1')),
                'Nonfinite saved likelihood component')
        require(abs(math.fsum((v['event_log_ratio_sum'],v['compensator_reduction']))-v['log_lr'])<=1e-6,
                'Direct signed likelihood arithmetic differs')
        require(v['method']=='cuda_fp64_gauss' and v['stress_modes']==v['trigger_modes']==195 and
                v['quadrature_nodes']==v['panels']*v['order'] and
                0<v['maximum_working_query_nodes']<=32768,'Modes/nodes/backend differ')
        g=v['cuda_metrics']
        require(g['dtype']=='float64' and all(g[k] is False for k in ('allow_tf32','mixed_precision','fast_math_requested')) and
                g['synchronized'] is True and g['fresh_case_buffers'] is True and g['device']=='cuda:0',
                'CUDA precision/synchronization differs')
        require(g['max_allocated_bytes']==1024*2**20 and g['chunk_nodes']==32768 and
                0<=g['peak_allocated_bytes']<=1024*2**20 and g['peak_reserved_bytes']>=g['peak_allocated_bytes'],
                'CUDA memory/block gate differs')
    return result


def check_import(record,entry,plan):
    """Imported repeat0 payloads must be byte-authorized, never rescored here."""
    id=entry['id'];imports=plan['imports']
    require(set(imports)==set(IMPORTED_IDS),'Imported fixed identities differ')
    if id not in imports:
        require(not record.get('import_provenance'),'Unplanned imported case')
        return
    ref=imports[id];path=ROOT/ref['path']
    require(sha256(path)==ref['sha256'],'Imported iteration18 score bytes changed')
    original=read_sealed(path)
    require(original['status']=='complete' and original['id']==id and original['seed']==entry['seed'] and
            original['catalogue_sha256']==entry['files']['catalogue.npz']['sha256'] and
            original['clock_mode']==entry['clock_mode'] and original['task']['task_id']==f'gpu_{id}_r0' and
            original['task']['repeat']==0 and original['payload']==record['payload'],'Imported payload/clock/identity differs')
    provenance=record['import_provenance']
    require(provenance['path']==ref['path'] and provenance['sha256']==ref['sha256'] and
            provenance['source_plan_id']==original['plan_id'] and provenance['source_task_id']==original['task']['task_id'],
            'Imported provenance differs')


def validate_plan(plan):
    """Fixed source/science/config contract; no catalogue or score reads."""
    c=plan['config'];protocol=plan['protocol']
    require(plan['config_sha256']==CONFIG_SHA and sha256(ROOT/plan['config_path'])==CONFIG_SHA and
            read_json(ROOT/plan['config_path'])==c,'Frozen full-run configuration changed')
    require(c['phase17_protocol']['sha256']==PROTOCOL_SHA and c['inventory']['sha256']==INVENTORY_SHA and
            protocol==read_json(ROOT/c['phase17_protocol']['path']),'Scientific protocol differs')
    require(plan['ids']==EXPECTED_ALL and c['case_ids']==EXPECTED_ALL,'Fixed cohort differs')
    require(canonical_hash({k:plan[k] for k in PLAN_KEYS})==plan['plan_id'] and set(plan['sources'])==SOURCES,
            'Canonical plan or source inventory differs')
    require(plan['law_sha256']==canonical_hash(protocol['phase1']['law']),'Compiled law differs')
    require(set(plan['imports'])==set(IMPORTED_IDS),'Imported fixed identities differ')
    for path,digest in plan['sources'].items():require(sha256(ROOT/path)==digest,'Pinned runtime source changed')
    require(sha256(ROOT/'iteration_18/code/cuda_oracle.py')==CUDA_SHA,'Accepted CUDA backend changed')
    for key in ('phase17_protocol','inventory','prior_seal','backend_seal','benchmark_plan','benchmark_summary',
                'benchmark_runtime_freeze','backend','statistical_authority'):
        require(sha256(ROOT/c[key]['path'])==c[key]['sha256'],'Prior authority changed: '+key)
    benchmark_plan=read_sealed(ROOT/c['benchmark_plan']['path']);benchmark_summary=read_sealed(ROOT/c['benchmark_summary']['path'])
    require(benchmark_summary['backend_accepted'] is True and benchmark_summary['all_mandatory_tasks_complete'] is True and
            benchmark_summary['sessions_closed'] is True and benchmark_summary['plan_id']==benchmark_plan['plan_id'],
            'Benchmark acceptance authority differs')
    for id,ref in plan['imports'].items():
        require(ref['source_plan_id']==benchmark_plan['plan_id'] and ref['source_task_id']==f'gpu_{id}_r0' and
                ref['backend']=='cuda' and ref['repeat']==0,'Imported reference source differs')
    pure().validate_protocol(protocol)
    return protocol


def collect(run):
    """Metadata must prove terminality before score or fitted-statistic reads."""
    run=Path(run).resolve();require(run.is_relative_to(AREA/'results'),'Run outside iteration19/results')
    require((run/'plan.json').exists(),'Run is not prepared')
    with RunLock(run/'runner.lock'):
        return _collect_locked(run)


def _collect_locked(run):
    plan=read_sealed(run/'plan.json');terminal=read_sealed(run/'summary.json')
    ledger=read_sealed(run/'sessions.json');require(ledger['plan_id']==plan['plan_id'],'Session ledger plan differs')
    sessions=ledger['sessions'];index=read_sealed(run/'case_index.json')
    states=validate_terminal(plan,terminal,sessions,index)
    protocol=validate_plan(plan)
    inventory=read_sealed(ROOT/plan['config']['inventory']['path']);entries={e['id']:e for e in inventory['entries']}
    require(len(entries)==2299 and len(entries)==len(inventory['entries']) and
            plan['entries']==[entries[id] for id in EXPECTED_ALL] and
            len({entries[id]['seed'] for id in EXPECTED_ALL})==2149,'Inventory/seed quota differs')
    require({x.stem for x in (run/'cases').glob('*.json')}==set(EXPECTED_ALL),'Missing or extra case authorities')
    oracle={};fitted={};hashes={}
    for id in EXPECTED_ALL:
        e=entries[id];path=run/'cases'/(id+'.json');r=read_sealed(path)
        require(r['status']==states[id],'Terminal case status differs')
        require(sha256(ROOT/e['files']['catalogue.npz']['path'])==e['files']['catalogue.npz']['sha256'],
                'Input catalogue bytes changed')
        oracle[id]=validate_cuda_payload(r,e,plan);check_import(r,e,plan)
        fitted[id]=pure().load_fitted(e);hashes[id]=sha256(path)
    result=pure().analyse_values(protocol,oracle,fitted)
    result.update(created_utc=utc_now(),plan_id=plan['plan_id'],protocol_sha256=PROTOCOL_SHA,
                  inventory_sha256=INVENTORY_SHA,runner_summary_sha256=sha256(run/'summary.json'),
                  score_file_sha256=hashes,summarizer_sha256=sha256(Path(__file__)),pure_statistics_sha256=PURE_SHA,
                  scored_complete=sum(v is not None for v in oracle.values()),planned=2149,
                  charged_seconds=terminal['charged_seconds'],
                  budget_overrun_seconds=max(0.,terminal['charged_seconds']-14400.))
    return result


def resolved(result):
    return all(result['methods'][n][c]['unknown']==0 for n in ('oracle','fitted') for c in ('alternative_power','heldout_null_size'))


def publish(result,run):
    """Reuse only exact same plan, score hashes and statistical implementation."""
    run=Path(run);latest=run/'latest_analysis.json'
    signature=canonical_hash({k:result[k] for k in ('plan_id','protocol_sha256','inventory_sha256','score_file_sha256',
                                                   'summarizer_sha256','pure_statistics_sha256')})
    if latest.exists():
        ref=read_sealed(latest)
        if ref['analysis_signature']==signature:
            out=ROOT/ref['path'];require(out.resolve().is_relative_to(AREA/'results/analysis'),'Analysis path outside iteration19')
            for file,digest in ref['files'].items():require(sha256(out/file)==digest,'Pinned completed analysis changed')
            old=read_sealed(out/'summary.json');require(old['analysis_signature']==signature,'Analysis signature differs')
            return out,old,True
    out=AREA/'results/analysis'/utc_now().replace(':','').replace('.','').replace('+','_')
    out.mkdir(parents=True,exist_ok=False);result=dict(result,analysis_signature=signature)
    sealed_json(out/'summary.json',result)
    stream=io.StringIO(newline='');fields=['id','oracle_rank','oracle_reject','oracle_reason','fitted_rank','fitted_reject','fitted_reason']
    writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
    require(len(result['outcomes'])==1150 and len({r['id'] for r in result['outcomes']})==1150,'Query quota differs')
    for r in result['outcomes']:
        writer.writerow(dict(id=r['id'],**{f'{n}_{k}':r[n][k] for n in ('oracle','fitted') for k in ('rank','reject','reason')}))
    atomic_bytes(out/'outcomes.csv',stream.getvalue().encode())
    files={name:sha256(out/name) for name in ('summary.json','outcomes.csv')}
    sealed_json(out/'manifest.json',dict(plan_id=result['plan_id'],analysis_signature=signature,files=files,
        source_scores=result['score_file_sha256'],pure_statistics_sha256=PURE_SHA,summarizer_sha256=sha256(Path(__file__))))
    files['manifest.json']=sha256(out/'manifest.json')
    sealed_json(latest,dict(plan_id=result['plan_id'],analysis_signature=signature,path=out.relative_to(ROOT).as_posix(),files=files))
    return out,result,False


def main():
    p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,default=AREA/'results/full_cuda');p.add_argument('--status',action='store_true')
    args=p.parse_args();run=args.run_dir.resolve();require(run.is_relative_to(AREA/'results'),'Run outside iteration19')
    if args.status:
        print(read_sealed(run/'latest_analysis.json') if (run/'latest_analysis.json').exists() else {'analysis_available':False});return 0
    result=collect(run);out,result,reused=publish(result,run);print(out);print('analysis_reused='+str(reused).lower())
    return 0 if resolved(result) else 2


if __name__=='__main__':raise SystemExit(main())
