"""Render saved completion evidence only: no scoring, fitting or inference changes."""
from pathlib import Path
import csv
import hashlib
import io
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT / 'iteration_19'
RUN = AREA / 'results/full_cuda'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    value = json.loads(path.read_text(encoding='utf-8'))
    if 'record_sha256' in value:
        expected = value.pop('record_sha256')
        # Use the already pinned project's sealing convention, checked below.
        assert CHECKPOINT.canonical_hash(value) == expected, f'Seal differs: {path}'
    return value


import importlib.util
plan_raw = json.loads((RUN / 'plan.json').read_text(encoding='utf-8'))
helper = ROOT / 'iteration_6/code/checkpoint_io.py'
assert digest(helper) == plan_raw['sources']['iteration_6/code/checkpoint_io.py']
spec = importlib.util.spec_from_file_location('completion_report_checkpoint', helper)
CHECKPOINT = importlib.util.module_from_spec(spec)
spec.loader.exec_module(CHECKPOINT)


def main():
    pointer = load(RUN / 'latest_analysis.json')
    folder = (ROOT / pointer['path']).resolve()
    assert folder.is_relative_to(AREA / 'results/analysis')
    for name, expected in pointer['files'].items():
        assert digest(folder / name) == expected
    result = load(folder / 'summary.json')
    terminal = load(RUN / 'summary.json')
    plan = load(RUN / 'plan.json')
    sessions = load(RUN / 'sessions.json')['sessions']
    assert result['plan_id'] == terminal['plan_id'] == plan['plan_id']
    assert terminal['counts'] == {'complete': 2149} and not terminal['active']
    assert all(s['closed'] for s in sessions) and result['scored_complete'] == 2149
    assert result['runner_summary_sha256'] == digest(RUN / 'summary.json')
    for name, expected in plan['sources'].items():
        assert digest(ROOT / name) == expected
    m = result['methods']
    rows = []
    for name in ('oracle', 'fitted'):
        for cohort in ('alternative_power', 'heldout_null_size'):
            v = m[name][cohort]
            rows.append(dict(method=name, cohort=cohort, rejections=v['rejections'],
                             requested=v['requested'], unknown=v['unknown'],
                             conditional_frequency=v['conditional_frequency'],
                             conditional_CP95_lower=v['exact_binomial_95_interval'][0],
                             conditional_CP95_upper=v['exact_binomial_95_interval'][1]))
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader(); writer.writerows(rows)
    (AREA / 'reports/completed_result_table.csv').write_text(stream.getvalue(), encoding='utf-8')
    table = ['| Test | Alternative detections | Conditional 95% interval | Held-out null rejections |',
             '|---|---:|---:|---:|']
    for name, title in [('oracle', 'Known-law likelihood ratio'), ('fitted', 'Saved fitted detector')]:
        p = m[name]['alternative_power']; z = m[name]['heldout_null_size']
        lo, hi = p['exact_binomial_95_interval']
        table.append(f"| {title} | {p['rejections']}/{p['requested']} ({100*p['conditional_frequency']:.1f}%) | "
                     f"{100*lo:.2f}% to {100*hi:.2f}% | {z['rejections']}/{z['requested']} ({100*z['conditional_frequency']:.1f}%) |")
    paired = result['paired']['alternative_power']
    assumed = sum(s.get('assumed_unobserved_seconds', 0.) for s in sessions)
    observed = sum(s.get('measured_prefix_seconds', s['elapsed_seconds']) for s in sessions)
    assert abs(observed + assumed - terminal['charged_seconds']) < 1e-9
    summary = dict(analysis_path=pointer['path'], analysis_signature=result['analysis_signature'],
                   analysis_summary_sha256=digest(folder/'summary.json'), plan_id=plan['plan_id'],
                   methods=m, paired=result['paired'], interpretation=result['interpretation'],
                   execution=dict(accepted=2149, imported=5, newly_scored=2144, sessions=len(sessions),
                                  measured_prefix_plus_closed_wall_seconds=observed,
                                  assumed_unobserved_reservation_seconds=assumed,
                                  charged_seconds=terminal['charged_seconds'],
                                  qualifier='Measured prefix is incomplete for the interrupted session; reservation is not measured GPU runtime'),
                   uncertainty='Conditional on realized999-reference banks and supplied generating law; no calibration-bank uncertainty',
                   provenance='Executed saved-history oracle comparison plus previously executed fitted-test statistics; no new simulations or fits')
    (AREA/'reports/completed_results.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
    report = f'''# Completed known-law versus fitted-detector comparison

The saved-history evaluation completed successfully: **2,149/2,149 accepted scores, no unresolved numerical cases**, followed by a completed calibrated analysis. It reused exactly five validated iteration-18 repeat-0 results and newly scored the other 2,144 histories. The run resumed after one interrupted session; its retained attempt history is audited separately. The final launcher, scoring and analysis exit statuses are all zero. No new catalogue, scientific simulation, fit, or nuisance ablation was launched in this completion review.

{chr(10).join(table)}

Both null-check intervals are 3.73% to 6.54%. Their identical observed 5% rejection frequencies pass the frozen descriptive size screens; they do not prove equal population sizes or uniform control over a composite nuisance null. Each statistic was calibrated against its own scores on the same 999 reference identities; the additional 1,000 null histories were held out of threshold construction. The earlier full-1,999-bank calibration was not substituted. The recalibrated fitted frequency happens to remain 57/150.

The paired alternative outcomes are **{paired['table']['both']} detected by both, {paired['table']['oracle_only']} by the known-law test alone, and zero fitted-only or neither**. The observed detection difference is **{100*paired['oracle_minus_fitted']:.1f} percentage points**, with descriptive paired Monte Carlo standard error **{100*paired['descriptive_MCSE']:.2f} points**. No new post-outcome significance test or confidence interval for that difference is added. All frozen strong-pipeline-contrast criteria pass.

## What this resolves

For this stipulated pair of observation laws and horizon, the data contain a readily detectable signal when the generating parameters are supplied. The previous 38% fitted detection frequency therefore does not describe an intrinsic inability to distinguish this particular fully specified null and alternative. There is a large loss between the supplied-parameter contrast and the existing estimation/search/test procedure.

That loss may reflect the statistical cost of unknown parameters, nuisance confounding, stress-kernel search, the chosen statistic/calibration or finite optimization. This comparison does **not** isolate any one cause, diagnose a coding or optimizer fault, or establish that a practical unknown-parameter procedure can attain the known-law result. In particular, a nuisance-adjusted null can resemble an inhibitory law even when the same-nuisance simple null is easily distinguished.

The pre-existing iteration-13 pathwise score-projection residual fractions (10.82% and 3.26%) remain prior evidence of overlap on two reference histories. They are not ensemble Fisher information and are not demonstrated causes of this 62-point contrast. Iteration 16's limited-sensitivity conclusion for the fitted detector survives; its explanation can now be narrowed using a high-sensitivity known-law comparison.

## Fixed law and uncertainty

The diagnostic intensity is `lambda_eta(t) = B(t)*exp(-eta*G(t)) + n*H(t)`, with `B(t)=exp(a+d*(2*t/T-1))` and predictable stress/trigger histories. This is the independently specified-background diagnostic reconstruction. Its result is not automatically a result for the manuscript's original physical-loading model or an exact infinite-memory kernel.

The two laws differ only in eta=0 versus eta=0.4885010300470942, with all generating nuisance parameters, beta=2.849401764894274, mark law, shared normalized 195-mode finite kernels, empty initial history and 24,394-day horizon supplied to the known-law evaluator. Both intensities use the same observed predictable marked history, random event count and full compensator. Marks are neither truncated nor refitted. The fitted detector retains its previously saved estimation and kernel-search procedure; it is not a new fit with those oracle inputs.

The 150/150 observed frequency is not certainty of detection: its exact two-sided conditional 95% binomial interval is 97.57% to 100%. The saved plug-in Bernoulli standard error is zero at this boundary and should not replace that interval. Intervals condition on the realized reference banks, fixed generating law and accepted numerical conventions; they omit calibration-bank uncertainty and uncertainty/selection in the generating parameters. Bounded rejection indicators permit these Monte Carlo summaries without assuming finite raw mark variance.

These histories and earlier fitted results were already inspected, so this is an exploratory comparison despite its frozen scoring/calibration protocol. Its simulated frequency is not a rigorous optimal-power bound. It supplies no observed-NZ inhibition claim, no causal physical mechanism, no discrimination between shared and different stress kernels, no catalogue-wide sample-size guarantee, and no new stability or nonlinear ergodicity theorem.

## Execution and numerical scope

The ledger records **{observed/60:.2f} minutes** of durably measured interrupted-session prefix plus closed-session wall, and a separate **{assumed/60:.2f}-minute assumed recovery allowance**, totaling **{terminal['charged_seconds']/60:.2f} charged minutes**. That total is conservative budget accounting, not measured GPU compute time. Clock time across the interruption is not charged as computation. See `../reviews/D_completed_execution.json` for the per-session and case timings.

The unfinished `null_0412` attempt was retained and the same catalogue completed after resume: 2,145 attempt records comprise 2,144 successful fresh cases and one interruption. The final GPU child has recorded exit -15 during owned cleanup after all case records were committed; it did not exit normally at zero. The resumed parent scoring command, subsequent analysis and launcher each have explicit exit zero. The first launch records wrapper exit2 without a captured native Python exit, so that native status is not inferred.

The accepted FP64 CUDA backend, authoritative clock representations, untruncated histories, 195-mode kernels and order16/32 refinement gate (conditional order64) remain those frozen before full scoring. Accepted refinement differences and numerical ordering envelopes resolve all decisions. These finite numerical checks are not rigorous integration error bounds. The full batch has not received a new CPU cross-check for every history; the existing independent CPU/CUDA validation belongs to iteration 18.

## Most valuable next step

Prepare a separately budgeted, matched-null **2 by 2 nuisance ablation** on these same catalogues: background intercept/trend known versus estimated, and a precisely declared triggering-nuisance block known versus estimated. Initially fix beta and the stress kernel at generating values and infer eta in every non-oracle procedure. The known/known cell still estimates eta; compare it with the fixed-eta oracle before assigning a loss to nuisance estimation. Give each procedure its own null calibration and compare achieved null size as well as detection. This can locate which knowledge loss matters. It does not require another 500 pairs merely to refine the same 38% estimate. No such refits or expanded campaign are launched or budgeted by this report.

## Authorities and reproduction

Saved analysis: `{pointer['path']}/summary.json`, SHA256 `{digest(folder/'summary.json')}`. Analysis signature: `{result['analysis_signature']}`. Plan ID: `{plan['plan_id']}`. Per-case outcomes and score hashes are retained in that immutable analysis directory; full histories, attempts and provenance remain in the original run and inventory paths.

Completion reviews: `../reviews/A_completed_run_review.json`, `../reviews/C_completed_statistics.json`, and `../reviews/D_completed_execution.json`. These are agent-assisted project checks, not independent academic refereeing. The original inputs and sealed iteration-17/18 authorities are preserved. `../manuscript_revisions/known_law_comparison.tex` is an uncompiled replacement fragment; no thesis source or PDF has been reconstructed.

Regenerate this report and its table from saved outputs, without scoring, fitting or recalibration:

```powershell
python -B iteration_19/reports/render_completed_report.py
```
'''
    (AREA/'reports/completed_evaluation.md').write_text(report, encoding='utf-8')
    print('Rendered completed_evaluation.md, completed_result_table.csv and completed_results.json; no scientific execution.')


if __name__ == '__main__':
    main()
