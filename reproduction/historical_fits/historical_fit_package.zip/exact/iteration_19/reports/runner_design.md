# Manual full CUDA evaluator

The runner is `iteration_19/code/run_full_cuda.py`. It evaluates the fixed 2,149 saved histories from the original iteration-17 protocol, using the unchanged iteration-18 FP64 CUDA backend. This implementation and its fixtures launch no new scientific scoring. The full evaluation is left for the user to launch.

## Command and fixed scope

From the workspace root, the low-level commands are:

```powershell
python -B -u iteration_19/code/run_full_cuda.py --prepare-only
python -B iteration_19/code/run_full_cuda.py --status
python -B -u iteration_19/code/run_full_cuda.py --resume
```

The last command performs the actual saved-history evaluation. The root-owned `iteration_19/run_full_evaluation.ps1` provides the user-facing launcher and terminal analysis. Preparation and status do not initialize CUDA. The default configuration is `iteration_19/configs/full_cuda_frozen.json`; default results are `iteration_19/results/full_cuda`. `--run-dir` can select another directory only beneath this iteration's results area.

There are exactly 1,999 null and 150 new-arm histories, with the original 999/1,000 null split. No new simulation, fitting, nuisance estimation, bootstrap, data retrieval, or seed selection is included. The fixed law and all clocks, modes and nodes remain unchanged. Only `null_0841` uses the paired clock; the other histories retain projected scoring. The original iteration-17 timeout and all iteration-18 results remain read-only.

## Frozen authority and reuse

Preparation verifies the exact resource-amendment hash, original scientific protocol and inventory, every planned NPZ hash, original protocol authorities, all sealed iteration-17/18 files, accepted benchmark plan/summary, runtime source pins, and the CUDA backend hash `be7ff7938596c0f5c3bc40962986e2ae511a0a9c1b05bc1d8d7b99008fa86505`. The sealed plan includes `PLAN_KEYS`, exported by the runner: schema, config path/hash/content, runtime source hashes, protocol, exact IDs/entries, deterministic imports, and compiled-law hash. The canonical hash of those fields is `plan_id`.

Exactly five already validated iteration-18 **repeat-0** CUDA payloads are imported: `null_0000`, `null_0841`, `null_1292`, `new_r000`, and `new_r076`. Selection never depends on speed or statistic. Payloads are unchanged and wrapped with the new plan identity, source record hash, old plan/task ID, catalogue identity and zero current computation charge. Existing imported checkpoints must match both the source payload and import provenance exactly. Runtime snapshots also pin this runner, the terminal analyser, the PowerShell launcher, the statistical authority, the backend and its numerical dependencies.

## Execution and completion checkpoints

One persistent CUDA worker runs behind an OS lock, child Job and start barrier. It cannot initialize CUDA before Job assignment and durable parent ownership metadata. It uses one native CPU thread, FP64, no TF32 or mixed precision, blocks of at most 32,768 nodes, and the validated 1 GiB Torch-allocation gate. Each case uses fresh preparation/buffers; only immutable kernel constants, device context and allocator pool persist.

A complete case is sealed once as `cases/<id>.json`. It contains the score-refinement payload and original identity aliases, compiled-law hash, origin and attempt/import provenance. Orders 16/32 and conditional 64 retain the `1e-6` refinement gate. Numerical failures and true per-case timeouts are sealed terminal unknowns. A subsequent resume skips these records and does not reinterpret them as non-rejections or silently retry them.

Attempt starts and finishes are separate immutable records under `attempts/<id>/`. They preserve interrupted work without creating a fake completed case. Parent dispatch, finish, worker exit and session events are saved at stage boundaries; there are no timed snapshots or heartbeats. Live progress reports completed/planned counts. The full case index is reconstructed once on startup and written on preparation/final closure, rather than rereading all case payloads or dumping the full state map at each stage.

`STOP` prevents a new dispatch and lets an active case finish. Ctrl+C interrupts the active attempt: the parent establishes child death before adopting a late case commit or writing an interrupted-attempt outcome. A later resume retries that same pending ID, preserving the old attempt. Remove `STOP` before continuing. `--pause-after-completed N` is an optional explicit case-boundary pause for engineering/manual checks.

## Budget and recovery

The frozen limits are 14,400 cumulative parent wall seconds, 600 seconds per case, 60 seconds for context setup, and a 15-second cleanup reserve. Each live invocation includes its preparation time in its session wall charge. The worker also receives the smaller global/per-case deadline. The parent supplies the hard process deadline and unconditional cleanup.

Boundary checkpoints store observed session elapsed time, the active attempt's declared cap, and worker PID plus process-creation token. After an unclean parent death, the next invocation first acquires the OS lock and verifies the old worker is gone; PID reuse cannot masquerade as the old worker. A still-live matching old worker blocks checkpoint adoption and a new launch. The Windows Job kills the assigned child when its owner dies; an unassigned child remains behind a barrier with parent-liveness checks and cannot score.

An unclean session is charged its observed durable prefix plus a conservative unobserved active-case bound (up to 600 seconds), or setup bound (60 seconds), plus cleanup allowance, capped by the remaining global allowance. That addition is explicitly labelled **assumed**, not measured compute or UTC downtime. It is applied once, not as a new four-hour allowance or a reservation of the entire remaining budget. If the allowance is exhausted, the runner preserves its pending ledger and exits without starting CUDA.

Completed-case replay is idempotent: if every case is already terminal, no worker is spawned and Torch is not imported. Exact all-complete status returns 0; explicit graceful pauses return 130; numerical/resource/incomplete outcomes return 2. Terminal analysis remains separate and refuses active or pending-prefix results. No runtime guarantee follows from the five-history benchmark.

## Implementation checks

`python -B iteration_19/tests/test_full_runner.py -v` passed **9 tests in 9.796 seconds** on the final implementation changes. Tests use fake owned children and only copy already scored iteration-18 payloads; they perform no GPU operation, likelihood evaluation, optimization or simulation. They exercise first dispatch, boundary pause/resume, byte-identical completed reuse, interruption and whole-case restart with separate attempts, no-Torch all-complete reuse, OS-lock refusal, source/identity rejection, live-old-worker refusal/PID reuse, one-time unclean accounting (`120 + 600 + 15 = 735` seconds), and rejection of a session ledger from another plan before checkpoint adoption.

An initial test-authoring failure came from a small fixture's expected-ID mock retaining two IDs after the fixture was reduced to one. The fixture was corrected before the passing run. Independent engineering review and metadata-only preparation provide separate checks; no full production launch is part of this implementation task.
