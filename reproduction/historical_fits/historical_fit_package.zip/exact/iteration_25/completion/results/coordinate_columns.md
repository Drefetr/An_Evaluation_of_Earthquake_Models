# Selected-coordinate columns

Each row is one history, procedure and phase. `a_estimated`, `d_estimated` and `eta_estimated` distinguish fitted coordinates from supplied/fixed ones. The null fixes eta=0; that does not count as an estimated boundary hit.

`*_exact_lower` and `*_exact_upper` test exact equality to the declared box endpoint for estimated coordinates. The compactly named `*_within_1e7_of_bound` columns use the actual source comparison `distance <= 1e-7`, namely 10 to the power minus seven. This is a post hoc proximity label, not a solver acceptance rule, KKT certificate or confidence statement. Raw coordinates remain available without rounding.

For alternative-generated new_r100, the saved both-free benchmark has exact d=-2 in the null and d=+2 in the alternative. The new constrained background coordinates are interior. Several null-generated alternatives select eta=0; these rows remain in the tables.
