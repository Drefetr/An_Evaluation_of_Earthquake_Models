"""Read-only verification of the recorded completed pilot and review bindings."""
from pathlib import Path
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sha256


def main():
    area=ROOT/'iteration_25';base=area/'completion'
    manifest=read_sealed(base/'logs/completion_manifest.json');errors=[]
    for path,h in manifest['artifact_sha256'].items():
        if not (ROOT/path).is_file() or sha256(ROOT/path)!=h:
            errors.append(path)
    preparation=read_sealed(area/'logs/preparation_manifest.json')
    for path,h in preparation['artifact_sha256'].items():
        if not (ROOT/path).is_file() or sha256(ROOT/path)!=h:
            errors.append('preparation:'+path)
    prior=read_sealed(area/'logs/prior_preservation_before.json')
    for path,h in prior['artifact_sha256'].items():
        if not (ROOT/path).is_file() or sha256(ROOT/path)!=h:
            errors.append('prior:'+path)
    for name in ['A_completion_review','C_completion_interpretation','D_resource_review']:
        if read_sealed(base/f'reviews/{name}.json')['passed'] is not True:
            errors.append(name)
    saved=read_sealed(area/'results/ablation_pilot/summary.json')
    result=read_sealed(base/'results/summary.json')
    if saved['counts']!={'complete':10} or not saved['all_complete'] or not saved['sessions_closed']:
        errors.append('Run incomplete/open')
    print(json.dumps(dict(passed=not errors,errors=errors,
        completion_artifacts_checked=len(manifest['artifact_sha256']),
        prepared_artifacts_preserved=len(preparation['artifact_sha256']),
        prior_paths_preserved=len(prior['artifact_sha256']),complete_cases=result['complete_cases'],
        all_four_selected_alternative_level_contraction_exceeds_trend=result['all_four_alternative_level_contraction_exceeds_trend'],
        BG_witness_rows=result['numerical_BG_witness_rows'],read_only=True,
        scope='Saved artifacts, reviewed arithmetic and recorded completion only; no fit, score or calibrated inference.'),indent=2))
    return 0 if not errors else 2


if __name__=='__main__':
    raise SystemExit(main())
