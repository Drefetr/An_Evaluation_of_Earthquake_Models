"""Audit saved operational metadata; no fitting, history scoring or GPU calls."""
from pathlib import Path
from datetime import datetime
import collections
import csv
import json
import subprocess
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_25/code'))
import run_ablation_pilot as runner
from checkpoint_io import canonical_hash,read_sealed,sealed_json,sha256,utc_now

RUN=ROOT/'iteration_25/results/ablation_pilot'
ANALYSIS=ROOT/'iteration_25/results/analysis/completed_pilot_01'
DEST=ROOT/'iteration_25/completion/reviews'


def require(ok,message):
    if not ok:raise AssertionError(message)


def main():
    plan=read_sealed(RUN/'plan.json');runner.guard(plan)
    c=plan['contract'];ledger=read_sealed(RUN/'sessions.json');summary=read_sealed(RUN/'summary.json')
    marker=read_sealed(RUN/'execution_started.json')
    require(ledger['plan_id']==summary['plan_id']==marker['plan_id']==plan['plan_id'],'Plan identity differs')
    require([e['id'] for e in plan['entries']]==runner.IDS,'Frozen fixed-ten cohort differs')
    require(len(ledger['sessions'])==1,'Unexpected recorded worker generation/session')
    session=ledger['sessions'][0]
    require(session['closed'] is True and session['reason']=='complete' and session['worker_exitcode']==0 and
            session['active_id'] is None and session['active_attempt_id'] is None and session['stage']=='closed','Session not cleanly closed')
    require(not session.get('censored',False) and not session.get('parent_error') and not session.get('worker_error'),'Censored/failed session')
    require(session['closure_allowance_seconds']==1. and session['elapsed_seconds']==session['measured_elapsed_seconds']+1.,'Wall debit differs')
    require(c['resources']['total_parent_wall_seconds']==7200 and session['elapsed_seconds']<7200,'Global policy budget exceeded')
    require(summary['all_complete'] is True and summary['sessions_closed'] is True and summary['counts']=={'complete':10} and
            set(summary['states'])==set(runner.IDS) and summary['active_ids']==[] and summary['reason']=='complete' and
            summary['charged_seconds']==session['elapsed_seconds'],'Production completion summary differs')
    require(not (RUN/'fatal.json').exists(),'Fatal ledger exists')
    identity=session['worker_identity'];current=runner.lifetime().process_identity(identity['pid'])
    require(current!=identity,'Recorded worker creation token is live')
    require(identity==dict(pid=25928,creation_token='134366920381383280'),'Actual worker identity differs')
    freeze=read_sealed(ROOT/'iteration_25/logs/runtime_source_freeze.json')
    source_snapshots=RUN/'source_snapshots'
    for path,digest in plan['sources'].items():
        require(sha256(source_snapshots/path)==digest,'Archived runtime source differs: '+path)
    input_pins={}
    benchmark_pins={}
    for e in plan['entries']:
        for record in e['files'].values():
            require(sha256(ROOT/record['path'])==record['sha256'],'Pinned history input changed')
            input_pins[record['path']]=record['sha256']
        b=plan['benchmarks'][e['id']]
        require(sha256(ROOT/b['path'])==b['sha256'],'Benchmark case changed')
        benchmark_pins[b['path']]=b['sha256']
    starts={p.name[:-len('.started.json')]:read_sealed(p) for p in (RUN/'attempts').glob('*.started.json')}
    finishes={p.name[:-len('.finished.json')]:read_sealed(p) for p in (RUN/'attempts').glob('*.finished.json')}
    require(len(starts)==len(finishes)==10 and starts.keys()==finishes.keys(),'Missing/extra attempts')
    require(len(list((RUN/'attempts').iterdir()))==20,'Additional attempt artifacts')
    require(collections.Counter(s['id'] for s in starts.values())==collections.Counter(runner.IDS),'Repeated or missing attempt')
    casepaths={p.stem:p for p in (RUN/'cases').iterdir()}
    require(set(casepaths)==set(runner.IDS) and all(p.suffix=='.json' for p in casepaths.values()),'Additional/missing case artifacts')
    counts=dict(cases=0,new_method_history_pairs=0,solver_records=0,Powell_starts=0,scalar_solver_records=0,
                old_backend_CUDA16_controls=0,fresh_CPU32_selected_controls=0,eta_profile_points=0,
                common_backend_identity_rows=0,interaction_identity_rows=0,direct_contrasts=0,
                partial_records=0,failed_or_censored_cases=0)
    cases=[];partials_expected=set();case_pins={};peak=0
    a0,d0,n=c['law']['alternative_generating_fit']['pars'][:3]
    fixedfit=c['law']['alternative_generating_fit']
    for e in plan['entries']:
        identifier=e['id'];path=casepaths[identifier];case=read_sealed(path);aid=case['attempt_id']
        require(aid==session['session_id']+'_'+identifier,'Attempt not bound to recorded session')
        st,fn=starts[aid],finishes[aid]
        expected=runner.identity(plan,e)
        require(all(case[k]==st[k]==v for k,v in expected.items()),'Case/start input identity differs')
        require(st['attempt_id']==fn['attempt_id']==aid and fn['id']==identifier and fn['plan_id']==plan['plan_id'],'Attempt identity differs')
        require(case['status']==fn['status']=='complete' and case['error'] is None and fn['case_sha256']==sha256(path),'Case/finish status or byte binding differs')
        cap=c['resources']['per_case_wall_seconds'][identifier]
        require(cap==(1800 if identifier=='null_1292' else 900),'Per-case cap differs')
        interval=(datetime.fromisoformat(case['completed_utc'])-datetime.fromisoformat(st['started_utc'])).total_seconds()
        require(0<=case['elapsed_seconds']<=cap and 0<=interval<=cap,'Case wall cap exceeded')
        p=case['payload'];require(p['complete'] is True and p['status']=='complete' and p['all_mandated_solvers_successful'] is True,'Incomplete recorded payload')
        require([m['id'] for m in p['methods']]==['level_only','trend_only'],'Constrained methods differ')
        require(p['feature_metadata']['clock_mode']==e['clock_mode'] and p['benchmark_binding']['id']==identifier,'Payload history/clock differs')
        benchmark=read_sealed(ROOT/plan['benchmarks'][identifier]['path'])
        require(p['benchmark_binding']['canonical_case_sha256']==canonical_hash(benchmark),'Canonical reused benchmark binding differs')
        require(p['input_binding']['contract_sha256']==canonical_hash(c),'Payload protocol binding differs')
        mark=p['mark_nll_constant']
        for m in p['methods']:
            require(m['complete'] is True and len(m['eta_profile'])==11,'Incomplete method/profile')
            for phase in ('null','alternative'):
                point=m[phase];x=point['pars']
                require(x[2]==n and point['trigger']==fixedfit['trigger'] and point['ratio']==fixedfit['ratio'],'Fixed trigger coordinates changed')
                require(x[1]==d0 if m['id']=='level_only' else x[0]==a0,'Constrained coordinate changed')
                require(point['full_marked_nll']==point['nll']+mark,'Marked NLL arithmetic differs')
            require(m['null']['pars'][3]==0.,'Null eta differs')
        require(len(p['old_backend_controls'])==16 and len(p['cpu32_controls'])==8 and
                all(r['passed'] is True for r in p['old_backend_controls']+p['cpu32_controls']),'Control completion/count differs')
        require(all(r['success'] is True for r in p['search_records']),'Failed mandated solver')
        metrics=p['cuda_metrics'];peak=max(peak,metrics['peak_allocated_bytes'])
        require(metrics['dtype']=='float64' and metrics['peak_allocated_bytes']<=2**30 and
                all(metrics[k] is False for k in ('allow_tf32','mixed_precision','fast_math_requested')),'Recorded GPU numerical/resource policy differs')
        partdir=RUN/'partials'/identifier/aid;parts=list(partdir.glob('*.json'));partials_expected.add(partdir)
        require(len(parts)==case['partial_records'],'Partial count differs')
        for part in parts:
            value=read_sealed(part)
            require(value['attempt_id']==aid and all(value[k]==v for k,v in expected.items()),'Partial identity differs')
            require(value['progress'].get('event')!='exception','Exception checkpoint exists')
        counts['cases']+=1;counts['new_method_history_pairs']+=len(p['methods']);counts['solver_records']+=len(p['search_records'])
        powells=sum(r['label']=='trend_alternative_Powell' for r in p['search_records'])
        counts['Powell_starts']+=powells;counts['scalar_solver_records']+=len(p['search_records'])-powells
        counts['old_backend_CUDA16_controls']+=len(p['old_backend_controls']);counts['fresh_CPU32_selected_controls']+=len(p['cpu32_controls'])
        counts['eta_profile_points']+=sum(len(m['eta_profile']) for m in p['methods']);counts['common_backend_identity_rows']+=len(p['common_backend_identities'])
        counts['interaction_identity_rows']+=len(p['interaction_identities']);counts['direct_contrasts']+=2*(len(p['methods'])+len(p['benchmark_methods']))
        counts['partial_records']+=len(parts);case_pins[path.relative_to(ROOT).as_posix()]=sha256(path)
        cases.append(dict(id=identifier,clock_mode=e['clock_mode'],status='complete',attempt_id=aid,case_sha256=sha256(path),
                          recorded_case_wall_seconds=case['elapsed_seconds'],parent_start_to_case_commit_seconds=interval,cap_seconds=cap,
                          solver_records=len(p['search_records']),Powell_starts=powells,partial_records=len(parts)))
    require({p.parent for p in (RUN/'partials').rglob('*.json')}==partials_expected,'Orphan/additional partial attempt')
    analysis=read_sealed(ANALYSIS/'summary.json')
    require(analysis['plan_id']==plan['plan_id'] and analysis['complete_cases']==analysis['planned_cases']==10 and analysis['all_complete'] is True and
            analysis['failure_ledger']==[] and analysis['unknown_ids']==[] and analysis['source_sha256']==case_pins,'Frozen analysis case/status binding differs')
    require(analysis['analysis_code_sha256']==sha256(ROOT/'iteration_25/code/analyse_ablation.py'),'Frozen analyser source differs')
    csvcounts={}
    for name,expected in [('case_status',10),('procedure_comparisons',80),('nonadditive_interactions',20),('BG_enclosure_witnesses',80)]:
        with (ANALYSIS/(name+'.csv')).open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
        require(len(rows)==expected,'Analysis table row count differs: '+name);csvcounts[name]=len(rows)
    verification=[]
    for script in ['iteration_25/code/verify_preparation.py','iteration_24/completion/code/verify_completion.py']:
        done=subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,capture_output=True,text=True)
        require(done.returncode==0,'Read-only verifier failed: '+script+' '+done.stderr)
        value=json.loads(done.stdout);require(value['passed'] and value['read_only'],'Verifier did not pass read-only')
        verification.append(dict(path=script,exitcode=done.returncode,result=value))
    pins=['iteration_25/results/ablation_pilot/plan.json','iteration_25/results/ablation_pilot/sessions.json',
          'iteration_25/results/ablation_pilot/summary.json','iteration_25/results/ablation_pilot/execution_started.json',
          'iteration_25/logs/runtime_source_freeze.json','iteration_25/logs/preparation_manifest.json',
          'iteration_25/logs/prior_preservation_before.json','iteration_25/configs/ablation_protocol_frozen.json',
          'iteration_25/results/analysis/completed_pilot_01/summary.json',Path(__file__).relative_to(ROOT).as_posix()]
    out=dict(role='D',review_utc=utc_now(),passed=True,decision='GO_for_recorded_completion_resource_and_provenance_scope',plan_id=plan['plan_id'],
             scope='Saved operational metadata and byte/identity/accounting review; not independent numerical likelihood or mathematical validation',
             new_fits_or_history_scoring=False,GPU_initialized=False,counts=counts,cases=cases,all_sessions_closed=True,
             recorded_sessions=1,recorded_started_attempts=10,recorded_finished_attempts=10,recorded_orphan_attempts=0,
             failures=[],unknown_ids=[],fatal_ledger_present=False,
             budget=dict(total_policy_parent_seconds=7200,measured_parent_seconds=session['measured_elapsed_seconds'],
                         final_write_operational_allowance_seconds=1.,charged_parent_seconds=session['elapsed_seconds'],
                         nominal_unused_policy_seconds=7200-session['elapsed_seconds'],
                         scope='Parent invocation wall through owned-worker cleanup and final payload adoption; final ledger/summary writes receive a one-second operational reservation, not measured/proved latency bound; not GPU-seconds',
                         unused_budget_authorizes_new_campaign=False),
             process_death=dict(recorded_identity=identity,current_identity=current,matching_creation_token_alive=False),
             runtime_live_and_archived_sources_checked=len(plan['sources']),pinned_history_inputs_checked=len(input_pins),
             reused_benchmark_cases_checked=len(benchmark_pins),peak_recorded_Torch_allocated_bytes=peak,
             analysis_csv_rows=csvcounts,verification=verification,evidence_sha256={p:sha256(ROOT/p) for p in pins},
             input_sha256=input_pins,benchmark_sha256=benchmark_pins,case_sha256=case_pins,
             absence_claim_scope='No additional/repeated/failed/censored/orphan attempt appears in this recorded audit tree; no assertion about unrecorded machine-wide history')
    DEST.mkdir(parents=True,exist_ok=True);path=DEST/'D_resource_review.json';require(not path.exists(),'Refusing D completion review replacement')
    sealed_json(path,out)
    print(json.dumps(dict(passed=True,counts=counts,charged_parent_seconds=session['elapsed_seconds'],
                          unused_policy_seconds=7200-session['elapsed_seconds'],source_count=len(plan['sources']),
                          input_count=len(input_pins),benchmark_count=len(benchmark_pins),review_sha256=sha256(path)),indent=2))


if __name__=='__main__':main()
