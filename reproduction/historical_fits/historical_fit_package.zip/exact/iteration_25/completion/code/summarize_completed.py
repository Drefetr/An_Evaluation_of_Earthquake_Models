"""Additional saved-metadata tables and plot; no likelihood evaluation or fitting."""
from pathlib import Path
import argparse
import csv
import sys
import time
import math

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sealed_json,sha256,utc_now
MODELS=['known_known','level_only','trend_only','background_estimated']


def read_csv(path):
    with Path(path).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))


def write_csv(path,rows):
    with Path(path).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main():
    began=time.perf_counter()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=ROOT/'iteration_25/completion/results')
    args=parser.parse_args();out=args.output_dir.resolve()
    if out.exists() or not out.is_relative_to(ROOT/'iteration_25/completion'):
        raise ValueError('Choose new output directory inside iteration_25/completion')
    run=ROOT/'iteration_25/results/ablation_pilot'
    analysis=ROOT/'iteration_25/results/analysis/completed_pilot_01'
    plan=read_sealed(run/'plan.json');frozen=read_sealed(analysis/'summary.json')
    assert frozen['all_complete'] and frozen['complete_cases']==10
    proc=read_csv(analysis/'procedure_comparisons.csv')
    interactions=read_csv(analysis/'nonadditive_interactions.csv')
    enclosures=read_csv(analysis/'BG_enclosure_witnesses.csv')
    wide=[]
    for entry in plan['entries']:
        identifier=entry['id'];family='alternative' if identifier.startswith('new_') else 'null'
        for order in (16,32):
            values={r['model']:r for r in proc if r['id']==identifier and int(r['order'])==order}
            row=dict(id=identifier,generating_family=family,order=order)
            for mid in MODELS:
                row['D_'+mid]=float(values[mid]['direct_statistic'])
                row['C_'+mid]=float(values[mid]['contraction_from_KK'])
            row['interaction']=float(next(r['interaction'] for r in interactions if r['id']==identifier and int(r['order'])==order))
            row['max_BG_minus_intermediate_NLL']=max(float(r['signed_BG_minus_intermediate_NLL']) for r in enclosures if r['id']==identifier and int(r['order'])==order)
            wide.append(row)
    coords=[];case_rows=[];solver_rows=[];hashes={};failure_rows=[]
    for entry in plan['entries']:
        identifier=entry['id'];path=run/f'cases/{identifier}.json';case=read_sealed(path)
        assert case['status']=='complete' and case['plan_id']==plan['plan_id']
        hashes[identifier]=sha256(path);payload=case['payload']
        assert payload['complete'] and payload['all_mandated_solvers_successful']
        controls=payload['old_backend_controls']+payload['cpu32_controls']
        assert len(controls)==24 and all(r['passed'] for r in controls)
        for record in payload['search_records']:
            assert record['success']
            solver_rows.append(dict(id=identifier,**{k:record.get(k) for k in ('label','index','success','status','nfev','nit','elapsed_seconds')}))
        case_rows.append(dict(id=identifier,generating_family='alternative' if identifier.startswith('new_') else 'null',
            events=next(c['n_events'] for c in plan['contract']['cases'] if c['id']==identifier),
            clock_mode=case['clock_mode'],status=case['status'],elapsed_seconds=case['elapsed_seconds'],
            cpu_seconds=case['cpu_seconds'],solver_records=len(payload['search_records']),
            powell_starts=sum(r['label']=='trend_alternative_Powell' for r in payload['search_records']),
            value_controls=len(controls),maximum_value_difference=max(r['absolute_difference'] for r in controls),
            eta_profile_points=sum(len(m['eta_profile']) for m in payload['methods']),
            amplitude_profiles=len(payload['evaluations']),queries=len(payload['queries']),
            peak_cuda_bytes=payload['cuda_metrics']['peak_allocated_bytes'],
            preparation16_seconds=payload['feature_metadata']['preparation16_seconds'],
            preparation32_seconds=payload['feature_metadata']['preparation32_seconds'],case_sha256=hashes[identifier]))
        for m in payload['methods']+payload['benchmark_methods']:
            mid=m['id']
            for phase in ('null','alternative'):
                a,d,n,eta=m[phase]['pars']
                a_free=mid in ('level_only','background_estimated')
                d_free=mid in ('trend_only','background_estimated')
                eta_free=phase=='alternative'
                row=dict(id=identifier,generating_family='alternative' if identifier.startswith('new_') else 'null',
                         model=mid,phase=phase,a=a,d=d,n=n,eta=eta,a_estimated=a_free,d_estimated=d_free,
                         eta_estimated=eta_free,ground_NLL16=m[phase]['nll'],
                         full_marked_NLL16=m[phase]['full_marked_nll'])
                for name,value,bounds,is_free in [('a',a,(-12.,0.),a_free),('d',d,(-2.,2.),d_free),('eta',eta,(0.,3.),eta_free)]:
                    row[name+'_exact_lower']=bool(is_free and value==bounds[0])
                    row[name+'_exact_upper']=bool(is_free and value==bounds[1])
                    row[name+'_within_1e7_of_bound']=bool(is_free and min(abs(value-bounds[0]),abs(value-bounds[1]))<=1e-7)
                coords.append(row)
    sessions=read_sealed(run/'sessions.json')['sessions']
    resource=dict(measured_parent_seconds=sum(s['measured_elapsed_seconds'] for s in sessions),
                  closure_allowance_seconds=sum(s['closure_allowance_seconds'] for s in sessions),
                  charged_seconds=sum(s['elapsed_seconds'] for s in sessions),
                  cap_seconds=plan['contract']['resources']['total_parent_wall_seconds'],
                  all_sessions_closed=all(s['closed'] for s in sessions),
                  all_worker_exits_zero=all(s['worker_exitcode']==0 for s in sessions),
                  sum_case_wall_seconds=sum(c['elapsed_seconds'] for c in case_rows),
                  peak_cuda_bytes=max(c['peak_cuda_bytes'] for c in case_rows))
    alternatives=[r for r in wide if r['order']==32 and r['generating_family']=='alternative']
    nulls=[r for r in wide if r['order']==32 and r['generating_family']=='null']
    summary=dict(created_utc=utc_now(),plan_id=plan['plan_id'],case_sha256=hashes,
        analysis_summary_sha256=sha256(analysis/'summary.json'),code_sha256=sha256(Path(__file__)),
        complete_cases=10,new_method_history_pairs=20,reused_benchmark_method_history_pairs=20,
        total_procedure_history_pairs=40,per_order_table_rows=len(proc),interaction_rows=len(interactions),
        enclosure_rows=len(enclosures),solver_records=len(solver_rows),powell_starts=sum(c['powell_starts'] for c in case_rows),
        numerical_controls=sum(c['value_controls'] for c in case_rows),
        eta_profile_points=sum(c['eta_profile_points'] for c in case_rows),
        maximum_value_difference=max(c['maximum_value_difference'] for c in case_rows),
        maximum_identity_residual=max(abs(float(r['identity_residual'])) for r in proc),
        maximum_interaction_identity_residual=max(abs(float(r['identity_residual'])) for r in interactions),
        numerical_BG_witness_rows=sum(r['numerical_witness']=='True' for r in enclosures),
        material_BG_witness_rows=sum(r['material_witness']=='True' for r in enclosures),
        largest_signed_BG_gap=max(float(r['signed_BG_minus_intermediate_NLL']) for r in enclosures),
        all_four_alternative_ordering_KK_trend_level_BG=all(r['D_known_known']>r['D_trend_only']>r['D_level_only']>r['D_background_estimated'] for r in alternatives),
        all_four_alternative_level_contraction_exceeds_trend=all(r['C_level_only']>r['C_trend_only'] for r in alternatives),
        selected_alternative_interactions=[r['interaction'] for r in alternatives],
        null_level_increase_ids=[r['id'] for r in nulls if r['C_level_only']<-.1],
        null_trend_increase_ids=[r['id'] for r in nulls if r['C_trend_only']<-.1],
        resource=resource,failure_ledger=failure_rows,
        scope='Descriptive fixed-ten ablation; no calibrated detection, power, causal shares or global-optimum certificate.',
        no_new_fits_or_likelihood_evaluations=True,elapsed_analysis_seconds=time.perf_counter()-began)
    out.mkdir(parents=True)
    for name,rows in [('comparison_by_case',wide),('selected_coordinates',coords),('case_summary',case_rows),('solver_records',solver_rows)]:
        write_csv(out/(name+'.csv'),rows)
    sealed_json(out/'summary.json',summary)
    table=['| Alternative history | Background known | Trend free | Level free | Both free | Interaction |',
           '|---|---:|---:|---:|---:|---:|']
    for r in alternatives:
        table.append(f"| {r['id']} | {r['D_known_known']:.3f} | {r['D_trend_only']:.3f} | {r['D_level_only']:.3f} | {r['D_background_estimated']:.3f} | {r['interaction']:.3f} |")
    (out/'alternative_comparison.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    colors=['#34526f','#3e8d98','#d39235','#805c91']
    fig,axes=plt.subplots(2,2,figsize=(9.5,6.7))
    for ax,r in zip(axes.flat,alternatives):
        vals=[r['D_'+mid] for mid in ['known_known','trend_only','level_only','background_estimated']]
        ax.bar(range(4),vals,color=colors,width=.65)
        ax.set_xticks(range(4),['Known','Trend free','Level free','Both free'])
        ax.set_title(r['id'].replace('_',' '),loc='left',fontsize=11)
        ax.set_ylabel('Direct twice-log-likelihood statistic')
        ax.spines[['top','right']].set_visible(False)
        ax.set_ylim(0,max(vals)*1.18)
        for j,value in enumerate(vals):
            ax.text(j,value+max(vals)*.025,f'{value:.1f}',ha='center',fontsize=9)
    fig.suptitle('Selected alternative histories: background-level and trend ablation',fontsize=13)
    fig.text(.5,.015,'Same observed histories; descriptive statistics. No shared critical value or power estimate.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.95))
    fig.savefig(out/'alternative_statistics.png',dpi=180)
    fig.savefig(out/'alternative_statistics.svg')
    plt.close(fig)
    print({k:summary[k] for k in ('complete_cases','solver_records','powell_starts','numerical_controls','numerical_BG_witness_rows','all_four_alternative_level_contraction_exceeds_trend')})


if __name__=='__main__':
    main()
