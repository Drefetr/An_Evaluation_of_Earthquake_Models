"""Audit saved analysis tables against independent metadata and raw records."""
from pathlib import Path
import csv
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
from checkpoint_io import read_json, read_sealed, sealed_json, sha256, utc_now


def table(path, keys):
    with path.open(encoding='utf-8', newline='') as stream:
        rows = list(csv.DictReader(stream))
    result = {tuple(row[key] for key in keys): row for row in rows}
    assert len(result) == len(rows)
    return result


def audit():
    audit_data = read_sealed(ROOT / 'iteration_25/completion/logs/A_metadata_audit.json')
    frozen = ROOT / 'iteration_25/results/analysis/completed_pilot_01'
    extra = ROOT / 'iteration_25/completion/results'
    tables = {
        'procedure': table(frozen / 'procedure_comparisons.csv', ['id', 'model', 'order']),
        'interaction': table(frozen / 'nonadditive_interactions.csv', ['id', 'order']),
        'enclosure': table(frozen / 'BG_enclosure_witnesses.csv', ['id', 'model', 'order', 'phase']),
        'coordinates': table(extra / 'selected_coordinates.csv', ['id', 'model', 'phase']),
        'wide': table(extra / 'comparison_by_case.csv', ['id', 'order']),
        'cases': table(extra / 'case_summary.csv', ['id']),
        'solvers': table(extra / 'solver_records.csv', ['id', 'label', 'index'])}
    cells = 0
    def check(actual, expected, tolerant=()):
        nonlocal cells
        assert set(actual) == set(expected), (set(actual), set(expected))
        for key, value in expected.items():
            if isinstance(value, bool):
                assert actual[key] == str(value), (key, actual[key], value)
            elif isinstance(value, int):
                assert int(actual[key]) == value, (key, actual[key], value)
            elif isinstance(value, float):
                error = abs(float(actual[key]) - value)
                assert error <= (1e-8 if key in tolerant else 0.), (key, actual[key], value)
            else:
                assert actual[key] == value, (key, actual[key], value)
            cells += 1
    for row in audit_data['procedure_rows']:
        expected = {key: value for key, value in row.items() if key not in ('mark_nll_constant', 'common_backend_identity_rhs')}
        expected.update(status='complete', material_phase_gain=max(row['null_gain_from_KK'], row['alternative_gain_from_KK']) >= .001,
                        material_statistic_change=abs(row['signed_change_from_KK']) >= .1)
        check(tables['procedure'][(row['id'], row['model'], str(row['order']))], expected)
    for row in audit_data['enclosure_rows']:
        expected = dict(id=row['id'], status='complete', order=row['order'], model=row['model'], phase=row['phase'],
                        signed_BG_minus_intermediate_NLL=row['signed_BG_minus_new_NLL'],
                        numerical_witness=row['numerical_enclosure_flag'], material_witness=row['material_enclosure_flag'],
                        finite_search_witness_only=True)
        check(tables['enclosure'][(row['id'], row['model'], str(row['order']), row['phase'])], expected)
    for row in audit_data['selected_parameters']:
        a, d, n, eta = row['pars']
        estimated = row['fitted_coordinates']
        expected = dict(id=row['id'], generating_family='alternative' if row['id'].startswith('new_') else 'null',
                        model=row['model'], phase=row['phase'], a=a, d=d, n=n, eta=eta,
                        a_estimated='a' in estimated, d_estimated='d' in estimated, eta_estimated='eta' in estimated,
                        ground_NLL16=row['NLL'], full_marked_NLL16=row['full_marked_NLL'])
        for name, value, lo, hi in [('a', a, -12., 0.), ('d', d, -2., 2.), ('eta', eta, 0., 3.)]:
            expected[name + '_exact_lower'] = name in estimated and value == lo
            expected[name + '_exact_upper'] = name in estimated and value == hi
            expected[name + '_within_1e7_of_bound'] = name in estimated and min(abs(value - lo), abs(value - hi)) <= 1e-7
        check(tables['coordinates'][(row['id'], row['model'], row['phase'])], expected)
    for case_row in audit_data['case_rows']:
        identifier = case_row['id']
        path = ROOT / 'iteration_25/results/ablation_pilot/cases' / (identifier + '.json')
        assert sha256(path) == audit_data['case_sha256'][identifier]
        case = read_json(path)
        payload = case['payload']
        for order in (16, 32):
            raw_i = next(row for row in payload['interaction_identities'] if row['order'] == order)
            expected = dict(id=identifier, status='complete', order=order, interaction=payload['nonadditive_interaction'][str(order)],
                            formula='D_BG-D_level-D_trend+D_KK', identity_residual=raw_i['residual'],
                            material_absolute_interaction=raw_i['material_absolute_interaction'], causal_or_additive_share=False)
            check(tables['interaction'][(identifier, str(order))], expected)
            p = {row['model']: row for row in audit_data['procedure_rows'] if row['id'] == identifier and row['order'] == order}
            expected = dict(id=identifier, generating_family='alternative' if identifier.startswith('new_') else 'null', order=order)
            for model in ('known_known', 'level_only', 'trend_only', 'background_estimated'):
                expected['D_' + model] = p[model]['direct_statistic']
                expected['C_' + model] = p[model]['contraction_from_KK']
            expected['interaction'] = payload['nonadditive_interaction'][str(order)]
            expected['max_BG_minus_intermediate_NLL'] = max(row['signed_BG_minus_new_NLL'] for row in audit_data['enclosure_rows'] if row['id'] == identifier and row['order'] == order)
            check(tables['wide'][(identifier, str(order))], expected)
        controls = payload['old_backend_controls'] + payload['cpu32_controls']
        expected = dict(id=identifier, generating_family='alternative' if identifier.startswith('new_') else 'null',
                        events=case_row['events'], clock_mode=case['clock_mode'], status=case['status'],
                        elapsed_seconds=case['elapsed_seconds'], cpu_seconds=case['cpu_seconds'],
                        solver_records=len(payload['search_records']),
                        powell_starts=sum(row['label'] == 'trend_alternative_Powell' for row in payload['search_records']),
                        value_controls=len(controls), maximum_value_difference=max(row['absolute_difference'] for row in controls),
                        eta_profile_points=sum(len(m['eta_profile']) for m in payload['methods']),
                        amplitude_profiles=len(payload['evaluations']), queries=len(payload['queries']),
                        peak_cuda_bytes=payload['cuda_metrics']['peak_allocated_bytes'],
                        preparation16_seconds=payload['feature_metadata']['preparation16_seconds'],
                        preparation32_seconds=payload['feature_metadata']['preparation32_seconds'],
                        case_sha256=audit_data['case_sha256'][identifier])
        check(tables['cases'][(identifier,)], expected)
        for row in payload['search_records']:
            expected = dict(id=identifier, **{key: row[key] for key in ('label', 'index', 'success', 'status', 'nfev', 'nit', 'elapsed_seconds')})
            check(tables['solvers'][(identifier, row['label'], str(row['index']))], expected)
    expected_counts = dict(procedure=80, interaction=20, enclosure=80, coordinates=80, wide=20, cases=10, solvers=157)
    assert {key: len(value) for key, value in tables.items()} == expected_counts
    analysis_summary = read_sealed(frozen / 'summary.json')
    extra_summary = read_sealed(extra / 'summary.json')
    assert analysis_summary['all_complete'] and analysis_summary['complete_cases'] == 10
    assert not analysis_summary['failure_ledger'] and not analysis_summary['unknown_ids']
    assert extra_summary['case_sha256'] == audit_data['case_sha256']
    alternatives = {row['id']: {} for row in audit_data['procedure_rows'] if row['id'].startswith('new_')}
    for row in audit_data['procedure_rows']:
        if row['id'].startswith('new_') and row['order'] == 32:
            alternatives[row['id']][row['model']] = row
    assert all(rows['known_known']['direct_statistic'] > rows['trend_only']['direct_statistic'] >
               rows['level_only']['direct_statistic'] > rows['background_estimated']['direct_statistic'] for rows in alternatives.values())
    assert all(rows['level_only']['contraction_from_KK'] > rows['trend_only']['contraction_from_KK'] for rows in alternatives.values())
    assert extra_summary['all_four_alternative_ordering_KK_trend_level_BG'] is True
    assert extra_summary['all_four_alternative_level_contraction_exceeds_trend'] is True
    result = dict(role='A', passed=True, audited_utc=utc_now(), table_rows=expected_counts,
                  exact_checked_cells=cells, all_cells_equal=True,
                  four_selected_alternative_ordering_verified=True,
                  estimated_coordinate_bound_screen_tolerance=1e-7,
                  bound_screen_scope='Post-hoc diagnostic label, not a new optimizer gate or KKT certificate',
                  artifact_sha256={path.relative_to(ROOT).as_posix(): sha256(path)
                                   for folder in (frozen, extra) for path in sorted(folder.iterdir()) if path.is_file()})
    out = ROOT / 'iteration_25/completion/logs/A_table_audit.json'
    assert not out.exists()
    sealed_json(out, result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    audit()
