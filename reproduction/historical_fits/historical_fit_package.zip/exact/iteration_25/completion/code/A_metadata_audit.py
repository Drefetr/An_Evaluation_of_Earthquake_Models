"""Read-only post-run metadata audit. No fitting, likelihood evaluation or GPU."""
from pathlib import Path
from contextlib import ExitStack
from unittest.mock import patch
import collections
import gc
import hashlib
import json
import math
import sys
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'iteration_25/code'))
sys.path.insert(0, str(ROOT / 'iteration_6/code'))
import ablation_fit as production
from checkpoint_io import canonical_hash, read_json, read_sealed, sealed_json, sha256, utc_now


def blocked(*args, **kwargs):
    raise AssertionError('Metadata audit attempted a scientific evaluation')


def statuses(model, phase, pars):
    fitted = {'known_known': [], 'level_only': ['a'], 'trend_only': ['d'],
              'background_estimated': ['a', 'd']}[model] + ([] if phase == 'null' else ['eta'])
    result = {}
    for name, index, lo, hi in [('a', 0, -12., 0.), ('d', 1, -2., 2.), ('eta', 3, 0., 3.)]:
        result[name] = ('fixed' if name not in fitted else
                        'lower' if pars[index] == lo else 'upper' if pars[index] == hi else 'interior')
    return fitted, result


def audit():
    run = ROOT / 'iteration_25/results/ablation_pilot'
    plan = read_sealed(run / 'plan.json')
    contract = plan['contract']
    assert canonical_hash({key: plan[key] for key in
                           ['config_path', 'config_sha256', 'contract', 'sources', 'entries', 'benchmarks']}) == plan['plan_id']
    assert sha256(ROOT / plan['config_path']) == plan['config_sha256']
    assert read_json(ROOT / plan['config_path']) == contract
    assert all(sha256(ROOT / path) == digest and sha256(run / 'source_snapshots' / path) == digest
               for path, digest in plan['sources'].items())
    assert all(sha256(ROOT / ref['path']) == ref['sha256'] for ref in contract['authorities'])
    assert set(path.stem for path in (run / 'cases').glob('*.json')) == set(contract['case_ids'])
    declared = {entry['id']: entry for entry in contract['cases']}
    inventory = {entry['id']: entry for entry in read_sealed(ROOT / 'iteration_17/results/inventory_20261016T120350054217Z.json')['entries']}
    case_hashes, rows, selected, procedure_rows, interactions, enclosures, solvers = {}, [], [], [], [], [], []
    fit = contract['law']['alternative_generating_fit']
    with ExitStack() as stack:
        for obj, name in [(production, 'RestrictedHistory'), (production, 'CudaOracleContext'),
                          (production, 'fit_ablation_case'), (production, 'minimize'),
                          (production.profile, 'amplitude_profile'), (production.profile, 'amplitude_value')]:
            stack.enter_context(patch.object(obj, name, side_effect=blocked))
        for entry in plan['entries']:
            identifier = entry['id']
            assert entry == inventory[identifier]
            path = run / 'cases' / (identifier + '.json')
            case_hashes[identifier] = sha256(path)
            case = read_sealed(path)
            payload = case['payload']
            assert case['plan_id'] == plan['plan_id'] and case['id'] == identifier
            assert case['seed'] == entry['seed'] and case['clock_mode'] == entry['clock_mode']
            assert case['inventory_entry_sha256'] == canonical_hash(entry)
            assert case['catalogue_sha256'] == entry['files']['catalogue.npz']['sha256']
            assert all(sha256(ROOT / ref['path']) == ref['sha256'] for ref in entry['files'].values())
            assert case['status'] == 'complete' and case['error'] is None
            assert production.validate_result(payload, contract) is True
            assert payload['input_binding']['clock_mode'] == payload['feature_metadata']['clock_mode'] == entry['clock_mode']
            assert all(digest == plan['sources'][path] for path, digest in payload['input_binding']['sources'].items())
            assert payload['benchmark_binding']['id'] == identifier
            benchmark_ref = plan['benchmarks'][identifier]
            assert case['benchmark_sha256'] == benchmark_ref['sha256'] == sha256(ROOT / benchmark_ref['path'])
            benchmark = read_sealed(ROOT / benchmark_ref['path'])
            assert payload['benchmark_binding']['canonical_case_sha256'] == canonical_hash(benchmark)
            old = {method['id']: method for method in benchmark['payload']['methods']}
            for bm in payload['benchmark_methods']:
                for phase in ('null', 'alternative'):
                    assert all(bm[phase][key] == old[bm['id']][phase][key] for key in ('pars', 'trigger', 'ratio'))
                    assert bm['saved_' + phase + '_nll'] == old[bm['id']][phase]['nll']
                for order in (16, 32):
                    assert bm['saved_contrast' + str(order)] == old[bm['id']]['contrast' + str(order)]
            with np.load(ROOT / entry['files']['catalogue.npz']['path'], allow_pickle=False) as archive:
                arrays = {name: archive[name] for name in archive.files}
            expected_arrays = {name: dict(dtype=value.dtype.str, shape=list(value.shape),
                                         sha256=hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest())
                               for name, value in arrays.items()}
            assert expected_arrays == payload['input_binding']['arrays']
            count = len(arrays['times'])
            assert count == declared[identifier]['n_events']
            mark = -count * math.log(contract['law']['beta']) + contract['law']['beta'] * math.fsum(arrays['excess'])
            assert mark == payload['mark_nll_constant']
            assert case['elapsed_seconds'] < contract['resources']['per_case_wall_seconds'][identifier]
            assert payload['validation_reserve_seconds'] == contract['resources']['validation_reserve_seconds'][identifier]
            roots = payload['evaluations']
            boundaries = collections.Counter()
            max_monotonicity = max_residual = max_bracket = 0.
            max_iterations = 0
            for index, point in enumerate(roots):
                amp = point['amplitude']
                assert point['evaluation_id'] == index and point['pars'][1] == fit['pars'][1]
                assert amp['n_events'] == count and amp['root_converged'] is True
                trace = sorted(amp['root_evaluations'], key=lambda row: row['a'])
                for left, right in zip(trace, trace[1:]):
                    violation = left['F_A'] - right['F_A']
                    max_monotonicity = max(max_monotonicity, violation)
                    assert violation <= 1e-10 * max(1., abs(left['F_A']), abs(right['F_A']))
                if amp['boundary'] is None:
                    max_residual = max(max_residual, abs(amp['F_A_at_solution']))
                    if amp['F_A_at_solution'] != 0:
                        width = min(row['a'] for row in trace if row['F_A'] > 0) - max(row['a'] for row in trace if row['F_A'] < 0)
                        assert 0 <= width <= 2.01e-12 + 4 * sys.float_info.epsilon * abs(amp['a'])
                        max_bracket = max(max_bracket, width)
                boundaries[str(amp['boundary'])] += 1
                max_iterations = max(max_iterations, amp['iterations'])
            for query in payload['queries']:
                assert query['pars'][1] == fit['pars'][1] if query['model'] == 'level_only' else query['pars'][0] == fit['pars'][0]
            methods = {m['id']: m for m in payload['methods'] + payload['benchmark_methods']}
            old_controls = {row['label']: row for row in payload['old_backend_controls']}
            cpu_controls = {row['label']: row for row in payload['cpu32_controls']}
            for model, method in methods.items():
                tag = 'old_' if model in ('known_known', 'background_estimated') else 'new_'
                for phase in ('null', 'alternative'):
                    point = method[phase]
                    fitted, boundary = statuses(model, phase, point['pars'])
                    selected.append(dict(id=identifier, model=model, phase=phase, pars=point['pars'],
                                         fitted_coordinates=fitted, parameter_status=boundary,
                                         NLL=point['nll'], full_marked_NLL=point['full_marked_nll']))
                for order, controls, field in [(16, old_controls, 'old_backend16_nll'), (32, cpu_controls, 'independent32_nll')]:
                    null = controls[tag + model + '_null'][field]
                    alt = controls[tag + model + '_alternative'][field]
                    kk_null = controls['old_known_known_null'][field]
                    kk_alt = controls['old_known_known_alternative'][field]
                    contrast = method['contrast' + str(order)]
                    baseline = methods['known_known']['contrast' + str(order)]
                    g0, g1 = kk_null - null, kk_alt - alt
                    delta = contrast['statistic'] - baseline['statistic']
                    rhs = 2 * (g1 - g0) + contrast['direct_minus_subtraction'] - baseline['direct_minus_subtraction']
                    assert abs(delta - rhs) < 1e-8
                    procedure_rows.append(dict(id=identifier, model=model, order=order,
                                               null_ground_NLL=null, alternative_ground_NLL=alt,
                                               null_full_marked_NLL=null + mark, alternative_full_marked_NLL=alt + mark,
                                               mark_nll_constant=mark, null_gain_from_KK=g0, alternative_gain_from_KK=g1,
                                               direct_statistic=contrast['statistic'], signed_change_from_KK=delta,
                                               contraction_from_KK=-delta, common_backend_identity_rhs=rhs,
                                               identity_residual=delta - rhs))
                    if model in ('level_only', 'trend_only'):
                        for phase, value in [('null', null), ('alternative', alt)]:
                            gap = controls['old_background_estimated_' + phase][field] - value
                            enclosures.append(dict(id=identifier, model=model, order=order, phase=phase,
                                                   signed_BG_minus_new_NLL=gap, numerical_enclosure_flag=gap > .0002,
                                                   material_enclosure_flag=gap >= .001))
            for order in (16, 32):
                statistic = sum(sign * methods[model]['contrast' + str(order)]['statistic'] for model, sign in
                                [('background_estimated', 1), ('level_only', -1), ('trend_only', -1), ('known_known', 1)])
                assert abs(statistic - payload['nonadditive_interaction'][str(order)]) <= contract['validation']['identity_tolerance']
                interactions.append(dict(id=identifier, order=order, interaction=statistic))
            for record in payload['search_records']:
                solvers.append(dict(id=identifier, **{key: record[key] for key in ('label', 'index', 'success', 'nit', 'nfev')}))
            rows.append(dict(id=identifier, events=count, clock_mode=entry['clock_mode'],
                             elapsed_seconds=case['elapsed_seconds'], roots=len(roots), root_boundary_counts=dict(boundaries),
                             max_root_iterations=max_iterations, max_interior_F_A_residual=max_residual,
                             max_terminal_sign_bracket_width=max_bracket, max_monotonicity_violation=max_monotonicity,
                             fixed_evaluations=len(payload['fixed_evaluations']), queries=len(payload['queries']),
                             solvers=len(payload['search_records']), profiles=sum(len(method['eta_profile']) for method in payload['methods']),
                             maximum_original_backend_difference=max(row['absolute_difference'] for row in payload['old_backend_controls']),
                             maximum_CPU32_difference=max(row['absolute_difference'] for row in payload['cpu32_controls']),
                             maximum_direct_order_difference=max(abs(m['contrast16']['statistic'] - m['contrast32']['statistic']) for m in methods.values()),
                             maximum_direct_subtraction_difference=max(abs(m['contrast' + str(o)]['direct_minus_subtraction']) for m in methods.values() for o in (16, 32)),
                             maximum_common_identity_residual=max(abs(row['residual']) for row in payload['common_backend_identities']),
                             maximum_interaction_identity_residual=max(abs(row['residual']) for row in payload['interaction_identities'])))
            print('AUDITED ' + identifier, file=sys.stderr, flush=True)
            del case, payload, benchmark, old, roots, arrays, methods
            gc.collect()
    assert len(rows) == 10 and len(procedure_rows) == len(enclosures) == 80 and len(interactions) == 20
    assert next(row for row in rows if row['id'] == 'null_1292')['events'] == 30276
    assert next(row for row in rows if row['id'] == 'null_0841')['clock_mode'] == 'paired_clock'
    assert all(row['success'] for row in solvers)
    result = dict(role='A', passed=True, audited_utc=utc_now(), plan_id=plan['plan_id'], source_hashes=plan['sources'],
                  case_sha256=case_hashes, case_rows=rows, selected_parameters=selected, procedure_rows=procedure_rows,
                  interaction_rows=interactions, enclosure_rows=enclosures, solver_rows=solvers,
                  scientific_likelihood_evaluations=0, GPU_initializations=0,
                  pure_guard_blockers=['History construction', 'GPU context creation', 'fit_ablation_case', 'minimize', 'amplitude_profile', 'amplitude_value'])
    out = ROOT / 'iteration_25/completion/logs/A_metadata_audit.json'
    assert not out.exists()
    sealed_json(out, result)
    print(json.dumps(dict(passed=True, log_path=out.relative_to(ROOT).as_posix(), log_sha256=sha256(out),
                         cases=len(rows), roots=sum(row['roots'] for row in rows), solvers=len(solvers),
                         procedure_rows=len(procedure_rows), interactions=len(interactions), enclosure_rows=len(enclosures))))


if __name__ == '__main__':
    audit()
