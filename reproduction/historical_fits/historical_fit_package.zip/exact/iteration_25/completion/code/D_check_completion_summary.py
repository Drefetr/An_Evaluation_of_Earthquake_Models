"""Cross-check saved completion resource tables against independent D metadata."""
from pathlib import Path
import csv
import json
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import read_sealed,sealed_json,sha256,utc_now


def main():
    area=ROOT/'iteration_25/completion'
    d=read_sealed(area/'reviews/D_resource_review.json')
    result=read_sealed(area/'results/summary.json')
    analysis=ROOT/'iteration_25/results/analysis/completed_pilot_01/summary.json'
    assert result['plan_id']==d['plan_id']
    counts=d['counts'];budget=d['budget']
    expected=dict(measured_parent_seconds=budget['measured_parent_seconds'],closure_allowance_seconds=1.,
                  charged_seconds=budget['charged_parent_seconds'],cap_seconds=7200,
                  all_sessions_closed=True,all_worker_exits_zero=True,
                  sum_case_wall_seconds=sum(c['recorded_case_wall_seconds'] for c in d['cases']),
                  peak_cuda_bytes=d['peak_recorded_Torch_allocated_bytes'])
    assert result['resource']==expected
    assert result['failure_ledger']==[]
    assert result['complete_cases']==10 and result['new_method_history_pairs']==20 and result['reused_benchmark_method_history_pairs']==20 and result['total_procedure_history_pairs']==40
    assert result['solver_records']==counts['solver_records'] and result['powell_starts']==counts['Powell_starts']
    assert result['numerical_controls']==counts['old_backend_CUDA16_controls']+counts['fresh_CPU32_selected_controls']
    assert result['eta_profile_points']==counts['eta_profile_points']
    assert (result['per_order_table_rows'],result['interaction_rows'],result['enclosure_rows'])==(80,20,80)
    with (area/'results/case_summary.csv').open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
    assert len(rows)==10 and len({r['id'] for r in rows})==10
    mapped={r['id']:r for r in rows}
    for case in d['cases']:
        row=mapped[case['id']]
        assert row['status']=='complete' and row['clock_mode']==case['clock_mode']
        assert float(row['elapsed_seconds'])==case['recorded_case_wall_seconds']
        assert int(row['solver_records'])==case['solver_records'] and int(row['powell_starts'])==case['Powell_starts']
        assert int(row['value_controls'])==24 and int(row['eta_profile_points'])==22
        assert row['case_sha256']==case['case_sha256']==result['case_sha256'][case['id']]
    assert result['analysis_summary_sha256']==sha256(analysis)
    assert result['code_sha256']==sha256(area/'code/summarize_completed.py')
    paths=[area/'results/summary.json',area/'results/case_summary.csv',area/'results/solver_records.csv',
           area/'code/summarize_completed.py',area/'reviews/D_resource_review.json',analysis,Path(__file__)]
    out=dict(role='D',passed=True,review_utc=utc_now(),resource_fields_checked=len(expected),case_rows_checked=10,
             counts_checked=dict(solver_records=157,Powell_starts=50,numerical_controls=240,eta_profile_points=220,
                                 procedure_history_pairs=40,per_order_rows=80,interaction_rows=20,enclosure_rows=80),
             failure_ledger=[],scope='Read-only operational resource/count/case-binding cross-check; no scientific result re-evaluation',
             read_only_inputs=True,new_fits_or_history_scoring=False,GPU_initialized=False,
             input_sha256={p.relative_to(ROOT).as_posix():sha256(p) for p in paths})
    log=area/'logs/D_aggregation_crosscheck.json'
    assert not log.exists(),'Refusing review evidence replacement'
    sealed_json(log,out)
    print(json.dumps(dict(passed=True,resource_fields_checked=len(expected),case_rows_checked=10,
                          log_sha256=sha256(log),summary_sha256=sha256(area/'results/summary.json')),indent=2))


if __name__=='__main__':main()
