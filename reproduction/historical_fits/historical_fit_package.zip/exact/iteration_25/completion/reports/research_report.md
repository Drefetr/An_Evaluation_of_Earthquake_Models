# Completed background-level versus time-trend pilot

All ten histories and both new procedures completed and passed the numerical gates. On each of the four deliberately selected alternative-generated histories, allowing the background level to be estimated contracted the direct likelihood-ratio statistic much more than allowing trend alone. Allowing both contracted it further. No intermediate fit improved on the saved both-free phase values, so the frozen benchmark-gap follow-up rule was not triggered.

This is a new finite-path ablation result. It does not estimate power, establish global optima, or identify a physical earthquake mechanism. The six null and four alternative histories were selected after earlier diagnostics; four matching orderings are not a representative probability estimate.

## Actual numerical comparison

The table uses the fresh CPU32 selected-point convention. Each entry is a direct twice-log-likelihood statistic, not a p-value or detection. Every procedure would require its own matched null calculation for calibrated inference. I=D_BG-D_level-D_trend+D_KK.

| Alternative history | Background known | Trend free | Level free | Both free | Interaction |
|---|---:|---:|---:|---:|---:|
| new_r000 | 59.033 | 48.592 | 11.348 | 2.442 | 1.534 |
| new_r076 | 292.139 | 237.221 | 124.343 | 26.776 | -42.650 |
| new_r100 | 460.765 | 402.106 | 103.994 | 25.037 | -20.299 |
| new_r140 | 61.789 | 57.065 | 6.427 | 4.363 | 2.660 |


![Four selected alternative histories](../results/alternative_statistics.png)

The standard-tool PNG/SVG was visually inspected. The panels have different vertical scales to preserve readability within each history. No critical value, confidence interval or population error rate is implied.

On these four paths, the level-only statistic contractions were 47.685, 167.796, 356.770 and 55.362, versus 10.441, 54.918, 58.659 and 4.724 for trend-only. The interaction had both signs: +1.534, -42.650, -20.299 and +2.660. Thus these changes cannot be reported as additive shares of an explained power loss. Both-order rows, all nulls and signed phase gaps are retained in the saved tables.

The null histories show why calibration cannot be skipped: level estimation increased the statistic for null_0841 (2.551 to 4.859), while trend estimation increased it for null_1292 (0.685 to 2.377) and null_1345 (1.310 to 1.510). Parameter-space nesting orders ideal phasewise minima separately; it does not order their likelihood-ratio differences. No old threshold was applied to these new statistics.

## Where the contraction occurs

On each selected alternative path, freeing level improved the fitted no-inhibition likelihood much more than the fitted inhibited likelihood. For new_r000 the null NLL gain was 24.174929, versus .332533 for the alternative, giving a statistic contraction of 47.684791 after the recorded direct/subtraction correction. The corresponding null versus alternative gains were 84.028292 versus .130494, 178.494848 versus .109622, and 27.723220 versus .042060 for the other three paths.

The level-only null chose a=-4.5974, -5.1854, -6.1153 and -4.6301, below the supplied a0=-4.1621 on all four. In this specified diagnostic, fitting a lower baseline can accommodate part of the reduced activity that otherwise favors inhibition when the baseline is supplied. This is an interpretation of the conditional fitted likelihoods. It is not a measurement of tectonic loading, proof of a unique causal explanation, or an intrinsic information bound. Alternative eta estimates remain positive; a smaller fit advantage is distinct from estimating eta exactly zero.

This interpretation is consistent with the earlier pathwise amplitude-profile identity: at an interior amplitude optimum, the integrated background component equals the sum of fitted background event shares. That identity was established in the earlier restricted calculus; it is not a new ensemble Fisher-information result. The present pilot measures how the stipulated finite procedures use background freedom.

## Numerical and provenance review

There are 20 newly fitted method-history pairs and 20 reused benchmark pairs, giving 40 procedure-history comparisons and 80 order-specific rows. All 157 mandated solver records (50 Powell starts) and 240 value controls passed; all 220 new eta-profile points are present with validated search metadata and constraints. Fresh CPU32 comparisons cover the eight selected phase points per history, not every eta-profile integral. The largest saved value-control discrepancy was 2.91038305e-11; maximum common-backend interaction-identity residual was 1.42108547e-14. The prior both-known and both-free points were rescored as controls, not refitted or replaced.

Every one of the 80 signed BG-minus-intermediate phase gaps is negative; the largest is -2.72672e-05. There is no numerical or material BG-improvement witness in this pilot. This concerns the saved candidate points and finite declared searches, not a global optimality certificate.

Selected coordinate and bound-status tables are saved. New fitted level/trend coordinates are interior. Several null-generated alternative fits choose eta=0; these are retained. The saved both-free new_r100 benchmark has d=-2 in the null and d=+2 in the alternative. Its interaction therefore remains specific to the stipulated trend box. The coordinate table records exact endpoints and a separately labeled 1e-7 proximity screen; proximity is not a KKT or confidence claim.

A independently checked raw metadata, constrained queries, amplitude roots, fixed-law/mark constants, original benchmark coordinates and numerical identities, and cross-checked the saved tables. C separately reaggregated the interpretation and accounting. D checked recorded attempts, process death, resources and preservation. Agent checks are collaborative project reviews, not independent academic refereeing. Fresh CPU32 controls share the pinned history geometry with CUDA16. They do not independently reconstruct all history features or prove a universal quadrature bound. The finite grids, roots and successful solvers do not certify a global solution.

## Scope and relation to earlier work

The intensity remains exp(a+d*(2t/T-1))*exp(-eta*G(t))+n*H(t), with triggering, beta, productivity and both finite195-mode kernels supplied. The same marked histories, pre-event intensities, empty prehistory, random event counts, full compensators and original clock conventions were preserved. There is no clipping, new catalogue, scientific simulation or mark-law re-estimation. The transformed-mark regime still has infinite second moment; no Fisher/Wilks approximation was used.

The earlier 150/150 versus 68/150 calibrated procedure contrast remains unchanged under its own banks and qualifications. This pilot identifies a stronger level-only than trend-only contraction on four selected paths; it does not recompute those power frequencies or establish equal-size performance of the new tests. The historical fuller-nuisance57/150 result remains a separate procedure. This diagnostic differs from the original physical loading model and is not evidence of an empirical NZ stress mechanism or of shared versus different kernels. First-moment stability and infinite-memory questions remain separate.

## Resource outcome and next question

The measured parent duration was 559.240840 seconds. The charged duration was 560.240840 seconds (about 9 minutes20seconds), including the explicit one-second final-write allowance, within the 7200-second budget. The allowance is not a proved storage-latency bound. All cases respected their own caps, the worker exited zero and its creation-token identity is dead. No failed, censored, dropped, replaced or unresolved case appears in the recorded pilot. Parent wall is not GPU compute time. Unused budget does not authorize another study.

The single most useful next question is whether level-only estimation reduces calibrated detection after using its own matched null reference and held-out checks. A separately frozen, resource-capped comparison could reuse the existing catalogue roles, but must fit the new procedure on its null bank and derive its own calibration. The present alternative-statistic drop cannot answer that question because the null distribution also changed. No calibration, bootstrap or additional fitting was launched here.

## Evidence and reproduction

The immutable prepared sources and earlier authorities remain unchanged. The initial README/STATUS describe preparation; this completion area supplies the updated result. Added tables are in `iteration_25/completion/results/`, the frozen full comparison is in `iteration_25/results/analysis/completed_pilot_01/`, and exact case hashes/review scopes are in `reviews/` and the completion manifest. No integrated original thesis or PDF was produced; a targeted replacement fragment is supplied.

Read-only completion verification from the project root:

```powershell
python -B iteration_25/completion/code/verify_completion.py
```

Reproduce the frozen descriptive analysis into a new directory, without fitting or scoring:

```powershell
python -B iteration_25/code/analyse_ablation.py --output-dir iteration_25/results/analysis/reproduction_01
```

Reproduce added metadata tables and the figure into a new directory:

```powershell
python -B iteration_25/completion/code/summarize_completed.py --output-dir iteration_25/completion/reproduction_01
```

Do not use --resume to analyze this sealed completed run. The comparison is exploratory and conditioned on the selected histories and supplied law.
