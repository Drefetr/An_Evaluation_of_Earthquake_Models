# C completion interpretation review

**Accepted: the completed pilot shows stronger level-only than trend-only statistic contraction on the four selected alternative-generated paths.** Both quadrature orders give D_KK>D_trend>D_level>D_BG on each of those paths. This is a finite-path result on a purposive set, not a calibrated power ordering or a causal decomposition.

All ten cases completed:20new method-history pairs and20reused benchmark pairs. C independently reaggregated all80procedure rows,20interaction rows and80signed enclosure rows, checked all80coordinate/estimated-bound rows, and matched selected raw points and control values for new_r100,new_r076,null_0841andnull_1292. The 402 passed assertions are metadata/arithmetic checks, not independent statistical experiments. No history likelihood, fit, GPU call, simulation, calibration, rank, p-value or power calculation was performed by C. A separately reviewed complete raw numerical/provenance metadata; D reviewed resources/preservation. Their sealed reviews are pinned separately.

The frozen BG-witness priority was evaluated first. Every signed BG-minus-intermediate phase gap at both orders is negative; the largest is -2.7267200e-5. No numerical-scale or material better-than-BG witness was found. This supports the recorded phasewise ordering of these finite candidates and does not establish a global envelope. No benchmark repair or extra search follows automatically.

The following are fresh CPU32 direct twice-log-likelihood statistics. They are not detections.

| Selected alternative | D_KK | D_trend | D_level | D_BG | I |
|---|---:|---:|---:|---:|---:|
| new_r000 | 59.033 | 48.592 | 11.348 | 2.442 | 1.534 |
| new_r076 | 292.139 | 237.221 | 124.343 | 26.776 | -42.650 |
| new_r100 | 460.765 | 402.106 | 103.994 | 25.037 | -20.299 |
| new_r140 | 61.789 | 57.065 | 6.427 | 4.363 | 2.660 |

Level-only contractions on these four paths are47.685,167.796,356.770and55.362, versus10.441,54.918,58.659and4.724 for trend-only. For level-only, null NLL gains are24.174929,84.028292,178.494848and27.723220; alternative gains are.332533,.130494,.109622and.042060. Thus the null receives substantially more fitted-likelihood improvement than the inhibited alternative. The recorded direct-minus-subtraction corrections reconcile that phase accounting with the direct statistic.

At supplied trend, the level-only null chooses a=-4.5974,-5.1854,-6.1153and-4.6301, all below supplied a0=-4.1621. The fitted no-inhibition model can lower its background component to accommodate some of the activity reduction that otherwise favors inhibition when the level is supplied. This is consistent with background-level overlap in these conditional fits. All four procedures retain positive alternative eta on the four alternative-generated paths, so the contraction is distinct from forcing the eta estimate to zero. It is not a measurement of physical loading or proof of a unique causal explanation.

The interaction I=D_BG-D_level-D_trend+D_KK has both signs: +1.534,-42.650,-20.299,+2.660. The joint contraction is therefore sometimes above and sometimes below the sum of the two intermediate contractions. Neither ratios of contractions nor this interaction are additive shares of power loss, attributable fractions or ensemble information.

The six null paths also show heterogeneous signs. Level-only increases null_0841 from2.551to4.859; trend-only increases null_1292 from.685to2.377 and null_1345 from1.310to1.510. The smaller level-only increase on null_1107 is.0101, below the frozen .1statistic screen. On null_0000 the intermediate statistics remain0while BG becomes.262; null_1166 has0for all four. Parameter-space nesting constrains ideal phasewise minima, not their likelihood-ratio differences. These null reversals are a direct reason to require each changed procedure's own calibration.

The maximum table direct-statistic difference between orders is1.1368683772161603e-13; common marked-NLL offsets agree within4.547473508864641e-13. These are saved-arithmetic consistency checks, not independent integration. The saved summary/A review record157successful solver records,50Powell starts,240value controls and220eta-profile points; maximum value discrepancy is2.91e-11. Selected-pointCPU32 controls share pinned history geometry withCUDA16. The sampled curves and finite successful searches provide no universal quadrature bound or global-optimum certificate.

All newly fitted a/dcoordinates are interior under the1e-7proximity screen. The saved BG new_r100 benchmark still uses d=-2for the null and d=+2for the alternative, so that joint comparison remains conditional on the prescribed trend box. Fixed null eta=0is not counted as an estimated-bound event; estimated eta=0alternative endpoints on some null histories remain in the record. C's selected raw checks preserve old24benchmark coordinates and their saved-value reproduction convention.

The prior2149-history study retains its own999reference nulls,1000held-out nulls and150alternatives, with earlier150/150known/eta-only versus68/150background-estimated detections and their original qualifications. The historical57/150fuller-nuisance result is a separate procedure. No such counts were recomputed or decomposed here, and no old cutoff was applied to the intermediate statistics. Four selected matching orderings do not estimate a population detection rate.

**Single next bounded question: does level_only lose calibrated detection after its own matched null reference and held-out checks?** If separately authorized, prepare a resource-capped fixed-cohort protocol using the existing reference/check/alternative catalogue roles, fitting the exact prospective level-only procedure on its own null bank and deriving its own calibration. The pilot cannot answer that question because its null distribution also changed. No new calibration protocol, bank fit, trend/full expansion or scientific launch is authorized by this review or unused budget.

The model remains the supplied-trigger/beta/productivity, finite195-mode specified-background diagnostic with full marked likelihood, predictable histories and full compensators. It does not reconstruct the original physical loading model, identify an empirical NZ mechanism, discriminate kernels, or prove intrinsic information loss/infinite-memory results. Mark transforms remain in the declared infinite-second-moment regime; no Fisher/Wilks approximation is introduced.

The sealed JSON pins the frozen contract/config/plan, original80/20/80tables, coordinate/completion sources and tables, peer reviews, runtime source map and selectively checked raw cases. All prepared sealed authorities remain read-only. Root report/replacement interpretation was reviewed consistently with these findings. The measured/charged durations and operational closure allowance remain D's resource evidence; no exact latency guarantee is added here.

