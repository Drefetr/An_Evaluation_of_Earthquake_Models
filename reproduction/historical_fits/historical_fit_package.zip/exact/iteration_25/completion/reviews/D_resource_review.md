# D resource and provenance completion review

**GO for the recorded iteration 25 pilot's operational resource and provenance completion.** This review read existing artifacts, checked byte/seal bindings and queried a recorded process identity. It performed no fit, history scoring, likelihood evaluation or GPU initialization. It is not a separate mathematical or independent likelihood validation; those remain the scope of the A/C reviews.

The sealed review is `completion/reviews/D_resource_review.json`, SHA256 `7042b5a248feec0d9aeb5c5405bdf8459f1ed6e6fdf8c725b8bc6cfd8d88a880`. Its new operational audit script is `completion/code/D_resource_review.py`, SHA256 `a7ec0434d6adc692bdc0767a18564b943760a969e0c0f7b4590b5dded29779d1`. The original preparation/status documents, source freezes, plan, cases, sessions and earlier deliveries were not edited; completion evidence was added only under `iteration_25/completion`.

The frozen plan ID remains `8c540680db593213dbbe0ea4a2867c15871bb2870a0de4a193d9f391cf3695d9`. All ten planned histories have exactly one recorded started attempt and one matching finished attempt, bound to the single recorded session. Every finished record identifies the current completed case bytes. All 180 partial records have valid seals and matching plan/history/attempt identities and belong to those ten attempts. There are no additional or orphan recorded partial-attempt directories, terminal failures, censored cases, unknown IDs or fatal ledger in this audit tree. This does not assert an absence of unrecorded machine-wide work.

The session is closed with reason `complete`, worker exit code zero, no active case/attempt and no recorded parent/worker error. The pinned process lifetime helper returned no live process matching PID **25928**, creation token **134366920381383280**. Every recorded case wall duration and independently its parent attempt-start to case-commit interval is below its declared cap: 900 seconds ordinarily and 1800 seconds for `null_1292`. The longest case was `null_1292`: 228.296383 seconds recorded case wall and 228.313028 seconds by that timestamp interval.

| Resource item | Seconds |
|---|---:|
| Measured parent invocation wall | 559.2408398999833 |
| Explicit final-write operational allowance | 1 |
| Charged parent wall | **560.2408398999833** |
| New pilot policy cap | 7200 |
| Nominal unused policy allowance | **6639.759160100017** |
| Sum of recorded case wall durations | 538.9009351001587 |

The parent measurement covers invocation before preflight through owned-worker cleanup and final payload adoption. The final ledger/summary writes receive the explicit one-second operational reservation, which is neither measured latency nor a proved upper bound on durable storage or scheduling latency. The case-wall sum has a narrower scope and is not a substitute for the parent total. These numbers are **wall accounting, not GPU-seconds**. The maximum recorded Torch allocation was 169,438,720 bytes, below the 1 GiB allocation guard; this is not total GPU memory or process RSS. All recorded cases retain FP64, disabled TF32, disabled mixed precision and no requested fast math.

Actual recorded totals:

| Item | Count |
|---|---:|
| Completed histories | 10 |
| New constrained method/history pairs | 20 |
| Reused benchmark method/history pairs | 20 |
| Successful solver records | 157 |
| Powell starts | 50 |
| Scalar solver records | 107 |
| Original-backend CUDA16 point controls | 160 |
| Fresh CPU32 selected-point controls | 80 |
| Mandatory eta-profile points | 220 |
| Common-backend identity rows | 60 |
| Interaction identity rows | 20 |
| Direct contrasts across four procedures/two orders | 80 |
| Durable partial records | 180 |
| Failed or censored cases | 0 |

The saved payloads record complete methods, successful mandated solvers and passed point controls. Operational coordinate checks confirm `level_only` retains supplied d, `trend_only` retains supplied a, both retain the supplied n/trigger/productivity ratio, nulls use eta0, and recorded full marked NLL equals ground NLL plus the common recorded mark constant. The saved explicit clock agrees with each planned history, including the paired-clock history. This checks recorded model/provenance consistency without re-evaluating real-history likelihoods.

All **16 live runtime sources and their archived source snapshots** match the frozen plan. All **44 unique pinned history input artifacts** and **10 reused iteration 24 benchmark cases** match their declared hashes; canonical benchmark bindings inside new payloads also match the saved benchmark records. The existing runtime source freeze, A/C review snapshots and validation snapshots pass the runner's read-only guard.

Commands actually run:

```powershell
python -B iteration_25/code/verify_preparation.py
python -B iteration_24/completion/code/verify_completion.py
python -B iteration_25/completion/code/D_resource_review.py
python -B iteration_25/completion/code/D_check_completion_summary.py
```

The preparation verifier passed **52 preparation artifacts and 659 preserved prior paths**. The iteration 24 completion verifier passed **265 completion artifacts and 70 original handoff artifacts**. No wider historical rerun, fit or scoring rescan was performed.

The frozen analyser output at `results/analysis/completed_pilot_01` is bound to the same ten current case hashes and analyser source. It reports ten planned/complete histories, no failure/unknown IDs and the expected **80 procedure comparison rows, 20 interaction rows and 80 enclosure rows**. This review checked those table sizes and source/status bindings; interpretation of numerical effects remains outside the D operational scope.

The coordinator's later `completion/results/summary.json` was independently cross-checked against the sealed D review without rewriting it. All eight resource fields, ten case-summary hash/clock/status/time/solver rows, aggregate solver/control/profile counts, 40 total procedure/history pairs and the empty failure ledger matched. Separate sealed supporting evidence is `completion/logs/D_aggregation_crosscheck.json`, SHA256 `000ee91d61c239780b42384b23710793b6c49e854731fb1a0c05baadd309d9bf`.

Supporting aggregation pins:

* `completion/results/summary.json`: `4ef85fa659fa6a5a45feb55f63d538fe43e58868aafa5e7ead838113dd632177`.
* `completion/results/case_summary.csv`: `0810f81dd601ea46e0fbb3b802cef89352a601cda69cf21ebf8ed896534a1122`.
* `completion/code/summarize_completed.py`: `ca940cf2bc64b61891867ebd0e47a2a8cd3be6d2efc6a889b4926585d363d1fa`.
* `completion/code/D_check_completion_summary.py`: `6fe4c380c583ae498b9b572dba9e88ab2f9fef4139e64333cda90e580ed62bfc`.

The unused nominal allowance does not authorize another pilot, benchmark repair, new calibration, simulation or power campaign. Earlier failures and prior studies retain their original records and scope.
