# Completed background ablation pilot

All ten cases completed. On all four selected alternative-generated histories, estimating background level alone contracted the statistic more than estimating trend alone; allowing both contracted it further. Effects were non-additive and some null histories showed increases. This is a fixed-ten descriptive result, not a new power estimate or empirical earthquake mechanism claim.

- `reports/research_report.md`: actual comparison, interpretation, qualifications and reproduction commands.
- `results/alternative_statistics.png` and `.svg`: visually inspected scientific figure.
- `results/selected_coordinates.csv`: all selected coordinates and estimated-parameter bound flags.
- `reviews/`: actual A numerical, C interpretation and D resource/provenance completion reviews.
- `manuscript/`: targeted new LaTeX fragment and editorial map; no original thesis reconstructed.

The frozen analysis retains every case, signed statistic, non-additive interaction and BG phase gap in `iteration_25/results/analysis/completed_pilot_01/`. No BG-improvement witness was found; no benchmark was repaired.

Read-only final verification:

```powershell
python -B iteration_25/completion/code/verify_completion.py
```

The original prepared README/STATUS remain the immutable launch checkpoint. This directory supplies the completion status. No further fit, calibration, bootstrap, catalogue or simulation is running or scheduled by this work.
