# Finite-reference-path score geometry at zero inhibition

The bounded CPU analysis completed with exit0 in **34.375 seconds parent wall time and33.531 CPU seconds**, using one native thread. It read only the two previously frozen effect-calibration histories (1,100 and2,024 events), their calibration metadata and the prospective protocol. It ran no fitting, new simulation, pilot outcome inspection or power tally. [Machine results](../results/reference_score_geometry.json) and the [standalone script](reference_score_geometry.py) retain inputs, sources, matrices and scalar checks. The child was owned by a Windows kill-on-close Job Object, released only after assignment, with a44-second wall cap and40-second CPU work guard.

## Derivation

Fix the event/mark history and the chosen shared finite-mixture kernel. Let

`B(t)=exp(a+d*x(t))`, `x(t)=2t/T-1`, `lambda_0(t)=B(t)+n*H(t)`,

where H is the unit-productivity trigger history and G is the M6-normalized stress history. The four derivatives of log intensity at eta=0 are

`s_a=B/lambda_0`, `s_d=x*B/lambda_0`, `s_n=H/lambda_0`, `s_eta=-G*B/lambda_0`.

The eta derivative is the right derivative of the declared eta>=0 family; the formulas do not imply that the stress kernel is identified under that null. The full point-process score, when defined, also subtracts its compensator derivative. Here the computed object is simply the finite-path weighted Gram matrix

`J_ij = integral_0^T lambda_0(t)*s_i(t)*s_j(t) dt`.

It is positive semidefinite because `v'Jv=integral lambda_0*(v's)^2>=0`. This algebraic statement does not require an ensemble expectation or finite population Fisher information. Calling this realized path functional a conditional Fisher-information matrix would require additional probability statements that are not established here.

Write its(a,d,n) block as A and its nuisance/eta cross-vector as c. Both measured A matrices are positive definite. The least-squares projection coefficients are `b=A^-1*c`, and

`J_eta_residual = J_eta_eta-c'*A^-1*c`

`= min_b integral lambda_0*(s_eta-b_a*s_a-b_d*s_d-b_n*s_n)^2 dt`.

This follows by expanding the square and solving its normal equations. If, on a path, `G=c0+c1*x+c2*H/B`, then `s_eta=-c0*s_a-c1*s_d-c2*s_n` and the residual is exactly zero. Nearly constant or nearly trend-like stress can therefore resemble changes in immigrant intercept/trend; its relationship to triggering can add branching confounding. A sizeable fixed-history intensity suppression need not translate into a comparably distinct fitted alternative after nuisance adjustment.

Only a,d,n are projected out. Mark-law estimation, productivity-ratio search, alpha, time scales and the unidentified-at-null stress-kernel search are omitted. Adding directions cannot increase this residual squared norm for the same fixed-path inner product. That is a projection fact, not a bound on the power of the searched likelihood-ratio test. Absolute numbers depend on the eta parameterization and are not information about a physical causal count effect.

## Actual quadrature controls

The true generating values were kept fixed: a=-4.162108473051707,d=.23211265877958467,n=.5017751599706763,beta=2.849401764894274,productivity ratio=.7. Trigger and selected stress shape are the original alpha=.5,tau1day finite positive mixture. The long path uses x=2t/73182-1. Both paths have strictly increasing projected times; the analysis uses the original projected-lag scoring convention. No infinite-memory/exact-ML assertion is made.

| Fixed reference | Tdays | Events | Order32nodes | Raw eta squared norm | Residual after(a,d,n) | Residual/raw |
|---|---:|---:|---:|---:|---:|---:|
|reference_h1|24,394|1,100|857,824|3167.725339|342.788748|.108212901|
|reference_h3|73,182|2,024|1,796,480|6978.095201|227.800341|.032645061|

Thus approximately89.18% and96.74% of the respective squared norms lie in this three-dimensional nuisance span. The two paths differ in their random histories and calibration functions. Their ordering does **not** demonstrate that more exposure decreases expected information, expected detection, or the power of a fixed observable-effect contrast. In particular the actual power design recalibrates eta separately at the two horizons. These finite-path numbers do not estimate ensemble means or a sample-size requirement.

Order16 used428,912 and898,240 nodes. Moving to order32 changed the largest matrix entry by at most.041681 and.057122, respectively; maximum changes scaled entrywise by `max(1,abs(order32entry))` were1.632e-5 and1.765e-5. Residual squared norms changed by.000223505 and.000140995 (about6.52e-7 and6.19e-7 relative). This is a two-order numerical comparison for this functional and these paths, not a uniform error bound or a substitute for any likelihood-validation gate.

At three scalar queries per path, separate literal sums over all prior events matched modal histories to the declared2e-12 relative/absolute smoke tolerance. Central differences for a,d,n and a one-sided second-order eta difference matched the four analytic log-intensity directions; maximum absolute error normalized by `1+abs(analytic)` was1.251e-10, below the predeclared5e-5 smoke tolerance. The Gram accumulation reuses one finite-mode decay per quadrature chunk for H and G. No gradient clipping, nuisance fitting or mark truncation was used.

The path-null compensators were1095.446538 and2139.919248; the background integrals were383.349581 and1150.048742. A compensator on a realized fixed path is not an expected event count. These figures do not turn the reference histories into count-matched samples.

## Provenance and limits

Short input NPZ SHA256: `7ffce85b812af813708f95d6547353c2fb3df67e27d02a433c44d354d20f09ef`; long: `a6477b01e1cbbfdec16271f182385df1ceec26b9324ceb82f33adb0ed4076165`. Both matched their frozen calibration hashes. Scientific source files were imported read-only with bytecode writing disabled. No core iteration13 source or preceding bank was changed.

Script SHA256: `d378749762a42b3799638f6e59915791ef2780c565e79faca7fbe787b47344f9`. Result SHA256: `47617028548309041c403cbe7d1a0c7cf13ac28ef4a493665437fa757ed9a55b`. Reproduction command: `python -B iteration_13/reports/reference_score_geometry.py`; it refuses to overwrite the existing result. A deliberate new experiment needs a new output authority.

The result is descriptive evidence of finite-path nuisance overlap, obtained before inspecting pilot power outcomes. It does not establish finite expected information, regular local asymptotics, universal identifiability, an optimal test, reliable general power, or a physical stress mechanism.
