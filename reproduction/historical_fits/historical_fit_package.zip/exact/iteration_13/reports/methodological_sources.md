# Methodological references and retrieval scope

Retrieved/checked on 16 October 2026 through public search and publisher/author records. No claim of novelty follows from this limited methods check.

1. Morris TP, White IR, Crowther MJ. *Using simulation studies to evaluate statistical methods*. Statistics in Medicine. 2019;38(11):2074--2102. DOI [10.1002/sim.8086](https://doi.org/10.1002/sim.8086). The structured aims, generating mechanisms, estimands, methods and performance measures in Section 3, and Monte Carlo precision reporting in Section 5.2, motivate the protocol and result tables. Publisher metadata and public indexed text were available. A direct PMC open returned a browser-verification page; no local full-text snapshot is claimed.

2. Phipson B, Smyth GK. *Permutation P-values should never be zero: calculating exact P-values when permutations are randomly drawn*. Statistical Applications in Genetics and Molecular Biology. 2010;9:Article 39. DOI [10.2202/1544-6115.1585](https://doi.org/10.2202/1544-6115.1585); [PubMed record](https://pubmed.ncbi.nlm.nih.gov/21044043/). Bibliographic metadata and abstract were checked. Its discrete Monte Carlo/permutation setting must not be used to assert exactness of a fitted-nuisance parametric bootstrap. The exchangeability argument in `assumptions_and_estimands.md` is stated only for a known null law.

No ordinary likelihood-ratio chi-square law is imported from either source. Exact binomial intervals in reports quantify outer simulation uncertainty conditional on the setting and frozen reference threshold; they do not incorporate model uncertainty or certify power for the real catalogue.
