# Restricted finite-horizon inhibition-score bound

**The proposed bound is valid under the assumptions stated below.** In the pilot's positive-excitation regime it proves a finite second moment for the specified fixed-kernel inhibition score, despite an infinite raw second stress-mark moment. It does not prove regular likelihood-ratio asymptotics, finite information in every searched nuisance direction, or a power/sample-size theorem. This proof was reviewed without reading pilot power outcomes and involves no additional fit or simulation.

## Assumptions and notation

On a finite window[0,T], with empty initial history, write

`lambda(t)=b_eta(t)+n*H(t)`, `b_eta(t)=B(t)*exp(-eta*G(t))`,

`G(t)=sum_(t_i<t) g_i*phi_s(t-t_i)`,

`H(t)=sum_(t_i<t) kappa_i*h_e(t-t_i)`.

Assume eta>=0,n>0,0<B(t)<=Bmax<infinity, strictly positive kappa_i and h_e(u) for0<=u<=T, and nonnegative g_i,phi_s. The same event/mark parents must supply both histories. Marks are drawn independently from a fixed common law only after their event is accepted, so the inclusion event{t_i<=T} is determined before the fresh mark_i. Assume E[N(T)]<infinity and

`C_T=integral_0^T phi_s(u)^2/h_e(u) du < infinity`,

`m=E[g(Q)^2/kappa(Q)] < infinity`.

Here kappa is the **unit** trigger amplitude: n is outside H. If kappa instead included n, its moment and the displayed prefactor would have to be changed consistently. In the actual source, `kappa=(1-r)*exp(r*beta*Q)` and `g=exp(gamma*(Q-1))`, where gamma=.75log(10). The rate mixture's derivative h_e is normalized to integrate to1. Stress and triggering may have different positive kernels; they need not have the same time scale.

Finite strictly positive exponential mixtures satisfy the C_T condition: h_e is continuous and strictly positive on the compact interval[0,T], while phi_s is bounded. This guarantees finiteness, not a useful uniform numerical bound as T or the kernel parameters vary. For an exact/singular kernel, positivity and the stated integrability condition must be established separately; they do not follow from a finite-mixture label.

The expectation-of-count assumption is satisfied in this project's empty-history, normalized, subcritical regime0<n<1 with E[kappa]=1. Localizing at the first M events, the expected compensator is bounded by `integral B+n*E[N_M(T)]`, because each parent's integrated trigger kernel over the remaining window is at most1 and its fresh amplitude has mean1. Thus `E[N_M(T)]<=integral B/(1-n)` uniformly in M. Monotone convergence gives finite E[N(T)] and rules out a finite-window infinite event count. This is a count bound; it is not an equality for the empty-history finite window.

## Pathwise inequality

When H(t)>0, apply weighted Cauchy-Schwarz with weights kappa_i*h_e(t-t_i):

`G(t)^2 <= H(t) * sum_(t_i<t) [g_i^2/kappa_i] * phi_s(t-t_i)^2/h_e(t-t_i)`.

When H=0, positivity means there are no preceding parents and G=0; define0/0=0 for this inequality. Since lambda>=nH and b_eta<=Bmax,

`(G*b_eta)^2/lambda`

`<= (Bmax^2/n) * sum_(t_i<t) [g_i^2/kappa_i] * phi_s(t-t_i)^2/h_e(t-t_i)`.

Nonnegative integration and Tonelli then give, pathwise,

`integral_0^T (G*b_eta)^2/lambda dt`

`<= (Bmax^2/n) * sum_(t_i<T) [g_i^2/kappa_i] * C_(T-t_i)`

`<= (Bmax^2/n) * C_T * sum_(t_i<T) g_i^2/kappa_i`.

For a fresh mark, E[1{t_i<T}*g_i^2/kappa_i]=P(t_i<T)*m. Summing this nonnegative equality yields

`E[sum_(t_i<T) g_i^2/kappa_i] = E[N(T)] * m`.

This is predictable fresh-mark factorization. It does **not** assume that N(T) is independent of the marks: an accepted mark changes subsequent triggering/inhibition and therefore the future count. Consequently,

`E[integral_0^T (G*b_eta)^2/lambda dt]`

`<= (Bmax^2/n) * C_T * E[N(T)] * E[g^2/kappa] < infinity`.

With fixed B,n,marks and kernels, the eta-direction log-intensity derivative is `s_eta=-G*b_eta/lambda`. Its compensated score is

`U_eta(T)=integral_0^T s_eta(t)*(dN(t)-lambda(t)dt)`.

The preceding bound gives its finite expected predictable quadratic variation and hence an L2 martingale with `E[U_eta(T)^2]=E[integral s_eta^2*lambda dt]`. At eta=0 this is the right score for the declared boundary family. Pathwise likelihood differentiation is legitimate on each finite path under these bounded finite-mode assumptions. This establishes the restricted score's second moment, without asserting quadratic-mean differentiability of the full searched/unidentified model.

## Exact exponential-mark threshold

For Q~Exp(beta),0<=r<1,

`g^2/kappa = exp(-2gamma)/(1-r) * exp((2gamma-r*beta)*Q)`.

Therefore

`E[g^2/kappa] = exp(-2gamma)*beta / ((1-r)*((1+r)*beta-2gamma))`

if `(1+r)*beta>2gamma`; it is infinite when that inequality fails, including equality. For the pilot beta=2.849401764894274 and r=.7, the denominator gap is1.3901053608291964 and the moment is **.21606514632806195**. Its threshold beta>2.0316927291123936 is met, whereas raw E[g^2] is infinite because beta<2gamma=3.453877639491069. Raw trigger-amplitude variance is also infinite at r=.7. Those raw facts therefore do not establish infinite variance of this intensity-weighted eta score.

The bound is not uniform as n decreases to0, as r approaches1, as the weighted-moment gap approaches0, or as the kernel ratio integral C_T grows. No population estimate of C_T or general finite-information claim is made by the separate two-path geometry calculation.

## Boundary counterexample and positive-inhibition regularization

At n=0,eta=0, the ground process is an NHPP with positive deterministic B. Suppose gamma<beta<=2gamma, so E[g]<infinity but E[g^2]=infinity, and phi_s is positive. On the positive-probability event that exactly one point occurs at S<T, the event score contribution is zero (empty history before that point) and

`U_eta(T)=g * integral_S^T B(t)*phi_s(t-S) dt`.

The fresh mark is independent of this NHPP event/time configuration. On any interior set of S with positive probability, the integral is strictly positive, and this term has infinite second moment. Thus the eta=0 score is not L2. Equivalently, E[G(t)^2] is infinite after a positive immigration exposure, so the expected bracket `E[integral B*G^2]` is infinite. The finite first stress moment ensures the compensated score is still integrable in this example; there is no claim that it has a finite variance.

At any fixed eta>0 there is a simpler regularizing inequality, even for n=0:

`(G*b_eta)^2/lambda <= G^2*b_eta = B*G^2*exp(-eta*G)`

`<= 4*B/(e^2*eta^2)`.

The last bound is the maximum of z^2exp(-eta*z) for z>=0. For integrable B this gives a finite expected eta-score bracket without a raw E[g^2] assumption, provided the process/history is well defined. It is not uniform as eta decreases to0. This distinguishes positive-inhibition damping from the boundary at which inhibition is being tested.

## Scope

The argument requires matched positive trigger/stress parents and a fresh mark law; unmatched exogenous stress or random prehistory needs an additional term and its own moment assumptions. It proves a finite-horizon L2 result for this one fixed-kernel direction at positive n (or positive eta via the simpler bound). It does not establish all kernel/mark/ratio score moments, stationarity, a central limit theorem, a regular Fisher-information matrix for the searched model, a Wilks law at eta=0, uniform validity near n=0, or the power of the plug-in calibration. The unspecified stress kernel remains unidentified under no inhibition, and the numerical search/boundary distribution still requires its declared calibration and acceptance gates.
