# Prospective power-study design

The initial study compares5%,10% and20% event-time fixed-history total-intensity suppression at two horizons:24394 and73182 days. These are six matched observable-effect settings. The pilot targets25 independent outer replications per setting, with a common reduction determined only from three independent timing benchmarks. All seeds, targets, allocation rules and limits are specified in `configs/power_protocol.json` before power-fit outcomes. A500-replication configuration is prospective and is not launched automatically.

The bounded initial study estimates **pointwise known-DGP screening power**, conditional on specified reference calibration banks. It does not estimate the power of the full sample-specific plug-in bootstrap procedure. Two predetermined nested-bootstrap audits can run if the frozen cost rule makes them affordable; those two audits test the procedure's execution and compare decisions, rather than estimate full-pipeline power. If they are not run, that remains explicit.

## Generating laws and the sample-size question

All six settings use the original fitted no-inhibition law as their uninhibited reference: beta2.849401764894274, productivity ratio.7, n0.5017751599706763, background `exp(a+d*(2t/T-1))` with a−4.162108473051707 and d0.23211265877958467, and the same normalized finite ML mixture with alpha.5 and tau1day. Inhibition shares that trigger kernel. Each simulation starts with empty history and draws fresh marks; actual counts remain random. Parameters are not adjusted to force a realized count or resampled until a desired count occurs.

This is the **current-catalogue fitted-law horizon**, not an experiment guaranteed to contain913 events. Its expected immigrant count is383.3495808034536, and its long-run nominal total-count upper bound is769.4308874300428. The empty-history finite-window expectation is at most that bound. The corresponding3T upper bound is2308.292662290128. Actual simulated counts and their distribution must accompany power summaries.

Day-scale kernel times are held fixed when exposure increases. The normalized deterministic trend coefficient d is also held fixed, so its physical daily slope is one third as large at3T. Eta is calibrated separately for each target and horizon. Therefore these compare matched reference observable effects and exposure; they are not a forecast obtained by observing one unchanged physical system for three times as long. Background fraction, different stress scales, finite-variance controls, off-grid background laws and missing-history sensitivity remain prospective followups, not additional executed power dimensions in this six-setting pilot.

## What5%,10% and20% mean

An independent fixed-seed uninhibited reference history is generated for each horizon. With its entire event/mark history held fixed, define

`F(eta)=mean_i[pB0_i*(1-exp(-eta*G_i))]`, where `pB0=B/(B+nH)`.

This is the mean event-time fractional reduction in total conditional intensity when inhibition is switched on without changing that history or its other parameters. It is not a causal reduction in the number of earthquakes or the mean count of a coupled process. The effect is bounded by its history's background fraction and, more precisely, by `mean[pB0*I(G>0)]`; the first event has no prior stress history. The fitting-box ceiling is F(3). An infeasible target must be reported, never clamped to the box edge or obtained by replacing the reference history.

Both reference histories completed under the preregistered seeds. Their sizes were1100 and2024, with mean event-time background fractions.35131357 and.55293055. All targets were feasible below F(3)=.34021272 and.53267901. The pre-fit calibrated etas are:

| Horizon |5%|10%|20%|
|---|---:|---:|---:|
| T |.04886924266|.10858867488|.28399742889|
|3T|.03924921454|.08394931884|.19642640446|

The largest recorded target error is below5.6e-14. Source, specification, NPZ and exact-clock-state hashes are saved under `results/effect_calibration/`. Each outer catalogue must also report the same functional on its own realized history at its true generating parameters, so discrepancies between a reference label and achieved effects remain visible.

## Testing and calibration

Every dataset receives the same full234-record/162-prescribed-start search: common loglinear nuisance background, productivity ratios.4/.7/.8, ML trigger/kernel-scale grid, no Omori search, original numerical tiers followed only on failure by the declared iteration12 recovery. All marks and nuisance parameters are re-estimated. Independent selected CPU32 likelihood checks, finite/nesting gates and complete-search/start-acceptance gates remain mandatory. A finite-mixture numerical law and local optimization do not supply global optimality or exact singular-ML claims.

The primary statistic is twice the separate-scale log-likelihood gain over the no-inhibition fit. The boundary and unidentified stress kernel under zero inhibition preclude an ordinary chi-square/Fisher shortcut. For each outer statistic, use the corrected rank `(1+count[Tnull>=Touter])/(B+1)` and reject at rank<=.05; ties count. There is no interpolated percentile threshold.

The short-horizon generating law is exactly matched to the completed iteration12 null bank, subject to the separate source/DGP/resolved-statistic audit. Primary calibration uses its predetermined first B replications and a new B-draw long-horizon null bank, with B39 preferred and B19 allowed only by the predeclared cost rule. These give ranks on.025 and.05 grids. All1999 short-reference draws provide a separately labelled calibration-resolution sensitivity. Changing B must not depend on a reference threshold or a rejection result. Both banks must be fully accepted before any corresponding detection proportion is reported.

For independent observations and a matched known null, the Monte Carlo rank is marginally superuniform with conservative ties; this does not certify plug-in bootstrap validity over composite nuisance laws. Reusing a fixed reference bank also makes threshold uncertainty common to the outer replications. Binomial Monte Carlo intervals for outer rejection frequency condition on that bank and exclude its calibration uncertainty. The pilot must report this scope. Small outer counts give wide intervals and cannot establish80% power or a universal minimum number of earthquakes.

## Budget, failures and subsequent work

The initial active-work allowance is3600s. Three independent benchmark seeds, excluded from every power denominator, determine conservative short/long costs. Before subsequent outcomes are inspected, a frozen decision selects B39 or B19, a common outer prefix up to25 per setting, and either zero or two preselected B19 nested audits. All benchmark records remain saved. The projected cost formula, reserve and selection priority are in the protocol; no allocation responds to an LR, estimated eta or a preferred rejection rate.

The actual timing-only decision selected **B39 and R8 per setting, with zero nested audits**. The pilot therefore requests39 new long-null references and48 alternatives. It leaves all1999 short-null references available for the declared secondary check; primary comparisons use the fixed first39. The complete allocation and its source hashes were frozen before reference-test or alternative outcomes. `reviews/C_protocol_review.md` records the independent cost-rule check. Full sample-specific plug-in power remains unperformed.

Simulation/fit/validation/resource failures remain attached to their fixed IDs and seeds. A failed null-reference draw withholds that bank's decisions. Unresolved outer draws are not non-rejections or replacement opportunities: the complete rejection-frequency estimate is withheld and any `[rejected/N,(rejected+unresolved)/N]` tally is labelled a finite-cohort computational-missingness bound, not a confidence interval for population power. Resource caps are execution censors, not part of the physical data law.

The heavy baseline has finite first stress/productivity moments but not their raw second moments; even their mixed first-product moment diverges. This neither proves infinite information nor licenses Gaussian information arguments. The future beta4.5/ratio.4 control has finite second moments of both mark amplitudes and their covariance, not necessarily every nonlinear score moment. Limiting fixtures can verify these distinctions and distinguish shared versus unequal stress scales, but do not constitute executed power experiments for those alternatives.

A subsequent full study can increase outer replication, audit size, span background fractions and meaningful scale separation, and calibrate every outer dataset's fitted null when full-procedure power is the target. That requires its own explicit source/seed/resource plan; this pilot does not silently launch it or claim its results.
