"""Read-only completion inventory; hashes establish provenance, not scientific truth."""
from pathlib import Path
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
ROOT = Path(__file__).resolve().parents[2]
AREA = ROOT / "iteration_13"
sys.path.insert(0, str(ROOT / "iteration_6/code"))
from checkpoint_io import read_json, read_sealed, sealed_json, sha256


def main():
    supplied = read_json(ROOT / "SOURCE_MANIFEST.json")
    inputs = []
    for entry in supplied["files"]:
        if entry["path"].startswith("inputs/"):
            path = ROOT / entry["path"]
            actual = sha256(path)
            inputs.append(dict(path=entry["path"], sha256=actual,
                               expected_sha256=entry["sha256"], passed=actual == entry["sha256"]))
    assert len(inputs) == 7 and all(row["passed"] for row in inputs)
    summary_path = AREA / "results/analysis/2026-10-16T071947262917_0000/summary.json"
    summary = read_sealed(summary_path)
    assert summary["all_planned_validated"] and summary["validated"] == 87
    calibration_path = AREA / "results/achieved_effect_calibration/20261016T073220937353Z/summary.json"
    calibration = read_sealed(calibration_path)
    assert calibration["all_metrics_complete"] and calibration["completed_metrics"] == 144
    assert calibration["execution"]["exitcode"] == 0
    target = AREA / "results/completion_manifest.json"
    files = []
    for path in sorted(AREA.rglob("*")):
        if not path.is_file() or path == target or "__pycache__" in path.parts:
            continue
        if path.suffix in (".pyc", ".lock", ".tmp"):
            continue
        files.append(dict(path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                          sha256=sha256(path)))
    sealed_json(target, dict(created_utc=datetime.now(timezone.utc).isoformat(),
        scope="Final iteration-13 file inventory and original-input equality; not proof certification",
        original_inputs=inputs, original_inputs_unchanged=True,
        authoritative_analysis=summary_path.relative_to(ROOT).as_posix(),
        validated_new_primary_cases=87,
        separate_achieved_effect_summary=calibration_path.relative_to(ROOT).as_posix(),
        completed_simulation_only_supplement=144,
        files=files, file_count=len(files),
        exclusions=["this manifest itself", "__pycache__", "pyc/lock/tmp files"]))
    print(f"Recorded {len(files)} files; all seven supplied inputs unchanged; 87 new primary cases and 144 separate simulation-only metrics complete.")


if __name__ == "__main__":
    main()
