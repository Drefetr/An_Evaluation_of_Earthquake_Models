"""Bounded finite-reference-path geometry; no fit, simulation or pilot reads."""
import sys,os
sys.dont_write_bytecode=True
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
from pathlib import Path
import argparse,hashlib,json,math,subprocess,time,traceback
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'iteration_6/code'))
from checkpoint_io import ChildJob,atomic_json
OUTPUT=ROOT/'iteration_13/results/reference_score_geometry.json'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def utc():return datetime.now(timezone.utc).isoformat()

def worker():
    if sys.stdin.buffer.read(1)!=b'1':return 4
    started=time.perf_counter();cpu=time.process_time()
    result=dict(started_utc=utc(),complete=False,orders=[],sources={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in
        (Path(__file__),ROOT/'iteration_5/code/empirical_process.py',ROOT/'iteration_5/code/kernels.py',ROOT/'iteration_6/code/checkpoint_io.py')},
        scope='Descriptive Gram integral on two fixed reference paths at eta0; no expected Fisher, fitting, power or pilot outcomes',
        nuisance_span=['a','d','n'],omitted_nuisances=['beta/mark-law estimation','kernel family/alpha/time scale','productivity ratio'],
        numerical_clock='Original projected-time history; both reference paths have strictly increasing projected times')
    def save():atomic_json(OUTPUT,result,False)
    def guard():
        if time.process_time()-cpu>40:raise TimeoutError('40-second CPU work limit')
    try:
        import numpy as np
        sys.path.insert(0,str(ROOT/'iteration_5/code'))
        from empirical_process import EmpiricalHistory,event_states,unit_productivity,GAMMA,G6
        from kernels import KernelSpec
        protocol_path=ROOT/'iteration_13/configs/power_protocol.json'
        calibration_path=ROOT/'iteration_13/results/effect_calibration/calibration.json'
        protocol=json.loads(protocol_path.read_text(encoding='utf-8'));calibration=json.loads(calibration_path.read_text(encoding='utf-8'))
        fit=protocol['base_null_fit'];a,d,n=fit['pars'];beta=protocol['beta'];kernel=KernelSpec(**fit['trigger']);w,r=kernel.mixture
        result.update(protocol_sha256=sha(protocol_path),calibration_sha256=sha(calibration_path),generating_pars=dict(a=a,d=d,n=n,beta=beta,ratio=fit['ratio']),
                      stress_kernel=dict(fit['trigger']),input_paths=[])
        for reference in calibration['references']:
            path=calibration_path.parent/reference['catalogue_file']
            if sha(path)!=reference['catalogue_sha256']:raise ValueError('Reference input changed')
            with np.load(path,allow_pickle=False) as archive:times=archive['times'].copy();marks=archive['excess'].copy()
            if np.any(np.diff(times)<=0) or reference['coarse_tie_count']!=0:raise ValueError('This profile requires original no-tie histories')
            T=reference['horizon'];K=unit_productivity(marks,beta,fit['ratio']);g=np.exp(GAMMA*marks)/G6
            preK=event_states(times,K,kernel);preG=event_states(times,g,kernel)
            postK=np.vstack([np.zeros(len(r)),preK+K[:,None]]);postG=np.vstack([np.zeros(len(r)),preG+g[:,None]])
            result['input_paths'].append(dict(id=reference['id'],path=str(path.relative_to(ROOT)).replace('\\','/'),sha256=sha(path),n_events=len(times),horizon=T))
            # Independent literal histories and numerical log-intensity slopes
            # at only three scalar queries. Eta is one-sided at its boundary.
            controls=[]
            for query in (T*.1,T*.5,T*.9):
                keep=times<query;lag=query-times[keep]
                H=float(np.dot(K[keep],kernel.h(lag)));G=float(np.dot(g[keep],kernel.phi(lag)))
                j=int(np.searchsorted(times,query,side='left'));left=0. if j==0 else times[j-1]
                decay=np.exp(-r*(query-left));modalH=float((postK[j]*decay)@(w*r));modalG=float((postG[j]*decay)@w)
                if not np.allclose([modalH,modalG],[H,G],rtol=2e-12,atol=2e-12):raise ValueError('Literal/modal scalar history mismatch')
                x=2*query/T-1;B=math.exp(a+d*x);lam=B+n*H
                analytic=np.array([B/lam,x*B/lam,H/lam,-G*B/lam])
                pars=np.array([a,d,n,0.]);finite=[]
                def loglam(p):return float(np.logaddexp(p[0]+p[1]*x-p[3]*G,math.log(p[2]*H) if p[2]*H>0 else -np.inf))
                for k in range(4):
                    step=1e-5/(max(1.,G) if k==3 else 1.)
                    one=pars.copy();one[k]+=step
                    if k==3:
                        two=pars.copy();two[k]+=2*step
                        estimate=(-3*loglam(pars)+4*loglam(one)-loglam(two))/(2*step)
                    else:
                        minus=pars.copy();minus[k]-=step;estimate=(loglam(one)-loglam(minus))/(2*step)
                    finite.append(estimate)
                normalized=float(np.max(np.abs(np.asarray(finite)-analytic)/(1+np.abs(analytic))))
                if normalized>5e-5:raise ValueError('Scalar finite-difference score mismatch')
                controls.append(dict(query=query,H=H,G=G,analytic=analytic.tolist(),finite_difference=finite,max_normalized_error=normalized))
            for order in (16,32):
                guard();began=time.perf_counter()
                h=EmpiricalHistory(times,marks,beta,T,T,order=order,memory_limit_mb=800.)
                J=np.zeros((4,4));compensator=0.;total_background=0.
                for start in range(0,len(h.tq),2048):
                    guard();sl=slice(start,start+2048);indices=h.qindex[sl];decay=np.exp(-h.qlag[sl,None]*r)
                    H=(postK[indices]*decay)@(w*r);G=(postG[indices]*decay)@w
                    x=h.xq[sl];B=np.exp(a+d*x);lam=B+n*H;fraction=B/lam
                    scores=np.column_stack((fraction,x*fraction,H/lam,-G*fraction))
                    weight=h.wq[sl]*lam
                    J+=scores.T@(weight[:,None]*scores);compensator+=float(weight.sum());total_background+=float(np.dot(h.wq[sl],B))
                nuisance=J[:3,:3];cross=J[:3,3];coefficients=np.linalg.solve(nuisance,cross)
                raw=float(J[3,3]);residual=float(raw-cross@coefficients)
                if not np.isfinite(J).all() or residual < -1e-10*max(raw,1.):raise ValueError('Invalid finite-path Gram/projection')
                eig=np.linalg.eigvalsh(nuisance)
                row=dict(reference_id=reference['id'],n_events=len(times),horizon=T,order=order,q_nodes=len(h.tq),
                    gram=J.tolist(),eta_raw_squared_norm=raw,eta_residual_squared_norm=residual,
                    eta_residual_fraction=residual/raw if raw else None,eta_projection_coefficients=coefficients.tolist(),
                    nuisance_eigenvalues=eig.tolist(),nuisance_condition_number=float(eig[-1]/eig[0]),
                    path_null_compensator=compensator,path_background_integral=total_background,
                    scalar_controls=controls,elapsed_seconds=time.perf_counter()-began,cumulative_cpu_seconds=time.process_time()-cpu)
                result['orders'].append(row);del h;save()
        comparisons=[]
        for name in [r['id'] for r in calibration['references']]:
            coarse,fine=[x for x in result['orders'] if x['reference_id']==name]
            first=np.array(coarse['gram']);second=np.array(fine['gram'])
            comparisons.append(dict(reference_id=name,max_absolute_gram_change=float(np.max(np.abs(first-second))),
                max_scaled_gram_change=float(np.max(np.abs(first-second)/np.maximum(1.,np.abs(second)))),
                residual_squared_norm_change=fine['eta_residual_squared_norm']-coarse['eta_residual_squared_norm']))
        result.update(complete=True,comparisons=comparisons,elapsed_seconds=time.perf_counter()-started,cpu_seconds=time.process_time()-cpu,ended_utc=utc());save();return 0
    except BaseException as exc:
        result.update(error=type(exc).__name__+': '+str(exc),traceback=traceback.format_exc(),elapsed_seconds=time.perf_counter()-started,cpu_seconds=time.process_time()-cpu,ended_utc=utc());save();return 1

def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');args=p.parse_args()
    if args.worker:return worker()
    if OUTPUT.exists():raise FileExistsError('Exclusive profile output already exists')
    OUTPUT.parent.mkdir(parents=True,exist_ok=True);began=time.perf_counter();job=ChildJob();child=None;timedout=False
    try:
        child=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--worker'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,cwd=ROOT)
        job.assign(child);child.stdin.write(b'1');child.stdin.flush();child.stdin.close();child.stdin=None
        try:stdout,_=child.communicate(timeout=44)
        except subprocess.TimeoutExpired:timedout=True;child.kill();stdout,_=child.communicate(timeout=3)
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=3)
        job.close()
    result=json.loads(OUTPUT.read_text(encoding='utf-8')) if OUTPUT.exists() else {'complete':False,'orders':[]}
    result['execution']=dict(exitcode=child.returncode,timed_out=timedout,parent_wall_seconds=time.perf_counter()-began,
                             hard_child_wall_seconds=44,scientific_cpu_guard_seconds=40,source_sha256=sha(__file__))
    if timedout:result.update(complete=False,parent_cap='44-second owned child wall cap')
    if stdout:result['worker_output']=stdout.decode('utf-8',errors='replace')[-4000:]
    atomic_json(OUTPUT,result,False);print(json.dumps(result['execution']));return 1 if timedout else child.returncode

if __name__=='__main__':raise SystemExit(main())
