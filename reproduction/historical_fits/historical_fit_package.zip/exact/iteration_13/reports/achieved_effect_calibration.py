"""Post-pilot simulation-only mean-of-catalogue-effects calibration.

No fitting, GPU, rejection statistic or primary-pilot outcome reads. The plan,
seed bank, parameters and source snapshots precede every new generation.
"""
import os,sys
sys.dont_write_bytecode=True
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
from pathlib import Path
import argparse,copy,hashlib,importlib.metadata,json,math,subprocess,time,traceback
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2];AREA=ROOT/'iteration_13'
sys.path.insert(0,str(ROOT/'iteration_6/code'))
sys.path.insert(0,str(ROOT/'iteration_12/code'))
sys.path.insert(0,str(ROOT/'iteration_13/code'))
from checkpoint_io import ChildJob,atomic_npz,atomic_json,atomic_bytes,sealed_json,read_sealed,sha256,canonical_hash
CONFIG=AREA/'configs/achieved_effect_calibration.json'
SOURCE_NAMES=('iteration_13/reports/achieved_effect_calibration.py','iteration_13/code/power_engine.py',
 'iteration_12/code/clock_simulator.py','iteration_5/code/empirical_process.py','iteration_5/code/kernels.py','iteration_6/code/checkpoint_io.py')
def utc():return datetime.now(timezone.utc).isoformat()
def rel(path):return Path(path).relative_to(ROOT).as_posix()
def require(test,message):
    if not test:raise ValueError(message)

def prepare(run):
    import numpy as np
    config=json.loads(CONFIG.read_text(encoding='utf-8'))
    require(config['schema_version']==1 and config['replications_per_cell']==12,'Wrong design')
    require(config['eta_grids']==[[.04,.065,.12,.18,.35,.55],[.03,.045,.08,.11,.20,.28]],'Unfrozen eta grid')
    require(config['horizons']==[24394.,73182.],'Wrong exposure')
    source=ROOT/config['baseline_protocol']['path']
    require(sha256(source)==config['baseline_protocol']['sha256'],'Frozen baseline protocol changed')
    protocol=json.loads(source.read_text(encoding='utf-8'))
    require(config['beta']==protocol['beta'] and config['base_null_fit']==protocol['base_null_fit'],'True generating law differs')
    settings=[];draws=[]
    for hi,T in enumerate(config['horizons']):
        for ei,eta in enumerate(config['eta_grids'][hi]):
            setting_id=f'h{1 if hi==0 else 3}_e{ei}'
            fit=config['base_null_fit']
            generated=dict(trigger=copy.deepcopy(fit['trigger']),stress=copy.deepcopy(fit['trigger']),
                           ratio=fit['ratio'],pars=list(fit['pars'])+[eta])
            settings.append(dict(id=setting_id,horizon=T,coordinate_horizon=T,beta=config['beta'],
                                 horizon_index=hi,eta_index=ei,eta=eta,generating_fit=generated))
            for replication in range(12):
                seed=int(np.random.SeedSequence([20261016,13,600,hi,ei,replication]).generate_state(1,dtype=np.uint64)[0])
                draws.append(dict(id=f'{setting_id}_r{replication:02d}',setting_id=setting_id,horizon_index=hi,eta_index=ei,
                                  replication=replication,seed=seed))
    require(len(draws)==144 and len({d['seed'] for d in draws})==144,'Duplicate or missing seeds')
    # Scan recorded JSON seed fields without parsing old scientific fits.
    # Exclude this new config/output area; seed generation is still pre-outcome.
    prior=[p for p in ROOT.glob('iteration_*') if p.is_dir() and p.name!='iteration_13']
    command=['rg','--no-heading','--no-filename','--glob','*.json','-o',r'"seed"\s*:\s*[0-9]+',*[str(p) for p in prior]]
    scan=subprocess.run(command,capture_output=True,text=True,timeout=30)
    require(scan.returncode in (0,1) and not scan.stderr,'Prior seed scan failed')
    import re,csv
    previous={int(x) for x in re.findall(r'\d+',scan.stdout)}
    for p in AREA.rglob('*.json'):
        if 'achieved_effect_calibration' in p.parts or p==CONFIG:continue
        previous.update(int(x) for x in re.findall(r'"seed"\s*:\s*([0-9]+)',p.read_text(encoding='utf-8')))
    for area in prior+[AREA]:
        for p in area.rglob('*.csv'):
            if 'achieved_effect_calibration' in p.parts:continue
            with p.open(encoding='utf-8-sig',newline='') as stream:
                reader=csv.DictReader(stream);keys=[k for k in (reader.fieldnames or []) if k.strip().lower()=='seed']
                if keys:
                    for row in reader:
                        for k in keys:
                            value=(row.get(k) or '').strip()
                            if value.isdecimal():previous.add(int(value))
    require(not ({d['seed'] for d in draws}&previous),'New seed overlaps recorded prior stream')
    sources={name:sha256(ROOT/name) for name in SOURCE_NAMES}
    authority=dict(config=config,config_path=rel(CONFIG),config_sha256=sha256(CONFIG),settings=settings,draws=draws,sources=sources,
        prior_seed_audit=dict(recorded_unique_numeric_seeds=len(previous),new_unique=144,overlap=0,
          prior_set_sha256=hashlib.sha256(json.dumps(sorted(previous),separators=(',',':')).encode()).hexdigest()),
        environment=dict(python=sys.version,executable=sys.executable,packages={n:importlib.metadata.version(n) for n in ('numpy','scipy','threadpoolctl')},native_threads=1))
    plan=dict(authority,plan_id=canonical_hash(authority),created_utc=utc())
    run.mkdir(parents=True,exist_ok=False)
    for name in sources:atomic_bytes(run/'source_snapshots'/name,(ROOT/name).read_bytes())
    atomic_bytes(run/'config_as_used.json',CONFIG.read_bytes());sealed_json(run/'plan.json',plan)
    return read_sealed(run/'plan.json')

def worker(run):
    if sys.stdin.buffer.read(1)!=b'1':return 4
    run=Path(run);plan=read_sealed(run/'plan.json')
    for name,digest in plan['sources'].items():require(sha256(ROOT/name)==digest,'Source changed before generation')
    from clock_simulator import simulate_fitted,ARRAY_KEYS
    from power_engine import fixed_history_metrics
    import numpy as np
    from threadpoolctl import threadpool_limits
    settings={s['id']:s for s in plan['settings']};limits=plan['config']['limits'];began=time.perf_counter()
    with threadpool_limits(limits=1):
        for case in plan['draws']:
            path=run/'cases'/case['id'];path.mkdir(parents=True,exist_ok=False);s=settings[case['setting_id']]
            start=time.perf_counter()
            try:
                generated=simulate_fitted(case['seed'],s['horizon'],s['beta'],s['generating_fit'],
                    max_events=limits['max_events'],max_proposals=limits['max_proposals'],seconds=limits['per_simulation_seconds'])
                arrays={k:generated[k] for k in ARRAY_KEYS}
                atomic_npz(path/'catalogue.npz',**arrays);atomic_json(path/'state.json',generated['checkpoint_state'],False)
                generation=dict(**case,plan_id=plan['plan_id'],complete=bool(generated['complete']),reason=generated['reason'],
                    n_events=len(arrays['times']),proposals=generated['proposals'],catalogue_sha256=sha256(path/'catalogue.npz'),
                    state_sha256=sha256(path/'state.json'),simulation_seconds=generated['elapsed_seconds'],
                    coarse_tie_count=generated['coarse_tie_count'],requires_precise_likelihood=generated['requires_precise_likelihood'],updated_utc=utc())
                sealed_json(path/'generation.json',generation)
                if generation['complete']:
                    if len(arrays['times']):
                        metric=fixed_history_metrics(arrays,s)
                        value=metric['mean_event_fixed_history_total_suppression']
                        require(math.isfinite(value) and 0<=value<=1,'Undefined/unbounded achieved effect')
                        require(value<=metric['mean_event_background_fraction']+1e-12,'Background ceiling violated')
                        sealed_json(path/'effect.json',dict(**case,plan_id=plan['plan_id'],complete=True,value=value,metric=metric,
                            generation_sha256=sha256(path/'generation.json'),elapsed_seconds=time.perf_counter()-start,updated_utc=utc()))
                print(json.dumps(dict(id=case['id'],complete=generation['complete'],n_events=generation['n_events'],seconds=time.perf_counter()-start)),flush=True)
            except BaseException as exc:
                sealed_json(path/'error.json',dict(**case,plan_id=plan['plan_id'],complete=False,error=type(exc).__name__+': '+str(exc),
                    traceback=traceback.format_exc(),elapsed_seconds=time.perf_counter()-start,updated_utc=utc()))
                print(json.dumps(dict(id=case['id'],error=type(exc).__name__+': '+str(exc))),flush=True)
                # Unexpected source/arithmetic/allocation errors remain fatal;
                # returned simulator resource censors are retained and continue.
                return 1
    for name,digest in plan['sources'].items():require(sha256(ROOT/name)==digest,'Source changed during generation')
    print(json.dumps(dict(event='all_planned_processed',elapsed_seconds=time.perf_counter()-began,torch_imported='torch' in sys.modules)),flush=True)
    return 0

def summarize(run,execution):
    import numpy as np
    run=Path(run);plan=read_sealed(run/'plan.json');outcomes=[]
    for case in plan['draws']:
        path=run/'cases'/case['id'];row=dict(case,status='not_completed',value=None,n_events=None)
        if (path/'generation.json').exists():
            generation=read_sealed(path/'generation.json')
            require(all(generation[k]==v for k,v in case.items()) and generation['plan_id']==plan['plan_id'],'Generation identity changed')
            require(generation['catalogue_sha256']==sha256(path/'catalogue.npz') and generation['state_sha256']==sha256(path/'state.json'),'Generation bytes changed')
            status=('empty_catalogue_undefined' if generation['n_events']==0 else 'generation_complete') if generation['complete'] else 'simulation_censored'
            row.update(status=status,n_events=generation['n_events'],reason=generation['reason'],
                       generation_sha256=sha256(path/'generation.json'),catalogue_sha256=generation['catalogue_sha256'])
        if (path/'effect.json').exists():
            effect=read_sealed(path/'effect.json')
            require(all(effect[k]==v for k,v in case.items()) and effect['plan_id']==plan['plan_id'],'Metric identity changed')
            require(row['status']=='generation_complete' and effect['generation_sha256']==row['generation_sha256'],'Metric generation differs')
            require(effect['complete'] and math.isfinite(effect['value']) and 0<=effect['value']<=1,'Invalid completed metric')
            row.update(status='metric_complete',value=effect['value'],effect_sha256=sha256(path/'effect.json'))
        if (path/'error.json').exists():row.update(status='error',error=read_sealed(path/'error.json')['error'])
        outcomes.append(row)
    cells=[]
    for setting in plan['settings']:
        selected=[x for x in outcomes if x['setting_id']==setting['id']];values=[x['value'] for x in selected if x['status']=='metric_complete'];unknown=12-len(values)
        cell=dict(setting_id=setting['id'],horizon=setting['horizon'],eta=setting['eta'],requested=12,complete=len(values),unknown=unknown,
                  mean=None,mcse=None,mean_accounting_bounds=[sum(values)/12,(sum(values)+unknown)/12],
                  event_counts=[x['n_events'] for x in selected],values=values,statuses={k:sum(x['status']==k for x in selected) for k in sorted({x['status'] for x in selected})})
        if not unknown:cell.update(mean=float(np.mean(values)),mcse=float(np.std(values,ddof=1)/math.sqrt(12)))
        cells.append(cell)
    interpolation=[]
    for horizon in plan['config']['horizons']:
        selected=[x for x in cells if x['horizon']==horizon];all_complete=all(not x['unknown'] for x in selected)
        monotone=all_complete and all(b['mean']>=a['mean'] for a,b in zip(selected[:-1],selected[1:]))
        for target in (.05,.1,.2):
            brackets=[]
            if all_complete:
                for a,b in zip(selected[:-1],selected[1:]):
                    if a['mean']<=target<=b['mean'] and b['mean']>a['mean']:
                        eta=a['eta']+(b['eta']-a['eta'])*(target-a['mean'])/(b['mean']-a['mean'])
                        brackets.append(dict(eta_pair=[a['eta'],b['eta']],mean_pair=[a['mean'],b['mean']],linear_starting_eta=eta))
            interpolation.append(dict(horizon=horizon,target=target,all_six_cells_complete=all_complete,sample_grid_monotone=monotone,
                adjacent_increasing_brackets=brackets,unique_starting_eta=brackets[0]['linear_starting_eta'] if len(brackets)==1 and monotone else None,
                scope='Interpolation starting value only; not independently validated target, power, monotonicity theorem or confidence interval'))
    summary=dict(plan_id=plan['plan_id'],created_utc=utc(),plan_sha256=sha256(run/'plan.json'),execution=execution,
        requested=144,completed_metrics=sum(x['status']=='metric_complete' for x in outcomes),all_metrics_complete=all(x['status']=='metric_complete' for x in outcomes),
        estimand=plan['config']['estimand'],mean_scope='Equal-weight catalogue event means; N=0 is undefined and retainedunknown with[0,1] bounds; not a pooled-event mean',
        precision_scope='MCSE=s/sqrt(12) only for complete fixed cells; rough small-Monte-Carlo precision; no Clopper-Pearson or normal CI',
        missingness_scope='Unknowns retain their original planned denominator and possibleY in[0,1]; bounds are accounting ranges, not confidence intervals',
        cells=cells,interpolation=interpolation,outcomes=outcomes)
    sealed_json(run/'summary.json',summary);return summary

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--worker',type=Path);parser.add_argument('--prepare-only',action='store_true');args=parser.parse_args()
    if args.worker:return worker(args.worker)
    began=time.perf_counter();started_utc=utc()
    run=AREA/'results/achieved_effect_calibration'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    plan=prepare(run)
    if args.prepare_only:print(str(run));return 0
    preparation_seconds=time.perf_counter()-began
    # Reserve five seconds inside the whole-parent budget for owned cleanup,
    # summary reconstruction and final artifact commits.
    deadline=began+180.;job=ChildJob();child=None;timedout=False;child_began=None
    try:
        with (run/'execution.log').open('xb') as log:
            require(time.perf_counter()<deadline-5.,'Preparation exhausted whole-parent budget before generation')
            child_began=time.perf_counter()
            child=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--worker',str(run)],stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
            job.assign(child);child.stdin.write(b'1');child.stdin.flush();child.stdin.close()
            try:exitcode=child.wait(timeout=max(0.,deadline-time.perf_counter()-5.))
            except subprocess.TimeoutExpired:timedout=True;child.kill();exitcode=child.wait(timeout=3)
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=3)
        job.close()
    execution=dict(started_utc=started_utc,ended_utc=utc(),parent_wall_seconds_before_summary=time.perf_counter()-began,preparation_seed_scan_seconds=preparation_seconds,
        owned_child_wall_seconds=time.perf_counter()-child_began if child_began is not None else 0.,exitcode=exitcode,
        whole_parent_budget_seconds=180,finalization_reserve_seconds=5,timed_out=timedout,source_sha256=sha256(Path(__file__)),no_fitting_or_gpu=True)
    sealed_json(run/'execution.json',execution);summary_began=time.perf_counter();result=summarize(run,execution)
    execution.update(total_parent_wall_seconds=time.perf_counter()-began,summary_seconds=time.perf_counter()-summary_began,ended_utc=utc())
    sealed_json(run/'execution.json',execution);result['execution']=execution;sealed_json(run/'summary.json',result)
    print(json.dumps(dict(run=str(run),complete=result['all_metrics_complete'],completed=result['completed_metrics'],**execution)))
    return 0 if result['all_metrics_complete'] and not timedout and exitcode==0 else 2

if __name__=='__main__':raise SystemExit(main())
