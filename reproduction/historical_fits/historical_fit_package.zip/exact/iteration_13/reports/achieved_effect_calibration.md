# New simulation-only achieved-effect calibration

The separately planned supplement completed **144/144 generations and effect metrics**,12 independent catalogues in each of12 cells, with exit0 and no censor, error, empty catalogue or projected-time tie. It used **81.903 seconds total parent wall time** within the declared180-second budget:4.821s preparation/seed scan,71.543s owned child, and5.529s final summary. No fit, GPU operation, rejection statistic or additional power replication was run. The worker confirms Torch was not imported.

This new grid was chosen after the primary pilot's achieved-effect summaries showed that targets on a single uninhibited reference history need not match effects averaged over new inhibited histories. It uses independent new seeds and does not alter or relabel the primary pilot's data, fitted outcomes, reference-target labels or power results. The supplied primary achieved-effect summaries, rather than LR/rejection counts, informed the new eta grid. This is a post-pilot supplement, not an additional prospectively chosen primary power contrast.

## Estimand and fixed design

For each generated nonempty catalogue, the metric is the equal-weight event mean of

`pB0_i*(1-exp(-eta*G_i))`, `pB0_i=B_i/(B_i+n*H_i)`,

using the known true generating beta, ratio, background, branching and shared kernels on that catalogue's realized predictable history. Cell means then give **equal weight to each catalogue**, rather than pooling all events across catalogues. Random N can be informative, so those two averages differ. The metric is a fixed-history intensity contrast; it is not a causal count reduction.

A complete N=0 generation would have an undefined event mean and remain an unknown contribution within[0,1], with no replacement or conditioning on N. Thus the design does not silently specify a unique unconditional population mean at N=0. No empty catalogue occurred. Reported complete-cell averages describe the observed finite experiment; an independently validated population target would require a declared population convention and further validation.

All parameters except eta and the exposure horizon retain the original known fitted-null generating law. The two horizons are24,394 and73,182 days, with coordinate2t/T-1 and unchanged day-scale kernels. The fixed grids were short `[.04,.065,.12,.18,.35,.55]` and long `[.03,.045,.08,.11,.20,.28]`,12 replications per cell. Fresh untruncated Exp(beta) marks were drawn only after acceptance. The original repaired precise-clock simulator and existing `fixed_history_metrics` were reused without modifying their source.

The config and all144 seed/parameter assignments were frozen before new outcomes. Seeds use `SeedSequence([20261016,13,600,horizon_index,eta_index,replication])` converted to uint64. All144 were unique and disjoint from4,291 recorded prior numeric JSON/CSV seed fields; this is the explicit recorded-field scan scope, not a claim about unrecorded random streams. The plan committed at07:32:25.651299Z; the first generation committed at07:32:27.004502Z. Returned caps would be retained without replacement. Guards were10s per simulation,100,000 events,5,000,000 proposals,one native thread and a single180s parent work budget including preparation, with a five-second finalization reserve. The actual summary took5.529s; total wall remained far below the budget.

## Actual means and simulation precision

Every cell has12 complete defined metrics. MCSE is sampleSD/sqrt(12), shown in **percentage points**. It is a rough small-simulation precision estimate. No Clopper-Pearson or normal confidence interval is supplied for this continuous mean. The defined effect is bounded in[0,1], hence has finite variance even though raw stress/productivity amplitudes can have infinite variance. That does not make12 replications a precision certificate.

| Horizon | Eta | Mean achieved effect | MCSE, percentage points | Event-count range |
|---|---:|---:|---:|---:|
|T|.040|2.938%|.098|549–981|
|T|.065|4.713%|.106|582–1,074|
|T|.120|7.792%|.133|548–753|
|T|.180|10.460%|.191|479–787|
|T|.350|16.455%|.238|429–530|
|T|.550|21.574%|.521|392–553|
|3T|.030|3.920%|.077|1,951–2,364|
|3T|.045|5.353%|.078|1,861–2,820|
|3T|.080|8.506%|.117|1,637–1,991|
|3T|.110|11.258%|.124|1,619–1,786|
|3T|.200|16.526%|.209|1,411–1,800|
|3T|.280|20.091%|.441|1,261–1,755|

The observed cell means increase on each grid; no monotonicity was imposed. All three desired percentages are bracketed by adjacent increasing means. This is not a theorem that the population mapping is monotone: changing eta also changes the generated history and counts.

If a cell had f unknown outcomes among12, its planned mean accounting range would be `[sum(knownY)/12,(sum(knownY)+f)/12]`; its mean estimate and MCSE would be withheld. These are possible-completion bounds, not confidence intervals. No incomplete catalogue was dropped or treated as zero.

## Future starting values only

Linear interpolation between the independently generated adjacent cell means gives:

| Desired mean effect | T starting eta | 3T starting eta |
|---|---:|---:|
|5%|.07013|.04130|
|10%|.16965|.09629|
|20%|.48850|.27797|

These are **future interpolation starting values**. No catalogue was generated at these exact interpolated values, no target was independently validated there, and no power was measured at them. Sampling error and interpolation curvature are not incorporated as an eta confidence interval. Future target validation or power requires a separately authorized fixed plan and fresh seeds. The old primary points retain their original declared estimand and labels.

## Checkpoints, reproduction and limits

Authoritative directory: `iteration_13/results/achieved_effect_calibration/20261016T073220937353Z/`. It contains the sealed plan/config, source snapshots,144 catalogue/state/generation checkpoints,144 completed metric records,execution log,execution record and terminal summary. Only completed generation/metric stages were committed; there are no periodic optimizer or full-run snapshots. All actual generations completed with no caps, so there is no unresolved supplement work to resume.

The command `python -B iteration_13/reports/achieved_effect_calibration.py` creates a **new exclusive output directory using the same144 fixed seeds**. It is a deterministic replay attempt, not144 additional independent replications. `--prepare-only` freezes a new plan without generation. The present CLI has no in-place resume command and makes no automatic source/cap/seed amendments. After an interruption, existing completed generation checkpoints remain available for explicit reviewed reuse; rerunning the default command does not consume them as a continuation. No rerun or automatic500-replication extension was launched.

Config SHA256: `92012fcc7c6e1749c8ff3cfb0f8671f0984db5ad496b0ce2f286a9ff63ace0c1`.

Script SHA256: `6234e101c84a5b2f3a8b3a2bb6b33f2de028179bc031d5fe9bc40963b1545c0d`.

Plan SHA256: `a5de0866bed3052d01f67a2c3a6d3a07175d2ed26b7d1c9edec0970fcd6b7013`.

Terminal summary SHA256: `808a7310555262b640b0a2bb8e55ef733595592fff3c1e54450f9ee78dffacb4`.

The source/config contract received C review before execution; actual terminal acceptance is a separate C audit. Original inputs, primary power-study plans/fits, and all preceding banks remain unchanged. The original manuscript data/code are unavailable, and this remains an independent diagnostic reconstruction.
