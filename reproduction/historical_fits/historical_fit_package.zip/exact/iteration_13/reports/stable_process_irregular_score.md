# A stable finite-mode process with an infinite-variance inhibition score

This is a restricted analytical corollary, derived separately from the power pilot. Its purpose is to distinguish first-moment stability from regularity of inference. It is not a novelty claim or an extension to nonlinear infinite memory.

Take one stress mode, a constant B>0 and k>0. At n=eta=0 let N be a rate-B Poisson process with fresh independent marks Q~Exp(beta), and let

\[
 dX_t=-kX_t\,dt+g(Q_t)\,dN_t,
 \qquad g(q)=\exp\{\gamma(q-1)\},
 \qquad \gamma<\beta\leq2\gamma.
\]

The ground process is non-explosive. Stress has finite first mark moment and infinite second mark moment. Construct a two-sided independently marked rate-B Poisson process on the whole real line. Its positive stationary shot noise is

\[
 X_t^\pi=\sum_{t_i\leq t}g(Q_i)e^{-k(t-t_i)},
 \qquad \mathrm E X_t^\pi=B\mathrm E g/k<\infty.
\]

Finite expectation of this nonnegative sum ensures it is finite almost surely. Coupling two solutions with identical future Poisson times and marks gives the exact difference

\[
 |X_t^x-X_t^y|=e^{-kt}|x-y|.
\]

Consequently the semigroup contracts the Wasserstein distance associated with absolute distance by e^{-kt}. It has the invariant law above and is unique among invariant probability laws with finite first moment. For deterministic x, coupling with an invariant initial state gives

\[
 W_1(\mathcal L(X_t^x),\pi)
 \leq e^{-kt}\mathrm E|x-X_0^\pi|\longrightarrow0.
\]

Thus the example has an explicit finite first-moment invariant law and convergence, not merely a finite-window count bound. No quadratic Lyapunov conclusion is asserted. Its second stress moment is infinite: retaining only marks in any finite past interval gives a Poisson sum with a positive coefficient bounded away from zero times a mark with infinite second moment.

Consider the inhibition family with the same state equation and predictable intensity B exp(-eta X_{t-}), eta>=0. At its boundary eta=0 the right likelihood score is

\[
 U_0(T)=-\int_0^T X_{t-}(dN_t-B\,dt).
\]

For this likelihood, the initial state X_0 (or its complete past history) is observed and conditioned upon. Average its conditional score under the fixed null invariant law and use the future Poisson construction independent of that state. On the event of no future points in [0,T], which has probability exp(-BT)>0,

\[
 U_0(T)=\frac{B}{k}(1-e^{-kT})X_0^\pi.
\]

This event is independent of X_0^pi. Hence E[U_0(T)^2]=infinity, although E|U_0(T)| is finite and the null state is stable in the first-moment sense above. Marginalizing an unobserved initial state gives a different score; it is not the displayed conditional score.

The same state process started from the known empty state X_0=0 converges in W_1 to this invariant law and has an infinite-variance score on every nonzero window. On the positive-probability event N(T)=1, its sole point is at S<T, the pre-event state is zero, and U_0(T)=g B(1-e^{-k(T-S)})/k. Given this Poisson event/time configuration the fresh mark remains independent and has infinite second moment. This also proves the score conclusion under known empty history, without observed stationary prehistory or an initial mixing law.

For this argument the initial law is held fixed when differentiating the conditional likelihood; no derivative of an eta-dependent invariant density is included. Such a density/initial-law score would be a different inferential formulation. The example does not imply infinite score variance at positive excitation or positive inhibition; the preceding restricted bounds give sufficient finite-moment regimes there. It also does not identify the stress kernel at eta=0 or provide a likelihood-ratio limit law.
