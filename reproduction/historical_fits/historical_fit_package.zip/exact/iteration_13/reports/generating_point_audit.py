"""Post-outcome likelihood witness scores only; no optimization or data draws."""
from pathlib import Path
import os
for _k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[_k]='1'
import sys
sys.dont_write_bytecode=True
import json,time,gc,traceback,multiprocessing as mp
ROOT=Path(__file__).resolve().parents[2];AREA=ROOT/'iteration_13';RUN=AREA/'results/pilot'
OUT=AREA/'results/generating_point_audit.json';PROGRESS=AREA/'results/generating_point_audit_progress.json'
sys.path.insert(0,str(AREA/'code'))
from power_engine import (prepare,setting_for,case_path,load_simulation,verify,read_sealed,
                         sealed_json,sha256,utc_now)
from checkpoint_io import ChildJob
GPU_SECONDS=180.;CPU_SECONDS=60.;TOL=1e-5


def save(value):sealed_json(OUT,dict(value,updated_utc=utc_now()))


def worker(ready):
    while not ready.wait(.1):
        if not mp.parent_process().is_alive():return
    began=time.perf_counter();value=dict(complete=False,scope='Post-outcome fixed-point scoring; no optimizer, no new simulated catalogues, no changes to saved fits/statistics',
        gpu_budget_seconds=GPU_SECONDS,cpu32_budget_seconds=CPU_SECONDS,gap_definition='candidate_NLL - selected_NLL; negative means candidate better',
        failure_threshold_strictly_below=-TOL,rows=[],cpu32_checks=[])
    try:
        import numpy as np
        import torch
        from threadpoolctl import threadpool_limits
        from cuda_history import CUDAHistory
        from paired_history import PairedHistory,cuda_history_class
        from empirical_process import EmpiricalHistory
        from kernels import KernelSpec
        plan=prepare(AREA/'configs/pilot.json',RUN);summary=read_sealed(RUN/'summary.json')
        if not summary['all_planned_validated']:raise ValueError('Pilot must be terminal and fully validated')
        cases=[c for c in plan['config']['draws'] if c['role']=='alternative']
        if len(cases)!=48:raise ValueError('Expected exactly48savedoutercatalogues')
        immutable={str(p.relative_to(ROOT)):sha256(p) for c in cases for p in case_path(RUN,c).iterdir() if p.is_file()}
        sources={str(p.relative_to(ROOT)):sha256(p) for p in (Path(__file__),ROOT/'iteration_5_performance/gpu/cuda_history.py',
            ROOT/'iteration_12/code/paired_history.py',ROOT/'iteration_5/code/empirical_process.py',ROOT/'iteration_5/code/kernels.py',
            ROOT/'iteration_5_performance/cpu/numexpr_objective.py',ROOT/'iteration_6/code/checkpoint_io.py')}
        value.update(plan_id=plan['plan_id'],plan_sha256=sha256(RUN/'plan.json'),sources=sources,input_hashes=immutable,
            candidate_beta_rule='Eachsavedbeta_refitted; keepgeneratinga,d,n,eta,ratio,kernels unchanged. This is a feasible fitted-family witness, not the exact DGP intensity when beta_hat differs.')
        save(value);sealed_json(PROGRESS,dict(stage='GPU16',started_perf=began))
        paired_cls=cuda_history_class();torch.set_num_threads(1);torch.cuda.init();torch.cuda.reset_peak_memory_stats()
        with threadpool_limits(limits=1):
            for case in cases:
                if time.perf_counter()-began>GPU_SECONDS:raise TimeoutError('GPU16audit180secondcap')
                start=time.perf_counter();sim,arrays,state=load_simulation(plan,case,RUN)
                fitted=read_sealed(case_path(RUN,case)/'fit.json');verify(fitted,plan,case)
                s=setting_for(plan,case);fit=s['generating_fit'];beta=float(1/arrays['excess'].mean())
                if beta!=fitted['beta_refitted']:raise ValueError('Saved refittedbeta differs')
                paired=fitted['paired_likelihood'];extra=dict(times_lo=arrays['times_lo'],event_gaps=arrays['event_gaps']) if paired else {}
                h=(paired_cls if paired else CUDAHistory)(arrays['times'],arrays['excess'],beta,s['horizon'],s['horizon'],
                    order=16,memory_limit_mb=24576.,**extra)
                candidate,grad=h.objective(fit['pars'],KernelSpec(**fit['trigger']),fit['ratio'],KernelSpec(**fit['stress']),True)
                torch.cuda.synchronize();best=fitted['fit']['best']
                gaps={name:float(candidate-best[name]['nll']) for name in ('ml_shared','ml_separate_scale')}
                if not np.isfinite([candidate,*gaps.values()]).all():raise FloatingPointError('Nonfinitewitnessscore')
                row=dict(id=case['id'],setting_id=case['setting_id'],n_events=len(arrays['times']),paired_likelihood=paired,
                    beta_refitted=beta,candidate_pars=fit['pars'],candidate_ratio=fit['ratio'],candidate_NLL=float(candidate),
                    selected_NLL={k:best[k]['nll'] for k in gaps},gaps=gaps,witness_beats_selected=any(g<-TOL for g in gaps.values()),
                    elapsed_seconds=time.perf_counter()-start,fit_sha256=sha256(case_path(RUN,case)/'fit.json'))
                value['rows'].append(row);del h,arrays;gc.collect();torch.cuda.empty_cache();save(value)
                print(json.dumps(dict(id=case['id'],event='GPU16scored',minimum_gap=min(gaps.values()))),flush=True)
            value['gpu_stage_seconds']=time.perf_counter()-began
            value['peak_cuda_allocated_bytes']=torch.cuda.max_memory_allocated()
            value['gpu_complete']=True
            first_short=next(c for c in cases if setting_for(plan,c)['horizon']==24394.)
            first_long=next(c for c in cases if setting_for(plan,c)['horizon']==73182.)
            selected=[first_short['id'],first_long['id']]
            worst=min(value['rows'],key=lambda r:min(r['gaps'].values()))
            if min(worst['gaps'].values())<-TOL and worst['id'] not in selected:selected.append(worst['id'])
            # CPU32 checks independently evaluate the candidate; saved winners
            # already passed their original CPU32 gates. No records are altered.
            cpu_started=time.perf_counter();sealed_json(PROGRESS,dict(stage='CPU32',started_perf=cpu_started))
            for name in selected:
                if time.perf_counter()-cpu_started>CPU_SECONDS:
                    value['cpu32_incomplete_reason']='CPU32cumulative60secondcap';break
                case=next(c for c in cases if c['id']==name);s=setting_for(plan,case);fit=s['generating_fit']
                sim,arrays,state=load_simulation(plan,case,RUN);fitted=read_sealed(case_path(RUN,case)/'fit.json')
                paired=fitted['paired_likelihood'];extra=dict(times_lo=arrays['times_lo'],event_gaps=arrays['event_gaps']) if paired else {}
                cpu=(PairedHistory if paired else EmpiricalHistory)(arrays['times'],arrays['excess'],fitted['beta_refitted'],s['horizon'],s['horizon'],
                    order=32,memory_limit_mb=26000.,**extra)
                candidate=float(cpu.objective(fit['pars'],KernelSpec(**fit['trigger']),fit['ratio'],KernelSpec(**fit['stress']),False))
                row=next(r for r in value['rows'] if r['id']==name)
                value['cpu32_checks'].append(dict(id=name,candidate_NLL=candidate,CPU32_minus_GPU16=candidate-row['candidate_NLL'],
                    gaps_vs_saved16={k:candidate-nll for k,nll in row['selected_NLL'].items()},
                    scope='IndependentCPU32candidatevsimmutable savedselectedGPU16scores; selectedCPU32gates already passed in originalpilot'))
                del cpu,arrays;gc.collect();save(value)
                print(json.dumps(dict(id=name,event='CPU32candidate_scored')),flush=True)
            value['cpu32_seconds']=time.perf_counter()-cpu_started
            if value['cpu32_seconds']>CPU_SECONDS:value['cpu32_incomplete_reason']='CPU32cumulative60secondcap'
        value.update(complete=True,all48_scored=len(value['rows'])==48,
            witness_count=sum(r['witness_beats_selected'] for r in value['rows']),
            minimum_gap=min(g for r in value['rows'] for g in r['gaps'].values()),
            passed_no_obvious_witness=not any(r['witness_beats_selected'] for r in value['rows']),
            elapsed_seconds=time.perf_counter()-began,
            inputs_byte_identical=all(sha256(ROOT/n)==digest for n,digest in immutable.items()))
        save(value)
    except BaseException as exc:
        traceback.print_exc();value.update(error=f'{type(exc).__name__}: {exc}',elapsed_seconds=time.perf_counter()-began);save(value);raise


def main():
    if OUT.exists():raise FileExistsError('Preservepreviousaudit; noautomaticreplay')
    context=mp.get_context('spawn');ready=context.Event();child=context.Process(target=worker,args=(ready,));job=ChildJob();began=time.perf_counter()
    try:
        child.start();job.assign(child);ready.set()
        while child.is_alive():
            child.join(.5)
            if time.perf_counter()-began>GPU_SECONDS+CPU_SECONDS+15:raise TimeoutError('Parent255secondcap')
            if PROGRESS.exists():
                state=read_sealed(PROGRESS);cap=GPU_SECONDS if state['stage']=='GPU16' else CPU_SECONDS
                if time.perf_counter()-state['started_perf']>cap:raise TimeoutError(state['stage']+'stagewallcap')
    except TimeoutError as exc:
        child.terminate();child.join(10)
        value=read_sealed(OUT) if OUT.exists() else dict(complete=False,rows=[])
        value.update(complete=False,parent_error=str(exc));save(value)
    finally:
        job.close()
        if child.is_alive():child.terminate();child.join(10)
    value=read_sealed(OUT);print(json.dumps(dict(complete=value.get('complete'),rows=len(value.get('rows',[])),
        passed=value.get('passed_no_obvious_witness'),exitcode=child.exitcode,parent_elapsed_seconds=time.perf_counter()-began)),flush=True)
    return 0 if child.exitcode==0 and value.get('complete') else 2


if __name__=='__main__':raise SystemExit(main())
