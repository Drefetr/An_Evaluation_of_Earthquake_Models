# Inhibition power pilot: complete

The pilot attempted the frozen 87 cases: 39 new longer-horizon null references and 48 inhibited alternatives (eight per cell). It has **87/87 validated cases**. Two independent effect-reference simulations and three timing fits precede it; the timing fits are excluded from every power denominator. The completed iteration-12 null bank supplies the matched short reference and the secondary 1,999-reference sensitivity. No observed earthquake catalogue was refitted or extended in this study.

Authoritative analysis: `iteration_13/results/analysis/2026-10-16T071947262917_0000/summary.json`, `outcomes.json`, and `power.csv`. This is **known-generating-law screening power conditional on frozen reference banks**, not the power of the original sample-specific fitted-null bootstrap. The nested audit was excluded by the predeclared cost rule and was not executed.

## Executed detection rates

| Setting | Reference target | Rejections/planned | Conditional estimate | Exact 95% interval | Unknown decisions | Complete counts: median [min,max] | Realised mean suppression |
|---|---:|---:|---:|---|---:|---|---:|
| h1_e05 | 5% | 0/8 | 0.0% | [0.0%, 36.9%] | 0 | 757 [607, 1076] | 3.8% |
| h1_e10 | 10% | 1/8 | 12.5% | [0.3%, 52.7%] | 0 | 634 [551, 777] | 7.0% |
| h1_e20 | 20% | 2/8 | 25.0% | [3.2%, 65.1%] | 0 | 532 [484, 911] | 13.7% |
| h3_e05 | 5% | 2/8 | 25.0% | [3.2%, 65.1%] | 0 | 1948 [1793, 3111] | 4.7% |
| h3_e10 | 10% | 5/8 | 62.5% | [24.5%, 91.5%] | 0 | 1828 [1672, 2199] | 9.1% |
| h3_e20 | 20% | 2/8 | 25.0% | [3.2%, 65.1%] | 0 | 1493 [1389, 1581] | 16.5% |

![Saved pilot figure](figures/power_pilot.png)

Each decision uses `(1+count(T_null>=T_outer))/40 <= 0.05`, with feedback statistic twice the fitted NLL difference between the no-inhibition model and separate-stress-scale alternative. All 39 selected references must validate. A missing calibration draw withholds every corresponding decision; unresolved outer draws remain in the denominator with accounting bounds rather than a success-only estimate. Exact binomial intervals are given only for complete outer cells, conditional on their shared fixed reference bank. They exclude threshold-bank and physical-model uncertainty. No multiple-comparison certification is made from these exploratory six cells.

The effect target is defined on the independent reference history, not as a promised long-run count reduction. The last column checks the same fixed-history functional on validated generated inhibited histories. These need not equal the targets because inhibition changes the history. The counts describe complete simulations; censored prefix lengths are kept separately in the machine-readable summary.

## Calibration precision sensitivity

| Short setting | Primary B39 rejections | Secondary B1999 rejections | Secondary conditional estimate |
|---|---:|---:|---:|
| h1_e05 | 0/8 | 0/8 | 0.0% |
| h1_e10 | 1/8 | 1/8 | 12.5% |
| h1_e20 | 2/8 | 2/8 | 25.0% |

The larger short bank is a prespecified secondary check. Selecting a favourable bank after seeing outcomes would invalidate the comparison. There is no matching 1,999-case longer bank in this pilot, so the secondary column is not a controlled horizon contrast.

## Generating effects and assumptions

| Independent reference | Events | Target | Frozen eta | Achieved reference effect |
|---|---:|---:|---:|---:|
| reference_h1 | 1100 | 5% | 0.048869243 | 5.000000000% |
| reference_h1 | 1100 | 10% | 0.108588675 | 10.000000000% |
| reference_h1 | 1100 | 20% | 0.283997429 | 20.000000000% |
| reference_h3 | 2024 | 5% | 0.039249215 | 5.000000000% |
| reference_h3 | 2024 | 10% | 0.083949319 | 10.000000000% |
| reference_h3 | 2024 | 20% | 0.196426404 | 20.000000000% |

The baseline law was fitted to 913 observed events but has a finite-window count upper bound of approximately 769.43; the 3× horizon bound is 2,308.29. Histories start empty. Counts remain random. We retain fitted a,d,n,beta, productivity ratio 0.7 and the shared finite-mixture kernel, while calibrating eta separately at each horizon. Holding normalized trend d fixed changes the physical trend slope; holding the reference percentage fixed changes eta. This is not a forecast of following exactly the same physical system for three times as long. The single reference path at each horizon is part of the conditional design; its variability is not propagated into power intervals.

Tripling synthetic exposure also does not represent lowering the real earthquake magnitude threshold. A lower-threshold catalogue changes mark normalization, triggering/inhibition histories, the observed background fraction and detection/missing-parent assumptions. These results cannot be converted directly into an M4/M4.5 catalogue requirement without that recalibration.

Every candidate fit estimates the same flexible background intercept/trend and performs the full 234-record/162-start search, including the declared failure-only numerical amendments and beta refitting. CPU32 selected likelihood differences must be strictly below 1e-4 and the nesting/finite/full-search gates must pass. Fresh heavy-tailed marks, original seeds and the precise accepted-event clock are retained, with paired likelihoods for projected ties. There is no event-count conditioning, mark truncation, event jitter or replacement draw.

After seeing the pilot outcomes, a separate numerical check scored all 48 alternatives at their generating continuous parameters and shared kernel/productivity grid point, using each dataset's fitted beta. These are feasible fitted-family witnesses, rather than exact generating intensities when fitted beta differs. None improved either saved inhibited-model winner; the smallest candidate-minus-selected NLL gap was 0.168947. Two preselected candidates also agreed with CPU32 within 1.82e-12. This excludes one specific missed-fit explanation and does not certify a global optimum. It changes no saved fits, test statistics or detection decisions. See `reports/generating_point_audit.md`.

## What the pilot can establish

The saved frequencies describe detectability at these six specified generating points under the known-law benchmark. Eight outer replications leave coarse sampling uncertainty: even 8/8 has a 95% lower binomial bound near 63%, and 0/8 has an upper bound near 37%. A point estimate above 80% does not certify 80% power, and a zero count is not zero true power. These cells cannot supply a universal earthquake-count requirement, establish absence of inhibition, or prove shared physical memory.

Expanded background fractions, different stress/triggering scales, finite-variance mark controls, realistic missing history/completeness and off-grid generators remain unexecuted power dimensions. The Omori–Utsu ETAS-type alternative triggering benchmark is also deferred in this power study; the full searches here refer to the declared finite-mixture candidate grid. Limiting mathematical/numerical controls were checked, which is a validation result rather than an empirical power result. No chi-square/Fisher approximation is used. A real fitted-bootstrap power study requires per-outer null fitting and nested simulation/refitting and separate validity/size assessment.

## Separate post-pilot achieved-effect calibration

After the primary pilot, we froze a new six-eta grid at each horizon, with 12 independent catalogue simulations at each eta (144 planned). Grid choice used the pilot's achieved-effect summaries, so this is explicitly a new post-pilot study. Its sources, true generating parameters and independent seed branch were saved before any new generation. It has **144/144 complete effect metrics**; execution exited 0 in 81.903s against a 180s whole-parent budget. No likelihood was fitted and no power statistic was computed.

| Horizon | Eta | Complete/planned | Mean achieved effect | MCSE (percentage points) | Unknown |
|---|---:|---:|---:|---:|---:|
| 1T | 0.040 | 12/12 | 2.94% | 0.10 | 0 |
| 1T | 0.065 | 12/12 | 4.71% | 0.11 | 0 |
| 1T | 0.120 | 12/12 | 7.79% | 0.13 | 0 |
| 1T | 0.180 | 12/12 | 10.46% | 0.19 | 0 |
| 1T | 0.350 | 12/12 | 16.45% | 0.24 | 0 |
| 1T | 0.550 | 12/12 | 21.57% | 0.52 | 0 |
| 3T | 0.030 | 12/12 | 3.92% | 0.08 | 0 |
| 3T | 0.045 | 12/12 | 5.35% | 0.08 | 0 |
| 3T | 0.080 | 12/12 | 8.51% | 0.12 | 0 |
| 3T | 0.110 | 12/12 | 11.26% | 0.12 | 0 |
| 3T | 0.200 | 12/12 | 16.53% | 0.21 | 0 |
| 3T | 0.280 | 12/12 | 20.09% | 0.44 | 0 |

The estimand is an equal-weight mean of catalogue event-mean fixed-history suppression, evaluated at true generating parameters. It is not a pooled-event mean or a causal count reduction. Empty catalogues have undefined event means and remain unknown, bounded between zero and one; censored/error records also retain their planned denominators. Complete-cell MCSE uses sample SD divided by the square root of 12. This is rough Monte Carlo precision for a bounded continuous quantity, not a binomial interval or a target-validation guarantee.

A literal unconditional population mean still requires an empty-catalogue convention. Its numerical impact here is bounded explicitly: before the first event the rate equals B(t), so `P(N(T)=0)=exp[-exp(a)*T*sinh(d)/d]`. The corresponding log10 probabilities are -166.487 and -499.460 at the two horizons. The range across any bounded zero-event extensions is at most that probability. This negligible ambiguity is retained formally rather than setting its probability to zero.

| Horizon | Desired average effect | Interpolated starting eta only |
|---|---:|---:|
| 1T | 5% | 0.070129 |
| 1T | 10% | 0.169651 |
| 1T | 20% | 0.488501 |
| 3T | 5% | 0.041304 |
| 3T | 10% | 0.096292 |
| 3T | 20% | 0.277965 |

Interpolation is reported only for a complete, monotonically ordered sample grid with a unique adjacent increasing bracket; no monotonicity was forced and no extrapolation is used. These values are **starting points for future independent validation**, not established population targets or power estimates. The primary six cells and their frozen labels above are unchanged. Saved authority: `iteration_13/results/achieved_effect_calibration/20261016T073220937353Z/plan.json` and `summary.json`; separate report: `reports/achieved_effect_calibration.md`.

## Supporting sensitivity and restricted score result

The two fixed uninhibited reference paths also support a separately validated local score-geometry calculation, performed before reading power outcomes. Projecting the eta direction onto only the background intercept, trend and triggering-strength directions leaves approximately 10.82% and 3.26% of its weighted squared norm on the two paths. This is descriptive evidence of nuisance overlap. The paths differ, and the calculation omits mark/kernel/productivity nuisance directions: it neither estimates expected Fisher information nor shows that more data reduce expected information or power. See `reports/reference_score_geometry.md` for scalar controls and order 16/32 refinement.

A new restricted derivation, cross-reviewed in `reviews/C_score_bound_review.md`, gives a useful correction to blanket heavy-tail intuition. For common positive stress/triggering parents, n>0, finite expected count and finite kernel-ratio integral, the eta-score bracket is bounded by `(Bmax²/n)*C_T*E[N(T)]*E[g²/kappa]`. Under exponential marks this weighted moment is finite when `(1+r)*beta > 2*gamma`, as it is here, despite infinite raw second mark-amplitude moments. A no-excitation/no-inhibition Poisson counterexample has an infinite eta-score second moment; at fixed positive eta an exponential damping bound regularizes this one score component. These are finite-horizon, fixed-kernel results, not full Fisher regularity, stationary stability, a CLT/Wilks theorem or bootstrap-validity proof. The derivation is new to this iteration; literature novelty has not been determined. Exact assumptions and proof are in `reports/restricted_score_bound.md`.

The companion `reports/stable_process_irregular_score.md` makes the stability connection explicit. A one-mode, finite-first-moment Poisson shot-noise state has a stationary law and a synchronous Wasserstein contraction, yet its boundary inhibition score can have infinite second moment. The score claim holds with observed initial state/full prehistory conditioned on, and a known-empty-history one-event argument gives the same obstruction. First-moment state stability therefore cannot by itself justify a regular likelihood boundary test.

## Execution, review and continuation

Recorded scientific execution sums to 2718.848s: 3.141s reference generation/calibration, 75.159s independent timing session, 2491.711s pilot sessions, 34.375s separate score geometry, 32.559s post-outcome fixed-point scoring and 81.903s separate achieved-effect calibration. Some work ran concurrently: this sum is conservative for elapsed scientific wall, excludes implementation/review wall time, and is not summed CPU time. The pilot hard cap was 3401.700s; records retain any cap/failure. Checkpoints commit completed simulation, full fit and CPU validation stages. No periodic optimizer snapshots are required.

One resource-protocol description was not implemented: there was no fresh host-free/GPU-free memory preflight or host-RSS monitoring. The implementation applies constructor-estimate, generation and time guards, records per-fit peak CUDA allocation, releases caches and retains unexpected OOM errors. Reserved-memory peaks are not measured. The missing free-memory checks and supplementary calibration metadata are explicitly recorded in `reviews/coordinator_deviations.md`; the frozen protocol was not silently edited to claim compliance.

The combined final tests and their actual stdout/exit status are recorded in `logs/final_validation.json`. Environment is in `environment.json`; the frozen plan and source snapshots are in `results/pilot/`. A's design/summary reviews and C's protocol/baseline/final-output reviews are separate work tracks within this project, not independent academic refereeing. The primary methods references and their retrieval limits are recorded in `reports/methodological_sources.md`.

Use `iteration_13/README.md` for status, exact resume and verification commands. `configs/future_oracle_template.json` is a disabled 500-outer-per-cell specification. Its execution budget, seed manifest and aggregation extension still require preparation and review; it is not an already launched or completed experiment. Full fitted-bootstrap power is a separate extension. No original thesis source is available: replacement text is supplied below without rebuilding the thesis or producing a PDF.
