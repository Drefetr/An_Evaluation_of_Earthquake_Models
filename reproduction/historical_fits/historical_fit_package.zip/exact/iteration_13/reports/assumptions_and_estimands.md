# Power-study assumptions and estimands

This is a new simulation study using the independent reconstruction. All preceding iteration outputs and supplied inputs remain read-only. The executed pilot protocol and sealed plans, rather than this explanatory map, define the exact seeds, limits and settings.

The primary diagnostic intensity is

\[
 \lambda_\eta(t\mid\mathcal H_{t-})
 =B(t)\exp\{-\eta G(t)\}+nH(t),
 \qquad B(t)=\exp\{a+d(2t/T-1)\}.
\]

Histories exclude the current event; marks are drawn fresh after acceptance. The positive finite exponential mixture is the generating kernel and the numerical fitting target. It approximates a Mittag--Leffler kernel but is not an exact infinite-memory implementation. Background intercept, trend, triggering and kernel nuisance parameters are re-estimated by the full declared search. Marks and counts are not truncated to achieve a chosen sample size. Resource censors remain explicit unknown outcomes.

For a fixed reference history and fixed background/triggering parameters, define

\[
 D_\eta(t)=\frac{\lambda_0(t)-\lambda_\eta(t)}{\lambda_0(t)}
 =\frac{B(t)}{B(t)+nH(t)}\{1-\exp[-\eta G(t)]\}.
\]

The user selected 5%, 10% and 20% suppression targets. Their exact averaging measure and reference histories must be specified in the protocol. In every case these are fixed-history intensity contrasts, not causal or long-run earthquake-count reductions. Calibration must solve for eta before power outcomes, check the fitted parameter box and the maximum attainable contrast, and retain an explicit failure if a target cannot be reached. In particular

\[
 0\leq D_\eta(t)\leq B(t)/(B(t)+nH(t)).
\]

More inhibition cannot suppress the additive triggering contribution directly. A strong background suppression can therefore produce a modest total-intensity contrast, especially in an intense cluster. Reference-history averages do not guarantee the same average on the subsequent inhibited histories.

The six primary settings cross the three targets with two observation horizons. Larger horizons allow random larger counts; they do not condition the process on a fixed event total. The baseline generating coefficients are fitted to the existing 913-event catalogue. This does not make its expected count 913. Its immigrant expectation divided by 1-n is a nominal long-run count approximation/upper envelope, not the exact empty-history finite-window mean. Executed results must show counts and exposure alongside power.

More precisely, the normalized nonnegative triggering kernel has cumulative mass at most one. Fresh marks give mean offspring productivity n. The bounded inhibited immigration term and the localized compensator identity therefore give E[N(T)] <= integral(B)/(1-n), using the dominating subcritical marked Hawkes construction to justify finite first moments and passage to the full horizon. This is a finite-horizon first-moment bound, not a stationary or second-moment assertion. With the declared fitted coefficients it is approximately 769.43 at T and 2,308.29 at 3T. This explains why neither event target should be described as an exact expected count of 913 or 2,739.

When eta is recalibrated at each horizon, the comparison holds the chosen observable reference contrast fixed, rather than a physical eta. With a normalized trend coordinate, fixing d also changes the physical trend slope when T changes. These settings therefore do not provide a universal forecast for following the same physical system for three times as long. Different background fractions, kernel separation and finite-variance controls are separate follow-up settings; their absence from the primary pilot limits generalization.

Tripling exposure is not a surrogate for lowering the real magnitude threshold. That changes the mark normalization, selected triggering/background relationship, detection and omitted-parent assumptions. A catalogue-threshold recommendation requires its own calibration and power setting, rather than translating this study's event counts directly.

For Q exponentially distributed with rate beta, normalized triggering productivity is proportional to exp(r beta Q). Its p-th moment is finite only when pr<1. Stress productivity is proportional to exp(cQ), c=0.75 log(10), and its p-th moment is finite only when beta>pc. Thus r<0.5 alone is not a finite-second-moment control for both histories. The proposed full control also requires beta>2c. No ordinary Fisher-information or chi-square likelihood-ratio approximation is assumed.

## Calibration and scope of power

A null reference bank can be reused only when the generating law, observation horizon, mark law, kernel approximation, missing-history convention and amended full estimator match the new null exactly. Sharing a catalogue size or fitted mechanism label does not suffice. Holding a reference bank fixed yields conditional operating characteristics for its resulting threshold. Outer-replication intervals do not include uncertainty due to choosing a new reference bank.

For an independent statistic and B independent reference statistics drawn from the same **known** null law, the rank (1 + number of reference statistics at least as large)/(B+1) is super-uniform under exchangeability; counting ties is conservative. A short proof orders the B+1 statistics and notes that at most floor(alpha(B+1)) positions can have rank at most alpha, with ties only removing admissible positions. This is a known-law Monte Carlo statement. Plug-in nuisance estimation does not make the observed and simulated statistics exchangeable under the unknown true law.

The first pilot can measure known-generating-law screening power and feasibility. It cannot automatically measure the power of the original per-catalogue fitted-null bootstrap. A nested audit, if executed, must actually refit each outer catalogue's null and simulate/refit its bootstrap samples; a small number checks the pipeline rather than estimating a stable power curve.

All planned outer identities remain in the ledger. With r rejected, f unresolved and N planned, the observed decision-frequency range is [r/N,(r+f)/N]; this is an accounting range, not a sampling confidence interval. A failed or missing calibration draw cannot silently be discarded to manufacture a threshold. Timing benchmarks are separate from inferential replications, and any replication-count reduction is frozen from measured cost before power outcomes.

For a complete independent outer sample, MCSE of a rejection proportion is sqrt(p(1-p)/R). At p=0.8 it is 0.08 for R=25 and approximately 0.0179 for R=500. These quantify simulation precision conditional on the setting and reference threshold, not uncertainty about the real earthquake process. The pilot is insufficient to certify a five-percent size or eighty-percent power requirement.

The post-pilot achieved-effect supplement is a separate simulation-only study. It averages catalogue event means at known generating parameters, giving equal weight to catalogues rather than pooling events. An empty catalogue has an undefined event mean and is retained as unknown in [0,1]; a unique unconditional population mean would require an explicit empty-case convention. Before the first event the rate is B(t), hence the empty probability is exp(-A), with A=exp(a) T sinh(d)/d and continuous limit A=exp(a)T when d=0. Any bounded empty-case extensions differ in their population means by at most exp(-A). Here A is 383.3495808 and 1150.0487424, or log10 empty probabilities -166.4866076 and -499.4598227. This formal ambiguity is negligible numerically and is not set to zero. All 144 actual catalogues were nonempty. The supplemental interpolation provides starting eta values, with no new target-validation or power result.

## Separate restricted score result

The later derivation in `restricted_score_bound.md`, cross-reviewed in `../reviews/C_score_bound_review.md`, establishes a finite-horizon second moment for the fixed eta-score component under positive excitation and a weighted moment E[g²/kappa], even when both raw second amplitude moments are infinite. With finite E[kappa], Cauchy--Schwarz also gives E[g] <= sqrt(E[kappa] E[g²/kappa]). This is consistent with first-moment stress assumptions, without restoring quadratic state moments. A no-excitation/no-inhibition Poisson example has finite first stress moments and an infinite eta-score second moment. Stability/count control, score moments, parameter identifiability and likelihood-ratio calibration are distinct questions. No ordinary Fisher/Wilks conclusion or power claim follows from the restricted score bound.
