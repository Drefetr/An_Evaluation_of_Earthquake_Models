# Source and validation inventory

Provenance and validation are distinct. Exact runtime source hashes, configuration and reference-file authorities are in each sealed execution plan; the review reports do not replace those records.

| Source | Provenance | Use and validation status |
|---|---|---|
| Supplied `inputs/` | Manuscript and unreviewed earlier note, retained unchanged | Evidence of what was written; no new original-code replication claim |
| `iteration_8/configs/production.json` and iteration-11 plan | Frozen earlier reconstruction and generating coefficients | Exact fitted-null law inherited, checked against the new protocol |
| `iteration_12/results/aggregate/2026-10-16T061247128773_0000/` | Completed earlier3998-case reconstruction | Its1999null cases independently re-audited in `reviews/C_baseline_reuse.json`; exact match required for reuse |
| `iteration_12/code/clock_simulator.py`, `paired_history.py`, `stable_history.py` | Independently reconstructed and previously tested numerical repairs | Imported read-only; pins and explicit projected/paired scoring retained |
| `configs/power_protocol.json` | New prospective scientific choices | Saved before effect generation/fits; targets, seed recipes and timing-only rules reviewed |
| `results/effect_calibration/` | New two-reference simulation/calibration evidence | Fresh fixed seeds; exact predictable-history target checks by separate scalar recurrences |
| `results/benchmark/` | New three-fit timing evidence | Independent seeds, excluded from power counts; timing-only allocation authority |
| `results/allocation.json`, `configs/pilot.json` | New pre-outcome execution choices | B39 andR8 fixed from measured cost; no outcome-based enlargement; nested0 |
| `results/pilot/` | New simulation, full fitting and CPU32 evidence | Terminal: all 87 new cases validated; seven retained primary-start failures accepted under frozen recovery rules |
| `code/power_summary.py` | New read-only statistical implementation | A/C source review and adversarial fixtures; no interim tally allowed |
| `reports/assumptions_and_estimands.md` | Explicit derivations/qualifications | Finite-horizon first-moment count bound and fixed-history contrast; no nonlinear stationary theorem |
| `reports/methodological_sources.md` | Externally sourced methods metadata/text | Retrieval scope recorded; source theory is not used to certify fitted-bootstrap validity |
| `results/analysis/2026-10-16T071947262917_0000/` and rendered report | Derived summaries/figure | All ranks, effect summaries, intervals and CSV fields separately audited against saved terminal outcomes |
| `results/reference_score_geometry.json` | Two-reference numerical score geometry | Independently checked scalar recurrence, derivative controls and quadrature refinement; descriptive pathwise geometry only |
| `reports/restricted_score_bound.md`, `stable_process_irregular_score.md` | New restricted derivations | Separate proof review; finite-horizon weighted-moment bound and explicit stable Poisson counterexample, no general regular-inference claim |
| `results/generating_point_audit.json` | New post-outcome diagnostic, 48 fixed candidate scores | No candidate improves selected inhibited fit; two CPU32 cross-checks; not a global optimization certificate |
| `configs/achieved_effect_calibration.json`, `results/achieved_effect_calibration/` | Separate post-pilot simulation-only calibration | All 144 metrics complete under its own frozen grid, independent seeds and budget; C's terminal seed/mean/MCSE/interpolation and sampled recurrence audit passed; original pilot labels and outcomes unchanged |

The original historical source code, frozen manuscript catalogue and thesis LaTeX remain unavailable. Existing newly sourced earthquake data are unchanged. This power study has not downloaded or fitted a lower-threshold earthquake sample, and no synthetic event-count increase should be interpreted as a catalogue-completeness result.
