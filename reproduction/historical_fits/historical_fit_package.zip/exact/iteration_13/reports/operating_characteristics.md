# Interpreting a bounded power pilot

The primary six scenarios vary three declared fixed-history total-intensity suppression targets across two exposure horizons. They measure a selected known-generating-law/reference-threshold rejection experiment. They do not estimate the power of every per-catalogue fitted-null bootstrap and do not give a universal event-count requirement or a physical causal suppression limit. Event totals stay random; an observed913-event fit need not generate a null mean of913.

The completed pilot used eight independent outer draws per scenario at both horizons after the prospective cost-only allocation, with39 null references per horizon. Conditional on the realized reference bank, even0/8 rejections has an exact two-sided95% upper limit of.36942, and8/8 has a lower limit of.63058. These wide intervals describe the precision of the actual pilot.

The original default was25 outer draws per scenario. That planned count would have worst-case Monte Carlo standard error.10 (at rejection probability.5), or.08 near.8. The following exact two-sided95% Clopper-Pearson intervals are precision illustrations, not actual power outcomes:

| Independent outer draws | Rejections | Fraction | Exact95% interval |
|---:|---:|---:|---:|
|8|0|0|[0,.36942]|
|8|8|1|[.63058,1]|
|25|0|0|[0,.13719]|
|25|20|.80|[.59296,.93169]|
|25|25|1|[.86281,1]|
|100|80|.80|[.70816,.87334]|
|400|320|.80|[.75739,.83810]|

These intervals were computed from binomial beta quantiles as precision illustrations, not power outcomes. They condition on a fixed valid reference decision rule. They exclude model uncertainty, calibration-bank uncertainty and dependence induced by any shared simulation construction. The known-law finite-rank guarantee is an unconditional exchangeability statement over a fresh independent reference bank and test statistic; conditioning on the realized reference bank changes that interpretation.

If r of N planned outer IDs reject and f remain unresolved, `[r/N,(r+f)/N]` is the accounting range of their possible final decision fraction. It is not a confidence interval. Complete-case filtering or treating a cap as a nonrejection changes the estimand. An unresolved null reference draw also prevents silently constructing the planned reference rule from a smaller bank.

The primary horizon comparison used the same preselected null-reference count of39 at both horizons;19 was the prospective cost fallback and was not used. Short references are the original fixed replication prefix, not a subset selected by statistic; all1999 short references are a secondary calibration-resolution sensitivity. With39 references the corrected rank step is.025; the nominal five-percent decision can use only the two lowest attainable ranks. With19 it would be.05 and only the lowest rank would reject. Fine threshold or power comparisons are therefore limited by null-reference precision as well as the actual eight-draw outer precision. Exact ties must retain the declared>=convention.

Timing benchmarks may set a common balanced outer replication count prospectively within the declared one-hour budget. Read only runtime/status, freeze the selected count before examining rejection summaries, retain every attempted identity and all incomplete stages, and report the actual common count. An outcome-driven decision to add replications until a desired answer appears is a different experiment.
