# Iteration 27 research report

The added shared-inhibition term did not improve retrospective predictive performance in this declared comparison. ML shared inhibition lost 17.622859 total logscore units to ML triggering alone across 612 events in three disjoint test periods; each period favored the noninhibited ML recipe. The Omori triggering benchmark gained 12.458121 units over ML triggering alone and 30.080980 over shared inhibition. This is useful negative predictive evidence about the fitted recipes. It does not refute physical inhibition, establish an intrinsic information limit, or show that a particular larger catalogue would be sufficient.

## What actually ran

The frozen protocol [observed_frozen.json](../configs/observed_frozen.json) was reviewed against 33 pinned sources by A and C before new outcomes. Three strict training prefixes contained 301, 504 and 659 events; their disjoint test blocks contained 203, 155 and 254. The evaluation boundaries were 1993-05-24T00:00Z, 2003-05-31T02:24Z, 2013-06-06T04:48Z and 2026-10-15T00:00Z. Five families shared training-only beta and the same absolute background coordinate. Beta=N_train/sum(excess_train) is a common mark-only plug-in, not a joint marked-intensity MLE. Continuously refined Omori and the finite ML kernel grid have different kernel flexibility; this compares the declared recipes, not equal-complexity families or causal mechanisms. All 477 records and 411 mandatory optimizer start lineages completed; all 411 primary calls succeeded on the observed data, with no recovery needed. All 30 selected train/test numerical controls passed. The maximum absolute order16/order32 score change was 2.27373675e-13; the maximum finer-spectrum change was 1.92035901e-05, both below the prespecified 1e-4 gate.

This used the archived independent iteration 5 GeoNet snapshot, not the unavailable original manuscript catalogue or code. The 913 selected events span the 1960-origin, end-exclusive 2026-10-15 window, T0=24,394 days. No new catalogue was downloaded. All periods and earlier results had already been inspected: these are exploratory rolling-origin comparisons, not untouched confirmation. Omori continuous refinement was motivated by earlier results and frozen here before the new fits.

## Predictive evidence

Scores include the random event count, all quiet intervals, full predictable compensator and the common training-beta mark density. Within each period that mark term cancels between candidates; its total across periods is 1.062451. Higher score is better. Tables below are generated from saved outputs, not transcribed from console impressions.

| Comparison (first minus second) | .50-.65 T0 | .65-.80 T0 | .80-1 T0 | Total |
|---|---:|---:|---:|---:|
| ml_shared minus ml_trigger | -16.517557 | -0.075277 | -1.030025 | -17.622859 |
| etas_omori minus ml_trigger | +3.106623 | +2.837708 | +6.513790 | +12.458121 |
| etas_omori minus ml_shared | +19.624181 | +2.912985 | +7.543815 | +30.080980 |
| ml_trigger minus poisson_loglinear | +486.664719 | +483.567449 | +514.802746 | +1485.034914 |

| Model | Total marked test logscore |
|---|---:|
| poisson_constant | -2516.930664 |
| poisson_loglinear | -2487.663098 |
| etas_omori | -990.170063 |
| ml_trigger | -1002.628184 |
| ml_shared | -1020.251044 |

The triggering recipes have much higher test scores than the simple Poisson recipes in these comparisons. The inhibition contribution is much smaller and fails to generalize from training. Shared inhibition retains an exact matched-null floor, so a nonnegative training gain is partly built into the fitting procedure and is not itself evidence of out-of-sample benefit.

| Origin | Training shared-minus-ML loglikelihood | Selected eta | Test shared-minus-ML logscore |
|---|---:|---:|---:|
| fold_50 | +2.731009 | 1.646714 | -16.517557 |
| fold_65 | +0.302486 | 0.211710 | -0.075277 |
| fold_80 | +0.143866 | 0.105254 | -1.030025 |

The first period accounts for most of the loss. The selected inhibition/background combination is unstable across origins, with training eta changing alongside the fitted background and selected productivity ratio. This is compatible with fitting instability or model mismatch; this experiment does not isolate their causal contributions or turn the changing eta values into a physical trend.

## Residual evidence and observation limitations

| Period | ML mean rescaled gap | ML N-minus-compensator | Shared KS | ML KS | Omori KS |
|---|---:|---:|---:|---:|---:|
| fold_50 | 0.6469 | +69.931 | 0.2220 | 0.1604 | 0.1616 |
| fold_65 | 1.5710 | -90.523 | 0.1157 | 0.1211 | 0.1536 |
| fold_80 | 1.0266 | -7.140 | 0.0819 | 0.0912 | 0.1059 |

The ML mean complete compensator gap changes from below one to above one across periods. Its realized N-minus-compensator changes sign. The rescaled-wait distributions show visible departures, especially in the earlier blocks. These are descriptive concerns, not calibrated rejection probabilities or proof that every candidate is false. Omori has the better total score but higher KS than ML in the last two periods; different diagnostics assess different aspects. Later shared KS values improve while its total score remains worse. No ordinary fitted-KS p-value, independent-fold standard error, or Poisson count p-value is supplied.

See [residual ECDFs](../results/observed_analysis/residual_ecdfs.png), [score plot](../results/observed_analysis/test_scores.png), [all fold scores](../results/observed_analysis/fold_scores.csv), and [realized compensator curves](../results/observed_analysis/compensator_curves.csv). Both PNGs were rendered and visually inspected for legibility. Terminal quiet exposure is retained in the likelihood and saved as right-censored exposure, excluded from completed-gap samples.

The source audit found seven magnitude labels and changing label composition, plus differences between already archived catalogue interfaces. This establishes source heterogeneity, not a causal explanation of the score result or incompleteness. M<5 parents, external events, spatial/fault structure and pre-1960 history are omitted. Temporal aggregation and native magnitude measurements remain modeling restrictions. See [A's source/assumption audit](A_adequacy_audit.md), [D's inventory](D_inventory.md), and [the assumption map](assumption_map.md).

## Bounded horizon feasibility

The separately frozen [horizon protocol](../configs/horizon_frozen.json) stipulates eta=0 versus eta=0.4885010300470942, with the earlier controlled-law generating parameters. This positive eta is not the observed fit's effect estimate. At most ten fresh 4T0 paths supply nested prefixes at T0,2T0,4T0. The physical calendar-time background slope stays fixed through an explicitly tested coordinate transformation; longer exposure changes trend-driven composition as well as event count. No counts are conditioned or equalized. Holding eta fixed does not hold a history-dependent intensity reduction or a long-run count reduction fixed across horizons.

| Law | Horizon/T0 | Complete fit pairs | Event-count range among completed pairs | Fit-pair time range (s) |
|---|---:|---:|---|---|
| null | 1 | 5/5 | 667-999 | 5.98-8.85 |
| null | 2 | 5/5 | 1841-2079 | 13.28-24.10 |
| null | 4 | 4/5 | 6531-6953 | 57.76-71.88 |
| inhibited | 1 | 5/5 | 428-472 | 3.62-5.62 |
| inhibited | 2 | 4/5 | 894-963 | 9.11-17.86 |
| inhibited | 4 | 4/5 | 2043-2277 | 17.53-25.01 |

Closed outcome: `{"complete": 27, "pending": 2, "resource_limited": 1}`; whole-pilot acceptance `False`; child blocking/stop reason `TimeoutError: Insufficient remaining validation reserve`; outer reason `child_nonzero`. The next case was not started because the remaining time could not preserve the declared validation reserve; exit2 records incomplete planned work. See [every planned case](../results/horizon_analysis/case_outcomes.csv), [machine-readable coverage](../results/horizon_analysis/summary.json), and [raw pilot artifacts](../results/horizon_pilot/). Completed case controls compare selected GPU16 and fresh CPU32 likelihoods and stable full-compensator contrasts. All extreme/censored/unattempted states remain in the ledger; missing decisions do not become non-rejections.

This pilot supplies beta, kernel and productivity ratio, estimating only a,d,n under the null and a,d,n,eta under the alternative. It is a restricted computational feasibility exercise, not the observed five-family search. Five null paths per horizon cannot calibrate a 5% add-one test (minimum rank 1/6). No detection decisions, power estimate, sufficient-N estimate or rigorous numerical upper bound is reported. Nested horizons are dependent. A longer-horizon power calculation would need separately matched null reference/validation banks and a declared nuisance/search policy; no such campaign was launched.

## Relation to the original research

Earlier finite-path score projection and matched-null ablation results already established nuisance overlap and practical fitting loss in stipulated model-correct experiments. Iteration 27 does not rediscover those findings or convert them to ensemble Fisher information. It adds observed predictive non-generalization and finite residual diagnostics. These leave model/observation misspecification, weak physical effects and data sufficiency as separate questions.

The present independent-background diagnostic law is distinct from the original physical loading model. First-moment finite-mode ergodicity, nonlinear infinite-memory stability, temporal predictive performance and physical shared-memory identification retain separate assumptions. Finite-variance/Fisher shortcuts are unavailable for productivity ratio .7/.8 under the exponential-mark law. Numerical agreement here validates selected finite histories/parameters; it is not a universal theorem or a proof about the ideal infinite kernel.

## Provenance, review and resources

The old iteration 5 current protocol differs from the old execution hash. A separately preserved reconstructed version matches that hash, but was not an immutable launch snapshot. All four relevant historical files are pinned separately; no old authority was repaired. [Source inventory](../logs/source_inventory.json) and [prelaunch gate](../reviews/execution_gate.json) preserve these distinctions.

D's preparation benchmark used synthetic data only: 477 records, 411 accepted slots, 412 raw calls, one failure-only retry, 30 passing controls, 419.817 seconds. The failed draft receipt is preserved with an explicit chronology qualification. Final D tests passed 11 cases; A's overlapping cross-check suite passed 28; C's metadata/publication checks passed 9; root's likelihood/clock/small-CUDA and reporting fixtures passed. These are actual collaborative reviews and checks, not independent academic refereeing; their test counts must not be added as independent evidence.

Observed owned execution charged 353.537253/1800 seconds; separate analysis charged 7.552672/60 seconds; horizon owned execution charged 574.836513/600 seconds. Each includes the stated one-second operational closure allowance, which is not a proved scheduler/filesystem bound. [Environment](../logs/environment.json) records Python 3.13, eight logical CPUs and GTX 970 / CUDA 12.6. Observed fitting used one native CPU thread; the horizon likelihood used FP64 CUDA and CPU32 controls. Raw source/payload hashes, elapsed times, exit status and owned process identities are saved. The six prior authority hashes and all pinned earlier sources must pass the final read-only verification.

## Decision and continuation

Do not escalate to a large sample-size campaign on the basis of this pilot. The most valuable next step is a bounded observation/spatial sensitivity audit of the first period's non-generalization, using the existing event locations and magnitude/source metadata, before choosing a more complex physical model or a substantially larger power study. It should ask whether temporal aggregation/background and observation conventions plausibly account for the loss, with the same train-only rules and comparable background flexibility. That audit is a proposal, not an automatically launched experiment.

If the horizon pilot is incomplete, the closed summary, every saved long-path NPZ plus RNG state and exact planned state list form the continuation checkpoint. Do not reuse the same output directory or silently extend the frozen 600-second budget. A subsequent protocol must name the retained artifacts, remaining case IDs, estimator and separate resource allowance; preserve all previously unresolved cases. Completion of this iteration means the bounded protocol has reached a documented closed outcome, not that a power study or physical identification is complete.

Exact executed commands and read-only checks are in [reproduction.md](reproduction.md). Original thesis source remains unavailable; [replacement text](../manuscript/replacement_sections.md) is explicitly labelled and no reconstructed original thesis is supplied.
